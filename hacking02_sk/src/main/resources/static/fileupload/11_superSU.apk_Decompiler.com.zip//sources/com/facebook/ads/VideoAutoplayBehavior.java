package com.facebook.ads;

import androidx.annotation.Keep;

@Deprecated
@Keep
public enum VideoAutoplayBehavior {
    DEFAULT,
    ON,
    OFF
}
