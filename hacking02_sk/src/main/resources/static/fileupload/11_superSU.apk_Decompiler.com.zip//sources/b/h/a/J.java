package b.h.a;

import android.transition.Transition;
import android.view.View;
import java.util.ArrayList;

class J implements Transition.TransitionListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Object f726a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ ArrayList f727b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Object f728c;
    public final /* synthetic */ ArrayList d;
    public final /* synthetic */ Object e;
    public final /* synthetic */ ArrayList f;
    public final /* synthetic */ L g;

    public J(L l, Object obj, ArrayList arrayList, Object obj2, ArrayList arrayList2, Object obj3, ArrayList arrayList3) {
        this.g = l;
        this.f726a = obj;
        this.f727b = arrayList;
        this.f728c = obj2;
        this.d = arrayList2;
        this.e = obj3;
        this.f = arrayList3;
    }

    public void onTransitionCancel(Transition transition) {
    }

    public void onTransitionEnd(Transition transition) {
        transition.removeListener(this);
    }

    public void onTransitionPause(Transition transition) {
    }

    public void onTransitionResume(Transition transition) {
    }

    public void onTransitionStart(Transition transition) {
        Object obj = this.f726a;
        if (obj != null) {
            this.g.a(obj, (ArrayList<View>) this.f727b, (ArrayList<View>) null);
        }
        Object obj2 = this.f728c;
        if (obj2 != null) {
            this.g.a(obj2, (ArrayList<View>) this.d, (ArrayList<View>) null);
        }
        Object obj3 = this.e;
        if (obj3 != null) {
            this.g.a(obj3, (ArrayList<View>) this.f, (ArrayList<View>) null);
        }
    }
}
