package b.h.a;

/* renamed from: b.h.a.d  reason: case insensitive filesystem */
class C0073d implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0076g f741a;

    public C0073d(C0076g gVar) {
        this.f741a = gVar;
    }

    public void run() {
        this.f741a.y();
    }
}
