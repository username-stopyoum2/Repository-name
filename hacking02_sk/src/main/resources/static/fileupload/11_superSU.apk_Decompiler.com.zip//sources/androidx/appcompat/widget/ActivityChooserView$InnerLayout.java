package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import b.b.f.xa;

public class ActivityChooserView$InnerLayout extends LinearLayout {

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f85a = {16842964};

    public ActivityChooserView$InnerLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        xa a2 = xa.a(context, attributeSet, f85a);
        setBackgroundDrawable(a2.b(0));
        a2.f496b.recycle();
    }
}
