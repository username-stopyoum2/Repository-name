package c.b.a.a.e;

import android.os.IInterface;

public interface i extends IInterface {
}
