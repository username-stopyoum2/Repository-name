package com.facebook.ads;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.facebook.ads";
    public static final String BUILD_TYPE = "releaseDL";
    public static final boolean DEBUG = Boolean.parseBoolean("false");
    public static final String VERSION_NAME = "5.11.0";
}
