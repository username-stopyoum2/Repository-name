package c.b.a.a.d.a;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

public final class c implements Callable<Long> {

    /* renamed from: a  reason: collision with root package name */
    public /* synthetic */ SharedPreferences f891a;

    /* renamed from: b  reason: collision with root package name */
    public /* synthetic */ String f892b;

    /* renamed from: c  reason: collision with root package name */
    public /* synthetic */ Long f893c;

    public c(SharedPreferences sharedPreferences, String str, Long l) {
        this.f891a = sharedPreferences;
        this.f892b = str;
        this.f893c = l;
    }

    public final /* synthetic */ Object call() {
        return Long.valueOf(this.f891a.getLong(this.f892b, this.f893c.longValue()));
    }
}
