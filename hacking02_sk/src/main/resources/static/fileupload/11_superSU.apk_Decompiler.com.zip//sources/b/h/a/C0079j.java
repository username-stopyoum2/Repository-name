package b.h.a;

/* renamed from: b.h.a.j  reason: case insensitive filesystem */
public class C0079j {

    /* renamed from: a  reason: collision with root package name */
    public final C0081l<?> f750a;

    public C0079j(C0081l<?> lVar) {
        this.f750a = lVar;
    }

    public void a() {
        this.f750a.e.m();
    }
}
