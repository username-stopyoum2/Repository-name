package androidx.appcompat.view.menu;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import b.b.e.a.k;
import b.b.e.a.o;
import b.b.e.a.t;
import b.b.e.a.u;
import b.b.f.xa;

public final class ExpandedMenuView extends ListView implements k.b, u, AdapterView.OnItemClickListener {

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f71a = {16842964, 16843049};

    /* renamed from: b  reason: collision with root package name */
    public k f72b;

    /* renamed from: c  reason: collision with root package name */
    public int f73c;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842868);
    }

    public ExpandedMenuView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        xa a2 = xa.a(context, attributeSet, f71a, i, 0);
        if (a2.f(0)) {
            setBackgroundDrawable(a2.b(0));
        }
        if (a2.f(1)) {
            setDivider(a2.b(1));
        }
        a2.f496b.recycle();
    }

    public void a(k kVar) {
        this.f72b = kVar;
    }

    public boolean a(o oVar) {
        return this.f72b.a((MenuItem) oVar, (t) null, 0);
    }

    public int getWindowAnimations() {
        return this.f73c;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        a((o) getAdapter().getItem(i));
    }
}
