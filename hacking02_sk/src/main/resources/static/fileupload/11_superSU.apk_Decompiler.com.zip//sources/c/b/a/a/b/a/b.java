package c.b.a.a.b.a;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public static Object f869a = new Object();

    /* renamed from: b  reason: collision with root package name */
    public static boolean f870b;

    /* renamed from: c  reason: collision with root package name */
    public static int f871c;

    public static void a(Context context) {
        synchronized (f869a) {
            if (!f870b) {
                f870b = true;
                try {
                    Bundle bundle = c.b.a.a.e.b.f900a.a(context).f899a.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData;
                    if (bundle != null) {
                        bundle.getString("com.google.app.id");
                        f871c = bundle.getInt("com.google.android.gms.version");
                    }
                } catch (PackageManager.NameNotFoundException e) {
                    Log.wtf("MetadataValueReader", "This should never happen.", e);
                }
            }
        }
    }
}
