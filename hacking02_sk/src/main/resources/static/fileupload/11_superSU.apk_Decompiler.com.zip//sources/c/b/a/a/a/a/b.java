package c.b.a.a.a.a;

import android.util.Log;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public final class b extends Thread {

    /* renamed from: a  reason: collision with root package name */
    public /* synthetic */ String f868a;

    public b(a aVar, String str) {
        this.f868a = str;
    }

    public final void run() {
        String valueOf;
        StringBuilder sb;
        String str;
        Exception exc;
        HttpURLConnection httpURLConnection;
        String str2 = this.f868a;
        try {
            httpURLConnection = (HttpURLConnection) new URL(str2).openConnection();
            int responseCode = httpURLConnection.getResponseCode();
            if (responseCode < 200 || responseCode >= 300) {
                StringBuilder sb2 = new StringBuilder(String.valueOf(str2).length() + 65);
                sb2.append("Received non-success response code ");
                sb2.append(responseCode);
                sb2.append(" from pinging URL: ");
                sb2.append(str2);
                Log.w("HttpUrlPinger", sb2.toString());
            }
            httpURLConnection.disconnect();
        } catch (IndexOutOfBoundsException e) {
            valueOf = String.valueOf(e.getMessage());
            sb = new StringBuilder(valueOf.length() + String.valueOf(str2).length() + 32);
            str = "Error while parsing ping URL: ";
            exc = e;
            sb.append(str);
            sb.append(str2);
            sb.append(". ");
            sb.append(valueOf);
            Log.w("HttpUrlPinger", sb.toString(), exc);
        } catch (IOException | RuntimeException e2) {
            valueOf = String.valueOf(e2.getMessage());
            sb = new StringBuilder(valueOf.length() + String.valueOf(str2).length() + 27);
            str = "Error while pinging URL: ";
            exc = e2;
            sb.append(str);
            sb.append(str2);
            sb.append(". ");
            sb.append(valueOf);
            Log.w("HttpUrlPinger", sb.toString(), exc);
        } catch (Throwable th) {
            httpURLConnection.disconnect();
            throw th;
        }
    }
}
