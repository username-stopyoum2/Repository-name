package com.facebook.ads;

import androidx.annotation.Keep;

@Keep
public enum VideoStartReason {
    NOT_STARTED,
    USER_STARTED,
    AUTO_STARTED
}
