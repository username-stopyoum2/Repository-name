package c.b.a.a.b;

import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;
import c.b.a.a.b.a.a;
import c.b.a.a.c.c;
import c.b.a.a.e.g;
import c.b.a.a.e.h;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

public abstract class d extends g implements a {

    /* renamed from: a  reason: collision with root package name */
    public int f877a;

    public d(byte[] bArr) {
        String str;
        String str2;
        attachInterface(this, "com.google.android.gms.common.internal.ICertData");
        if (bArr.length != 25) {
            int length = bArr.length;
            int length2 = bArr.length;
            boolean z = true;
            if (bArr.length == 0 || length2 <= 0 || length2 > bArr.length) {
                str = null;
            } else {
                StringBuilder sb = new StringBuilder((((length2 + 16) - 1) / 16) * 57);
                int i = length2;
                int i2 = 0;
                int i3 = 0;
                while (i > 0) {
                    if (i2 != 0) {
                        if (i2 == 8) {
                            str2 = " -";
                        }
                        sb.append(String.format(" %02X", new Object[]{Integer.valueOf(bArr[i3] & 255)}));
                        i--;
                        i2++;
                        if (i2 != 16 || i == 0) {
                            sb.append(10);
                            i2 = 0;
                        }
                        i3++;
                    } else if (length2 < 65536) {
                        str2 = String.format("%04X:", new Object[]{Integer.valueOf(i3)});
                    } else {
                        str2 = String.format("%08X:", new Object[]{Integer.valueOf(i3)});
                    }
                    sb.append(str2);
                    sb.append(String.format(" %02X", new Object[]{Integer.valueOf(bArr[i3] & 255)}));
                    i--;
                    i2++;
                    if (i2 != 16) {
                    }
                    sb.append(10);
                    i2 = 0;
                    i3++;
                }
                str = sb.toString();
            }
            String valueOf = String.valueOf(str);
            StringBuilder sb2 = new StringBuilder(valueOf.length() + 51);
            sb2.append("Cert hash data has incorrect length (");
            sb2.append(length);
            sb2.append("):\n");
            sb2.append(valueOf);
            Log.wtf("GoogleCertificates", sb2.toString(), new Exception());
            bArr = Arrays.copyOfRange(bArr, 0, 25);
            z = bArr.length != 25 ? false : z;
            int length3 = bArr.length;
            StringBuilder sb3 = new StringBuilder(55);
            sb3.append("cert hash data has incorrect length. length=");
            sb3.append(length3);
            String sb4 = sb3.toString();
            if (!z) {
                throw new IllegalArgumentException(String.valueOf(sb4));
            }
        }
        this.f877a = Arrays.hashCode(bArr);
    }

    public static byte[] a(String str) {
        try {
            return str.getBytes("ISO-8859-1");
        } catch (UnsupportedEncodingException e) {
            throw new AssertionError(e);
        }
    }

    public abstract byte[] b();

    public final c.b.a.a.c.a c() {
        return new c(b());
    }

    public final int d() {
        return this.f877a;
    }

    public boolean equals(Object obj) {
        if (obj != null && (obj instanceof a)) {
            try {
                d dVar = (d) ((a) obj);
                if (dVar.d() != this.f877a) {
                    return false;
                }
                return Arrays.equals(b(), (byte[]) c.a(new c(dVar.b())));
            } catch (RemoteException e) {
                Log.e("GoogleCertificates", "Failed to get Google certificates from remote", e);
            }
        }
        return false;
    }

    public int hashCode() {
        return this.f877a;
    }

    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        if (a(i, parcel, parcel2, i2)) {
            return true;
        }
        if (i == 1) {
            c.b.a.a.c.a c2 = c();
            parcel2.writeNoException();
            h.a(parcel2, (IInterface) c2);
            return true;
        } else if (i != 2) {
            return false;
        } else {
            int d = d();
            parcel2.writeNoException();
            parcel2.writeInt(d);
            return true;
        }
    }
}
