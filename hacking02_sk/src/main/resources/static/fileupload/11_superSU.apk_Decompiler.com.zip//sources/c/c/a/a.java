package c.c.a;

import android.util.Log;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAdListener;
import com.sahani2020.suCheckerRoot.MainActivity;

class a implements InterstitialAdListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ MainActivity f904a;

    public a(MainActivity mainActivity) {
        this.f904a = mainActivity;
    }

    public void onAdClicked(Ad ad) {
        Log.d(this.f904a.E, "Interstitial ad clicked!");
    }

    public void onAdLoaded(Ad ad) {
        Log.d(this.f904a.E, "Interstitial ad is loaded and ready to be displayed!");
        this.f904a.B.show();
    }

    public void onError(Ad ad, AdError adError) {
        String str = this.f904a.E;
        StringBuilder a2 = c.a.a.a.a.a("Interstitial ad failed to load: ");
        a2.append(adError.getErrorMessage());
        Log.e(str, a2.toString());
    }

    public void onInterstitialDismissed(Ad ad) {
        Log.e(this.f904a.E, "Interstitial ad dismissed.");
        this.f904a.D.loadAd();
    }

    public void onInterstitialDisplayed(Ad ad) {
        Log.e(this.f904a.E, "Interstitial ad displayed.");
    }

    public void onLoggingImpression(Ad ad) {
        Log.d(this.f904a.E, "Interstitial ad impression logged!");
    }
}
