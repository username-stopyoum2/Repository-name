package android.support.v4.media;

import a.a.a.b.c;
import android.os.Bundle;
import android.os.Parcelable;
import java.util.ArrayList;

public class MediaBrowserCompat$SearchResultReceiver extends c {

    /* renamed from: c  reason: collision with root package name */
    public final String f18c;
    public final Bundle d;

    public void a(int i, Bundle bundle) {
        a.a.a.a.c.a(bundle);
        if (i != 0 || bundle == null || !bundle.containsKey("search_results")) {
            String str = this.f18c;
            Bundle bundle2 = this.d;
            throw null;
        }
        Parcelable[] parcelableArray = bundle.getParcelableArray("search_results");
        if (parcelableArray != null) {
            ArrayList arrayList = new ArrayList();
            for (Parcelable parcelable : parcelableArray) {
                arrayList.add((MediaBrowserCompat$MediaItem) parcelable);
            }
        }
        String str2 = this.f18c;
        Bundle bundle3 = this.d;
        throw null;
    }
}
