package androidx.activity;

import b.a.d;
import b.h.a.u;
import b.j.e;
import b.j.f;
import b.j.h;
import b.j.i;
import java.util.ArrayDeque;
import java.util.Iterator;

public final class OnBackPressedDispatcher {

    /* renamed from: a  reason: collision with root package name */
    public final Runnable f49a;

    /* renamed from: b  reason: collision with root package name */
    public final ArrayDeque<d> f50b = new ArrayDeque<>();

    private class LifecycleOnBackPressedCancellable implements f, b.a.a {

        /* renamed from: a  reason: collision with root package name */
        public final e f51a;

        /* renamed from: b  reason: collision with root package name */
        public final d f52b;

        /* renamed from: c  reason: collision with root package name */
        public b.a.a f53c;

        public LifecycleOnBackPressedCancellable(e eVar, d dVar) {
            this.f51a = eVar;
            this.f52b = dVar;
            eVar.a(this);
        }

        public void a(h hVar, e.a aVar) {
            if (aVar == e.a.ON_START) {
                OnBackPressedDispatcher onBackPressedDispatcher = OnBackPressedDispatcher.this;
                d dVar = this.f52b;
                onBackPressedDispatcher.f50b.add(dVar);
                a aVar2 = new a(dVar);
                dVar.a(aVar2);
                this.f53c = aVar2;
            } else if (aVar == e.a.ON_STOP) {
                b.a.a aVar3 = this.f53c;
                if (aVar3 != null) {
                    aVar3.cancel();
                }
            } else if (aVar == e.a.ON_DESTROY) {
                cancel();
            }
        }

        public void cancel() {
            this.f51a.b(this);
            this.f52b.f146b.remove(this);
            b.a.a aVar = this.f53c;
            if (aVar != null) {
                aVar.cancel();
                this.f53c = null;
            }
        }
    }

    private class a implements b.a.a {

        /* renamed from: a  reason: collision with root package name */
        public final d f54a;

        public a(d dVar) {
            this.f54a = dVar;
        }

        public void cancel() {
            OnBackPressedDispatcher.this.f50b.remove(this.f54a);
            this.f54a.f146b.remove(this);
        }
    }

    public OnBackPressedDispatcher(Runnable runnable) {
        this.f49a = runnable;
    }

    public void a(h hVar, d dVar) {
        e a2 = hVar.a();
        if (((i) a2).f803b != e.b.DESTROYED) {
            dVar.f146b.add(new LifecycleOnBackPressedCancellable(a2, dVar));
        }
    }

    public void a() {
        Iterator<d> descendingIterator = this.f50b.descendingIterator();
        while (descendingIterator.hasNext()) {
            d next = descendingIterator.next();
            if (next.f145a) {
                u uVar = ((C0083n) next).f757c;
                uVar.i();
                if (uVar.n.f145a) {
                    uVar.b();
                    return;
                } else {
                    uVar.m.a();
                    return;
                }
            }
        }
        Runnable runnable = this.f49a;
        if (runnable != null) {
            runnable.run();
        }
    }
}
