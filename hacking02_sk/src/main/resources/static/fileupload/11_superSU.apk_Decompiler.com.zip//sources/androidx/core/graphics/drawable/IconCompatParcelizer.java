package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import b.o.b;
import b.o.c;

public class IconCompatParcelizer {
    public static IconCompat read(b bVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f116b = bVar.a(iconCompat.f116b, 1);
        byte[] bArr = iconCompat.d;
        if (bVar.a(2)) {
            c cVar = (c) bVar;
            int readInt = cVar.e.readInt();
            if (readInt < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[readInt];
                cVar.e.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.d = bArr;
        iconCompat.e = bVar.a(iconCompat.e, 3);
        iconCompat.f = bVar.a(iconCompat.f, 4);
        iconCompat.g = bVar.a(iconCompat.g, 5);
        iconCompat.h = (ColorStateList) bVar.a(iconCompat.h, 6);
        String str = iconCompat.j;
        if (bVar.a(7)) {
            str = bVar.c();
        }
        iconCompat.j = str;
        iconCompat.c();
        return iconCompat;
    }

    public static void write(IconCompat iconCompat, b bVar) {
        bVar.a(true, true);
        iconCompat.a(false);
        int i = iconCompat.f116b;
        if (-1 != i) {
            bVar.b(i, 1);
        }
        byte[] bArr = iconCompat.d;
        if (bArr != null) {
            bVar.b(2);
            c cVar = (c) bVar;
            if (bArr != null) {
                cVar.e.writeInt(bArr.length);
                cVar.e.writeByteArray(bArr);
            } else {
                cVar.e.writeInt(-1);
            }
        }
        Parcelable parcelable = iconCompat.e;
        if (parcelable != null) {
            bVar.b(parcelable, 3);
        }
        int i2 = iconCompat.f;
        if (i2 != 0) {
            bVar.b(i2, 4);
        }
        int i3 = iconCompat.g;
        if (i3 != 0) {
            bVar.b(i3, 5);
        }
        ColorStateList colorStateList = iconCompat.h;
        if (colorStateList != null) {
            bVar.b((Parcelable) colorStateList, 6);
        }
        String str = iconCompat.j;
        if (str != null) {
            bVar.b(7);
            ((c) bVar).e.writeString(str);
        }
    }
}
