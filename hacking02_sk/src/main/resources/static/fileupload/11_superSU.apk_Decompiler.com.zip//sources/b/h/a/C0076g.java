package b.h.a;

import android.animation.Animator;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import b.e.a.g;
import b.h.a.C0077h;
import b.h.a.u;
import b.j.e;
import b.j.h;
import b.j.i;
import b.j.n;
import b.j.u;
import b.j.v;
import java.lang.reflect.InvocationTargetException;
import java.util.UUID;

/* renamed from: b.h.a.g  reason: case insensitive filesystem */
public class C0076g implements ComponentCallbacks, View.OnCreateContextMenuListener, h, v, b.m.c {

    /* renamed from: a  reason: collision with root package name */
    public static final Object f744a = new Object();
    public boolean A;
    public boolean B;
    public boolean C;
    public boolean D;
    public boolean E = true;
    public boolean F;
    public ViewGroup G;
    public View H;
    public View I;
    public boolean J;
    public boolean K = true;
    public a L;
    public boolean M;
    public boolean N;
    public float O;
    public LayoutInflater P;
    public boolean Q;
    public e.b R;
    public i S;
    public Q T;
    public n<h> U;
    public b.m.b V;
    public int W;

    /* renamed from: b  reason: collision with root package name */
    public int f745b = 0;

    /* renamed from: c  reason: collision with root package name */
    public Bundle f746c;
    public SparseArray<Parcelable> d;
    public Boolean e;
    public String f = UUID.randomUUID().toString();
    public Bundle g;
    public C0076g h;
    public String i = null;
    public int j;
    public Boolean k = null;
    public boolean l;
    public boolean m;
    public boolean n;
    public boolean o;
    public boolean p;
    public boolean q;
    public int r;
    public u s;
    public C0081l t;
    public u u = new u();
    public C0076g v;
    public int w;
    public int x;
    public String y;
    public boolean z;

    /* renamed from: b.h.a.g$a */
    static class a {

        /* renamed from: a  reason: collision with root package name */
        public View f747a;

        /* renamed from: b  reason: collision with root package name */
        public Animator f748b;

        /* renamed from: c  reason: collision with root package name */
        public int f749c;
        public int d;
        public int e;
        public int f;
        public Object g = null;
        public Object h;
        public Object i;
        public Object j;
        public Object k;
        public Object l;
        public Boolean m;
        public Boolean n;
        public g o;
        public g p;
        public boolean q;
        public c r;
        public boolean s;

        public a() {
            Object obj = C0076g.f744a;
            this.h = obj;
            this.i = null;
            this.j = obj;
            this.k = null;
            this.l = obj;
        }
    }

    /* renamed from: b.h.a.g$b */
    public static class b extends RuntimeException {
        public b(String str, Exception exc) {
            super(str, exc);
        }
    }

    /* renamed from: b.h.a.g$c */
    interface c {
    }

    public C0076g() {
        new C0073d(this);
        this.R = e.b.RESUMED;
        this.U = new n<>();
        s();
    }

    @Deprecated
    public static C0076g a(Context context, String str, Bundle bundle) {
        try {
            C0076g gVar = (C0076g) C0080k.d(context.getClassLoader(), str).getConstructor(new Class[0]).newInstance(new Object[0]);
            if (bundle != null) {
                bundle.setClassLoader(gVar.getClass().getClassLoader());
                gVar.b(bundle);
            }
            return gVar;
        } catch (InstantiationException e2) {
            throw new b("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e2);
        } catch (IllegalAccessException e3) {
            throw new b("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e3);
        } catch (NoSuchMethodException e4) {
            throw new b("Unable to instantiate fragment " + str + ": could not find Fragment constructor", e4);
        } catch (InvocationTargetException e5) {
            throw new b("Unable to instantiate fragment " + str + ": calling Fragment constructor caused an exception", e5);
        }
    }

    public C0076g a(String str) {
        return str.equals(this.f) ? this : this.u.a(str);
    }

    public e a() {
        return this.S;
    }

    public void a(int i2) {
        if (this.L != null || i2 != 0) {
            f().d = i2;
        }
    }

    public void a(Animator animator) {
        f().f748b = animator;
    }

    public void a(Context context, AttributeSet attributeSet, Bundle bundle) {
        this.F = true;
        C0081l lVar = this.t;
        if ((lVar == null ? null : lVar.f752a) != null) {
            this.F = false;
            this.F = true;
        }
    }

    public void a(View view) {
        f().f747a = view;
    }

    public void a(boolean z2) {
        this.u.a(z2);
    }

    public boolean a(Menu menu) {
        boolean z2 = false;
        if (this.z) {
            return false;
        }
        if (this.D && this.E) {
            z2 = true;
        }
        return z2 | this.u.b(menu);
    }

    public boolean a(Menu menu, MenuInflater menuInflater) {
        boolean z2 = false;
        if (this.z) {
            return false;
        }
        if (this.D && this.E) {
            z2 = true;
        }
        return z2 | this.u.a(menu, menuInflater);
    }

    public void b(Bundle bundle) {
        u uVar = this.s;
        if (uVar != null) {
            if (uVar == null ? false : uVar.l()) {
                throw new IllegalStateException("Fragment already added and state has been saved");
            }
        }
        this.g = bundle;
    }

    public void b(boolean z2) {
        this.u.b(z2);
    }

    public final b.m.a c() {
        return this.V.f826b;
    }

    public void c(boolean z2) {
        f().s = z2;
    }

    public u d() {
        u uVar = this.s;
        if (uVar != null) {
            return uVar.I.d(this);
        }
        throw new IllegalStateException("Can't access ViewModels from detached fragment");
    }

    public void e() {
        a aVar = this.L;
        Object obj = null;
        if (aVar != null) {
            aVar.q = false;
            Object obj2 = aVar.r;
            aVar.r = null;
            obj = obj2;
        }
        if (obj != null) {
            u.f fVar = (u.f) obj;
            fVar.f781c--;
            if (fVar.f781c == 0) {
                fVar.f780b.r.o();
            }
        }
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    public final a f() {
        if (this.L == null) {
            this.L = new a();
        }
        return this.L;
    }

    public View g() {
        a aVar = this.L;
        if (aVar == null) {
            return null;
        }
        return aVar.f747a;
    }

    public Animator h() {
        a aVar = this.L;
        if (aVar == null) {
            return null;
        }
        return aVar.f748b;
    }

    public final int hashCode() {
        return super.hashCode();
    }

    public final C0082m i() {
        if (this.t != null) {
            return this.u;
        }
        throw new IllegalStateException(c.a.a.a.a.a("Fragment ", (Object) this, " has not been attached yet."));
    }

    public Context j() {
        C0081l lVar = this.t;
        if (lVar == null) {
            return null;
        }
        return lVar.f753b;
    }

    public Object k() {
        a aVar = this.L;
        if (aVar == null) {
            return null;
        }
        return aVar.g;
    }

    public void l() {
        a aVar = this.L;
        if (aVar != null) {
            g gVar = aVar.o;
        }
    }

    public Object m() {
        a aVar = this.L;
        if (aVar == null) {
            return null;
        }
        return aVar.i;
    }

    public int n() {
        a aVar = this.L;
        if (aVar == null) {
            return 0;
        }
        return aVar.d;
    }

    public int o() {
        a aVar = this.L;
        if (aVar == null) {
            return 0;
        }
        return aVar.e;
    }

    public void onConfigurationChanged(Configuration configuration) {
        this.F = true;
    }

    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        C0077h hVar;
        C0081l lVar = this.t;
        if (lVar == null) {
            hVar = null;
        } else {
            hVar = (C0077h) lVar.f752a;
        }
        if (hVar != null) {
            hVar.onCreateContextMenu(contextMenu, view, contextMenuInfo);
            return;
        }
        throw new IllegalStateException(c.a.a.a.a.a("Fragment ", (Object) this, " not attached to an activity."));
    }

    public void onLowMemory() {
        this.F = true;
    }

    public int p() {
        a aVar = this.L;
        if (aVar == null) {
            return 0;
        }
        return aVar.f;
    }

    public Object q() {
        a aVar = this.L;
        if (aVar == null) {
            return null;
        }
        return aVar.k;
    }

    public int r() {
        a aVar = this.L;
        if (aVar == null) {
            return 0;
        }
        return aVar.f749c;
    }

    public final void s() {
        this.S = new i(this);
        this.V = new b.m.b(this);
        if (Build.VERSION.SDK_INT >= 19) {
            this.S.a((b.j.g) new Fragment$2(this));
        }
    }

    public boolean t() {
        a aVar = this.L;
        if (aVar == null) {
            return false;
        }
        return aVar.s;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        a.a.a.a.c.a((Object) this, sb);
        sb.append(" (");
        sb.append(this.f);
        sb.append(")");
        if (this.w != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.w));
        }
        if (this.y != null) {
            sb.append(" ");
            sb.append(this.y);
        }
        sb.append('}');
        return sb.toString();
    }

    public final boolean u() {
        return this.r > 0;
    }

    public void v() {
    }

    public void w() {
        this.F = true;
        this.u.f();
    }

    public final View x() {
        View view = this.H;
        if (view != null) {
            return view;
        }
        throw new IllegalStateException(c.a.a.a.a.a("Fragment ", (Object) this, " did not return a View from onCreateView() or this was called before onCreateView()."));
    }

    public void y() {
        u uVar = this.s;
        if (uVar == null || uVar.t == null) {
            f().q = false;
        } else if (Looper.myLooper() != this.s.t.f754c.getLooper()) {
            this.s.t.f754c.postAtFrontOfQueue(new C0074e(this));
        } else {
            e();
        }
    }

    public void a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.u.m();
        boolean z2 = true;
        this.q = true;
        this.T = new Q();
        int i2 = this.W;
        this.H = i2 != 0 ? layoutInflater.inflate(i2, viewGroup, false) : null;
        if (this.H != null) {
            Q q2 = this.T;
            if (q2.f737a == null) {
                q2.f737a = new i(q2);
            }
            this.U.a(this.T);
            return;
        }
        if (this.T.f737a == null) {
            z2 = false;
        }
        if (!z2) {
            this.T = null;
            return;
        }
        throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
    }

    public LayoutInflater a(Bundle bundle) {
        C0081l lVar = this.t;
        if (lVar != null) {
            C0077h.a aVar = (C0077h.a) lVar;
            LayoutInflater cloneInContext = C0077h.this.getLayoutInflater().cloneInContext(C0077h.this);
            u uVar = this.u;
            uVar.k();
            a.a.a.a.c.b(cloneInContext, (LayoutInflater.Factory2) uVar);
            this.P = cloneInContext;
            return this.P;
        }
        throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
    }

    public void a(c cVar) {
        f();
        c cVar2 = this.L.r;
        if (cVar != cVar2) {
            if (cVar == null || cVar2 == null) {
                a aVar = this.L;
                if (aVar.q) {
                    aVar.r = cVar;
                }
                if (cVar != null) {
                    ((u.f) cVar).f781c++;
                    return;
                }
                return;
            }
            throw new IllegalStateException("Trying to set a replacement startPostponedEnterTransition on " + this);
        }
    }
}
