package b.n.a.a;

import a.a.a.a.c;
import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Xml;
import b.n.a.a.j;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class d extends h implements b {

    /* renamed from: b  reason: collision with root package name */
    public a f831b;

    /* renamed from: c  reason: collision with root package name */
    public Context f832c;
    public ArgbEvaluator d;
    public final Drawable.Callback e;

    private static class a extends Drawable.ConstantState {

        /* renamed from: a  reason: collision with root package name */
        public int f833a;

        /* renamed from: b  reason: collision with root package name */
        public j f834b;

        /* renamed from: c  reason: collision with root package name */
        public AnimatorSet f835c;
        public ArrayList<Animator> d;
        public b.d.b<Animator, String> e;

        public a(Context context, a aVar, Drawable.Callback callback, Resources resources) {
            Drawable.ConstantState constantState;
            if (aVar != null) {
                this.f833a = aVar.f833a;
                j jVar = aVar.f834b;
                if (jVar != null) {
                    Drawable drawable = jVar.f841a;
                    if (drawable == null || Build.VERSION.SDK_INT < 24) {
                        jVar.f843c.f853a = jVar.getChangingConfigurations();
                        constantState = jVar.f843c;
                    } else {
                        constantState = new j.h(drawable.getConstantState());
                    }
                    this.f834b = (j) (resources != null ? constantState.newDrawable(resources) : constantState.newDrawable());
                    j jVar2 = this.f834b;
                    jVar2.mutate();
                    this.f834b = jVar2;
                    this.f834b.setCallback(callback);
                    this.f834b.setBounds(aVar.f834b.getBounds());
                    this.f834b.g = false;
                }
                ArrayList<Animator> arrayList = aVar.d;
                if (arrayList != null) {
                    int size = arrayList.size();
                    this.d = new ArrayList<>(size);
                    this.e = new b.d.b<>(size);
                    for (int i = 0; i < size; i++) {
                        Animator animator = aVar.d.get(i);
                        Animator clone = animator.clone();
                        String str = aVar.e.get(animator);
                        clone.setTarget(this.f834b.f843c.f854b.q.get(str));
                        this.d.add(clone);
                        this.e.put(clone, str);
                    }
                    if (this.f835c == null) {
                        this.f835c = new AnimatorSet();
                    }
                    this.f835c.playTogether(this.d);
                }
            }
        }

        public int getChangingConfigurations() {
            return this.f833a;
        }

        public Drawable newDrawable() {
            throw new IllegalStateException("No constant state support for SDK < 24.");
        }

        public Drawable newDrawable(Resources resources) {
            throw new IllegalStateException("No constant state support for SDK < 24.");
        }
    }

    public d() {
        this((Context) null, (a) null, (Resources) null);
    }

    public d(Context context, a aVar, Resources resources) {
        this.d = null;
        this.e = new c(this);
        this.f832c = context;
        if (aVar != null) {
            this.f831b = aVar;
        } else {
            this.f831b = new a(context, aVar, this.e, resources);
        }
    }

    public static d a(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        d dVar = new d(context, (a) null, (Resources) null);
        dVar.inflate(resources, xmlPullParser, attributeSet, theme);
        return dVar;
    }

    public final void a(Animator animator) {
        ArrayList<Animator> childAnimations;
        if ((animator instanceof AnimatorSet) && (childAnimations = ((AnimatorSet) animator).getChildAnimations()) != null) {
            for (int i = 0; i < childAnimations.size(); i++) {
                a(childAnimations.get(i));
            }
        }
        if (animator instanceof ObjectAnimator) {
            ObjectAnimator objectAnimator = (ObjectAnimator) animator;
            String propertyName = objectAnimator.getPropertyName();
            if ("fillColor".equals(propertyName) || "strokeColor".equals(propertyName)) {
                if (this.d == null) {
                    this.d = new ArgbEvaluator();
                }
                objectAnimator.setEvaluator(this.d);
            }
        }
    }

    public void applyTheme(Resources.Theme theme) {
        Drawable drawable = this.f841a;
        if (drawable != null && Build.VERSION.SDK_INT >= 21) {
            drawable.applyTheme(theme);
        }
    }

    public boolean canApplyTheme() {
        Drawable drawable = this.f841a;
        if (drawable == null || Build.VERSION.SDK_INT < 21) {
            return false;
        }
        return drawable.canApplyTheme();
    }

    public void draw(Canvas canvas) {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            drawable.draw(canvas);
            return;
        }
        j jVar = this.f831b.f834b;
        Drawable drawable2 = jVar.f841a;
        if (drawable2 != null) {
            drawable2.draw(canvas);
        } else {
            jVar.copyBounds(jVar.j);
            if (jVar.j.width() > 0 && jVar.j.height() > 0) {
                ColorFilter colorFilter = jVar.e;
                if (colorFilter == null) {
                    colorFilter = jVar.d;
                }
                canvas.getMatrix(jVar.i);
                jVar.i.getValues(jVar.h);
                float abs = Math.abs(jVar.h[0]);
                float abs2 = Math.abs(jVar.h[4]);
                boolean z = true;
                float abs3 = Math.abs(jVar.h[1]);
                float abs4 = Math.abs(jVar.h[3]);
                if (!(abs3 == 0.0f && abs4 == 0.0f)) {
                    abs = 1.0f;
                    abs2 = 1.0f;
                }
                int min = Math.min(2048, (int) (((float) jVar.j.width()) * abs));
                int min2 = Math.min(2048, (int) (((float) jVar.j.height()) * abs2));
                if (min > 0 && min2 > 0) {
                    int save = canvas.save();
                    Rect rect = jVar.j;
                    canvas.translate((float) rect.left, (float) rect.top);
                    int i = Build.VERSION.SDK_INT;
                    if (!jVar.isAutoMirrored() || c.a((Drawable) jVar) != 1) {
                        z = false;
                    }
                    if (z) {
                        canvas.translate((float) jVar.j.width(), 0.0f);
                        canvas.scale(-1.0f, 1.0f);
                    }
                    jVar.j.offsetTo(0, 0);
                    jVar.f843c.b(min, min2);
                    if (!jVar.g) {
                        jVar.f843c.c(min, min2);
                    } else if (!jVar.f843c.a()) {
                        jVar.f843c.c(min, min2);
                        jVar.f843c.d();
                    }
                    jVar.f843c.a(canvas, colorFilter, jVar.j);
                    canvas.restoreToCount(save);
                }
            }
        }
        if (this.f831b.f835c.isStarted()) {
            invalidateSelf();
        }
    }

    public int getAlpha() {
        Drawable drawable = this.f841a;
        if (drawable == null) {
            j jVar = this.f831b.f834b;
            Drawable drawable2 = jVar.f841a;
            if (drawable2 == null) {
                return jVar.f843c.f854b.getRootAlpha();
            }
            if (Build.VERSION.SDK_INT >= 19) {
                return drawable2.getAlpha();
            }
            return 0;
        } else if (Build.VERSION.SDK_INT >= 19) {
            return drawable.getAlpha();
        } else {
            return 0;
        }
    }

    public int getChangingConfigurations() {
        Drawable drawable = this.f841a;
        return drawable != null ? drawable.getChangingConfigurations() : super.getChangingConfigurations() | this.f831b.f833a;
    }

    public ColorFilter getColorFilter() {
        Drawable drawable = this.f841a;
        if (drawable == null) {
            j jVar = this.f831b.f834b;
            Drawable drawable2 = jVar.f841a;
            if (drawable2 == null) {
                return jVar.e;
            }
            if (Build.VERSION.SDK_INT >= 21) {
                return drawable2.getColorFilter();
            }
            return null;
        } else if (Build.VERSION.SDK_INT >= 21) {
            return drawable.getColorFilter();
        } else {
            return null;
        }
    }

    public Drawable.ConstantState getConstantState() {
        Drawable drawable = this.f841a;
        if (drawable == null || Build.VERSION.SDK_INT < 24) {
            return null;
        }
        return new b(drawable.getConstantState());
    }

    public int getIntrinsicHeight() {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            return drawable.getIntrinsicHeight();
        }
        j jVar = this.f831b.f834b;
        Drawable drawable2 = jVar.f841a;
        return drawable2 != null ? drawable2.getIntrinsicHeight() : (int) jVar.f843c.f854b.k;
    }

    public int getIntrinsicWidth() {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            return drawable.getIntrinsicWidth();
        }
        j jVar = this.f831b.f834b;
        Drawable drawable2 = jVar.f841a;
        return drawable2 != null ? drawable2.getIntrinsicWidth() : (int) jVar.f843c.f854b.j;
    }

    public int getOpacity() {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            return drawable.getOpacity();
        }
        Drawable drawable2 = this.f831b.f834b.f841a;
        if (drawable2 != null) {
            return drawable2.getOpacity();
        }
        return -3;
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) {
        inflate(resources, xmlPullParser, attributeSet, (Resources.Theme) null);
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        TypedArray typedArray;
        Animator animator;
        String str;
        Resources resources2 = resources;
        XmlPullParser xmlPullParser2 = xmlPullParser;
        AttributeSet attributeSet2 = attributeSet;
        Resources.Theme theme2 = theme;
        Drawable drawable = this.f841a;
        if (drawable == null) {
            int eventType = xmlPullParser.getEventType();
            int depth = xmlPullParser.getDepth() + 1;
            for (int i = 1; eventType != i && (xmlPullParser.getDepth() >= depth || eventType != 3); i = 1) {
                if (eventType == 2) {
                    String name = xmlPullParser.getName();
                    XmlResourceParser xmlResourceParser = null;
                    if ("animated-vector".equals(name)) {
                        typedArray = c.a(resources2, theme2, attributeSet2, a.e);
                        int resourceId = typedArray.getResourceId(0, 0);
                        if (resourceId != 0) {
                            j a2 = j.a(resources2, resourceId, theme2);
                            a2.g = false;
                            a2.setCallback(this.e);
                            j jVar = this.f831b.f834b;
                            if (jVar != null) {
                                jVar.setCallback((Drawable.Callback) null);
                            }
                            this.f831b.f834b = a2;
                        }
                    } else if ("target".equals(name)) {
                        typedArray = resources2.obtainAttributes(attributeSet2, a.f);
                        String string = typedArray.getString(0);
                        int resourceId2 = typedArray.getResourceId(i, 0);
                        if (resourceId2 != 0) {
                            Context context = this.f832c;
                            if (context != null) {
                                if (Build.VERSION.SDK_INT >= 24) {
                                    animator = AnimatorInflater.loadAnimator(context, resourceId2);
                                } else {
                                    Resources resources3 = context.getResources();
                                    Resources.Theme theme3 = context.getTheme();
                                    try {
                                        xmlResourceParser = resources3.getAnimation(resourceId2);
                                        str = "Can't load animation resource ID #0x";
                                        try {
                                            animator = c.a(context, resources3, theme3, xmlResourceParser, Xml.asAttributeSet(xmlResourceParser), (AnimatorSet) null, 0, 1.0f);
                                            xmlResourceParser.close();
                                        } catch (XmlPullParserException e2) {
                                            e = e2;
                                            Resources.NotFoundException notFoundException = new Resources.NotFoundException(str + Integer.toHexString(resourceId2));
                                            notFoundException.initCause(e);
                                            throw notFoundException;
                                        } catch (IOException e3) {
                                            e = e3;
                                            Resources.NotFoundException notFoundException2 = new Resources.NotFoundException(str + Integer.toHexString(resourceId2));
                                            notFoundException2.initCause(e);
                                            throw notFoundException2;
                                        }
                                    } catch (XmlPullParserException e4) {
                                        e = e4;
                                        str = "Can't load animation resource ID #0x";
                                        Resources.NotFoundException notFoundException3 = new Resources.NotFoundException(str + Integer.toHexString(resourceId2));
                                        notFoundException3.initCause(e);
                                        throw notFoundException3;
                                    } catch (IOException e5) {
                                        e = e5;
                                        str = "Can't load animation resource ID #0x";
                                        Resources.NotFoundException notFoundException22 = new Resources.NotFoundException(str + Integer.toHexString(resourceId2));
                                        notFoundException22.initCause(e);
                                        throw notFoundException22;
                                    } catch (Throwable th) {
                                        if (xmlResourceParser != null) {
                                            xmlResourceParser.close();
                                        }
                                        throw th;
                                    }
                                }
                                animator.setTarget(this.f831b.f834b.f843c.f854b.q.get(string));
                                if (Build.VERSION.SDK_INT < 21) {
                                    a(animator);
                                }
                                a aVar = this.f831b;
                                if (aVar.d == null) {
                                    aVar.d = new ArrayList<>();
                                    this.f831b.e = new b.d.b<>();
                                }
                                this.f831b.d.add(animator);
                                this.f831b.e.put(animator, string);
                            } else {
                                typedArray.recycle();
                                throw new IllegalStateException("Context can't be null when inflating animators");
                            }
                        }
                    } else {
                        continue;
                    }
                    typedArray.recycle();
                }
                eventType = xmlPullParser.next();
            }
            a aVar2 = this.f831b;
            if (aVar2.f835c == null) {
                aVar2.f835c = new AnimatorSet();
            }
            aVar2.f835c.playTogether(aVar2.d);
        } else if (Build.VERSION.SDK_INT >= 21) {
            drawable.inflate(resources2, xmlPullParser2, attributeSet2, theme2);
        } else {
            drawable.inflate(resources2, xmlPullParser2, attributeSet2);
        }
    }

    public boolean isAutoMirrored() {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            return c.b(drawable);
        }
        j jVar = this.f831b.f834b;
        Drawable drawable2 = jVar.f841a;
        return drawable2 != null ? c.b(drawable2) : jVar.f843c.e;
    }

    public boolean isRunning() {
        Drawable drawable = this.f841a;
        return drawable != null ? ((AnimatedVectorDrawable) drawable).isRunning() : this.f831b.f835c.isRunning();
    }

    public boolean isStateful() {
        Drawable drawable = this.f841a;
        return drawable != null ? drawable.isStateful() : this.f831b.f834b.isStateful();
    }

    public Drawable mutate() {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            drawable.mutate();
        }
        return this;
    }

    public void onBoundsChange(Rect rect) {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            drawable.setBounds(rect);
        } else {
            this.f831b.f834b.setBounds(rect);
        }
    }

    public boolean onLevelChange(int i) {
        Drawable drawable = this.f841a;
        return drawable != null ? drawable.setLevel(i) : this.f831b.f834b.setLevel(i);
    }

    public boolean onStateChange(int[] iArr) {
        Drawable drawable = this.f841a;
        return drawable != null ? drawable.setState(iArr) : this.f831b.f834b.setState(iArr);
    }

    public void setAlpha(int i) {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            drawable.setAlpha(i);
            return;
        }
        j jVar = this.f831b.f834b;
        Drawable drawable2 = jVar.f841a;
        if (drawable2 != null) {
            drawable2.setAlpha(i);
        } else if (jVar.f843c.f854b.getRootAlpha() != i) {
            jVar.f843c.f854b.setRootAlpha(i);
            jVar.invalidateSelf();
        }
    }

    public void setAutoMirrored(boolean z) {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            c.a(drawable, z);
            return;
        }
        j jVar = this.f831b.f834b;
        Drawable drawable2 = jVar.f841a;
        if (drawable2 != null) {
            c.a(drawable2, z);
        } else {
            jVar.f843c.e = z;
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            drawable.setColorFilter(colorFilter);
            return;
        }
        j jVar = this.f831b.f834b;
        Drawable drawable2 = jVar.f841a;
        if (drawable2 != null) {
            drawable2.setColorFilter(colorFilter);
            return;
        }
        jVar.e = colorFilter;
        jVar.invalidateSelf();
    }

    public void setTint(int i) {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            c.a(drawable, i);
            return;
        }
        j jVar = this.f831b.f834b;
        Drawable drawable2 = jVar.f841a;
        if (drawable2 != null) {
            c.a(drawable2, i);
        } else {
            jVar.setTintList(ColorStateList.valueOf(i));
        }
    }

    public void setTintList(ColorStateList colorStateList) {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            c.a(drawable, colorStateList);
        } else {
            this.f831b.f834b.setTintList(colorStateList);
        }
    }

    public void setTintMode(PorterDuff.Mode mode) {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            c.a(drawable, mode);
            return;
        }
        j jVar = this.f831b.f834b;
        Drawable drawable2 = jVar.f841a;
        if (drawable2 != null) {
            c.a(drawable2, mode);
            return;
        }
        j.g gVar = jVar.f843c;
        if (gVar.d != mode) {
            gVar.d = mode;
            jVar.d = jVar.a(jVar.d, gVar.f855c, mode);
            jVar.invalidateSelf();
        }
    }

    public boolean setVisible(boolean z, boolean z2) {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            return drawable.setVisible(z, z2);
        }
        this.f831b.f834b.setVisible(z, z2);
        return super.setVisible(z, z2);
    }

    public void start() {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            ((AnimatedVectorDrawable) drawable).start();
        } else if (!this.f831b.f835c.isStarted()) {
            this.f831b.f835c.start();
            invalidateSelf();
        }
    }

    public void stop() {
        Drawable drawable = this.f841a;
        if (drawable != null) {
            ((AnimatedVectorDrawable) drawable).stop();
        } else {
            this.f831b.f835c.end();
        }
    }

    private static class b extends Drawable.ConstantState {

        /* renamed from: a  reason: collision with root package name */
        public final Drawable.ConstantState f836a;

        public b(Drawable.ConstantState constantState) {
            this.f836a = constantState;
        }

        public boolean canApplyTheme() {
            return this.f836a.canApplyTheme();
        }

        public int getChangingConfigurations() {
            return this.f836a.getChangingConfigurations();
        }

        public Drawable newDrawable() {
            d dVar = new d((Context) null, (a) null, (Resources) null);
            dVar.f841a = this.f836a.newDrawable();
            dVar.f841a.setCallback(dVar.e);
            return dVar;
        }

        public Drawable newDrawable(Resources resources) {
            d dVar = new d((Context) null, (a) null, (Resources) null);
            dVar.f841a = this.f836a.newDrawable(resources);
            dVar.f841a.setCallback(dVar.e);
            return dVar;
        }

        public Drawable newDrawable(Resources resources, Resources.Theme theme) {
            d dVar = new d((Context) null, (a) null, (Resources) null);
            dVar.f841a = this.f836a.newDrawable(resources, theme);
            dVar.f841a.setCallback(dVar.e);
            return dVar;
        }
    }
}
