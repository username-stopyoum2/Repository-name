package androidx.appcompat.app;

import android.content.Context;
import android.content.ContextWrapper;
import android.util.AttributeSet;
import android.view.View;
import b.d.b;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

public class AppCompatViewInflater {

    /* renamed from: a  reason: collision with root package name */
    public static final Class<?>[] f65a = {Context.class, AttributeSet.class};

    /* renamed from: b  reason: collision with root package name */
    public static final int[] f66b = {16843375};

    /* renamed from: c  reason: collision with root package name */
    public static final String[] f67c = {"android.widget.", "android.view.", "android.webkit."};
    public static final Map<String, Constructor<? extends View>> d = new b();
    public final Object[] e = new Object[2];

    private static class a implements View.OnClickListener {

        /* renamed from: a  reason: collision with root package name */
        public final View f68a;

        /* renamed from: b  reason: collision with root package name */
        public final String f69b;

        /* renamed from: c  reason: collision with root package name */
        public Method f70c;
        public Context d;

        public a(View view, String str) {
            this.f68a = view;
            this.f69b = str;
        }

        public void onClick(View view) {
            String str;
            Method method;
            if (this.f70c == null) {
                String str2 = this.f69b;
                for (Context context = this.f68a.getContext(); context != null; context = context instanceof ContextWrapper ? ((ContextWrapper) context).getBaseContext() : null) {
                    try {
                        if (!context.isRestricted() && (method = context.getClass().getMethod(this.f69b, new Class[]{View.class})) != null) {
                            this.f70c = method;
                            this.d = context;
                        }
                    } catch (NoSuchMethodException unused) {
                    }
                }
                int id = this.f68a.getId();
                if (id == -1) {
                    str = "";
                } else {
                    StringBuilder a2 = c.a.a.a.a.a(" with id '");
                    a2.append(this.f68a.getContext().getResources().getResourceEntryName(id));
                    a2.append("'");
                    str = a2.toString();
                }
                StringBuilder a3 = c.a.a.a.a.a("Could not find method ");
                a3.append(this.f69b);
                a3.append("(View) in a parent or ancestor Context for android:onClick attribute defined on view ");
                a3.append(this.f68a.getClass());
                a3.append(str);
                throw new IllegalStateException(a3.toString());
            }
            try {
                this.f70c.invoke(this.d, new Object[]{view});
            } catch (IllegalAccessException e) {
                throw new IllegalStateException("Could not execute non-public method for android:onClick", e);
            } catch (InvocationTargetException e2) {
                throw new IllegalStateException("Could not execute method for android:onClick", e2);
            }
        }
    }

    public final View a(Context context, String str, String str2) {
        String str3;
        Constructor<? extends U> constructor = d.get(str);
        if (constructor == null) {
            if (str2 != null) {
                try {
                    str3 = str2 + str;
                } catch (Exception unused) {
                    return null;
                }
            } else {
                str3 = str;
            }
            constructor = Class.forName(str3, false, context.getClassLoader()).asSubclass(View.class).getConstructor(f65a);
            d.put(str, constructor);
        }
        constructor.setAccessible(true);
        return (View) constructor.newInstance(this.e);
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View a(android.view.View r3, java.lang.String r4, android.content.Context r5, android.util.AttributeSet r6, boolean r7, boolean r8, boolean r9, boolean r10) {
        /*
            r2 = this;
            if (r7 == 0) goto L_0x0009
            if (r3 == 0) goto L_0x0009
            android.content.Context r3 = r3.getContext()
            goto L_0x000a
        L_0x0009:
            r3 = r5
        L_0x000a:
            r7 = 0
            if (r8 != 0) goto L_0x000f
            if (r9 == 0) goto L_0x0048
        L_0x000f:
            int[] r0 = b.b.j.View
            android.content.res.TypedArray r0 = r3.obtainStyledAttributes(r6, r0, r7, r7)
            if (r8 == 0) goto L_0x001e
            int r8 = b.b.j.View_android_theme
            int r8 = r0.getResourceId(r8, r7)
            goto L_0x001f
        L_0x001e:
            r8 = 0
        L_0x001f:
            if (r9 == 0) goto L_0x0032
            if (r8 != 0) goto L_0x0032
            int r8 = b.b.j.View_theme
            int r8 = r0.getResourceId(r8, r7)
            if (r8 == 0) goto L_0x0032
            java.lang.String r9 = "AppCompatViewInflater"
            java.lang.String r1 = "app:theme is now deprecated. Please move to using android:theme instead."
            android.util.Log.i(r9, r1)
        L_0x0032:
            r0.recycle()
            if (r8 == 0) goto L_0x0048
            boolean r9 = r3 instanceof b.b.e.c
            if (r9 == 0) goto L_0x0042
            r9 = r3
            b.b.e.c r9 = (b.b.e.c) r9
            int r9 = r9.f292a
            if (r9 == r8) goto L_0x0048
        L_0x0042:
            b.b.e.c r9 = new b.b.e.c
            r9.<init>(r3, r8)
            r3 = r9
        L_0x0048:
            if (r10 == 0) goto L_0x004e
            android.content.Context r3 = b.b.f.ua.a(r3)
        L_0x004e:
            int r8 = r4.hashCode()
            r9 = -1
            r10 = 1
            switch(r8) {
                case -1946472170: goto L_0x00e4;
                case -1455429095: goto L_0x00d9;
                case -1346021293: goto L_0x00ce;
                case -938935918: goto L_0x00c4;
                case -937446323: goto L_0x00ba;
                case -658531749: goto L_0x00af;
                case -339785223: goto L_0x00a5;
                case 776382189: goto L_0x009b;
                case 799298502: goto L_0x0090;
                case 1125864064: goto L_0x0086;
                case 1413872058: goto L_0x007a;
                case 1601505219: goto L_0x006f;
                case 1666676343: goto L_0x0064;
                case 2001146706: goto L_0x0059;
                default: goto L_0x0057;
            }
        L_0x0057:
            goto L_0x00ef
        L_0x0059:
            java.lang.String r8 = "Button"
            boolean r8 = r4.equals(r8)
            if (r8 == 0) goto L_0x00ef
            r8 = 2
            goto L_0x00f0
        L_0x0064:
            java.lang.String r8 = "EditText"
            boolean r8 = r4.equals(r8)
            if (r8 == 0) goto L_0x00ef
            r8 = 3
            goto L_0x00f0
        L_0x006f:
            java.lang.String r8 = "CheckBox"
            boolean r8 = r4.equals(r8)
            if (r8 == 0) goto L_0x00ef
            r8 = 6
            goto L_0x00f0
        L_0x007a:
            java.lang.String r8 = "AutoCompleteTextView"
            boolean r8 = r4.equals(r8)
            if (r8 == 0) goto L_0x00ef
            r8 = 9
            goto L_0x00f0
        L_0x0086:
            java.lang.String r8 = "ImageView"
            boolean r8 = r4.equals(r8)
            if (r8 == 0) goto L_0x00ef
            r8 = 1
            goto L_0x00f0
        L_0x0090:
            java.lang.String r8 = "ToggleButton"
            boolean r8 = r4.equals(r8)
            if (r8 == 0) goto L_0x00ef
            r8 = 13
            goto L_0x00f0
        L_0x009b:
            java.lang.String r8 = "RadioButton"
            boolean r8 = r4.equals(r8)
            if (r8 == 0) goto L_0x00ef
            r8 = 7
            goto L_0x00f0
        L_0x00a5:
            java.lang.String r8 = "Spinner"
            boolean r8 = r4.equals(r8)
            if (r8 == 0) goto L_0x00ef
            r8 = 4
            goto L_0x00f0
        L_0x00af:
            java.lang.String r8 = "SeekBar"
            boolean r8 = r4.equals(r8)
            if (r8 == 0) goto L_0x00ef
            r8 = 12
            goto L_0x00f0
        L_0x00ba:
            java.lang.String r8 = "ImageButton"
            boolean r8 = r4.equals(r8)
            if (r8 == 0) goto L_0x00ef
            r8 = 5
            goto L_0x00f0
        L_0x00c4:
            java.lang.String r8 = "TextView"
            boolean r8 = r4.equals(r8)
            if (r8 == 0) goto L_0x00ef
            r8 = 0
            goto L_0x00f0
        L_0x00ce:
            java.lang.String r8 = "MultiAutoCompleteTextView"
            boolean r8 = r4.equals(r8)
            if (r8 == 0) goto L_0x00ef
            r8 = 10
            goto L_0x00f0
        L_0x00d9:
            java.lang.String r8 = "CheckedTextView"
            boolean r8 = r4.equals(r8)
            if (r8 == 0) goto L_0x00ef
            r8 = 8
            goto L_0x00f0
        L_0x00e4:
            java.lang.String r8 = "RatingBar"
            boolean r8 = r4.equals(r8)
            if (r8 == 0) goto L_0x00ef
            r8 = 11
            goto L_0x00f0
        L_0x00ef:
            r8 = -1
        L_0x00f0:
            r0 = 0
            switch(r8) {
                case 0: goto L_0x0149;
                case 1: goto L_0x0143;
                case 2: goto L_0x013d;
                case 3: goto L_0x0137;
                case 4: goto L_0x012f;
                case 5: goto L_0x0127;
                case 6: goto L_0x0121;
                case 7: goto L_0x011b;
                case 8: goto L_0x0115;
                case 9: goto L_0x010d;
                case 10: goto L_0x0107;
                case 11: goto L_0x0101;
                case 12: goto L_0x00fb;
                case 13: goto L_0x00f5;
                default: goto L_0x00f4;
            }
        L_0x00f4:
            goto L_0x0155
        L_0x00f5:
            b.b.f.M r8 = new b.b.f.M
            r8.<init>(r3, r6)
            goto L_0x0151
        L_0x00fb:
            b.b.f.z r8 = new b.b.f.z
            r8.<init>(r3, r6)
            goto L_0x0151
        L_0x0101:
            b.b.f.y r8 = new b.b.f.y
            r8.<init>(r3, r6)
            goto L_0x0151
        L_0x0107:
            b.b.f.u r8 = new b.b.f.u
            r8.<init>(r3, r6)
            goto L_0x0151
        L_0x010d:
            b.b.f.i r8 = new b.b.f.i
            int r1 = b.b.a.autoCompleteTextViewStyle
            r8.<init>(r3, r6, r1)
            goto L_0x0151
        L_0x0115:
            b.b.f.m r8 = new b.b.f.m
            r8.<init>(r3, r6)
            goto L_0x0151
        L_0x011b:
            b.b.f.x r8 = new b.b.f.x
            r8.<init>(r3, r6)
            goto L_0x0151
        L_0x0121:
            b.b.f.l r8 = new b.b.f.l
            r8.<init>(r3, r6)
            goto L_0x0151
        L_0x0127:
            b.b.f.r r8 = new b.b.f.r
            int r1 = b.b.a.imageButtonStyle
            r8.<init>(r3, r6, r1)
            goto L_0x0151
        L_0x012f:
            b.b.f.D r8 = new b.b.f.D
            int r1 = b.b.a.spinnerStyle
            r8.<init>(r3, r6, r1)
            goto L_0x0151
        L_0x0137:
            b.b.f.q r8 = new b.b.f.q
            r8.<init>(r3, r6)
            goto L_0x0151
        L_0x013d:
            b.b.f.k r8 = new b.b.f.k
            r8.<init>(r3, r6)
            goto L_0x0151
        L_0x0143:
            b.b.f.t r8 = new b.b.f.t
            r8.<init>(r3, r6)
            goto L_0x0151
        L_0x0149:
            b.b.f.K r8 = new b.b.f.K
            r1 = 16842884(0x1010084, float:2.3693928E-38)
            r8.<init>(r3, r6, r1)
        L_0x0151:
            r2.a(r8, r4)
            goto L_0x0156
        L_0x0155:
            r8 = r0
        L_0x0156:
            if (r8 != 0) goto L_0x01b4
            if (r5 == r3) goto L_0x01b4
            java.lang.String r5 = "view"
            boolean r5 = r4.equals(r5)
            if (r5 == 0) goto L_0x0168
            java.lang.String r4 = "class"
            java.lang.String r4 = r6.getAttributeValue(r0, r4)
        L_0x0168:
            java.lang.Object[] r5 = r2.e     // Catch:{ Exception -> 0x01ad, all -> 0x01a5 }
            r5[r7] = r3     // Catch:{ Exception -> 0x01ad, all -> 0x01a5 }
            java.lang.Object[] r5 = r2.e     // Catch:{ Exception -> 0x01ad, all -> 0x01a5 }
            r5[r10] = r6     // Catch:{ Exception -> 0x01ad, all -> 0x01a5 }
            r5 = 46
            int r5 = r4.indexOf(r5)     // Catch:{ Exception -> 0x01ad, all -> 0x01a5 }
            if (r9 != r5) goto L_0x0199
            r5 = 0
        L_0x0179:
            java.lang.String[] r8 = f67c     // Catch:{ Exception -> 0x01ad, all -> 0x01a5 }
            int r8 = r8.length     // Catch:{ Exception -> 0x01ad, all -> 0x01a5 }
            if (r5 >= r8) goto L_0x0192
            java.lang.String[] r8 = f67c     // Catch:{ Exception -> 0x01ad, all -> 0x01a5 }
            r8 = r8[r5]     // Catch:{ Exception -> 0x01ad, all -> 0x01a5 }
            android.view.View r8 = r2.a(r3, r4, r8)     // Catch:{ Exception -> 0x01ad, all -> 0x01a5 }
            if (r8 == 0) goto L_0x018f
            java.lang.Object[] r3 = r2.e
            r3[r7] = r0
            r3[r10] = r0
            goto L_0x01b4
        L_0x018f:
            int r5 = r5 + 1
            goto L_0x0179
        L_0x0192:
            java.lang.Object[] r3 = r2.e
            r3[r7] = r0
            r3[r10] = r0
            goto L_0x01b3
        L_0x0199:
            android.view.View r3 = r2.a(r3, r4, r0)     // Catch:{ Exception -> 0x01ad, all -> 0x01a5 }
            java.lang.Object[] r4 = r2.e
            r4[r7] = r0
            r4[r10] = r0
            r8 = r3
            goto L_0x01b4
        L_0x01a5:
            r3 = move-exception
            java.lang.Object[] r4 = r2.e
            r4[r7] = r0
            r4[r10] = r0
            throw r3
        L_0x01ad:
            java.lang.Object[] r3 = r2.e
            r3[r7] = r0
            r3[r10] = r0
        L_0x01b3:
            r8 = r0
        L_0x01b4:
            if (r8 == 0) goto L_0x01de
            android.content.Context r3 = r8.getContext()
            boolean r4 = r3 instanceof android.content.ContextWrapper
            if (r4 == 0) goto L_0x01de
            int r4 = android.os.Build.VERSION.SDK_INT
            boolean r4 = b.e.h.s.i(r8)
            if (r4 != 0) goto L_0x01c7
            goto L_0x01de
        L_0x01c7:
            int[] r4 = f66b
            android.content.res.TypedArray r3 = r3.obtainStyledAttributes(r6, r4)
            java.lang.String r4 = r3.getString(r7)
            if (r4 == 0) goto L_0x01db
            androidx.appcompat.app.AppCompatViewInflater$a r5 = new androidx.appcompat.app.AppCompatViewInflater$a
            r5.<init>(r8, r4)
            r8.setOnClickListener(r5)
        L_0x01db:
            r3.recycle()
        L_0x01de:
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AppCompatViewInflater.a(android.view.View, java.lang.String, android.content.Context, android.util.AttributeSet, boolean, boolean, boolean, boolean):android.view.View");
    }

    public final void a(View view, String str) {
        if (view == null) {
            throw new IllegalStateException(AppCompatViewInflater.class.getName() + " asked to inflate view for <" + str + ">, but returned null");
        }
    }
}
