package c.b.a.a.b;

import a.a.a.a.c;
import android.content.Context;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import java.util.concurrent.atomic.AtomicBoolean;

public class j {

    /* renamed from: a  reason: collision with root package name */
    public static final AtomicBoolean f882a = new AtomicBoolean();

    static {
        new AtomicBoolean();
    }

    public static Context a(Context context) {
        try {
            return context.createPackageContext("com.google.android.gms", 3);
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    @Deprecated
    public static boolean a(Context context, int i) {
        if (i == 18) {
            return true;
        }
        if (i != 1) {
            return false;
        }
        if (c.a()) {
            for (PackageInstaller.SessionInfo appPackageName : context.getPackageManager().getPackageInstaller().getAllSessions()) {
                if ("com.google.android.gms".equals(appPackageName.getAppPackageName())) {
                    return true;
                }
            }
        }
        try {
            return context.getPackageManager().getApplicationInfo("com.google.android.gms", 8192).enabled;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:31:0x00a4, code lost:
        if (a.a.a.a.c.v.booleanValue() != false) goto L_0x00a6;
     */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x00d7  */
    /* JADX WARNING: Removed duplicated region for block: B:64:0x010d  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x0129  */
    /* JADX WARNING: Removed duplicated region for block: B:83:0x0142  */
    /* JADX WARNING: Removed duplicated region for block: B:89:0x0156  */
    /* JADX WARNING: Removed duplicated region for block: B:91:0x0174  */
    @java.lang.Deprecated
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static int b(android.content.Context r11) {
        /*
            java.lang.String r0 = "GooglePlayServicesUtil"
            android.content.pm.PackageManager r1 = r11.getPackageManager()
            android.content.res.Resources r2 = r11.getResources()     // Catch:{ Throwable -> 0x0010 }
            int r3 = c.b.a.a.a.common_google_play_services_unknown_issue     // Catch:{ Throwable -> 0x0010 }
            r2.getString(r3)     // Catch:{ Throwable -> 0x0010 }
            goto L_0x0015
        L_0x0010:
            java.lang.String r2 = "The Google Play services resources were not found. Check your project configuration to ensure that the resources are included."
            android.util.Log.e(r0, r2)
        L_0x0015:
            java.lang.String r2 = r11.getPackageName()
            java.lang.String r3 = "com.google.android.gms"
            boolean r2 = r3.equals(r2)
            java.lang.String r4 = " but found "
            r5 = 11020000(0xa826e0, float:1.5442309E-38)
            if (r2 != 0) goto L_0x0072
            java.util.concurrent.atomic.AtomicBoolean r2 = f882a
            boolean r2 = r2.get()
            if (r2 != 0) goto L_0x0072
            c.b.a.a.b.a.b.a(r11)
            int r2 = c.b.a.a.b.a.b.f871c
            if (r2 == 0) goto L_0x006a
            if (r2 != r5) goto L_0x0038
            goto L_0x0072
        L_0x0038:
            java.lang.IllegalStateException r11 = new java.lang.IllegalStateException
            java.lang.String r0 = "com.google.android.gms.version"
            int r1 = r0.length()
            int r1 = r1 + 290
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>(r1)
            java.lang.String r1 = "The meta-data tag in your app's AndroidManifest.xml does not have the right value.  Expected "
            r3.append(r1)
            r3.append(r5)
            r3.append(r4)
            r3.append(r2)
            java.lang.String r1 = ".  You must have the following declaration within the <application> element:     <meta-data android:name=\""
            r3.append(r1)
            r3.append(r0)
            java.lang.String r0 = "\" android:value=\"@integer/google_play_services_version\" />"
            r3.append(r0)
            java.lang.String r0 = r3.toString()
            r11.<init>(r0)
            throw r11
        L_0x006a:
            java.lang.IllegalStateException r11 = new java.lang.IllegalStateException
            java.lang.String r0 = "A required meta-data tag in your app's AndroidManifest.xml does not exist.  You must have the following declaration within the <application> element:     <meta-data android:name=\"com.google.android.gms.version\" android:value=\"@integer/google_play_services_version\" />"
            r11.<init>(r0)
            throw r11
        L_0x0072:
            int r2 = android.os.Build.VERSION.SDK_INT
            r6 = 24
            r7 = 0
            r8 = 1
            if (r2 < r6) goto L_0x007c
            r2 = 1
            goto L_0x007d
        L_0x007c:
            r2 = 0
        L_0x007d:
            if (r2 == 0) goto L_0x00a6
            java.lang.Boolean r2 = a.a.a.a.c.v
            if (r2 != 0) goto L_0x009e
            boolean r2 = a.a.a.a.c.a()
            if (r2 == 0) goto L_0x0097
            android.content.pm.PackageManager r2 = r11.getPackageManager()
            java.lang.String r6 = "cn.google"
            boolean r2 = r2.hasSystemFeature(r6)
            if (r2 == 0) goto L_0x0097
            r2 = 1
            goto L_0x0098
        L_0x0097:
            r2 = 0
        L_0x0098:
            java.lang.Boolean r2 = java.lang.Boolean.valueOf(r2)
            a.a.a.a.c.v = r2
        L_0x009e:
            java.lang.Boolean r2 = a.a.a.a.c.v
            boolean r2 = r2.booleanValue()
            if (r2 == 0) goto L_0x00d4
        L_0x00a6:
            java.lang.Boolean r2 = a.a.a.a.c.u
            if (r2 != 0) goto L_0x00ca
            int r2 = android.os.Build.VERSION.SDK_INT
            r6 = 20
            if (r2 < r6) goto L_0x00b2
            r2 = 1
            goto L_0x00b3
        L_0x00b2:
            r2 = 0
        L_0x00b3:
            if (r2 == 0) goto L_0x00c3
            android.content.pm.PackageManager r2 = r11.getPackageManager()
            java.lang.String r6 = "android.hardware.type.watch"
            boolean r2 = r2.hasSystemFeature(r6)
            if (r2 == 0) goto L_0x00c3
            r2 = 1
            goto L_0x00c4
        L_0x00c3:
            r2 = 0
        L_0x00c4:
            java.lang.Boolean r2 = java.lang.Boolean.valueOf(r2)
            a.a.a.a.c.u = r2
        L_0x00ca:
            java.lang.Boolean r2 = a.a.a.a.c.u
            boolean r2 = r2.booleanValue()
            if (r2 == 0) goto L_0x00d4
            r2 = 1
            goto L_0x00d5
        L_0x00d4:
            r2 = 0
        L_0x00d5:
            if (r2 != 0) goto L_0x0107
            java.lang.Boolean r2 = a.a.a.a.c.w
            if (r2 != 0) goto L_0x00fd
            android.content.pm.PackageManager r2 = r11.getPackageManager()
            java.lang.String r6 = "android.hardware.type.iot"
            boolean r2 = r2.hasSystemFeature(r6)
            if (r2 != 0) goto L_0x00f6
            android.content.pm.PackageManager r2 = r11.getPackageManager()
            java.lang.String r6 = "android.hardware.type.embedded"
            boolean r2 = r2.hasSystemFeature(r6)
            if (r2 == 0) goto L_0x00f4
            goto L_0x00f6
        L_0x00f4:
            r2 = 0
            goto L_0x00f7
        L_0x00f6:
            r2 = 1
        L_0x00f7:
            java.lang.Boolean r2 = java.lang.Boolean.valueOf(r2)
            a.a.a.a.c.w = r2
        L_0x00fd:
            java.lang.Boolean r2 = a.a.a.a.c.w
            boolean r2 = r2.booleanValue()
            if (r2 != 0) goto L_0x0107
            r2 = 1
            goto L_0x0108
        L_0x0107:
            r2 = 0
        L_0x0108:
            r6 = 0
            r9 = 9
            if (r2 == 0) goto L_0x011c
            java.lang.String r6 = "com.android.vending"
            r10 = 8256(0x2040, float:1.1569E-41)
            android.content.pm.PackageInfo r6 = r1.getPackageInfo(r6, r10)     // Catch:{ NameNotFoundException -> 0x0116 }
            goto L_0x011c
        L_0x0116:
            java.lang.String r11 = "Google Play Store is missing."
        L_0x0118:
            android.util.Log.w(r0, r11)
            return r9
        L_0x011c:
            r10 = 64
            android.content.pm.PackageInfo r10 = r1.getPackageInfo(r3, r10)     // Catch:{ NameNotFoundException -> 0x018b }
            c.b.a.a.b.k.a(r11)
            java.lang.String r11 = "Google Play services signature invalid."
            if (r2 == 0) goto L_0x0142
            c.b.a.a.b.d[] r2 = c.b.a.a.b.g.f881a
            c.b.a.a.b.d r2 = c.b.a.a.b.k.a(r6, r2)
            if (r2 != 0) goto L_0x0134
            java.lang.String r11 = "Google Play Store signature invalid."
            goto L_0x0118
        L_0x0134:
            c.b.a.a.b.d[] r6 = new c.b.a.a.b.d[r8]
            r6[r7] = r2
            c.b.a.a.b.d r2 = c.b.a.a.b.k.a(r10, r6)
            if (r2 != 0) goto L_0x014e
            android.util.Log.w(r0, r11)
            return r9
        L_0x0142:
            c.b.a.a.b.d[] r2 = c.b.a.a.b.g.f881a
            c.b.a.a.b.d r2 = c.b.a.a.b.k.a(r10, r2)
            if (r2 != 0) goto L_0x014e
            android.util.Log.w(r0, r11)
            return r9
        L_0x014e:
            r11 = 11020(0x2b0c, float:1.5442E-41)
            int r2 = r10.versionCode
            int r6 = r2 / 1000
            if (r6 >= r11) goto L_0x0174
            r11 = 77
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>(r11)
            java.lang.String r11 = "Google Play services out of date.  Requires "
            r1.append(r11)
            r1.append(r5)
            r1.append(r4)
            r1.append(r2)
            java.lang.String r11 = r1.toString()
            android.util.Log.w(r0, r11)
            r11 = 2
            return r11
        L_0x0174:
            android.content.pm.ApplicationInfo r11 = r10.applicationInfo
            if (r11 != 0) goto L_0x0184
            android.content.pm.ApplicationInfo r11 = r1.getApplicationInfo(r3, r7)     // Catch:{ NameNotFoundException -> 0x017d }
            goto L_0x0184
        L_0x017d:
            r11 = move-exception
            java.lang.String r1 = "Google Play services missing when getting application info."
            android.util.Log.wtf(r0, r1, r11)
            return r8
        L_0x0184:
            boolean r11 = r11.enabled
            if (r11 != 0) goto L_0x018a
            r11 = 3
            return r11
        L_0x018a:
            return r7
        L_0x018b:
            java.lang.String r11 = "Google Play services is missing."
            android.util.Log.w(r0, r11)
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.a.a.b.j.b(android.content.Context):int");
    }
}
