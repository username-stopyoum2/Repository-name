package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import b.o.b;
import b.o.c;
import b.o.d;

public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(b bVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        Object obj = remoteActionCompat.f112a;
        if (bVar.a(1)) {
            obj = bVar.d();
        }
        remoteActionCompat.f112a = (IconCompat) obj;
        remoteActionCompat.f113b = bVar.a(remoteActionCompat.f113b, 2);
        remoteActionCompat.f114c = bVar.a(remoteActionCompat.f114c, 3);
        remoteActionCompat.d = (PendingIntent) bVar.a(remoteActionCompat.d, 4);
        remoteActionCompat.e = bVar.a(remoteActionCompat.e, 5);
        remoteActionCompat.f = bVar.a(remoteActionCompat.f, 6);
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, b bVar) {
        bVar.a(false, false);
        IconCompat iconCompat = remoteActionCompat.f112a;
        bVar.b(1);
        bVar.a((d) iconCompat);
        CharSequence charSequence = remoteActionCompat.f113b;
        bVar.b(2);
        c cVar = (c) bVar;
        TextUtils.writeToParcel(charSequence, cVar.e, 0);
        CharSequence charSequence2 = remoteActionCompat.f114c;
        bVar.b(3);
        TextUtils.writeToParcel(charSequence2, cVar.e, 0);
        bVar.b((Parcelable) remoteActionCompat.d, 4);
        boolean z = remoteActionCompat.e;
        bVar.b(5);
        cVar.e.writeInt(z ? 1 : 0);
        boolean z2 = remoteActionCompat.f;
        bVar.b(6);
        cVar.e.writeInt(z2 ? 1 : 0);
    }
}
