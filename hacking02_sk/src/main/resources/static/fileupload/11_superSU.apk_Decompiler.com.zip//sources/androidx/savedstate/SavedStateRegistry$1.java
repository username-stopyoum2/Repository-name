package androidx.savedstate;

import b.j.d;
import b.j.e;
import b.j.h;
import b.m.a;

public class SavedStateRegistry$1 implements d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a f139a;

    public SavedStateRegistry$1(a aVar) {
        this.f139a = aVar;
    }

    public void a(h hVar, e.a aVar) {
        if (aVar == e.a.ON_START || aVar == e.a.ON_STOP) {
            a aVar2 = this.f139a;
        }
    }
}
