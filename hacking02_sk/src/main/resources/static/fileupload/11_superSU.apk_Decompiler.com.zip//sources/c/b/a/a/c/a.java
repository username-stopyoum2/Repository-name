package c.b.a.a.c;

import android.os.IBinder;
import android.os.IInterface;
import c.b.a.a.e.g;

public interface a extends IInterface {

    /* renamed from: c.b.a.a.c.a$a  reason: collision with other inner class name */
    public static abstract class C0021a extends g implements a {
        public C0021a() {
            attachInterface(this, "com.google.android.gms.dynamic.IObjectWrapper");
        }

        public static a a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamic.IObjectWrapper");
            return queryLocalInterface instanceof a ? (a) queryLocalInterface : new b(iBinder);
        }
    }
}
