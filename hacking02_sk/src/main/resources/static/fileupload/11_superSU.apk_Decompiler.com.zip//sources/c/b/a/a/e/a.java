package c.b.a.a.e;

import android.content.Context;
import android.content.pm.ApplicationInfo;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public Context f899a;

    public a(Context context) {
        this.f899a = context;
    }

    public final ApplicationInfo a(String str, int i) {
        return this.f899a.getPackageManager().getApplicationInfo(str, i);
    }
}
