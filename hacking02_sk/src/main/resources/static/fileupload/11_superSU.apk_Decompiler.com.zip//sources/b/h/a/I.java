package b.h.a;

import android.transition.Transition;
import android.view.View;
import java.util.ArrayList;

class I implements Transition.TransitionListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ View f724a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ ArrayList f725b;

    public I(L l, View view, ArrayList arrayList) {
        this.f724a = view;
        this.f725b = arrayList;
    }

    public void onTransitionCancel(Transition transition) {
    }

    public void onTransitionEnd(Transition transition) {
        transition.removeListener(this);
        this.f724a.setVisibility(8);
        int size = this.f725b.size();
        for (int i = 0; i < size; i++) {
            ((View) this.f725b.get(i)).setVisibility(0);
        }
    }

    public void onTransitionPause(Transition transition) {
    }

    public void onTransitionResume(Transition transition) {
    }

    public void onTransitionStart(Transition transition) {
    }
}
