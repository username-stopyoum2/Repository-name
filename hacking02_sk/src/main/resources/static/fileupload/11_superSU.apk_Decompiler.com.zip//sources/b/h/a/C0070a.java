package b.h.a;

import android.util.Log;
import b.h.a.B;
import b.h.a.C0076g;
import b.h.a.C0082m;
import b.h.a.u;
import c.a.a.a.a;
import java.io.PrintWriter;
import java.util.ArrayList;

/* renamed from: b.h.a.a  reason: case insensitive filesystem */
public final class C0070a extends B implements C0082m.a, u.e {
    public final u r;
    public boolean s;
    public int t = -1;

    public C0070a(u uVar) {
        this.r = uVar;
    }

    public void a() {
        int size = this.f701a.size();
        for (int i = 0; i < size; i++) {
            B.a aVar = this.f701a.get(i);
            C0076g gVar = aVar.f705b;
            if (gVar != null) {
                int i2 = this.f;
                int i3 = this.g;
                if (!(gVar.L == null && i2 == 0 && i3 == 0)) {
                    gVar.f();
                    C0076g.a aVar2 = gVar.L;
                    aVar2.e = i2;
                    aVar2.f = i3;
                }
            }
            switch (aVar.f704a) {
                case 1:
                    gVar.a(aVar.f706c);
                    this.r.a(gVar, false);
                    break;
                case 3:
                    gVar.a(aVar.d);
                    this.r.i(gVar);
                    break;
                case 4:
                    gVar.a(aVar.d);
                    this.r.d(gVar);
                    break;
                case 5:
                    gVar.a(aVar.f706c);
                    this.r.m(gVar);
                    break;
                case 6:
                    gVar.a(aVar.d);
                    this.r.b(gVar);
                    break;
                case 7:
                    gVar.a(aVar.f706c);
                    this.r.a(gVar);
                    break;
                case 8:
                    this.r.l(gVar);
                    break;
                case 9:
                    this.r.l((C0076g) null);
                    break;
                case 10:
                    this.r.a(gVar, aVar.h);
                    break;
                default:
                    StringBuilder a2 = a.a("Unknown cmd: ");
                    a2.append(aVar.f704a);
                    throw new IllegalArgumentException(a2.toString());
            }
            if (!(this.p || aVar.f704a == 1 || gVar == null)) {
                this.r.h(gVar);
            }
        }
        if (!this.p) {
            u uVar = this.r;
            uVar.a(uVar.s, true);
        }
    }

    public void a(int i) {
        if (this.h) {
            if (u.f770c) {
                Log.v("FragmentManager", "Bump nesting in " + this + " by " + i);
            }
            int size = this.f701a.size();
            for (int i2 = 0; i2 < size; i2++) {
                B.a aVar = this.f701a.get(i2);
                C0076g gVar = aVar.f705b;
                if (gVar != null) {
                    gVar.r += i;
                    if (u.f770c) {
                        StringBuilder a2 = a.a("Bump nesting of ");
                        a2.append(aVar.f705b);
                        a2.append(" to ");
                        a2.append(aVar.f705b.r);
                        Log.v("FragmentManager", a2.toString());
                    }
                }
            }
        }
    }

    public void a(String str, PrintWriter printWriter, boolean z) {
        String str2;
        if (z) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.i);
            printWriter.print(" mIndex=");
            printWriter.print(this.t);
            printWriter.print(" mCommitted=");
            printWriter.println(this.s);
            if (this.f != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f));
                printWriter.print(" mTransitionStyle=#");
                printWriter.println(Integer.toHexString(this.g));
            }
            if (!(this.f702b == 0 && this.f703c == 0)) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f702b));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f703c));
            }
            if (!(this.d == 0 && this.e == 0)) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.d));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.e));
            }
            if (!(this.j == 0 && this.k == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.j));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.k);
            }
            if (!(this.l == 0 && this.m == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.l));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.m);
            }
        }
        if (!this.f701a.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Operations:");
            int size = this.f701a.size();
            for (int i = 0; i < size; i++) {
                B.a aVar = this.f701a.get(i);
                switch (aVar.f704a) {
                    case 0:
                        str2 = "NULL";
                        break;
                    case 1:
                        str2 = "ADD";
                        break;
                    case 2:
                        str2 = "REPLACE";
                        break;
                    case 3:
                        str2 = "REMOVE";
                        break;
                    case 4:
                        str2 = "HIDE";
                        break;
                    case 5:
                        str2 = "SHOW";
                        break;
                    case 6:
                        str2 = "DETACH";
                        break;
                    case 7:
                        str2 = "ATTACH";
                        break;
                    case 8:
                        str2 = "SET_PRIMARY_NAV";
                        break;
                    case 9:
                        str2 = "UNSET_PRIMARY_NAV";
                        break;
                    case 10:
                        str2 = "OP_SET_MAX_LIFECYCLE";
                        break;
                    default:
                        StringBuilder a2 = a.a("cmd=");
                        a2.append(aVar.f704a);
                        str2 = a2.toString();
                        break;
                }
                printWriter.print(str);
                printWriter.print("  Op #");
                printWriter.print(i);
                printWriter.print(": ");
                printWriter.print(str2);
                printWriter.print(" ");
                printWriter.println(aVar.f705b);
                if (z) {
                    if (!(aVar.f706c == 0 && aVar.d == 0)) {
                        printWriter.print(str);
                        printWriter.print("enterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.f706c));
                        printWriter.print(" exitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.d));
                    }
                    if (aVar.e != 0 || aVar.f != 0) {
                        printWriter.print(str);
                        printWriter.print("popEnterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.e));
                        printWriter.print(" popExitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.f));
                    }
                }
            }
        }
    }

    public boolean a(ArrayList<C0070a> arrayList, int i, int i2) {
        if (i2 == i) {
            return false;
        }
        int size = this.f701a.size();
        int i3 = -1;
        for (int i4 = 0; i4 < size; i4++) {
            C0076g gVar = this.f701a.get(i4).f705b;
            int i5 = gVar != null ? gVar.x : 0;
            if (!(i5 == 0 || i5 == i3)) {
                for (int i6 = i; i6 < i2; i6++) {
                    C0070a aVar = arrayList.get(i6);
                    int size2 = aVar.f701a.size();
                    for (int i7 = 0; i7 < size2; i7++) {
                        C0076g gVar2 = aVar.f701a.get(i7).f705b;
                        if ((gVar2 != null ? gVar2.x : 0) == i5) {
                            return true;
                        }
                    }
                }
                i3 = i5;
            }
        }
        return false;
    }

    public boolean b(int i) {
        int size = this.f701a.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0076g gVar = this.f701a.get(i2).f705b;
            int i3 = gVar != null ? gVar.x : 0;
            if (i3 != 0 && i3 == i) {
                return true;
            }
        }
        return false;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.t >= 0) {
            sb.append(" #");
            sb.append(this.t);
        }
        if (this.i != null) {
            sb.append(" ");
            sb.append(this.i);
        }
        sb.append("}");
        return sb.toString();
    }

    public void a(boolean z) {
        for (int size = this.f701a.size() - 1; size >= 0; size--) {
            B.a aVar = this.f701a.get(size);
            C0076g gVar = aVar.f705b;
            if (gVar != null) {
                int d = u.d(this.f);
                int i = this.g;
                if (!(gVar.L == null && d == 0 && i == 0)) {
                    gVar.f();
                    C0076g.a aVar2 = gVar.L;
                    aVar2.e = d;
                    aVar2.f = i;
                }
            }
            switch (aVar.f704a) {
                case 1:
                    gVar.a(aVar.f);
                    this.r.i(gVar);
                    break;
                case 3:
                    gVar.a(aVar.e);
                    this.r.a(gVar, false);
                    break;
                case 4:
                    gVar.a(aVar.e);
                    this.r.m(gVar);
                    break;
                case 5:
                    gVar.a(aVar.f);
                    this.r.d(gVar);
                    break;
                case 6:
                    gVar.a(aVar.e);
                    this.r.a(gVar);
                    break;
                case 7:
                    gVar.a(aVar.f);
                    this.r.b(gVar);
                    break;
                case 8:
                    this.r.l((C0076g) null);
                    break;
                case 9:
                    this.r.l(gVar);
                    break;
                case 10:
                    this.r.a(gVar, aVar.g);
                    break;
                default:
                    StringBuilder a2 = a.a("Unknown cmd: ");
                    a2.append(aVar.f704a);
                    throw new IllegalArgumentException(a2.toString());
            }
            if (!(this.p || aVar.f704a == 3 || gVar == null)) {
                this.r.h(gVar);
            }
        }
        if (!this.p && z) {
            u uVar = this.r;
            uVar.a(uVar.s, true);
        }
    }

    public boolean a(ArrayList<C0070a> arrayList, ArrayList<Boolean> arrayList2) {
        if (u.f770c) {
            a.b("Run: ", this, "FragmentManager");
        }
        arrayList.add(this);
        arrayList2.add(false);
        if (!this.h) {
            return true;
        }
        u uVar = this.r;
        if (uVar.k == null) {
            uVar.k = new ArrayList<>();
        }
        uVar.k.add(this);
        return true;
    }

    public static boolean a(B.a aVar) {
        C0076g gVar = aVar.f705b;
        if (gVar == null || !gVar.l || gVar.H == null || gVar.A || gVar.z) {
            return false;
        }
        C0076g.a aVar2 = gVar.L;
        return aVar2 == null ? false : aVar2.q;
    }
}
