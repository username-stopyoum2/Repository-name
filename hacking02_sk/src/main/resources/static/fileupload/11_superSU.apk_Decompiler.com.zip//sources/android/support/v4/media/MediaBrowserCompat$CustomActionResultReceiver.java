package android.support.v4.media;

import a.a.a.b.c;
import android.os.Bundle;

public class MediaBrowserCompat$CustomActionResultReceiver extends c {
    public void a(int i, Bundle bundle) {
    }
}
