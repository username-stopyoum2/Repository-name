package b.h.a;

import b.a.d;

/* renamed from: b.h.a.n  reason: case insensitive filesystem */
class C0083n extends d {

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ u f757c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0083n(u uVar, boolean z) {
        super(z);
        this.f757c = uVar;
    }
}
