package b.n.a.a;

import a.a.a.a.c;
import android.animation.TypeEvaluator;
import b.e.c.b;

public class e implements TypeEvaluator<b[]> {

    /* renamed from: a  reason: collision with root package name */
    public b[] f837a;

    public Object evaluate(float f, Object obj, Object obj2) {
        b[] bVarArr = (b[]) obj;
        b[] bVarArr2 = (b[]) obj2;
        if (c.a(bVarArr, bVarArr2)) {
            if (!c.a(this.f837a, bVarArr)) {
                this.f837a = c.a(bVarArr);
            }
            for (int i = 0; i < bVarArr.length; i++) {
                this.f837a[i].a(bVarArr[i], bVarArr2[i], f);
            }
            return this.f837a;
        }
        throw new IllegalArgumentException("Can't interpolate between two incompatible pathData");
    }
}
