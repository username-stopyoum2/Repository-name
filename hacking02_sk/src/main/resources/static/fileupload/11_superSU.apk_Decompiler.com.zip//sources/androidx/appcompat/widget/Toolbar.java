package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.ActionMenuView;
import b.b.a.C0022a;
import b.b.e.a.A;
import b.b.e.a.k;
import b.b.e.a.o;
import b.b.e.a.t;
import b.b.e.f;
import b.b.f.C0037ca;
import b.b.f.C0044g;
import b.b.f.C0062t;
import b.b.f.Ea;
import b.b.f.K;
import b.b.f.Ka;
import b.b.f.O;
import b.b.f.r;
import b.b.f.xa;
import b.b.j;
import b.e.h.s;
import java.util.ArrayList;
import java.util.List;

public class Toolbar extends ViewGroup {
    public ColorStateList A;
    public boolean B;
    public boolean C;
    public final ArrayList<View> D;
    public final ArrayList<View> E;
    public final int[] F;
    public final ActionMenuView.e G;
    public Ea H;
    public C0044g I;
    public a J;
    public t.a K;
    public k.a L;
    public boolean M;
    public final Runnable N;

    /* renamed from: a  reason: collision with root package name */
    public ActionMenuView f101a;

    /* renamed from: b  reason: collision with root package name */
    public TextView f102b;

    /* renamed from: c  reason: collision with root package name */
    public TextView f103c;
    public ImageButton d;
    public ImageView e;
    public Drawable f;
    public CharSequence g;
    public ImageButton h;
    public View i;
    public Context j;
    public int k;
    public int l;
    public int m;
    public int n;
    public int o;
    public int p;
    public int q;
    public int r;
    public int s;
    public C0037ca t;
    public int u;
    public int v;
    public int w;
    public CharSequence x;
    public CharSequence y;
    public ColorStateList z;

    private class a implements t {

        /* renamed from: a  reason: collision with root package name */
        public k f104a;

        /* renamed from: b  reason: collision with root package name */
        public o f105b;

        public a() {
        }

        public void a(Context context, k kVar) {
            o oVar;
            k kVar2 = this.f104a;
            if (!(kVar2 == null || (oVar = this.f105b) == null)) {
                kVar2.a(oVar);
            }
            this.f104a = kVar;
        }

        public void a(k kVar, boolean z) {
        }

        public boolean a() {
            return false;
        }

        public boolean a(A a2) {
            return false;
        }

        public boolean a(k kVar, o oVar) {
            View view = Toolbar.this.i;
            if (view instanceof b.b.e.b) {
                ((b.b.e.b) view).onActionViewCollapsed();
            }
            Toolbar toolbar = Toolbar.this;
            toolbar.removeView(toolbar.i);
            Toolbar toolbar2 = Toolbar.this;
            toolbar2.removeView(toolbar2.h);
            Toolbar toolbar3 = Toolbar.this;
            toolbar3.i = null;
            toolbar3.a();
            this.f105b = null;
            Toolbar.this.requestLayout();
            oVar.D = false;
            oVar.n.b(false);
            return true;
        }

        public boolean b(k kVar, o oVar) {
            Toolbar.this.e();
            ViewParent parent = Toolbar.this.h.getParent();
            Toolbar toolbar = Toolbar.this;
            if (parent != toolbar) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(toolbar.h);
                }
                Toolbar toolbar2 = Toolbar.this;
                toolbar2.addView(toolbar2.h);
            }
            Toolbar.this.i = oVar.getActionView();
            this.f105b = oVar;
            ViewParent parent2 = Toolbar.this.i.getParent();
            Toolbar toolbar3 = Toolbar.this;
            if (parent2 != toolbar3) {
                if (parent2 instanceof ViewGroup) {
                    ((ViewGroup) parent2).removeView(toolbar3.i);
                }
                b generateDefaultLayoutParams = Toolbar.this.generateDefaultLayoutParams();
                Toolbar toolbar4 = Toolbar.this;
                generateDefaultLayoutParams.f165a = 8388611 | (toolbar4.n & j.AppCompatTheme_tooltipForegroundColor);
                generateDefaultLayoutParams.f107b = 2;
                toolbar4.i.setLayoutParams(generateDefaultLayoutParams);
                Toolbar toolbar5 = Toolbar.this;
                toolbar5.addView(toolbar5.i);
            }
            Toolbar.this.o();
            Toolbar.this.requestLayout();
            oVar.D = true;
            oVar.n.b(false);
            View view = Toolbar.this.i;
            if (view instanceof b.b.e.b) {
                ((b.b.e.b) view).onActionViewExpanded();
            }
            return true;
        }

        public void a(boolean z) {
            boolean z2;
            if (this.f105b != null) {
                k kVar = this.f104a;
                if (kVar != null) {
                    int size = kVar.size();
                    int i = 0;
                    while (true) {
                        if (i >= size) {
                            break;
                        } else if (this.f104a.getItem(i) == this.f105b) {
                            z2 = true;
                            break;
                        } else {
                            i++;
                        }
                    }
                }
                z2 = false;
                if (!z2) {
                    k kVar2 = this.f104a;
                    o oVar = this.f105b;
                    View view = Toolbar.this.i;
                    if (view instanceof b.b.e.b) {
                        ((b.b.e.b) view).onActionViewCollapsed();
                    }
                    Toolbar toolbar = Toolbar.this;
                    toolbar.removeView(toolbar.i);
                    Toolbar toolbar2 = Toolbar.this;
                    toolbar2.removeView(toolbar2.h);
                    Toolbar toolbar3 = Toolbar.this;
                    toolbar3.i = null;
                    toolbar3.a();
                    this.f105b = null;
                    Toolbar.this.requestLayout();
                    oVar.a(false);
                }
            }
        }
    }

    public static class b extends C0022a.C0004a {

        /* renamed from: b  reason: collision with root package name */
        public int f107b = 0;

        public b(int i, int i2) {
            super(i, i2);
            this.f165a = 8388627;
        }

        public b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public b(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public b(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super((ViewGroup.LayoutParams) marginLayoutParams);
            this.leftMargin = marginLayoutParams.leftMargin;
            this.topMargin = marginLayoutParams.topMargin;
            this.rightMargin = marginLayoutParams.rightMargin;
            this.bottomMargin = marginLayoutParams.bottomMargin;
        }

        public b(b bVar) {
            super((C0022a.C0004a) bVar);
            this.f107b = bVar.f107b;
        }

        public b(C0022a.C0004a aVar) {
            super(aVar);
        }
    }

    public interface c {
    }

    public static class d extends b.g.a.c {
        public static final Parcelable.Creator<d> CREATOR = new Ba();

        /* renamed from: c  reason: collision with root package name */
        public int f108c;
        public boolean d;

        public d(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f108c = parcel.readInt();
            this.d = parcel.readInt() != 0;
        }

        public d(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f697b, i);
            parcel.writeInt(this.f108c);
            parcel.writeInt(this.d ? 1 : 0);
        }
    }

    public Toolbar(Context context) {
        this(context, (AttributeSet) null, b.b.a.toolbarStyle);
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b.b.a.toolbarStyle);
    }

    private MenuInflater getMenuInflater() {
        return new f(getContext());
    }

    public final int a(int i2) {
        int e2 = s.e(this);
        int a2 = a.a.a.a.c.a(i2, e2) & 7;
        return (a2 == 1 || a2 == 3 || a2 == 5) ? a2 : e2 == 1 ? 5 : 3;
    }

    public final int a(View view, int i2) {
        b bVar = (b) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i3 = i2 > 0 ? (measuredHeight - i2) / 2 : 0;
        int i4 = bVar.f165a & j.AppCompatTheme_tooltipForegroundColor;
        if (!(i4 == 16 || i4 == 48 || i4 == 80)) {
            i4 = this.w & j.AppCompatTheme_tooltipForegroundColor;
        }
        if (i4 == 48) {
            return getPaddingTop() - i3;
        }
        if (i4 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - bVar.bottomMargin) - i3;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int i5 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i6 = bVar.topMargin;
        if (i5 < i6) {
            i5 = i6;
        } else {
            int i7 = (((height - paddingBottom) - measuredHeight) - i5) - paddingTop;
            int i8 = bVar.bottomMargin;
            if (i7 < i8) {
                i5 = Math.max(0, i5 - (i8 - i7));
            }
        }
        return paddingTop + i5;
    }

    public final int a(View view, int i2, int i3, int i4, int i5, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i6 = marginLayoutParams.leftMargin - iArr[0];
        int i7 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i7) + Math.max(0, i6);
        iArr[0] = Math.max(0, -i6);
        iArr[1] = Math.max(0, -i7);
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + max + i3, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    public final int a(View view, int i2, int[] iArr, int i3) {
        b bVar = (b) view.getLayoutParams();
        int i4 = bVar.leftMargin - iArr[0];
        int max = Math.max(0, i4) + i2;
        iArr[0] = Math.max(0, -i4);
        int a2 = a(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, a2, max + measuredWidth, view.getMeasuredHeight() + a2);
        return measuredWidth + bVar.rightMargin + max;
    }

    public void a() {
        for (int size = this.E.size() - 1; size >= 0; size--) {
            addView(this.E.get(size));
        }
        this.E.clear();
    }

    public void a(int i2, int i3) {
        f();
        this.t.a(i2, i3);
    }

    public void a(Context context, int i2) {
        this.m = i2;
        TextView textView = this.f103c;
        if (textView != null) {
            textView.setTextAppearance(context, i2);
        }
    }

    public final void a(View view, int i2, int i3, int i4, int i5, int i6) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i6 >= 0) {
            if (mode != 0) {
                i6 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i6);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i6, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public final void a(View view, boolean z2) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        b generateDefaultLayoutParams = layoutParams == null ? generateDefaultLayoutParams() : !checkLayoutParams(layoutParams) ? generateLayoutParams(layoutParams) : (b) layoutParams;
        generateDefaultLayoutParams.f107b = 1;
        if (!z2 || this.i == null) {
            addView(view, generateDefaultLayoutParams);
            return;
        }
        view.setLayoutParams(generateDefaultLayoutParams);
        this.E.add(view);
    }

    public final void a(List<View> list, int i2) {
        boolean z2 = s.e(this) == 1;
        int childCount = getChildCount();
        int a2 = a.a.a.a.c.a(i2, s.e(this));
        list.clear();
        if (z2) {
            for (int i3 = childCount - 1; i3 >= 0; i3--) {
                View childAt = getChildAt(i3);
                b bVar = (b) childAt.getLayoutParams();
                if (bVar.f107b == 0 && d(childAt) && a(bVar.f165a) == a2) {
                    list.add(childAt);
                }
            }
            return;
        }
        for (int i4 = 0; i4 < childCount; i4++) {
            View childAt2 = getChildAt(i4);
            b bVar2 = (b) childAt2.getLayoutParams();
            if (bVar2.f107b == 0 && d(childAt2) && a(bVar2.f165a) == a2) {
                list.add(childAt2);
            }
        }
    }

    public final int b(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final int b(View view, int i2, int[] iArr, int i3) {
        b bVar = (b) view.getLayoutParams();
        int i4 = bVar.rightMargin - iArr[1];
        int max = i2 - Math.max(0, i4);
        iArr[1] = Math.max(0, -i4);
        int a2 = a(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, a2, max, view.getMeasuredHeight() + a2);
        return max - (measuredWidth + bVar.leftMargin);
    }

    public void b(int i2) {
        getMenuInflater().inflate(i2, getMenu());
    }

    public void b(Context context, int i2) {
        this.l = i2;
        TextView textView = this.f102b;
        if (textView != null) {
            textView.setTextAppearance(context, i2);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r1.f101a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean b() {
        /*
            r1 = this;
            int r0 = r1.getVisibility()
            if (r0 != 0) goto L_0x0012
            androidx.appcompat.widget.ActionMenuView r0 = r1.f101a
            if (r0 == 0) goto L_0x0012
            boolean r0 = r0.f()
            if (r0 == 0) goto L_0x0012
            r0 = 1
            goto L_0x0013
        L_0x0012:
            r0 = 0
        L_0x0013:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.b():boolean");
    }

    public void c() {
        a aVar = this.J;
        o oVar = aVar == null ? null : aVar.f105b;
        if (oVar != null && (oVar.z & 8) != 0 && oVar.A != null) {
            MenuItem.OnActionExpandListener onActionExpandListener = oVar.C;
            if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionCollapse(oVar)) {
                oVar.n.a(oVar);
            }
        }
    }

    public final boolean c(View view) {
        return view.getParent() == this || this.E.contains(view);
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof b);
    }

    public void d() {
        ActionMenuView actionMenuView = this.f101a;
        if (actionMenuView != null) {
            actionMenuView.a();
        }
    }

    public final boolean d(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    public void e() {
        if (this.h == null) {
            this.h = new r(getContext(), (AttributeSet) null, b.b.a.toolbarNavigationButtonStyle);
            this.h.setImageDrawable(this.f);
            this.h.setContentDescription(this.g);
            b generateDefaultLayoutParams = generateDefaultLayoutParams();
            generateDefaultLayoutParams.f165a = 8388611 | (this.n & j.AppCompatTheme_tooltipForegroundColor);
            generateDefaultLayoutParams.f107b = 2;
            this.h.setLayoutParams(generateDefaultLayoutParams);
            this.h.setOnClickListener(new Aa(this));
        }
    }

    public final void f() {
        if (this.t == null) {
            this.t = new C0037ca();
        }
    }

    public final void g() {
        if (this.e == null) {
            this.e = new C0062t(getContext());
        }
    }

    public b generateDefaultLayoutParams() {
        return new b(-2, -2);
    }

    public b generateLayoutParams(AttributeSet attributeSet) {
        return new b(getContext(), attributeSet);
    }

    public b generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof b ? new b((b) layoutParams) : layoutParams instanceof C0022a.C0004a ? new b((C0022a.C0004a) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new b((ViewGroup.MarginLayoutParams) layoutParams) : new b(layoutParams);
    }

    public CharSequence getCollapseContentDescription() {
        ImageButton imageButton = this.h;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        ImageButton imageButton = this.h;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        C0037ca caVar = this.t;
        if (caVar != null) {
            return caVar.g ? caVar.f407a : caVar.f408b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i2 = this.v;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        C0037ca caVar = this.t;
        if (caVar != null) {
            return caVar.f407a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        C0037ca caVar = this.t;
        if (caVar != null) {
            return caVar.f408b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        C0037ca caVar = this.t;
        if (caVar != null) {
            return caVar.g ? caVar.f408b : caVar.f407a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i2 = this.u;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetStart();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0005, code lost:
        r0 = r0.g();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int getCurrentContentInsetEnd() {
        /*
            r3 = this;
            androidx.appcompat.widget.ActionMenuView r0 = r3.f101a
            r1 = 0
            if (r0 == 0) goto L_0x0013
            b.b.e.a.k r0 = r0.g()
            if (r0 == 0) goto L_0x0013
            boolean r0 = r0.hasVisibleItems()
            if (r0 == 0) goto L_0x0013
            r0 = 1
            goto L_0x0014
        L_0x0013:
            r0 = 0
        L_0x0014:
            if (r0 == 0) goto L_0x0025
            int r0 = r3.getContentInsetEnd()
            int r2 = r3.v
            int r1 = java.lang.Math.max(r2, r1)
            int r0 = java.lang.Math.max(r0, r1)
            goto L_0x0029
        L_0x0025:
            int r0 = r3.getContentInsetEnd()
        L_0x0029:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.getCurrentContentInsetEnd():int");
    }

    public int getCurrentContentInsetLeft() {
        return s.e(this) == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        return s.e(this) == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.u, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        ImageView imageView = this.e;
        if (imageView != null) {
            return imageView.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        ImageView imageView = this.e;
        if (imageView != null) {
            return imageView.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        h();
        return this.f101a.getMenu();
    }

    public CharSequence getNavigationContentDescription() {
        ImageButton imageButton = this.d;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        ImageButton imageButton = this.d;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public C0044g getOuterActionMenuPresenter() {
        return this.I;
    }

    public Drawable getOverflowIcon() {
        h();
        return this.f101a.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.j;
    }

    public int getPopupTheme() {
        return this.k;
    }

    public CharSequence getSubtitle() {
        return this.y;
    }

    public final TextView getSubtitleTextView() {
        return this.f103c;
    }

    public CharSequence getTitle() {
        return this.x;
    }

    public int getTitleMarginBottom() {
        return this.s;
    }

    public int getTitleMarginEnd() {
        return this.q;
    }

    public int getTitleMarginStart() {
        return this.p;
    }

    public int getTitleMarginTop() {
        return this.r;
    }

    public final TextView getTitleTextView() {
        return this.f102b;
    }

    public O getWrapper() {
        if (this.H == null) {
            this.H = new Ea(this, true);
        }
        return this.H;
    }

    public final void h() {
        i();
        if (this.f101a.g() == null) {
            k kVar = (k) this.f101a.getMenu();
            if (this.J == null) {
                this.J = new a();
            }
            this.f101a.setExpandedActionViewsExclusive(true);
            kVar.a((t) this.J, this.j);
        }
    }

    public final void i() {
        if (this.f101a == null) {
            this.f101a = new ActionMenuView(getContext(), (AttributeSet) null);
            this.f101a.setPopupTheme(this.k);
            this.f101a.setOnMenuItemClickListener(this.G);
            this.f101a.a(this.K, this.L);
            b generateDefaultLayoutParams = generateDefaultLayoutParams();
            generateDefaultLayoutParams.f165a = 8388613 | (this.n & j.AppCompatTheme_tooltipForegroundColor);
            this.f101a.setLayoutParams(generateDefaultLayoutParams);
            a((View) this.f101a, false);
        }
    }

    public final void j() {
        if (this.d == null) {
            this.d = new r(getContext(), (AttributeSet) null, b.b.a.toolbarNavigationButtonStyle);
            b generateDefaultLayoutParams = generateDefaultLayoutParams();
            generateDefaultLayoutParams.f165a = 8388611 | (this.n & j.AppCompatTheme_tooltipForegroundColor);
            this.d.setLayoutParams(generateDefaultLayoutParams);
        }
    }

    public boolean k() {
        a aVar = this.J;
        return (aVar == null || aVar.f105b == null) ? false : true;
    }

    public boolean l() {
        ActionMenuView actionMenuView = this.f101a;
        return actionMenuView != null && actionMenuView.c();
    }

    public boolean m() {
        ActionMenuView actionMenuView = this.f101a;
        return actionMenuView != null && actionMenuView.d();
    }

    public boolean n() {
        ActionMenuView actionMenuView = this.f101a;
        return actionMenuView != null && actionMenuView.e();
    }

    public void o() {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            if (!(((b) childAt.getLayoutParams()).f107b == 2 || childAt == this.f101a)) {
                removeViewAt(childCount);
                this.E.add(childAt);
            }
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.N);
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.C = false;
        }
        if (!this.C) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.C = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.C = false;
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:101:0x02a5 A[LOOP:0: B:100:0x02a3->B:101:0x02a5, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:104:0x02c7 A[LOOP:1: B:103:0x02c5->B:104:0x02c7, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:107:0x02ed A[LOOP:2: B:106:0x02eb->B:107:0x02ed, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:110:0x032f  */
    /* JADX WARNING: Removed duplicated region for block: B:115:0x033e A[LOOP:3: B:114:0x033c->B:115:0x033e, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x005f  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0076  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x00b3  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x00ca  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00e7  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x0100  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x0105  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x011d  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x012c  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x012f  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x0133  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x0136  */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x0169  */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x01a7  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x01b8  */
    /* JADX WARNING: Removed duplicated region for block: B:87:0x022a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r20, int r21, int r22, int r23, int r24) {
        /*
            r19 = this;
            r0 = r19
            int r1 = b.e.h.s.e(r19)
            r2 = 1
            r3 = 0
            if (r1 != r2) goto L_0x000c
            r1 = 1
            goto L_0x000d
        L_0x000c:
            r1 = 0
        L_0x000d:
            int r4 = r19.getWidth()
            int r5 = r19.getHeight()
            int r6 = r19.getPaddingLeft()
            int r7 = r19.getPaddingRight()
            int r8 = r19.getPaddingTop()
            int r9 = r19.getPaddingBottom()
            int r10 = r4 - r7
            int[] r11 = r0.F
            r11[r2] = r3
            r11[r3] = r3
            int r12 = b.e.h.s.f(r19)
            if (r12 < 0) goto L_0x003a
            int r13 = r24 - r22
            int r12 = java.lang.Math.min(r12, r13)
            goto L_0x003b
        L_0x003a:
            r12 = 0
        L_0x003b:
            android.widget.ImageButton r13 = r0.d
            boolean r13 = r0.d(r13)
            if (r13 == 0) goto L_0x0055
            if (r1 == 0) goto L_0x004e
            android.widget.ImageButton r13 = r0.d
            int r13 = r0.b(r13, r10, r11, r12)
            r14 = r13
            r13 = r6
            goto L_0x0057
        L_0x004e:
            android.widget.ImageButton r13 = r0.d
            int r13 = r0.a(r13, r6, r11, r12)
            goto L_0x0056
        L_0x0055:
            r13 = r6
        L_0x0056:
            r14 = r10
        L_0x0057:
            android.widget.ImageButton r15 = r0.h
            boolean r15 = r0.d(r15)
            if (r15 == 0) goto L_0x006e
            if (r1 == 0) goto L_0x0068
            android.widget.ImageButton r15 = r0.h
            int r14 = r0.b(r15, r14, r11, r12)
            goto L_0x006e
        L_0x0068:
            android.widget.ImageButton r15 = r0.h
            int r13 = r0.a(r15, r13, r11, r12)
        L_0x006e:
            androidx.appcompat.widget.ActionMenuView r15 = r0.f101a
            boolean r15 = r0.d(r15)
            if (r15 == 0) goto L_0x0085
            if (r1 == 0) goto L_0x007f
            androidx.appcompat.widget.ActionMenuView r15 = r0.f101a
            int r13 = r0.a(r15, r13, r11, r12)
            goto L_0x0085
        L_0x007f:
            androidx.appcompat.widget.ActionMenuView r15 = r0.f101a
            int r14 = r0.b(r15, r14, r11, r12)
        L_0x0085:
            int r15 = r19.getCurrentContentInsetLeft()
            int r16 = r19.getCurrentContentInsetRight()
            int r2 = r15 - r13
            int r2 = java.lang.Math.max(r3, r2)
            r11[r3] = r2
            int r2 = r10 - r14
            int r2 = r16 - r2
            int r2 = java.lang.Math.max(r3, r2)
            r17 = 1
            r11[r17] = r2
            int r2 = java.lang.Math.max(r13, r15)
            int r10 = r10 - r16
            int r10 = java.lang.Math.min(r14, r10)
            android.view.View r13 = r0.i
            boolean r13 = r0.d(r13)
            if (r13 == 0) goto L_0x00c2
            if (r1 == 0) goto L_0x00bc
            android.view.View r13 = r0.i
            int r10 = r0.b(r13, r10, r11, r12)
            goto L_0x00c2
        L_0x00bc:
            android.view.View r13 = r0.i
            int r2 = r0.a(r13, r2, r11, r12)
        L_0x00c2:
            android.widget.ImageView r13 = r0.e
            boolean r13 = r0.d(r13)
            if (r13 == 0) goto L_0x00d9
            if (r1 == 0) goto L_0x00d3
            android.widget.ImageView r13 = r0.e
            int r10 = r0.b(r13, r10, r11, r12)
            goto L_0x00d9
        L_0x00d3:
            android.widget.ImageView r13 = r0.e
            int r2 = r0.a(r13, r2, r11, r12)
        L_0x00d9:
            android.widget.TextView r13 = r0.f102b
            boolean r13 = r0.d(r13)
            android.widget.TextView r14 = r0.f103c
            boolean r14 = r0.d(r14)
            if (r13 == 0) goto L_0x0100
            android.widget.TextView r15 = r0.f102b
            android.view.ViewGroup$LayoutParams r15 = r15.getLayoutParams()
            androidx.appcompat.widget.Toolbar$b r15 = (androidx.appcompat.widget.Toolbar.b) r15
            int r3 = r15.topMargin
            r23 = r7
            android.widget.TextView r7 = r0.f102b
            int r7 = r7.getMeasuredHeight()
            int r7 = r7 + r3
            int r3 = r15.bottomMargin
            int r7 = r7 + r3
            r3 = 0
            int r7 = r7 + r3
            goto L_0x0103
        L_0x0100:
            r23 = r7
            r7 = 0
        L_0x0103:
            if (r14 == 0) goto L_0x011d
            android.widget.TextView r3 = r0.f103c
            android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
            androidx.appcompat.widget.Toolbar$b r3 = (androidx.appcompat.widget.Toolbar.b) r3
            int r15 = r3.topMargin
            r16 = r4
            android.widget.TextView r4 = r0.f103c
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r15
            int r3 = r3.bottomMargin
            int r4 = r4 + r3
            int r7 = r7 + r4
            goto L_0x011f
        L_0x011d:
            r16 = r4
        L_0x011f:
            if (r13 != 0) goto L_0x012a
            if (r14 == 0) goto L_0x0124
            goto L_0x012a
        L_0x0124:
            r17 = r6
            r22 = r12
            goto L_0x0295
        L_0x012a:
            if (r13 == 0) goto L_0x012f
            android.widget.TextView r3 = r0.f102b
            goto L_0x0131
        L_0x012f:
            android.widget.TextView r3 = r0.f103c
        L_0x0131:
            if (r14 == 0) goto L_0x0136
            android.widget.TextView r4 = r0.f103c
            goto L_0x0138
        L_0x0136:
            android.widget.TextView r4 = r0.f102b
        L_0x0138:
            android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
            androidx.appcompat.widget.Toolbar$b r3 = (androidx.appcompat.widget.Toolbar.b) r3
            android.view.ViewGroup$LayoutParams r4 = r4.getLayoutParams()
            androidx.appcompat.widget.Toolbar$b r4 = (androidx.appcompat.widget.Toolbar.b) r4
            if (r13 == 0) goto L_0x014e
            android.widget.TextView r15 = r0.f102b
            int r15 = r15.getMeasuredWidth()
            if (r15 > 0) goto L_0x0158
        L_0x014e:
            if (r14 == 0) goto L_0x015c
            android.widget.TextView r15 = r0.f103c
            int r15 = r15.getMeasuredWidth()
            if (r15 <= 0) goto L_0x015c
        L_0x0158:
            r17 = r6
            r15 = 1
            goto L_0x015f
        L_0x015c:
            r17 = r6
            r15 = 0
        L_0x015f:
            int r6 = r0.w
            r6 = r6 & 112(0x70, float:1.57E-43)
            r22 = r12
            r12 = 48
            if (r6 == r12) goto L_0x01a7
            r12 = 80
            if (r6 == r12) goto L_0x0199
            int r6 = r5 - r8
            int r6 = r6 - r9
            int r6 = r6 - r7
            int r6 = r6 / 2
            int r12 = r3.topMargin
            r24 = r2
            int r2 = r0.r
            r18 = r14
            int r14 = r12 + r2
            if (r6 >= r14) goto L_0x0182
            int r6 = r12 + r2
            goto L_0x0197
        L_0x0182:
            int r5 = r5 - r9
            int r5 = r5 - r7
            int r5 = r5 - r6
            int r5 = r5 - r8
            int r2 = r3.bottomMargin
            int r3 = r0.s
            int r2 = r2 + r3
            if (r5 >= r2) goto L_0x0197
            int r2 = r4.bottomMargin
            int r2 = r2 + r3
            int r2 = r2 - r5
            int r6 = r6 - r2
            r2 = 0
            int r6 = java.lang.Math.max(r2, r6)
        L_0x0197:
            int r8 = r8 + r6
            goto L_0x01b6
        L_0x0199:
            r24 = r2
            r18 = r14
            int r5 = r5 - r9
            int r2 = r4.bottomMargin
            int r5 = r5 - r2
            int r2 = r0.s
            int r5 = r5 - r2
            int r8 = r5 - r7
            goto L_0x01b6
        L_0x01a7:
            r24 = r2
            r18 = r14
            int r2 = r19.getPaddingTop()
            int r3 = r3.topMargin
            int r2 = r2 + r3
            int r3 = r0.r
            int r8 = r2 + r3
        L_0x01b6:
            if (r1 == 0) goto L_0x022a
            if (r15 == 0) goto L_0x01be
            int r3 = r0.p
            r1 = 1
            goto L_0x01c0
        L_0x01be:
            r1 = 1
            r3 = 0
        L_0x01c0:
            r2 = r11[r1]
            int r3 = r3 - r2
            r2 = 0
            int r4 = java.lang.Math.max(r2, r3)
            int r10 = r10 - r4
            int r3 = -r3
            int r3 = java.lang.Math.max(r2, r3)
            r11[r1] = r3
            if (r13 == 0) goto L_0x01f6
            android.widget.TextView r1 = r0.f102b
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$b r1 = (androidx.appcompat.widget.Toolbar.b) r1
            android.widget.TextView r2 = r0.f102b
            int r2 = r2.getMeasuredWidth()
            int r2 = r10 - r2
            android.widget.TextView r3 = r0.f102b
            int r3 = r3.getMeasuredHeight()
            int r3 = r3 + r8
            android.widget.TextView r4 = r0.f102b
            r4.layout(r2, r8, r10, r3)
            int r4 = r0.q
            int r2 = r2 - r4
            int r1 = r1.bottomMargin
            int r8 = r3 + r1
            goto L_0x01f7
        L_0x01f6:
            r2 = r10
        L_0x01f7:
            if (r18 == 0) goto L_0x021f
            android.widget.TextView r1 = r0.f103c
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$b r1 = (androidx.appcompat.widget.Toolbar.b) r1
            int r3 = r1.topMargin
            int r8 = r8 + r3
            android.widget.TextView r3 = r0.f103c
            int r3 = r3.getMeasuredWidth()
            int r3 = r10 - r3
            android.widget.TextView r4 = r0.f103c
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r8
            android.widget.TextView r5 = r0.f103c
            r5.layout(r3, r8, r10, r4)
            int r3 = r0.q
            int r3 = r10 - r3
            int r1 = r1.bottomMargin
            goto L_0x0220
        L_0x021f:
            r3 = r10
        L_0x0220:
            if (r15 == 0) goto L_0x0227
            int r1 = java.lang.Math.min(r2, r3)
            r10 = r1
        L_0x0227:
            r2 = r24
            goto L_0x0295
        L_0x022a:
            if (r15 == 0) goto L_0x0230
            int r3 = r0.p
            r1 = 0
            goto L_0x0232
        L_0x0230:
            r1 = 0
            r3 = 0
        L_0x0232:
            r2 = r11[r1]
            int r3 = r3 - r2
            int r2 = java.lang.Math.max(r1, r3)
            int r2 = r2 + r24
            int r3 = -r3
            int r3 = java.lang.Math.max(r1, r3)
            r11[r1] = r3
            if (r13 == 0) goto L_0x0267
            android.widget.TextView r1 = r0.f102b
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$b r1 = (androidx.appcompat.widget.Toolbar.b) r1
            android.widget.TextView r3 = r0.f102b
            int r3 = r3.getMeasuredWidth()
            int r3 = r3 + r2
            android.widget.TextView r4 = r0.f102b
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r8
            android.widget.TextView r5 = r0.f102b
            r5.layout(r2, r8, r3, r4)
            int r5 = r0.q
            int r3 = r3 + r5
            int r1 = r1.bottomMargin
            int r8 = r4 + r1
            goto L_0x0268
        L_0x0267:
            r3 = r2
        L_0x0268:
            if (r18 == 0) goto L_0x028e
            android.widget.TextView r1 = r0.f103c
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$b r1 = (androidx.appcompat.widget.Toolbar.b) r1
            int r4 = r1.topMargin
            int r8 = r8 + r4
            android.widget.TextView r4 = r0.f103c
            int r4 = r4.getMeasuredWidth()
            int r4 = r4 + r2
            android.widget.TextView r5 = r0.f103c
            int r5 = r5.getMeasuredHeight()
            int r5 = r5 + r8
            android.widget.TextView r6 = r0.f103c
            r6.layout(r2, r8, r4, r5)
            int r5 = r0.q
            int r4 = r4 + r5
            int r1 = r1.bottomMargin
            goto L_0x028f
        L_0x028e:
            r4 = r2
        L_0x028f:
            if (r15 == 0) goto L_0x0295
            int r2 = java.lang.Math.max(r3, r4)
        L_0x0295:
            java.util.ArrayList<android.view.View> r1 = r0.D
            r3 = 3
            r0.a((java.util.List<android.view.View>) r1, (int) r3)
            java.util.ArrayList<android.view.View> r1 = r0.D
            int r1 = r1.size()
            r3 = r2
            r2 = 0
        L_0x02a3:
            if (r2 >= r1) goto L_0x02b6
            java.util.ArrayList<android.view.View> r4 = r0.D
            java.lang.Object r4 = r4.get(r2)
            android.view.View r4 = (android.view.View) r4
            r12 = r22
            int r3 = r0.a(r4, r3, r11, r12)
            int r2 = r2 + 1
            goto L_0x02a3
        L_0x02b6:
            r12 = r22
            java.util.ArrayList<android.view.View> r1 = r0.D
            r2 = 5
            r0.a((java.util.List<android.view.View>) r1, (int) r2)
            java.util.ArrayList<android.view.View> r1 = r0.D
            int r1 = r1.size()
            r2 = 0
        L_0x02c5:
            if (r2 >= r1) goto L_0x02d6
            java.util.ArrayList<android.view.View> r4 = r0.D
            java.lang.Object r4 = r4.get(r2)
            android.view.View r4 = (android.view.View) r4
            int r10 = r0.b(r4, r10, r11, r12)
            int r2 = r2 + 1
            goto L_0x02c5
        L_0x02d6:
            java.util.ArrayList<android.view.View> r1 = r0.D
            r2 = 1
            r0.a((java.util.List<android.view.View>) r1, (int) r2)
            java.util.ArrayList<android.view.View> r1 = r0.D
            r4 = 0
            r5 = r11[r4]
            r2 = r11[r2]
            int r4 = r1.size()
            r7 = r2
            r6 = r5
            r2 = 0
            r5 = 0
        L_0x02eb:
            if (r2 >= r4) goto L_0x031e
            java.lang.Object r8 = r1.get(r2)
            android.view.View r8 = (android.view.View) r8
            android.view.ViewGroup$LayoutParams r9 = r8.getLayoutParams()
            androidx.appcompat.widget.Toolbar$b r9 = (androidx.appcompat.widget.Toolbar.b) r9
            int r13 = r9.leftMargin
            int r13 = r13 - r6
            int r6 = r9.rightMargin
            int r6 = r6 - r7
            r7 = 0
            int r9 = java.lang.Math.max(r7, r13)
            int r14 = java.lang.Math.max(r7, r6)
            int r13 = -r13
            int r13 = java.lang.Math.max(r7, r13)
            int r6 = -r6
            int r6 = java.lang.Math.max(r7, r6)
            int r8 = r8.getMeasuredWidth()
            int r8 = r8 + r9
            int r8 = r8 + r14
            int r5 = r5 + r8
            int r2 = r2 + 1
            r7 = r6
            r6 = r13
            goto L_0x02eb
        L_0x031e:
            r7 = 0
            int r4 = r16 - r17
            int r4 = r4 - r23
            int r4 = r4 / 2
            int r4 = r4 + r17
            int r1 = r5 / 2
            int r1 = r4 - r1
            int r5 = r5 + r1
            if (r1 >= r3) goto L_0x032f
            goto L_0x0336
        L_0x032f:
            if (r5 <= r10) goto L_0x0335
            int r5 = r5 - r10
            int r3 = r1 - r5
            goto L_0x0336
        L_0x0335:
            r3 = r1
        L_0x0336:
            java.util.ArrayList<android.view.View> r1 = r0.D
            int r1 = r1.size()
        L_0x033c:
            if (r7 >= r1) goto L_0x034d
            java.util.ArrayList<android.view.View> r2 = r0.D
            java.lang.Object r2 = r2.get(r7)
            android.view.View r2 = (android.view.View) r2
            int r3 = r0.a(r2, r3, r11, r12)
            int r7 = r7 + 1
            goto L_0x033c
        L_0x034d:
            java.util.ArrayList<android.view.View> r1 = r0.D
            r1.clear()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    public void onMeasure(int i2, int i3) {
        char c2;
        char c3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int[] iArr = this.F;
        boolean z2 = true;
        if (Ka.a(this)) {
            c3 = 1;
            c2 = 0;
        } else {
            c3 = 0;
            c2 = 1;
        }
        if (d(this.d)) {
            a((View) this.d, i2, 0, i3, 0, this.o);
            i6 = this.d.getMeasuredWidth() + a((View) this.d);
            i5 = Math.max(0, b((View) this.d) + this.d.getMeasuredHeight());
            i4 = View.combineMeasuredStates(0, this.d.getMeasuredState());
        } else {
            i6 = 0;
            i5 = 0;
            i4 = 0;
        }
        if (d(this.h)) {
            a((View) this.h, i2, 0, i3, 0, this.o);
            i6 = this.h.getMeasuredWidth() + a((View) this.h);
            i5 = Math.max(i5, b((View) this.h) + this.h.getMeasuredHeight());
            i4 = View.combineMeasuredStates(i4, this.h.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int max = Math.max(currentContentInsetStart, i6) + 0;
        iArr[c3] = Math.max(0, currentContentInsetStart - i6);
        if (d(this.f101a)) {
            a((View) this.f101a, i2, max, i3, 0, this.o);
            i7 = this.f101a.getMeasuredWidth() + a((View) this.f101a);
            i5 = Math.max(i5, b((View) this.f101a) + this.f101a.getMeasuredHeight());
            i4 = View.combineMeasuredStates(i4, this.f101a.getMeasuredState());
        } else {
            i7 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int max2 = Math.max(currentContentInsetEnd, i7) + max;
        iArr[c2] = Math.max(0, currentContentInsetEnd - i7);
        if (d(this.i)) {
            max2 += a(this.i, i2, max2, i3, 0, iArr);
            i5 = Math.max(i5, b(this.i) + this.i.getMeasuredHeight());
            i4 = View.combineMeasuredStates(i4, this.i.getMeasuredState());
        }
        if (d(this.e)) {
            max2 += a((View) this.e, i2, max2, i3, 0, iArr);
            i5 = Math.max(i5, b((View) this.e) + this.e.getMeasuredHeight());
            i4 = View.combineMeasuredStates(i4, this.e.getMeasuredState());
        }
        int childCount = getChildCount();
        int i11 = i5;
        int i12 = max2;
        for (int i13 = 0; i13 < childCount; i13++) {
            View childAt = getChildAt(i13);
            if (((b) childAt.getLayoutParams()).f107b == 0 && d(childAt)) {
                View view = childAt;
                i12 += a(childAt, i2, i12, i3, 0, iArr);
                View view2 = view;
                i11 = Math.max(i11, b(view2) + view.getMeasuredHeight());
                i4 = View.combineMeasuredStates(i4, view2.getMeasuredState());
            }
        }
        int i14 = this.r + this.s;
        int i15 = this.p + this.q;
        if (d(this.f102b)) {
            a((View) this.f102b, i2, i12 + i15, i3, i14, iArr);
            int measuredWidth = this.f102b.getMeasuredWidth() + a((View) this.f102b);
            i8 = this.f102b.getMeasuredHeight() + b((View) this.f102b);
            i10 = View.combineMeasuredStates(i4, this.f102b.getMeasuredState());
            i9 = measuredWidth;
        } else {
            i10 = i4;
            i9 = 0;
            i8 = 0;
        }
        if (d(this.f103c)) {
            int i16 = i8 + i14;
            i9 = Math.max(i9, a((View) this.f103c, i2, i12 + i15, i3, i16, iArr));
            i8 = b((View) this.f103c) + this.f103c.getMeasuredHeight() + i8;
            i10 = View.combineMeasuredStates(i10, this.f103c.getMeasuredState());
        } else {
            int i17 = i10;
        }
        int max3 = Math.max(i11, i8);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop() + max3;
        int resolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight + i12 + i9, getSuggestedMinimumWidth()), i2, -16777216 & i10);
        int resolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i3, i10 << 16);
        if (this.M) {
            int childCount2 = getChildCount();
            int i18 = 0;
            while (true) {
                if (i18 >= childCount2) {
                    break;
                }
                View childAt2 = getChildAt(i18);
                if (d(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                    break;
                }
                i18++;
            }
        }
        z2 = false;
        if (z2) {
            resolveSizeAndState2 = 0;
        }
        setMeasuredDimension(resolveSizeAndState, resolveSizeAndState2);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem findItem;
        if (!(parcelable instanceof d)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        d dVar = (d) parcelable;
        super.onRestoreInstanceState(dVar.f697b);
        ActionMenuView actionMenuView = this.f101a;
        k g2 = actionMenuView != null ? actionMenuView.g() : null;
        int i2 = dVar.f108c;
        if (!(i2 == 0 || this.J == null || g2 == null || (findItem = g2.findItem(i2)) == null)) {
            findItem.expandActionView();
        }
        if (dVar.d) {
            removeCallbacks(this.N);
            post(this.N);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0029, code lost:
        if (r1 != Integer.MIN_VALUE) goto L_0x0040;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0037, code lost:
        if (r1 != Integer.MIN_VALUE) goto L_0x0040;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onRtlPropertiesChanged(int r3) {
        /*
            r2 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            super.onRtlPropertiesChanged(r3)
            r2.f()
            b.b.f.ca r0 = r2.t
            r1 = 1
            if (r3 != r1) goto L_0x000e
            goto L_0x000f
        L_0x000e:
            r1 = 0
        L_0x000f:
            boolean r3 = r0.g
            if (r1 != r3) goto L_0x0014
            goto L_0x0042
        L_0x0014:
            r0.g = r1
            boolean r3 = r0.h
            if (r3 == 0) goto L_0x003a
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r1 == 0) goto L_0x002c
            int r1 = r0.d
            if (r1 == r3) goto L_0x0023
            goto L_0x0025
        L_0x0023:
            int r1 = r0.e
        L_0x0025:
            r0.f407a = r1
            int r1 = r0.f409c
            if (r1 == r3) goto L_0x003e
            goto L_0x0040
        L_0x002c:
            int r1 = r0.f409c
            if (r1 == r3) goto L_0x0031
            goto L_0x0033
        L_0x0031:
            int r1 = r0.e
        L_0x0033:
            r0.f407a = r1
            int r1 = r0.d
            if (r1 == r3) goto L_0x003e
            goto L_0x0040
        L_0x003a:
            int r3 = r0.e
            r0.f407a = r3
        L_0x003e:
            int r1 = r0.f
        L_0x0040:
            r0.f408b = r1
        L_0x0042:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onRtlPropertiesChanged(int):void");
    }

    public Parcelable onSaveInstanceState() {
        o oVar;
        d dVar = new d(super.onSaveInstanceState());
        a aVar = this.J;
        if (!(aVar == null || (oVar = aVar.f105b) == null)) {
            dVar.f108c = oVar.f273a;
        }
        dVar.d = n();
        return dVar;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.B = false;
        }
        if (!this.B) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.B = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.B = false;
        }
        return true;
    }

    public boolean p() {
        ActionMenuView actionMenuView = this.f101a;
        return actionMenuView != null && actionMenuView.h();
    }

    public void setCollapseContentDescription(int i2) {
        setCollapseContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            e();
        }
        ImageButton imageButton = this.h;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(int i2) {
        setCollapseIcon(b.b.b.a.a.c(getContext(), i2));
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            e();
            this.h.setImageDrawable(drawable);
            return;
        }
        ImageButton imageButton = this.h;
        if (imageButton != null) {
            imageButton.setImageDrawable(this.f);
        }
    }

    public void setCollapsible(boolean z2) {
        this.M = z2;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.v) {
            this.v = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.u) {
            this.u = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i2) {
        setLogo(b.b.b.a.a.c(getContext(), i2));
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            g();
            if (!c(this.e)) {
                a((View) this.e, true);
            }
        } else {
            ImageView imageView = this.e;
            if (imageView != null && c(imageView)) {
                removeView(this.e);
                this.E.remove(this.e);
            }
        }
        ImageView imageView2 = this.e;
        if (imageView2 != null) {
            imageView2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(int i2) {
        setLogoDescription(getContext().getText(i2));
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        ImageView imageView = this.e;
        if (imageView != null) {
            imageView.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(int i2) {
        setNavigationContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            j();
        }
        ImageButton imageButton = this.d;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setNavigationIcon(int i2) {
        setNavigationIcon(b.b.b.a.a.c(getContext(), i2));
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            j();
            if (!c(this.d)) {
                a((View) this.d, true);
            }
        } else {
            ImageButton imageButton = this.d;
            if (imageButton != null && c(imageButton)) {
                removeView(this.d);
                this.E.remove(this.d);
            }
        }
        ImageButton imageButton2 = this.d;
        if (imageButton2 != null) {
            imageButton2.setImageDrawable(drawable);
        }
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        j();
        this.d.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(c cVar) {
    }

    public void setOverflowIcon(Drawable drawable) {
        h();
        this.f101a.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i2) {
        if (this.k != i2) {
            this.k = i2;
            if (i2 == 0) {
                this.j = getContext();
            } else {
                this.j = new ContextThemeWrapper(getContext(), i2);
            }
        }
    }

    public void setSubtitle(int i2) {
        setSubtitle(getContext().getText(i2));
    }

    public void setSubtitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f103c == null) {
                Context context = getContext();
                this.f103c = new K(context);
                this.f103c.setSingleLine();
                this.f103c.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.m;
                if (i2 != 0) {
                    this.f103c.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.A;
                if (colorStateList != null) {
                    this.f103c.setTextColor(colorStateList);
                }
            }
            if (!c(this.f103c)) {
                a((View) this.f103c, true);
            }
        } else {
            TextView textView = this.f103c;
            if (textView != null && c(textView)) {
                removeView(this.f103c);
                this.E.remove(this.f103c);
            }
        }
        TextView textView2 = this.f103c;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.y = charSequence;
    }

    public void setSubtitleTextColor(int i2) {
        setSubtitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.A = colorStateList;
        TextView textView = this.f103c;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setTitle(int i2) {
        setTitle(getContext().getText(i2));
    }

    public void setTitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f102b == null) {
                Context context = getContext();
                this.f102b = new K(context);
                this.f102b.setSingleLine();
                this.f102b.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.l;
                if (i2 != 0) {
                    this.f102b.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.z;
                if (colorStateList != null) {
                    this.f102b.setTextColor(colorStateList);
                }
            }
            if (!c(this.f102b)) {
                a((View) this.f102b, true);
            }
        } else {
            TextView textView = this.f102b;
            if (textView != null && c(textView)) {
                removeView(this.f102b);
                this.E.remove(this.f102b);
            }
        }
        TextView textView2 = this.f102b;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.x = charSequence;
    }

    public void setTitleMarginBottom(int i2) {
        this.s = i2;
        requestLayout();
    }

    public void setTitleMarginEnd(int i2) {
        this.q = i2;
        requestLayout();
    }

    public void setTitleMarginStart(int i2) {
        this.p = i2;
        requestLayout();
    }

    public void setTitleMarginTop(int i2) {
        this.r = i2;
        requestLayout();
    }

    public void setTitleTextColor(int i2) {
        setTitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.z = colorStateList;
        TextView textView = this.f102b;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.w = 8388627;
        this.D = new ArrayList<>();
        this.E = new ArrayList<>();
        this.F = new int[2];
        this.G = new ya(this);
        this.N = new za(this);
        xa a2 = xa.a(getContext(), attributeSet, j.Toolbar, i2, 0);
        this.l = a2.e(j.Toolbar_titleTextAppearance, 0);
        this.m = a2.e(j.Toolbar_subtitleTextAppearance, 0);
        this.w = a2.f496b.getInteger(j.Toolbar_android_gravity, this.w);
        this.n = a2.f496b.getInteger(j.Toolbar_buttonGravity, 48);
        int a3 = a2.a(j.Toolbar_titleMargin, 0);
        a3 = a2.f(j.Toolbar_titleMargins) ? a2.a(j.Toolbar_titleMargins, a3) : a3;
        this.s = a3;
        this.r = a3;
        this.q = a3;
        this.p = a3;
        int a4 = a2.a(j.Toolbar_titleMarginStart, -1);
        if (a4 >= 0) {
            this.p = a4;
        }
        int a5 = a2.a(j.Toolbar_titleMarginEnd, -1);
        if (a5 >= 0) {
            this.q = a5;
        }
        int a6 = a2.a(j.Toolbar_titleMarginTop, -1);
        if (a6 >= 0) {
            this.r = a6;
        }
        int a7 = a2.a(j.Toolbar_titleMarginBottom, -1);
        if (a7 >= 0) {
            this.s = a7;
        }
        this.o = a2.b(j.Toolbar_maxButtonHeight, -1);
        int a8 = a2.a(j.Toolbar_contentInsetStart, Integer.MIN_VALUE);
        int a9 = a2.a(j.Toolbar_contentInsetEnd, Integer.MIN_VALUE);
        int b2 = a2.b(j.Toolbar_contentInsetLeft, 0);
        int b3 = a2.b(j.Toolbar_contentInsetRight, 0);
        f();
        C0037ca caVar = this.t;
        caVar.h = false;
        if (b2 != Integer.MIN_VALUE) {
            caVar.e = b2;
            caVar.f407a = b2;
        }
        if (b3 != Integer.MIN_VALUE) {
            caVar.f = b3;
            caVar.f408b = b3;
        }
        if (!(a8 == Integer.MIN_VALUE && a9 == Integer.MIN_VALUE)) {
            this.t.a(a8, a9);
        }
        this.u = a2.a(j.Toolbar_contentInsetStartWithNavigation, Integer.MIN_VALUE);
        this.v = a2.a(j.Toolbar_contentInsetEndWithActions, Integer.MIN_VALUE);
        this.f = a2.b(j.Toolbar_collapseIcon);
        this.g = a2.e(j.Toolbar_collapseContentDescription);
        CharSequence e2 = a2.e(j.Toolbar_title);
        if (!TextUtils.isEmpty(e2)) {
            setTitle(e2);
        }
        CharSequence e3 = a2.e(j.Toolbar_subtitle);
        if (!TextUtils.isEmpty(e3)) {
            setSubtitle(e3);
        }
        this.j = getContext();
        setPopupTheme(a2.e(j.Toolbar_popupTheme, 0));
        Drawable b4 = a2.b(j.Toolbar_navigationIcon);
        if (b4 != null) {
            setNavigationIcon(b4);
        }
        CharSequence e4 = a2.e(j.Toolbar_navigationContentDescription);
        if (!TextUtils.isEmpty(e4)) {
            setNavigationContentDescription(e4);
        }
        Drawable b5 = a2.b(j.Toolbar_logo);
        if (b5 != null) {
            setLogo(b5);
        }
        CharSequence e5 = a2.e(j.Toolbar_logoDescription);
        if (!TextUtils.isEmpty(e5)) {
            setLogoDescription(e5);
        }
        if (a2.f(j.Toolbar_titleTextColor)) {
            setTitleTextColor(a2.a(j.Toolbar_titleTextColor));
        }
        if (a2.f(j.Toolbar_subtitleTextColor)) {
            setSubtitleTextColor(a2.a(j.Toolbar_subtitleTextColor));
        }
        if (a2.f(j.Toolbar_menu)) {
            b(a2.e(j.Toolbar_menu, 0));
        }
        a2.f496b.recycle();
    }

    public final int a(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i2 = Build.VERSION.SDK_INT;
        int marginStart = marginLayoutParams.getMarginStart();
        int i3 = Build.VERSION.SDK_INT;
        return marginStart + marginLayoutParams.getMarginEnd();
    }

    public void a(k kVar, C0044g gVar) {
        o oVar;
        if (kVar != null || this.f101a != null) {
            i();
            k g2 = this.f101a.g();
            if (g2 != kVar) {
                if (g2 != null) {
                    g2.a((t) this.I);
                    g2.a((t) this.J);
                }
                if (this.J == null) {
                    this.J = new a();
                }
                boolean z2 = true;
                gVar.t = true;
                if (kVar != null) {
                    kVar.a((t) gVar, this.j);
                    kVar.a((t) this.J, this.j);
                } else {
                    Context context = this.j;
                    gVar.f242b = context;
                    LayoutInflater.from(gVar.f242b);
                    gVar.f243c = null;
                    Resources resources = context.getResources();
                    if (!gVar.m) {
                        gVar.l = Build.VERSION.SDK_INT >= 19 ? true : !ViewConfiguration.get(context).hasPermanentMenuKey();
                    }
                    int i2 = 2;
                    if (!gVar.s) {
                        gVar.n = context.getResources().getDisplayMetrics().widthPixels / 2;
                    }
                    if (!gVar.q) {
                        Configuration configuration = context.getResources().getConfiguration();
                        int i3 = configuration.screenWidthDp;
                        int i4 = configuration.screenHeightDp;
                        if (configuration.smallestScreenWidthDp > 600 || i3 > 600 || ((i3 > 960 && i4 > 720) || (i3 > 720 && i4 > 960))) {
                            i2 = 5;
                        } else if (i3 >= 500 || ((i3 > 640 && i4 > 480) || (i3 > 480 && i4 > 640))) {
                            i2 = 4;
                        } else if (i3 >= 360) {
                            i2 = 3;
                        }
                        gVar.p = i2;
                    }
                    int i5 = gVar.n;
                    if (gVar.l) {
                        if (gVar.i == null) {
                            gVar.i = new C0044g.d(gVar.f241a);
                            if (gVar.k) {
                                gVar.i.setImageDrawable(gVar.j);
                                gVar.j = null;
                                gVar.k = false;
                            }
                            int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                            gVar.i.measure(makeMeasureSpec, makeMeasureSpec);
                        }
                        i5 -= gVar.i.getMeasuredWidth();
                    } else {
                        gVar.i = null;
                    }
                    gVar.o = i5;
                    gVar.u = (int) (resources.getDisplayMetrics().density * 56.0f);
                    a aVar = this.J;
                    Context context2 = this.j;
                    k kVar2 = aVar.f104a;
                    if (!(kVar2 == null || (oVar = aVar.f105b) == null)) {
                        kVar2.a(oVar);
                    }
                    aVar.f104a = null;
                    gVar.a(true);
                    a aVar2 = this.J;
                    if (aVar2.f105b != null) {
                        k kVar3 = aVar2.f104a;
                        if (kVar3 != null) {
                            int size = kVar3.size();
                            int i6 = 0;
                            while (true) {
                                if (i6 >= size) {
                                    break;
                                } else if (aVar2.f104a.getItem(i6) == aVar2.f105b) {
                                    break;
                                } else {
                                    i6++;
                                }
                            }
                        }
                        z2 = false;
                        if (!z2) {
                            k kVar4 = aVar2.f104a;
                            o oVar2 = aVar2.f105b;
                            View view = Toolbar.this.i;
                            if (view instanceof b.b.e.b) {
                                ((b.b.e.b) view).onActionViewCollapsed();
                            }
                            Toolbar toolbar = Toolbar.this;
                            toolbar.removeView(toolbar.i);
                            Toolbar toolbar2 = Toolbar.this;
                            toolbar2.removeView(toolbar2.h);
                            Toolbar toolbar3 = Toolbar.this;
                            toolbar3.i = null;
                            toolbar3.a();
                            aVar2.f105b = null;
                            Toolbar.this.requestLayout();
                            oVar2.D = false;
                            oVar2.n.b(false);
                        }
                    }
                }
                this.f101a.setPopupTheme(this.k);
                this.f101a.setPresenter(gVar);
                this.I = gVar;
            }
        }
    }
}
