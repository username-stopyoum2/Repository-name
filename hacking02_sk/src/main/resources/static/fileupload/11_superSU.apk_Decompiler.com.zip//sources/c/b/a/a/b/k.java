package c.b.a.a.b;

import a.a.a.a.c;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.Signature;
import android.util.Log;

public class k {

    /* renamed from: a  reason: collision with root package name */
    public static k f883a;

    public k(Context context) {
        context.getApplicationContext();
    }

    public static d a(PackageInfo packageInfo, d... dVarArr) {
        Signature[] signatureArr = packageInfo.signatures;
        if (signatureArr == null) {
            return null;
        }
        if (signatureArr.length != 1) {
            Log.w("GoogleSignatureVerifier", "Package has more than one signature.");
            return null;
        }
        e eVar = new e(signatureArr[0].toByteArray());
        for (int i = 0; i < dVarArr.length; i++) {
            if (dVarArr[i].equals(eVar)) {
                return dVarArr[i];
            }
        }
        return null;
    }

    public static k a(Context context) {
        c.b(context);
        synchronized (k.class) {
            if (f883a == null) {
                c.a(context);
                f883a = new k(context);
            }
        }
        return f883a;
    }
}
