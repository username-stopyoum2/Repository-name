package c.b.a.a.b;

import a.a.a.a.c;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public final class b implements ServiceConnection {

    /* renamed from: a  reason: collision with root package name */
    public boolean f872a = false;

    /* renamed from: b  reason: collision with root package name */
    public final BlockingQueue<IBinder> f873b = new LinkedBlockingQueue();

    public final IBinder a(long j, TimeUnit timeUnit) {
        c.c("BlockingServiceConnection.getServiceWithTimeout() called on main thread");
        if (!this.f872a) {
            this.f872a = true;
            IBinder poll = this.f873b.poll(10000, timeUnit);
            if (poll != null) {
                return poll;
            }
            throw new TimeoutException("Timed out waiting for the service connection");
        }
        throw new IllegalStateException("Cannot call get on this connection more than once");
    }

    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        this.f873b.add(iBinder);
    }

    public final void onServiceDisconnected(ComponentName componentName) {
    }
}
