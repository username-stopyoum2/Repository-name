package b.h.a;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

/* renamed from: b.h.a.m  reason: case insensitive filesystem */
public abstract class C0082m {

    /* renamed from: a  reason: collision with root package name */
    public static final C0080k f755a = new C0080k();

    /* renamed from: b  reason: collision with root package name */
    public C0080k f756b = null;

    /* renamed from: b.h.a.m$a */
    public interface a {
    }

    /* renamed from: b.h.a.m$b */
    public static abstract class b {
    }

    /* renamed from: b.h.a.m$c */
    public interface c {
        void onBackStackChanged();
    }

    public abstract List<C0076g> a();

    public abstract void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public abstract boolean b();
}
