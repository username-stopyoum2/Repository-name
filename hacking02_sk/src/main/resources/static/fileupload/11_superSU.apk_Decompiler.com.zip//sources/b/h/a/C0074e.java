package b.h.a;

/* renamed from: b.h.a.e  reason: case insensitive filesystem */
class C0074e implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0076g f742a;

    public C0074e(C0076g gVar) {
        this.f742a = gVar;
    }

    public void run() {
        this.f742a.e();
    }
}
