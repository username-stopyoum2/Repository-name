package b.h.a;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

@SuppressLint({"BanParcelableUsage"})
public final class w implements Parcelable {
    public static final Parcelable.Creator<w> CREATOR = new v();

    /* renamed from: a  reason: collision with root package name */
    public ArrayList<A> f782a;

    /* renamed from: b  reason: collision with root package name */
    public ArrayList<String> f783b;

    /* renamed from: c  reason: collision with root package name */
    public C0072c[] f784c;
    public String d = null;
    public int e;

    public w() {
    }

    public w(Parcel parcel) {
        this.f782a = parcel.createTypedArrayList(A.CREATOR);
        this.f783b = parcel.createStringArrayList();
        this.f784c = (C0072c[]) parcel.createTypedArray(C0072c.CREATOR);
        this.d = parcel.readString();
        this.e = parcel.readInt();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedList(this.f782a);
        parcel.writeStringList(this.f783b);
        parcel.writeTypedArray(this.f784c, i);
        parcel.writeString(this.d);
        parcel.writeInt(this.e);
    }
}
