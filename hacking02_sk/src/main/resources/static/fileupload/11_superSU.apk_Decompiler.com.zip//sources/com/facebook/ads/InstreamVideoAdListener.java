package com.facebook.ads;

import androidx.annotation.Keep;

@Deprecated
@Keep
public interface InstreamVideoAdListener extends AdListener {
    void onAdVideoComplete(Ad ad);
}
