package b.h.a;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

/* renamed from: b.h.a.i  reason: case insensitive filesystem */
public abstract class C0078i {
    public abstract View a(int i);

    @Deprecated
    public C0076g a(Context context, String str, Bundle bundle) {
        return C0076g.a(context, str, bundle);
    }

    public abstract boolean c();
}
