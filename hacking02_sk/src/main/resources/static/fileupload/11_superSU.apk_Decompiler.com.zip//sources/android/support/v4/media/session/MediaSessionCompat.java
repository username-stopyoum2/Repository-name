package android.support.v4.media.session;

import a.a.a.a.a.b;
import android.media.session.MediaSession;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.ResultReceiver;
import android.support.v4.media.MediaDescriptionCompat;
import c.a.a.a.a;
import java.util.ArrayList;
import java.util.List;

public class MediaSessionCompat {

    public static final class QueueItem implements Parcelable {
        public static final Parcelable.Creator<QueueItem> CREATOR = new h();

        /* renamed from: a  reason: collision with root package name */
        public final MediaDescriptionCompat f30a;

        /* renamed from: b  reason: collision with root package name */
        public final long f31b;

        public QueueItem(Parcel parcel) {
            this.f30a = MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
            this.f31b = parcel.readLong();
        }

        public QueueItem(Object obj, MediaDescriptionCompat mediaDescriptionCompat, long j) {
            if (mediaDescriptionCompat == null) {
                throw new IllegalArgumentException("Description cannot be null.");
            } else if (j != -1) {
                this.f30a = mediaDescriptionCompat;
                this.f31b = j;
            } else {
                throw new IllegalArgumentException("Id cannot be QueueItem.UNKNOWN_ID");
            }
        }

        public static List<QueueItem> a(List<?> list) {
            QueueItem queueItem;
            if (list == null || Build.VERSION.SDK_INT < 21) {
                return null;
            }
            ArrayList arrayList = new ArrayList();
            for (Object next : list) {
                if (next == null || Build.VERSION.SDK_INT < 21) {
                    queueItem = null;
                } else {
                    MediaSession.QueueItem queueItem2 = (MediaSession.QueueItem) next;
                    queueItem = new QueueItem(next, MediaDescriptionCompat.a(queueItem2.getDescription()), queueItem2.getQueueId());
                }
                arrayList.add(queueItem);
            }
            return arrayList;
        }

        public int describeContents() {
            return 0;
        }

        public String toString() {
            StringBuilder a2 = a.a("MediaSession.QueueItem {Description=");
            a2.append(this.f30a);
            a2.append(", Id=");
            a2.append(this.f31b);
            a2.append(" }");
            return a2.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            this.f30a.writeToParcel(parcel, i);
            parcel.writeLong(this.f31b);
        }
    }

    public static final class ResultReceiverWrapper implements Parcelable {
        public static final Parcelable.Creator<ResultReceiverWrapper> CREATOR = new i();

        /* renamed from: a  reason: collision with root package name */
        public ResultReceiver f32a;

        public ResultReceiverWrapper(Parcel parcel) {
            this.f32a = (ResultReceiver) ResultReceiver.CREATOR.createFromParcel(parcel);
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            this.f32a.writeToParcel(parcel, i);
        }
    }

    public static final class Token implements Parcelable {
        public static final Parcelable.Creator<Token> CREATOR = new j();

        /* renamed from: a  reason: collision with root package name */
        public final Object f33a;

        /* renamed from: b  reason: collision with root package name */
        public b f34b = null;

        public Token(Object obj) {
            this.f33a = obj;
        }

        public b a() {
            return this.f34b;
        }

        public void a(b bVar) {
            this.f34b = bVar;
        }

        public void a(Bundle bundle) {
        }

        public int describeContents() {
            return 0;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Token)) {
                return false;
            }
            Token token = (Token) obj;
            Object obj2 = this.f33a;
            if (obj2 == null) {
                return token.f33a == null;
            }
            Object obj3 = token.f33a;
            if (obj3 == null) {
                return false;
            }
            return obj2.equals(obj3);
        }

        public int hashCode() {
            Object obj = this.f33a;
            if (obj == null) {
                return 0;
            }
            return obj.hashCode();
        }

        public void writeToParcel(Parcel parcel, int i) {
            if (Build.VERSION.SDK_INT >= 21) {
                parcel.writeParcelable((Parcelable) this.f33a, i);
            } else {
                parcel.writeStrongBinder((IBinder) this.f33a);
            }
        }
    }
}
