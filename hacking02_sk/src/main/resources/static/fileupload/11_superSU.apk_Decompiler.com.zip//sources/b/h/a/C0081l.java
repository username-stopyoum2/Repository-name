package b.h.a;

import a.a.a.a.c;
import android.app.Activity;
import android.content.Context;
import android.os.Handler;

/* renamed from: b.h.a.l  reason: case insensitive filesystem */
public abstract class C0081l<E> extends C0078i {

    /* renamed from: a  reason: collision with root package name */
    public final Activity f752a;

    /* renamed from: b  reason: collision with root package name */
    public final Context f753b;

    /* renamed from: c  reason: collision with root package name */
    public final Handler f754c;
    public final int d;
    public final u e = new u();

    public C0081l(C0077h hVar) {
        Handler handler = new Handler();
        this.f752a = hVar;
        c.a(hVar, (Object) "context == null");
        this.f753b = hVar;
        c.a(handler, (Object) "handler == null");
        this.f754c = handler;
        this.d = 0;
    }
}
