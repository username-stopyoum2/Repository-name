package c.c.a;

import android.content.DialogInterface;
import com.sahani2020.suCheckerRoot.MainActivity;

class b implements DialogInterface.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ MainActivity f905a;

    public b(MainActivity mainActivity) {
        this.f905a = mainActivity;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        this.f905a.C.destroy();
        this.f905a.o();
    }
}
