package android.support.v4.media;

import a.a.a.b.c;
import android.os.Bundle;
import android.os.Parcelable;

public class MediaBrowserCompat$ItemReceiver extends c {

    /* renamed from: c  reason: collision with root package name */
    public final String f15c;

    public void a(int i, Bundle bundle) {
        a.a.a.a.c.a(bundle);
        if (i != 0 || bundle == null || !bundle.containsKey("media_item")) {
            String str = this.f15c;
            throw null;
        }
        Parcelable parcelable = bundle.getParcelable("media_item");
        if (parcelable == null || (parcelable instanceof MediaBrowserCompat$MediaItem)) {
            MediaBrowserCompat$MediaItem mediaBrowserCompat$MediaItem = (MediaBrowserCompat$MediaItem) parcelable;
            throw null;
        } else {
            String str2 = this.f15c;
            throw null;
        }
    }
}
