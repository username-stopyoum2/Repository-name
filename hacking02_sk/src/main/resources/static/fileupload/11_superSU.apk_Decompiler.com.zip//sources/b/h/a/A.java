package b.h.a;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint({"BanParcelableUsage"})
public final class A implements Parcelable {
    public static final Parcelable.Creator<A> CREATOR = new z();

    /* renamed from: a  reason: collision with root package name */
    public final String f698a;

    /* renamed from: b  reason: collision with root package name */
    public final String f699b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f700c;
    public final int d;
    public final int e;
    public final String f;
    public final boolean g;
    public final boolean h;
    public final boolean i;
    public final Bundle j;
    public final boolean k;
    public final int l;
    public Bundle m;
    public C0076g n;

    public A(Parcel parcel) {
        this.f698a = parcel.readString();
        this.f699b = parcel.readString();
        boolean z = true;
        this.f700c = parcel.readInt() != 0;
        this.d = parcel.readInt();
        this.e = parcel.readInt();
        this.f = parcel.readString();
        this.g = parcel.readInt() != 0;
        this.h = parcel.readInt() != 0;
        this.i = parcel.readInt() != 0;
        this.j = parcel.readBundle();
        this.k = parcel.readInt() == 0 ? false : z;
        this.m = parcel.readBundle();
        this.l = parcel.readInt();
    }

    public A(C0076g gVar) {
        this.f698a = gVar.getClass().getName();
        this.f699b = gVar.f;
        this.f700c = gVar.n;
        this.d = gVar.w;
        this.e = gVar.x;
        this.f = gVar.y;
        this.g = gVar.B;
        this.h = gVar.m;
        this.i = gVar.A;
        this.j = gVar.g;
        this.k = gVar.z;
        this.l = gVar.R.ordinal();
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentState{");
        sb.append(this.f698a);
        sb.append(" (");
        sb.append(this.f699b);
        sb.append(")}:");
        if (this.f700c) {
            sb.append(" fromLayout");
        }
        if (this.e != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.e));
        }
        String str = this.f;
        if (str != null && !str.isEmpty()) {
            sb.append(" tag=");
            sb.append(this.f);
        }
        if (this.g) {
            sb.append(" retainInstance");
        }
        if (this.h) {
            sb.append(" removing");
        }
        if (this.i) {
            sb.append(" detached");
        }
        if (this.k) {
            sb.append(" hidden");
        }
        return sb.toString();
    }

    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeString(this.f698a);
        parcel.writeString(this.f699b);
        parcel.writeInt(this.f700c ? 1 : 0);
        parcel.writeInt(this.d);
        parcel.writeInt(this.e);
        parcel.writeString(this.f);
        parcel.writeInt(this.g ? 1 : 0);
        parcel.writeInt(this.h ? 1 : 0);
        parcel.writeInt(this.i ? 1 : 0);
        parcel.writeBundle(this.j);
        parcel.writeInt(this.k ? 1 : 0);
        parcel.writeBundle(this.m);
        parcel.writeInt(this.l);
    }
}
