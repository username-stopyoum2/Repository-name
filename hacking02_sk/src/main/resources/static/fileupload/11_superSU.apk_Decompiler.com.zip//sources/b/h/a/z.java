package b.h.a;

import android.os.Parcel;
import android.os.Parcelable;

class z implements Parcelable.Creator<A> {
    public Object createFromParcel(Parcel parcel) {
        return new A(parcel);
    }

    public Object[] newArray(int i) {
        return new A[i];
    }
}
