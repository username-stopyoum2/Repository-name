package c.b.a.a.b;

import java.util.Arrays;

public final class e extends d {

    /* renamed from: b  reason: collision with root package name */
    public final byte[] f878b;

    public e(byte[] bArr) {
        super(Arrays.copyOfRange(bArr, 0, 25));
        this.f878b = bArr;
    }

    public final byte[] b() {
        return this.f878b;
    }
}
