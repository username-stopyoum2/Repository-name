package b.h.a;

import android.graphics.Rect;
import android.transition.Transition;

class K extends Transition.EpicenterCallback {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Rect f729a;

    public K(L l, Rect rect) {
        this.f729a = rect;
    }

    public Rect onGetEpicenter(Transition transition) {
        Rect rect = this.f729a;
        if (rect == null || rect.isEmpty()) {
            return null;
        }
        return this.f729a;
    }
}
