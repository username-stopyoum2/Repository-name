package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.style.ClickableSpan;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import androidx.appcompat.app.AlertController;
import b.b.a.C0025d;
import b.e.h.C0069a;
import b.e.h.a.b;
import b.e.h.d;
import b.e.h.f;
import b.e.h.g;
import b.e.h.h;
import b.e.h.i;
import b.e.h.j;
import b.e.h.m;
import b.e.h.s;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

public class NestedScrollView extends FrameLayout implements h, d, m {

    /* renamed from: a  reason: collision with root package name */
    public static final a f118a = new a();

    /* renamed from: b  reason: collision with root package name */
    public static final int[] f119b = {16843130};
    public float A;
    public b B;

    /* renamed from: c  reason: collision with root package name */
    public long f120c;
    public final Rect d;
    public OverScroller e;
    public EdgeEffect f;
    public EdgeEffect g;
    public int h;
    public boolean i;
    public boolean j;
    public View k;
    public boolean l;
    public VelocityTracker m;
    public boolean n;
    public boolean o;
    public int p;
    public int q;
    public int r;
    public int s;
    public final int[] t;
    public final int[] u;
    public int v;
    public int w;
    public c x;
    public final j y;
    public final f z;

    public interface b {
    }

    static class c extends View.BaseSavedState {
        public static final Parcelable.Creator<c> CREATOR = new d();

        /* renamed from: a  reason: collision with root package name */
        public int f121a;

        public c(Parcel parcel) {
            super(parcel);
            this.f121a = parcel.readInt();
        }

        public c(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder a2 = c.a.a.a.a.a("HorizontalScrollView.SavedState{");
            a2.append(Integer.toHexString(System.identityHashCode(this)));
            a2.append(" scrollPosition=");
            a2.append(this.f121a);
            a2.append("}");
            return a2.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f121a);
        }
    }

    public NestedScrollView(Context context) {
        this(context, (AttributeSet) null, 0);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public static int a(int i2, int i3, int i4) {
        if (i3 >= i4 || i2 < 0) {
            return 0;
        }
        return i3 + i2 > i4 ? i4 - i3 : i2;
    }

    public static boolean a(View view, View view2) {
        if (view == view2) {
            return true;
        }
        ViewParent parent = view.getParent();
        return (parent instanceof ViewGroup) && a((View) parent, view2);
    }

    private float getVerticalScrollFactorCompat() {
        if (this.A == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
                this.A = typedValue.getDimension(context.getResources().getDisplayMetrics());
            } else {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
        }
        return this.A;
    }

    public int a(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i2 = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i3 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i2 - verticalFadingEdgeLength : i2;
        if (rect.bottom > i3 && rect.top > scrollY) {
            return Math.min((rect.height() > height ? rect.top - scrollY : rect.bottom - i3) + 0, (childAt.getBottom() + layoutParams.bottomMargin) - i2);
        } else if (rect.top >= scrollY || rect.bottom >= i3) {
            return 0;
        } else {
            return Math.max(rect.height() > height ? 0 - (i3 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
        }
    }

    public final void a() {
        this.e.abortAnimation();
        g(1);
    }

    public final void a(int i2, int i3) {
        if (getChildCount() != 0) {
            if (AnimationUtils.currentAnimationTimeMillis() - this.f120c > 250) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                int height = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
                int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
                int scrollY = getScrollY();
                OverScroller overScroller = this.e;
                int scrollX = getScrollX();
                overScroller.startScroll(scrollX, scrollY, 0, Math.max(0, Math.min(i3 + scrollY, Math.max(0, height - height2))) - scrollY);
                a(false);
            } else {
                if (!this.e.isFinished()) {
                    a();
                }
                scrollBy(i2, i3);
            }
            this.f120c = AnimationUtils.currentAnimationTimeMillis();
        }
    }

    public final void a(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.s) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.h = (int) motionEvent.getY(i2);
            this.s = motionEvent.getPointerId(i2);
            VelocityTracker velocityTracker = this.m;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    public final void a(View view) {
        view.getDrawingRect(this.d);
        offsetDescendantRectToMyCoords(view, this.d);
        int a2 = a(this.d);
        if (a2 != 0) {
            scrollBy(0, a2);
        }
    }

    public void a(View view, int i2, int i3, int i4, int i5, int i6) {
        a(i5, i6, (int[]) null);
    }

    public void a(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        a(i5, i6, iArr);
    }

    public void a(View view, int i2, int i3, int[] iArr, int i4) {
        a(i2, i3, iArr, (int[]) null, i4);
    }

    public final void a(boolean z2) {
        if (z2) {
            c(2, 1);
        } else {
            g(1);
        }
        this.w = getScrollY();
        s.n(this);
    }

    public boolean a(int i2) {
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i2);
        int maxScrollAmount = getMaxScrollAmount();
        if (findNextFocus == null || !a(findNextFocus, maxScrollAmount, getHeight())) {
            if (i2 == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i2 == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i2 != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            b(maxScrollAmount);
        } else {
            findNextFocus.getDrawingRect(this.d);
            offsetDescendantRectToMyCoords(findNextFocus, this.d);
            b(a(this.d));
            findNextFocus.requestFocus(i2);
        }
        if (findFocus != null && findFocus.isFocused() && (!a(findFocus, 0, getHeight()))) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:33:0x0057  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x005a  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0083 A[ADDED_TO_REGION] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean a(int r13, int r14, int r15, int r16, int r17, int r18, int r19, int r20, boolean r21) {
        /*
            r12 = this;
            r0 = r12
            int r1 = r12.getOverScrollMode()
            int r2 = r12.computeHorizontalScrollRange()
            int r3 = r12.computeHorizontalScrollExtent()
            r4 = 0
            r5 = 1
            if (r2 <= r3) goto L_0x0013
            r2 = 1
            goto L_0x0014
        L_0x0013:
            r2 = 0
        L_0x0014:
            int r3 = r12.computeVerticalScrollRange()
            int r6 = r12.computeVerticalScrollExtent()
            if (r3 <= r6) goto L_0x0020
            r3 = 1
            goto L_0x0021
        L_0x0020:
            r3 = 0
        L_0x0021:
            if (r1 == 0) goto L_0x002a
            if (r1 != r5) goto L_0x0028
            if (r2 == 0) goto L_0x0028
            goto L_0x002a
        L_0x0028:
            r2 = 0
            goto L_0x002b
        L_0x002a:
            r2 = 1
        L_0x002b:
            if (r1 == 0) goto L_0x0034
            if (r1 != r5) goto L_0x0032
            if (r3 == 0) goto L_0x0032
            goto L_0x0034
        L_0x0032:
            r1 = 0
            goto L_0x0035
        L_0x0034:
            r1 = 1
        L_0x0035:
            int r3 = r15 + r13
            if (r2 != 0) goto L_0x003b
            r2 = 0
            goto L_0x003d
        L_0x003b:
            r2 = r19
        L_0x003d:
            int r6 = r16 + r14
            if (r1 != 0) goto L_0x0043
            r1 = 0
            goto L_0x0045
        L_0x0043:
            r1 = r20
        L_0x0045:
            int r7 = -r2
            int r2 = r2 + r17
            int r8 = -r1
            int r1 = r1 + r18
            if (r3 <= r2) goto L_0x0050
            r7 = r2
        L_0x004e:
            r2 = 1
            goto L_0x0055
        L_0x0050:
            if (r3 >= r7) goto L_0x0053
            goto L_0x004e
        L_0x0053:
            r7 = r3
            r2 = 0
        L_0x0055:
            if (r6 <= r1) goto L_0x005a
            r6 = r1
        L_0x0058:
            r1 = 1
            goto L_0x005f
        L_0x005a:
            if (r6 >= r8) goto L_0x005e
            r6 = r8
            goto L_0x0058
        L_0x005e:
            r1 = 0
        L_0x005f:
            if (r1 == 0) goto L_0x007e
            boolean r3 = r12.e(r5)
            if (r3 != 0) goto L_0x007e
            android.widget.OverScroller r3 = r0.e
            r8 = 0
            r9 = 0
            r10 = 0
            int r11 = r12.getScrollRange()
            r13 = r3
            r14 = r7
            r15 = r6
            r16 = r8
            r17 = r9
            r18 = r10
            r19 = r11
            r13.springBack(r14, r15, r16, r17, r18, r19)
        L_0x007e:
            r12.onOverScrolled(r7, r6, r2, r1)
            if (r2 != 0) goto L_0x0085
            if (r1 == 0) goto L_0x0086
        L_0x0085:
            r4 = 1
        L_0x0086:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.a(int, int, int, int, int, int, int, int, boolean):boolean");
    }

    public final boolean a(View view, int i2, int i3) {
        view.getDrawingRect(this.d);
        offsetDescendantRectToMyCoords(view, this.d);
        return this.d.bottom + i2 >= getScrollY() && this.d.top - i2 <= getScrollY() + i3;
    }

    public boolean a(View view, View view2, int i2, int i3) {
        return (i2 & 2) != 0;
    }

    public void addView(View view) {
        if (getChildCount() <= 0) {
            super.addView(view);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, int i2) {
        if (getChildCount() <= 0) {
            super.addView(view, i2);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i2, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public final void b() {
        if (getOverScrollMode() == 2) {
            this.f = null;
            this.g = null;
        } else if (this.f == null) {
            Context context = getContext();
            this.f = new EdgeEffect(context);
            this.g = new EdgeEffect(context);
        }
    }

    public final void b(int i2) {
        if (i2 == 0) {
            return;
        }
        if (this.o) {
            a(0, i2);
        } else {
            scrollBy(0, i2);
        }
    }

    public final void b(int i2, int i3) {
        a(i2 - getScrollX(), i3 - getScrollY());
    }

    public void b(View view, View view2, int i2, int i3) {
        j jVar = this.y;
        if (i3 == 1) {
            jVar.f657b = i2;
        } else {
            jVar.f656a = i2;
        }
        c(2, i3);
    }

    public final void c() {
        VelocityTracker velocityTracker = this.m;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.m = null;
        }
    }

    public void c(int i2) {
        if (getChildCount() > 0) {
            this.e.fling(getScrollX(), getScrollY(), 0, i2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            a(true);
        }
    }

    public boolean c(int i2, int i3) {
        boolean z2;
        f fVar = this.z;
        if (fVar.b(i3)) {
            return true;
        }
        if (fVar.d) {
            ViewParent parent = fVar.f655c.getParent();
            View view = fVar.f655c;
            while (parent != null) {
                View view2 = fVar.f655c;
                boolean z3 = parent instanceof g;
                if (z3) {
                    z2 = ((g) parent).a(view, view2, i2, i3);
                } else {
                    if (i3 == 0) {
                        if (Build.VERSION.SDK_INT >= 21) {
                            try {
                                z2 = parent.onStartNestedScroll(view, view2, i2);
                            } catch (AbstractMethodError e2) {
                                c.a.a.a.a.a("ViewParent ", parent, " does not implement interface method onStartNestedScroll", "ViewParentCompat", e2);
                            }
                        } else if (parent instanceof i) {
                            z2 = ((i) parent).onStartNestedScroll(view, view2, i2);
                        }
                    }
                    z2 = false;
                }
                if (z2) {
                    fVar.a(i3, parent);
                    View view3 = fVar.f655c;
                    if (z3) {
                        ((g) parent).b(view, view3, i2, i3);
                        return true;
                    } else if (i3 != 0) {
                        return true;
                    } else {
                        if (Build.VERSION.SDK_INT >= 21) {
                            try {
                                parent.onNestedScrollAccepted(view, view3, i2);
                                return true;
                            } catch (AbstractMethodError e3) {
                                c.a.a.a.a.a("ViewParent ", parent, " does not implement interface method onNestedScrollAccepted", "ViewParentCompat", e3);
                                return true;
                            }
                        } else if (!(parent instanceof i)) {
                            return true;
                        } else {
                            ((i) parent).onNestedScrollAccepted(view, view3, i2);
                            return true;
                        }
                    }
                } else {
                    if (parent instanceof View) {
                        view = (View) parent;
                    }
                    parent = parent.getParent();
                }
            }
        }
        return false;
    }

    public int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    public int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    public int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    public void computeScroll() {
        EdgeEffect edgeEffect;
        if (!this.e.isFinished()) {
            this.e.computeScrollOffset();
            int currY = this.e.getCurrY();
            int i2 = currY - this.w;
            this.w = currY;
            int[] iArr = this.u;
            boolean z2 = false;
            iArr[1] = 0;
            a(0, i2, iArr, (int[]) null, 1);
            int i3 = i2 - this.u[1];
            int scrollRange = getScrollRange();
            if (i3 != 0) {
                int scrollY = getScrollY();
                a(0, i3, getScrollX(), scrollY, 0, scrollRange, 0, 0, false);
                int scrollY2 = getScrollY() - scrollY;
                int i4 = i3 - scrollY2;
                int[] iArr2 = this.u;
                iArr2[1] = 0;
                a(0, scrollY2, 0, i4, this.t, 1, iArr2);
                i3 = i4 - this.u[1];
            }
            if (i3 != 0) {
                int overScrollMode = getOverScrollMode();
                if (overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0)) {
                    z2 = true;
                }
                if (z2) {
                    b();
                    if (i3 < 0) {
                        if (this.f.isFinished()) {
                            edgeEffect = this.f;
                        }
                    } else if (this.g.isFinished()) {
                        edgeEffect = this.g;
                    }
                    edgeEffect.onAbsorb((int) this.e.getCurrVelocity());
                }
                a();
            }
            if (!this.e.isFinished()) {
                s.n(this);
            }
        }
    }

    public int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    public int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    public int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int max = Math.max(0, bottom - height);
        return scrollY < 0 ? bottom - scrollY : scrollY > max ? bottom + (scrollY - max) : bottom;
    }

    public boolean d(int i2) {
        int childCount;
        boolean z2 = i2 == 130;
        int height = getHeight();
        Rect rect = this.d;
        rect.top = 0;
        rect.bottom = height;
        if (z2 && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            this.d.bottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            Rect rect2 = this.d;
            rect2.top = rect2.bottom - height;
        }
        Rect rect3 = this.d;
        return b(i2, rect3.top, rect3.bottom);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || a(keyEvent);
    }

    public boolean dispatchNestedFling(float f2, float f3, boolean z2) {
        ViewParent a2;
        f fVar = this.z;
        if (!fVar.d || (a2 = fVar.a(0)) == null) {
            return false;
        }
        View view = fVar.f655c;
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                return a2.onNestedFling(view, f2, f3, z2);
            } catch (AbstractMethodError e2) {
                c.a.a.a.a.a("ViewParent ", a2, " does not implement interface method onNestedFling", "ViewParentCompat", e2);
                return false;
            }
        } else if (a2 instanceof i) {
            return ((i) a2).onNestedFling(view, f2, f3, z2);
        } else {
            return false;
        }
    }

    public boolean dispatchNestedPreFling(float f2, float f3) {
        ViewParent a2;
        f fVar = this.z;
        if (!fVar.d || (a2 = fVar.a(0)) == null) {
            return false;
        }
        View view = fVar.f655c;
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                return a2.onNestedPreFling(view, f2, f3);
            } catch (AbstractMethodError e2) {
                c.a.a.a.a.a("ViewParent ", a2, " does not implement interface method onNestedPreFling", "ViewParentCompat", e2);
                return false;
            }
        } else if (a2 instanceof i) {
            return ((i) a2).onNestedPreFling(view, f2, f3);
        } else {
            return false;
        }
    }

    public boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return a(i2, i3, iArr, iArr2, 0);
    }

    public boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return this.z.a(i2, i3, i4, i5, iArr, 0, (int[]) null);
    }

    public void draw(Canvas canvas) {
        int i2;
        super.draw(canvas);
        if (this.f != null) {
            int scrollY = getScrollY();
            int i3 = 0;
            if (!this.f.isFinished()) {
                int save = canvas.save();
                int width = getWidth();
                int height = getHeight();
                int min = Math.min(0, scrollY);
                if (Build.VERSION.SDK_INT < 21 || getClipToPadding()) {
                    width -= getPaddingRight() + getPaddingLeft();
                    i2 = getPaddingLeft() + 0;
                } else {
                    i2 = 0;
                }
                if (Build.VERSION.SDK_INT >= 21 && getClipToPadding()) {
                    height -= getPaddingBottom() + getPaddingTop();
                    min += getPaddingTop();
                }
                canvas.translate((float) i2, (float) min);
                this.f.setSize(width, height);
                if (this.f.draw(canvas)) {
                    s.n(this);
                }
                canvas.restoreToCount(save);
            }
            if (!this.g.isFinished()) {
                int save2 = canvas.save();
                int width2 = getWidth();
                int height2 = getHeight();
                int max = Math.max(getScrollRange(), scrollY) + height2;
                if (Build.VERSION.SDK_INT < 21 || getClipToPadding()) {
                    width2 -= getPaddingRight() + getPaddingLeft();
                    i3 = 0 + getPaddingLeft();
                }
                if (Build.VERSION.SDK_INT >= 21 && getClipToPadding()) {
                    height2 -= getPaddingBottom() + getPaddingTop();
                    max -= getPaddingBottom();
                }
                canvas.translate((float) (i3 - width2), (float) max);
                canvas.rotate(180.0f, (float) width2, 0.0f);
                this.g.setSize(width2, height2);
                if (this.g.draw(canvas)) {
                    s.n(this);
                }
                canvas.restoreToCount(save2);
            }
        }
    }

    public boolean e(int i2) {
        return this.z.a(i2) != null;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x004b, code lost:
        if (r0.top < 0) goto L_0x004d;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean f(int r5) {
        /*
            r4 = this;
            r0 = 1
            r1 = 0
            r2 = 130(0x82, float:1.82E-43)
            if (r5 != r2) goto L_0x0008
            r2 = 1
            goto L_0x0009
        L_0x0008:
            r2 = 0
        L_0x0009:
            int r3 = r4.getHeight()
            if (r2 == 0) goto L_0x003e
            android.graphics.Rect r1 = r4.d
            int r2 = r4.getScrollY()
            int r2 = r2 + r3
            r1.top = r2
            int r1 = r4.getChildCount()
            if (r1 <= 0) goto L_0x004f
            int r1 = r1 - r0
            android.view.View r0 = r4.getChildAt(r1)
            android.view.ViewGroup$LayoutParams r1 = r0.getLayoutParams()
            android.widget.FrameLayout$LayoutParams r1 = (android.widget.FrameLayout.LayoutParams) r1
            int r0 = r0.getBottom()
            int r1 = r1.bottomMargin
            int r0 = r0 + r1
            int r1 = r4.getPaddingBottom()
            int r1 = r1 + r0
            android.graphics.Rect r0 = r4.d
            int r2 = r0.top
            int r2 = r2 + r3
            if (r2 <= r1) goto L_0x004f
            int r1 = r1 - r3
            goto L_0x004d
        L_0x003e:
            android.graphics.Rect r0 = r4.d
            int r2 = r4.getScrollY()
            int r2 = r2 - r3
            r0.top = r2
            android.graphics.Rect r0 = r4.d
            int r2 = r0.top
            if (r2 >= 0) goto L_0x004f
        L_0x004d:
            r0.top = r1
        L_0x004f:
            android.graphics.Rect r0 = r4.d
            int r1 = r0.top
            int r3 = r3 + r1
            r0.bottom = r3
            int r0 = r0.bottom
            boolean r5 = r4.b(r5, r1, r0)
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.f(int):boolean");
    }

    public void g(int i2) {
        f fVar = this.z;
        ViewParent a2 = fVar.a(i2);
        if (a2 != null) {
            View view = fVar.f655c;
            if (a2 instanceof g) {
                ((g) a2).a(view, i2);
            } else if (i2 == 0) {
                if (Build.VERSION.SDK_INT >= 21) {
                    try {
                        a2.onStopNestedScroll(view);
                    } catch (AbstractMethodError e2) {
                        c.a.a.a.a.a("ViewParent ", a2, " does not implement interface method onStopNestedScroll", "ViewParentCompat", e2);
                    }
                } else if (a2 instanceof i) {
                    ((i) a2).onStopNestedScroll(view);
                }
            }
            fVar.a(i2, (ViewParent) null);
        }
    }

    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return ((float) bottom) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (((float) getHeight()) * 0.5f);
    }

    public int getNestedScrollAxes() {
        j jVar = this.y;
        return jVar.f657b | jVar.f656a;
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return ((float) scrollY) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public boolean hasNestedScrollingParent() {
        return e(0);
    }

    public boolean isNestedScrollingEnabled() {
        return this.z.d;
    }

    public void measureChild(View view, int i2, int i3) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(FrameLayout.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    public void measureChildWithMargins(View view, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(FrameLayout.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.j = false;
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if ((motionEvent.getSource() & 2) != 0 && motionEvent.getAction() == 8 && !this.l) {
            float axisValue = motionEvent.getAxisValue(9);
            if (axisValue != 0.0f) {
                int scrollRange = getScrollRange();
                int scrollY = getScrollY();
                int verticalScrollFactorCompat = scrollY - ((int) (axisValue * getVerticalScrollFactorCompat()));
                if (verticalScrollFactorCompat < 0) {
                    verticalScrollFactorCompat = 0;
                } else if (verticalScrollFactorCompat > scrollRange) {
                    verticalScrollFactorCompat = scrollRange;
                }
                if (verticalScrollFactorCompat != scrollY) {
                    super.scrollTo(getScrollX(), verticalScrollFactorCompat);
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:47:0x00e1  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00e7  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onInterceptTouchEvent(android.view.MotionEvent r12) {
        /*
            r11 = this;
            int r0 = r12.getAction()
            r1 = 1
            r2 = 2
            if (r0 != r2) goto L_0x000d
            boolean r3 = r11.l
            if (r3 == 0) goto L_0x000d
            return r1
        L_0x000d:
            r0 = r0 & 255(0xff, float:3.57E-43)
            r3 = 0
            if (r0 == 0) goto L_0x00aa
            r4 = -1
            if (r0 == r1) goto L_0x0085
            if (r0 == r2) goto L_0x0024
            r1 = 3
            if (r0 == r1) goto L_0x0085
            r1 = 6
            if (r0 == r1) goto L_0x001f
            goto L_0x0113
        L_0x001f:
            r11.a((android.view.MotionEvent) r12)
            goto L_0x0113
        L_0x0024:
            int r0 = r11.s
            if (r0 != r4) goto L_0x002a
            goto L_0x0113
        L_0x002a:
            int r5 = r12.findPointerIndex(r0)
            if (r5 != r4) goto L_0x004d
            java.lang.StringBuilder r12 = new java.lang.StringBuilder
            r12.<init>()
            java.lang.String r1 = "Invalid pointerId="
            r12.append(r1)
            r12.append(r0)
            java.lang.String r0 = " in onInterceptTouchEvent"
            r12.append(r0)
            java.lang.String r12 = r12.toString()
            java.lang.String r0 = "NestedScrollView"
            android.util.Log.e(r0, r12)
            goto L_0x0113
        L_0x004d:
            float r0 = r12.getY(r5)
            int r0 = (int) r0
            int r4 = r11.h
            int r4 = r0 - r4
            int r4 = java.lang.Math.abs(r4)
            int r5 = r11.p
            if (r4 <= r5) goto L_0x0113
            int r4 = r11.getNestedScrollAxes()
            r2 = r2 & r4
            if (r2 != 0) goto L_0x0113
            r11.l = r1
            r11.h = r0
            android.view.VelocityTracker r0 = r11.m
            if (r0 != 0) goto L_0x0073
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r11.m = r0
        L_0x0073:
            android.view.VelocityTracker r0 = r11.m
            r0.addMovement(r12)
            r11.v = r3
            android.view.ViewParent r12 = r11.getParent()
            if (r12 == 0) goto L_0x0113
            r12.requestDisallowInterceptTouchEvent(r1)
            goto L_0x0113
        L_0x0085:
            r11.l = r3
            r11.s = r4
            r11.c()
            android.widget.OverScroller r4 = r11.e
            int r5 = r11.getScrollX()
            int r6 = r11.getScrollY()
            r7 = 0
            r8 = 0
            r9 = 0
            int r10 = r11.getScrollRange()
            boolean r12 = r4.springBack(r5, r6, r7, r8, r9, r10)
            if (r12 == 0) goto L_0x00a6
            b.e.h.s.n(r11)
        L_0x00a6:
            r11.g(r3)
            goto L_0x0113
        L_0x00aa:
            float r0 = r12.getY()
            int r0 = (int) r0
            float r4 = r12.getX()
            int r4 = (int) r4
            int r5 = r11.getChildCount()
            if (r5 <= 0) goto L_0x00de
            int r5 = r11.getScrollY()
            android.view.View r6 = r11.getChildAt(r3)
            int r7 = r6.getTop()
            int r7 = r7 - r5
            if (r0 < r7) goto L_0x00de
            int r7 = r6.getBottom()
            int r7 = r7 - r5
            if (r0 >= r7) goto L_0x00de
            int r5 = r6.getLeft()
            if (r4 < r5) goto L_0x00de
            int r5 = r6.getRight()
            if (r4 >= r5) goto L_0x00de
            r4 = 1
            goto L_0x00df
        L_0x00de:
            r4 = 0
        L_0x00df:
            if (r4 != 0) goto L_0x00e7
            r11.l = r3
            r11.c()
            goto L_0x0113
        L_0x00e7:
            r11.h = r0
            int r0 = r12.getPointerId(r3)
            r11.s = r0
            android.view.VelocityTracker r0 = r11.m
            if (r0 != 0) goto L_0x00fa
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r11.m = r0
            goto L_0x00fd
        L_0x00fa:
            r0.clear()
        L_0x00fd:
            android.view.VelocityTracker r0 = r11.m
            r0.addMovement(r12)
            android.widget.OverScroller r12 = r11.e
            r12.computeScrollOffset()
            android.widget.OverScroller r12 = r11.e
            boolean r12 = r12.isFinished()
            r12 = r12 ^ r1
            r11.l = r12
            r11.c(r2, r3)
        L_0x0113:
            boolean r12 = r11.l
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.onInterceptTouchEvent(android.view.MotionEvent):boolean");
    }

    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        int i6 = 0;
        this.i = false;
        View view = this.k;
        if (view != null && a(view, (View) this)) {
            a(this.k);
        }
        this.k = null;
        if (!this.j) {
            if (this.x != null) {
                scrollTo(getScrollX(), this.x.f121a);
                this.x = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                i6 = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            }
            int paddingTop = ((i5 - i3) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            int a2 = a(scrollY, paddingTop, i6);
            if (a2 != scrollY) {
                scrollTo(getScrollX(), a2);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.j = true;
    }

    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.n && View.MeasureSpec.getMode(i3) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(FrameLayout.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        if (z2) {
            return false;
        }
        dispatchNestedFling(0.0f, f3, true);
        c((int) f3);
        return true;
    }

    public boolean onNestedPreFling(View view, float f2, float f3) {
        return dispatchNestedPreFling(f2, f3);
    }

    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        a(view, i2, i3, iArr, 0);
    }

    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        a(i5, 0, (int[]) null);
    }

    public void onNestedScrollAccepted(View view, View view2, int i2) {
        b(view, view2, i2, 0);
    }

    public void onOverScrolled(int i2, int i3, boolean z2, boolean z3) {
        super.scrollTo(i2, i3);
    }

    public boolean onRequestFocusInDescendants(int i2, Rect rect) {
        if (i2 == 2) {
            i2 = 130;
        } else if (i2 == 1) {
            i2 = 33;
        }
        View findNextFocus = rect == null ? FocusFinder.getInstance().findNextFocus(this, (View) null, i2) : FocusFinder.getInstance().findNextFocusFromRect(this, rect, i2);
        if (findNextFocus != null && !(true ^ a(findNextFocus, 0, getHeight()))) {
            return findNextFocus.requestFocus(i2, rect);
        }
        return false;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof c)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        c cVar = (c) parcelable;
        super.onRestoreInstanceState(cVar.getSuperState());
        this.x = cVar;
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        c cVar = new c(super.onSaveInstanceState());
        cVar.f121a = getScrollY();
        return cVar;
    }

    public void onScrollChanged(int i2, int i3, int i4, int i5) {
        super.onScrollChanged(i2, i3, i4, i5);
        b bVar = this.B;
        if (bVar != null) {
            C0025d dVar = (C0025d) bVar;
            AlertController.a(this, dVar.f167a, dVar.f168b);
        }
    }

    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        View findFocus = findFocus();
        if (findFocus != null && this != findFocus && a(findFocus, 0, i5)) {
            findFocus.getDrawingRect(this.d);
            offsetDescendantRectToMyCoords(findFocus, this.d);
            b(a(this.d));
        }
    }

    public boolean onStartNestedScroll(View view, View view2, int i2) {
        return a(view, view2, i2, 0);
    }

    public void onStopNestedScroll(View view) {
        a(view, 0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:24:0x007d, code lost:
        if (r10.e.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()) != false) goto L_0x0221;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:89:0x021f, code lost:
        if (r10.e.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()) != false) goto L_0x0221;
     */
    /* JADX WARNING: Removed duplicated region for block: B:93:0x0232  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r24) {
        /*
            r23 = this;
            r10 = r23
            r11 = r24
            android.view.VelocityTracker r0 = r10.m
            if (r0 != 0) goto L_0x000e
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r10.m = r0
        L_0x000e:
            int r0 = r24.getActionMasked()
            r12 = 0
            if (r0 != 0) goto L_0x0017
            r10.v = r12
        L_0x0017:
            android.view.MotionEvent r13 = android.view.MotionEvent.obtain(r24)
            int r1 = r10.v
            float r1 = (float) r1
            r2 = 0
            r13.offsetLocation(r2, r1)
            r1 = 2
            r14 = 1
            if (r0 == 0) goto L_0x023b
            r3 = -1
            if (r0 == r14) goto L_0x01df
            if (r0 == r1) goto L_0x0081
            r1 = 3
            if (r0 == r1) goto L_0x005b
            r1 = 5
            if (r0 == r1) goto L_0x0048
            r1 = 6
            if (r0 == r1) goto L_0x0036
            goto L_0x0271
        L_0x0036:
            r23.a((android.view.MotionEvent) r24)
            int r0 = r10.s
            int r0 = r11.findPointerIndex(r0)
            float r0 = r11.getY(r0)
            int r0 = (int) r0
            r10.h = r0
            goto L_0x0271
        L_0x0048:
            int r0 = r24.getActionIndex()
            float r1 = r11.getY(r0)
            int r1 = (int) r1
            r10.h = r1
            int r0 = r11.getPointerId(r0)
            r10.s = r0
            goto L_0x0271
        L_0x005b:
            boolean r0 = r10.l
            if (r0 == 0) goto L_0x0224
            int r0 = r23.getChildCount()
            if (r0 <= 0) goto L_0x0224
            android.widget.OverScroller r15 = r10.e
            int r16 = r23.getScrollX()
            int r17 = r23.getScrollY()
            r18 = 0
            r19 = 0
            r20 = 0
            int r21 = r23.getScrollRange()
            boolean r0 = r15.springBack(r16, r17, r18, r19, r20, r21)
            if (r0 == 0) goto L_0x0224
            goto L_0x0221
        L_0x0081:
            int r0 = r10.s
            int r15 = r11.findPointerIndex(r0)
            if (r15 != r3) goto L_0x00a4
            java.lang.String r0 = "Invalid pointerId="
            java.lang.StringBuilder r0 = c.a.a.a.a.a(r0)
            int r1 = r10.s
            r0.append(r1)
            java.lang.String r1 = " in onTouchEvent"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            java.lang.String r1 = "NestedScrollView"
            android.util.Log.e(r1, r0)
            goto L_0x0271
        L_0x00a4:
            float r0 = r11.getY(r15)
            int r6 = (int) r0
            int r0 = r10.h
            int r7 = r0 - r6
            r1 = 0
            int[] r3 = r10.u
            int[] r4 = r10.t
            r5 = 0
            r0 = r23
            r2 = r7
            boolean r0 = r0.a((int) r1, (int) r2, (int[]) r3, (int[]) r4, (int) r5)
            if (r0 == 0) goto L_0x00ca
            int[] r0 = r10.u
            r0 = r0[r14]
            int r7 = r7 - r0
            int r0 = r10.v
            int[] r1 = r10.t
            r1 = r1[r14]
            int r0 = r0 + r1
            r10.v = r0
        L_0x00ca:
            boolean r0 = r10.l
            if (r0 != 0) goto L_0x00ea
            int r0 = java.lang.Math.abs(r7)
            int r1 = r10.p
            if (r0 <= r1) goto L_0x00ea
            android.view.ViewParent r0 = r23.getParent()
            if (r0 == 0) goto L_0x00df
            r0.requestDisallowInterceptTouchEvent(r14)
        L_0x00df:
            r10.l = r14
            if (r7 <= 0) goto L_0x00e7
            int r0 = r10.p
            int r7 = r7 - r0
            goto L_0x00ea
        L_0x00e7:
            int r0 = r10.p
            int r7 = r7 + r0
        L_0x00ea:
            r16 = r7
            boolean r0 = r10.l
            if (r0 == 0) goto L_0x0271
            int[] r0 = r10.t
            r0 = r0[r14]
            int r6 = r6 - r0
            r10.h = r6
            int r17 = r23.getScrollY()
            int r9 = r23.getScrollRange()
            int r0 = r23.getOverScrollMode()
            if (r0 == 0) goto L_0x010e
            if (r0 != r14) goto L_0x010a
            if (r9 <= 0) goto L_0x010a
            goto L_0x010e
        L_0x010a:
            r0 = 0
            r18 = 0
            goto L_0x0111
        L_0x010e:
            r0 = 1
            r18 = 1
        L_0x0111:
            r1 = 0
            r3 = 0
            int r4 = r23.getScrollY()
            r5 = 0
            r7 = 0
            r8 = 0
            r19 = 1
            r0 = r23
            r2 = r16
            r6 = r9
            r22 = r9
            r9 = r19
            boolean r0 = r0.a(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            if (r0 == 0) goto L_0x0136
            boolean r0 = r10.e(r12)
            if (r0 != 0) goto L_0x0136
            android.view.VelocityTracker r0 = r10.m
            r0.clear()
        L_0x0136:
            int r0 = r23.getScrollY()
            int r2 = r0 - r17
            int r4 = r16 - r2
            int[] r7 = r10.u
            r7[r14] = r12
            r1 = 0
            r3 = 0
            int[] r5 = r10.t
            r6 = 0
            r0 = r23
            r0.a((int) r1, (int) r2, (int) r3, (int) r4, (int[]) r5, (int) r6, (int[]) r7)
            int r0 = r10.h
            int[] r1 = r10.t
            r2 = r1[r14]
            int r0 = r0 - r2
            r10.h = r0
            int r0 = r10.v
            r1 = r1[r14]
            int r0 = r0 + r1
            r10.v = r0
            if (r18 == 0) goto L_0x0271
            int[] r0 = r10.u
            r0 = r0[r14]
            int r0 = r16 - r0
            r23.b()
            int r1 = r17 + r0
            r2 = 21
            if (r1 >= 0) goto L_0x0196
            android.widget.EdgeEffect r1 = r10.f
            float r0 = (float) r0
            int r3 = r23.getHeight()
            float r3 = (float) r3
            float r0 = r0 / r3
            float r3 = r11.getX(r15)
            int r4 = r23.getWidth()
            float r4 = (float) r4
            float r3 = r3 / r4
            int r4 = android.os.Build.VERSION.SDK_INT
            if (r4 < r2) goto L_0x0188
            r1.onPull(r0, r3)
            goto L_0x018b
        L_0x0188:
            r1.onPull(r0)
        L_0x018b:
            android.widget.EdgeEffect r0 = r10.g
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x01c8
            android.widget.EdgeEffect r0 = r10.g
            goto L_0x01c5
        L_0x0196:
            r3 = r22
            if (r1 <= r3) goto L_0x01c8
            android.widget.EdgeEffect r1 = r10.g
            float r0 = (float) r0
            int r3 = r23.getHeight()
            float r3 = (float) r3
            float r0 = r0 / r3
            r3 = 1065353216(0x3f800000, float:1.0)
            float r4 = r11.getX(r15)
            int r5 = r23.getWidth()
            float r5 = (float) r5
            float r4 = r4 / r5
            float r3 = r3 - r4
            int r4 = android.os.Build.VERSION.SDK_INT
            if (r4 < r2) goto L_0x01b8
            r1.onPull(r0, r3)
            goto L_0x01bb
        L_0x01b8:
            r1.onPull(r0)
        L_0x01bb:
            android.widget.EdgeEffect r0 = r10.f
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x01c8
            android.widget.EdgeEffect r0 = r10.f
        L_0x01c5:
            r0.onRelease()
        L_0x01c8:
            android.widget.EdgeEffect r0 = r10.f
            if (r0 == 0) goto L_0x0271
            boolean r0 = r0.isFinished()
            if (r0 == 0) goto L_0x01da
            android.widget.EdgeEffect r0 = r10.g
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x0271
        L_0x01da:
            b.e.h.s.n(r23)
            goto L_0x0271
        L_0x01df:
            android.view.VelocityTracker r0 = r10.m
            r1 = 1000(0x3e8, float:1.401E-42)
            int r4 = r10.r
            float r4 = (float) r4
            r0.computeCurrentVelocity(r1, r4)
            int r1 = r10.s
            float r0 = r0.getYVelocity(r1)
            int r0 = (int) r0
            int r1 = java.lang.Math.abs(r0)
            int r4 = r10.q
            if (r1 <= r4) goto L_0x0207
            int r0 = -r0
            float r1 = (float) r0
            boolean r4 = r10.dispatchNestedPreFling(r2, r1)
            if (r4 != 0) goto L_0x0224
            r10.dispatchNestedFling(r2, r1, r14)
            r10.c(r0)
            goto L_0x0224
        L_0x0207:
            android.widget.OverScroller r15 = r10.e
            int r16 = r23.getScrollX()
            int r17 = r23.getScrollY()
            r18 = 0
            r19 = 0
            r20 = 0
            int r21 = r23.getScrollRange()
            boolean r0 = r15.springBack(r16, r17, r18, r19, r20, r21)
            if (r0 == 0) goto L_0x0224
        L_0x0221:
            b.e.h.s.n(r23)
        L_0x0224:
            r10.s = r3
            r10.l = r12
            r23.c()
            r10.g(r12)
            android.widget.EdgeEffect r0 = r10.f
            if (r0 == 0) goto L_0x0271
            r0.onRelease()
            android.widget.EdgeEffect r0 = r10.g
            r0.onRelease()
            goto L_0x0271
        L_0x023b:
            int r0 = r23.getChildCount()
            if (r0 != 0) goto L_0x0242
            return r12
        L_0x0242:
            android.widget.OverScroller r0 = r10.e
            boolean r0 = r0.isFinished()
            r0 = r0 ^ r14
            r10.l = r0
            if (r0 == 0) goto L_0x0256
            android.view.ViewParent r0 = r23.getParent()
            if (r0 == 0) goto L_0x0256
            r0.requestDisallowInterceptTouchEvent(r14)
        L_0x0256:
            android.widget.OverScroller r0 = r10.e
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x0261
            r23.a()
        L_0x0261:
            float r0 = r24.getY()
            int r0 = (int) r0
            r10.h = r0
            int r0 = r11.getPointerId(r12)
            r10.s = r0
            r10.c(r1, r12)
        L_0x0271:
            android.view.VelocityTracker r0 = r10.m
            if (r0 == 0) goto L_0x0278
            r0.addMovement(r13)
        L_0x0278:
            r13.recycle()
            return r14
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public void requestChildFocus(View view, View view2) {
        if (!this.i) {
            a(view2);
        } else {
            this.k = view2;
        }
        super.requestChildFocus(view, view2);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int a2 = a(rect);
        boolean z3 = a2 != 0;
        if (z3) {
            if (z2) {
                scrollBy(0, a2);
            } else {
                a(0, a2);
            }
        }
        return z3;
    }

    public void requestDisallowInterceptTouchEvent(boolean z2) {
        if (z2) {
            c();
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    public void requestLayout() {
        this.i = true;
        super.requestLayout();
    }

    public void scrollTo(int i2, int i3) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int a2 = a(i2, (getWidth() - getPaddingLeft()) - getPaddingRight(), childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin);
            int a3 = a(i3, (getHeight() - getPaddingTop()) - getPaddingBottom(), childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin);
            if (a2 != getScrollX() || a3 != getScrollY()) {
                super.scrollTo(a2, a3);
            }
        }
    }

    public void setFillViewport(boolean z2) {
        if (z2 != this.n) {
            this.n = z2;
            requestLayout();
        }
    }

    public void setNestedScrollingEnabled(boolean z2) {
        f fVar = this.z;
        if (fVar.d) {
            s.p(fVar.f655c);
        }
        fVar.d = z2;
    }

    public void setOnScrollChangeListener(b bVar) {
        this.B = bVar;
    }

    public void setSmoothScrollingEnabled(boolean z2) {
        this.o = z2;
    }

    public boolean shouldDelayChildPressedState() {
        return true;
    }

    public boolean startNestedScroll(int i2) {
        return c(i2, 0);
    }

    public void stopNestedScroll() {
        g(0);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.d = new Rect();
        this.i = true;
        this.j = false;
        this.k = null;
        this.l = false;
        this.o = true;
        this.s = -1;
        this.t = new int[2];
        this.u = new int[2];
        this.e = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.p = viewConfiguration.getScaledTouchSlop();
        this.q = viewConfiguration.getScaledMinimumFlingVelocity();
        this.r = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f119b, i2, 0);
        setFillViewport(obtainStyledAttributes.getBoolean(0, false));
        obtainStyledAttributes.recycle();
        this.y = new j(this);
        this.z = new f(this);
        setNestedScrollingEnabled(true);
        s.a((View) this, (C0069a) f118a);
    }

    public boolean a(int i2, int i3, int[] iArr, int[] iArr2, int i4) {
        ViewParent a2;
        int i5;
        int i6;
        int i7 = i2;
        int i8 = i3;
        int[] iArr3 = iArr2;
        int i9 = i4;
        f fVar = this.z;
        if (!fVar.d || (a2 = fVar.a(i9)) == null) {
            return false;
        }
        if (i7 != 0 || i8 != 0) {
            if (iArr3 != null) {
                fVar.f655c.getLocationInWindow(iArr3);
                i6 = iArr3[0];
                i5 = iArr3[1];
            } else {
                i6 = 0;
                i5 = 0;
            }
            int[] a3 = iArr == null ? fVar.a() : iArr;
            a3[0] = 0;
            a3[1] = 0;
            View view = fVar.f655c;
            if (a2 instanceof g) {
                ((g) a2).a(view, i2, i3, a3, i4);
            } else if (i9 == 0) {
                if (Build.VERSION.SDK_INT >= 21) {
                    try {
                        a2.onNestedPreScroll(view, i7, i8, a3);
                    } catch (AbstractMethodError e2) {
                        c.a.a.a.a.a("ViewParent ", a2, " does not implement interface method onNestedPreScroll", "ViewParentCompat", e2);
                    }
                } else if (a2 instanceof i) {
                    ((i) a2).onNestedPreScroll(view, i7, i8, a3);
                }
            }
            if (iArr3 != null) {
                fVar.f655c.getLocationInWindow(iArr3);
                iArr3[0] = iArr3[0] - i6;
                iArr3[1] = iArr3[1] - i5;
            }
            if (a3[0] == 0 && a3[1] == 0) {
                return false;
            }
            return true;
        } else if (iArr3 == null) {
            return false;
        } else {
            iArr3[0] = 0;
            iArr3[1] = 0;
            return false;
        }
    }

    public final boolean b(int i2, int i3, int i4) {
        boolean z2;
        int i5 = i2;
        int i6 = i3;
        int i7 = i4;
        int height = getHeight();
        int scrollY = getScrollY();
        int i8 = height + scrollY;
        boolean z3 = i5 == 33;
        ArrayList focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z4 = false;
        for (int i9 = 0; i9 < size; i9++) {
            View view2 = (View) focusables.get(i9);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i6 < bottom && top < i7) {
                boolean z5 = i6 < top && bottom < i7;
                if (view == null) {
                    view = view2;
                    z4 = z5;
                } else {
                    boolean z6 = (z3 && top < view.getTop()) || (!z3 && bottom > view.getBottom());
                    if (z4) {
                        if (z5) {
                            if (!z6) {
                            }
                        }
                    } else if (z5) {
                        view = view2;
                        z4 = true;
                    } else if (!z6) {
                    }
                    view = view2;
                }
            }
        }
        if (view == null) {
            view = this;
        }
        if (i6 < scrollY || i7 > i8) {
            b(z3 ? i6 - scrollY : i7 - i8);
            z2 = true;
        } else {
            z2 = false;
        }
        if (view != findFocus()) {
            view.requestFocus(i5);
        }
        return z2;
    }

    static class a extends C0069a {
        public void a(View view, AccessibilityEvent accessibilityEvent) {
            this.f637b.onInitializeAccessibilityEvent(view, accessibilityEvent);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            accessibilityEvent.setClassName(ScrollView.class.getName());
            accessibilityEvent.setScrollable(nestedScrollView.getScrollRange() > 0);
            accessibilityEvent.setScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setScrollY(nestedScrollView.getScrollY());
            int scrollX = nestedScrollView.getScrollX();
            int i = Build.VERSION.SDK_INT;
            accessibilityEvent.setMaxScrollX(scrollX);
            int scrollRange = nestedScrollView.getScrollRange();
            int i2 = Build.VERSION.SDK_INT;
            accessibilityEvent.setMaxScrollY(scrollRange);
        }

        public void a(View view, b.e.h.a.b bVar) {
            int scrollRange;
            this.f637b.onInitializeAccessibilityNodeInfo(view, bVar.f644b);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            bVar.f644b.setClassName(ScrollView.class.getName());
            if (nestedScrollView.isEnabled() && (scrollRange = nestedScrollView.getScrollRange()) > 0) {
                bVar.f644b.setScrollable(true);
                if (nestedScrollView.getScrollY() > 0) {
                    bVar.f644b.addAction(8192);
                }
                if (nestedScrollView.getScrollY() < scrollRange) {
                    bVar.f644b.addAction(4096);
                }
            }
        }

        public boolean a(View view, int i, Bundle bundle) {
            WeakReference weakReference;
            boolean z;
            List<b.a> b2 = C0069a.b(view);
            int i2 = 0;
            while (i2 < b2.size() && b2.get(i2).a() != i) {
                i2++;
            }
            int i3 = Build.VERSION.SDK_INT;
            boolean performAccessibilityAction = this.f637b.performAccessibilityAction(view, i, bundle);
            if (!performAccessibilityAction && i == b.e.b.accessibility_action_clickable_span) {
                int i4 = bundle.getInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", -1);
                SparseArray sparseArray = (SparseArray) view.getTag(b.e.b.tag_accessibility_clickable_spans);
                if (!(sparseArray == null || (weakReference = (WeakReference) sparseArray.get(i4)) == null)) {
                    ClickableSpan clickableSpan = (ClickableSpan) weakReference.get();
                    if (clickableSpan != null) {
                        ClickableSpan[] a2 = b.e.h.a.b.a(view.createAccessibilityNodeInfo().getText());
                        int i5 = 0;
                        while (true) {
                            if (a2 == null || i5 >= a2.length) {
                                break;
                            } else if (clickableSpan.equals(a2[i5])) {
                                z = true;
                                break;
                            } else {
                                i5++;
                            }
                        }
                    }
                    z = false;
                    if (z) {
                        clickableSpan.onClick(view);
                        performAccessibilityAction = true;
                    }
                }
                performAccessibilityAction = false;
            }
            if (performAccessibilityAction) {
                return true;
            }
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            if (!nestedScrollView.isEnabled()) {
                return false;
            }
            if (i == 4096) {
                int min = Math.min(nestedScrollView.getScrollY() + ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), nestedScrollView.getScrollRange());
                if (min == nestedScrollView.getScrollY()) {
                    return false;
                }
                nestedScrollView.b(0, min);
                return true;
            } else if (i != 8192) {
                return false;
            } else {
                int max = Math.max(nestedScrollView.getScrollY() - ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), 0);
                if (max == nestedScrollView.getScrollY()) {
                    return false;
                }
                nestedScrollView.b(0, max);
                return true;
            }
        }
    }

    public void a(int i2, int i3, int i4, int i5, int[] iArr, int i6, int[] iArr2) {
        this.z.a(i2, i3, i4, i5, iArr, i6, iArr2);
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x0062  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0038  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean a(android.view.KeyEvent r6) {
        /*
            r5 = this;
            android.graphics.Rect r0 = r5.d
            r0.setEmpty()
            int r0 = r5.getChildCount()
            r1 = 1
            r2 = 0
            if (r0 <= 0) goto L_0x0033
            android.view.View r0 = r5.getChildAt(r2)
            android.view.ViewGroup$LayoutParams r3 = r0.getLayoutParams()
            android.widget.FrameLayout$LayoutParams r3 = (android.widget.FrameLayout.LayoutParams) r3
            int r0 = r0.getHeight()
            int r4 = r3.topMargin
            int r0 = r0 + r4
            int r3 = r3.bottomMargin
            int r0 = r0 + r3
            int r3 = r5.getHeight()
            int r4 = r5.getPaddingTop()
            int r3 = r3 - r4
            int r4 = r5.getPaddingBottom()
            int r3 = r3 - r4
            if (r0 <= r3) goto L_0x0033
            r0 = 1
            goto L_0x0034
        L_0x0033:
            r0 = 0
        L_0x0034:
            r3 = 130(0x82, float:1.82E-43)
            if (r0 != 0) goto L_0x0062
            boolean r0 = r5.isFocused()
            if (r0 == 0) goto L_0x0061
            int r6 = r6.getKeyCode()
            r0 = 4
            if (r6 == r0) goto L_0x0061
            android.view.View r6 = r5.findFocus()
            if (r6 != r5) goto L_0x004c
            r6 = 0
        L_0x004c:
            android.view.FocusFinder r0 = android.view.FocusFinder.getInstance()
            android.view.View r6 = r0.findNextFocus(r5, r6, r3)
            if (r6 == 0) goto L_0x005f
            if (r6 == r5) goto L_0x005f
            boolean r6 = r6.requestFocus(r3)
            if (r6 == 0) goto L_0x005f
            goto L_0x0060
        L_0x005f:
            r1 = 0
        L_0x0060:
            return r1
        L_0x0061:
            return r2
        L_0x0062:
            int r0 = r6.getAction()
            if (r0 != 0) goto L_0x00a6
            int r0 = r6.getKeyCode()
            r1 = 19
            r4 = 33
            if (r0 == r1) goto L_0x0097
            r1 = 20
            if (r0 == r1) goto L_0x0087
            r1 = 62
            if (r0 == r1) goto L_0x007b
            goto L_0x00a6
        L_0x007b:
            boolean r6 = r6.isShiftPressed()
            if (r6 == 0) goto L_0x0083
            r3 = 33
        L_0x0083:
            r5.f(r3)
            goto L_0x00a6
        L_0x0087:
            boolean r6 = r6.isAltPressed()
            if (r6 != 0) goto L_0x0092
            boolean r2 = r5.a((int) r3)
            goto L_0x00a6
        L_0x0092:
            boolean r2 = r5.d(r3)
            goto L_0x00a6
        L_0x0097:
            boolean r6 = r6.isAltPressed()
            if (r6 != 0) goto L_0x00a2
            boolean r2 = r5.a((int) r4)
            goto L_0x00a6
        L_0x00a2:
            boolean r2 = r5.d(r4)
        L_0x00a6:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.a(android.view.KeyEvent):boolean");
    }

    public final void a(int i2, int i3, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i2);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.z.a(0, scrollY2, 0, i2 - scrollY2, (int[]) null, i3, iArr);
    }

    public void a(View view, int i2) {
        j jVar = this.y;
        if (i2 == 1) {
            jVar.f657b = 0;
        } else {
            jVar.f656a = 0;
        }
        g(i2);
    }
}
