package b.n.a.a;

import android.graphics.drawable.Animatable;

public interface b extends Animatable {
}
