package androidx.media;

import b.l.c;
import b.o.b;

public final class AudioAttributesImplBaseParcelizer {
    public static c read(b bVar) {
        c cVar = new c();
        cVar.f819a = bVar.a(cVar.f819a, 1);
        cVar.f820b = bVar.a(cVar.f820b, 2);
        cVar.f821c = bVar.a(cVar.f821c, 3);
        cVar.d = bVar.a(cVar.d, 4);
        return cVar;
    }

    public static void write(c cVar, b bVar) {
        bVar.a(false, false);
        bVar.b(cVar.f819a, 1);
        bVar.b(cVar.f820b, 2);
        bVar.b(cVar.f821c, 3);
        bVar.b(cVar.d, 4);
    }
}
