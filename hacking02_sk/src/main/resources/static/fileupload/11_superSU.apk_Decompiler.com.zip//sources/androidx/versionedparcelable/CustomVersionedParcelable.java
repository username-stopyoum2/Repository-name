package androidx.versionedparcelable;

import b.o.d;

public abstract class CustomVersionedParcelable implements d {
}
