package com.google.android.gms.dynamite;

import com.google.android.gms.common.util.DynamiteApi;

@DynamiteApi
public class DynamiteModule$DynamiteLoaderClassLoader {
    public static ClassLoader sClassLoader;
}
