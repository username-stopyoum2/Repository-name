package b.h.a;

import b.j.e;
import java.util.ArrayList;

public abstract class B {

    /* renamed from: a  reason: collision with root package name */
    public ArrayList<a> f701a = new ArrayList<>();

    /* renamed from: b  reason: collision with root package name */
    public int f702b;

    /* renamed from: c  reason: collision with root package name */
    public int f703c;
    public int d;
    public int e;
    public int f;
    public int g;
    public boolean h;
    public String i;
    public int j;
    public CharSequence k;
    public int l;
    public CharSequence m;
    public ArrayList<String> n;
    public ArrayList<String> o;
    public boolean p = false;
    public ArrayList<Runnable> q;

    static final class a {

        /* renamed from: a  reason: collision with root package name */
        public int f704a;

        /* renamed from: b  reason: collision with root package name */
        public C0076g f705b;

        /* renamed from: c  reason: collision with root package name */
        public int f706c;
        public int d;
        public int e;
        public int f;
        public e.b g;
        public e.b h;

        public a() {
        }

        public a(int i, C0076g gVar) {
            this.f704a = i;
            this.f705b = gVar;
            e.b bVar = e.b.RESUMED;
            this.g = bVar;
            this.h = bVar;
        }
    }
}
