package c.b.a.a.e;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public class f implements IInterface {

    /* renamed from: a  reason: collision with root package name */
    public final IBinder f902a;

    /* renamed from: b  reason: collision with root package name */
    public final String f903b;

    public f(IBinder iBinder, String str) {
        this.f902a = iBinder;
        this.f903b = str;
    }

    public final Parcel a(int i, Parcel parcel) {
        parcel = Parcel.obtain();
        try {
            this.f902a.transact(i, parcel, parcel, 0);
            parcel.readException();
            return parcel;
        } catch (RuntimeException e) {
            throw e;
        } finally {
            parcel.recycle();
        }
    }

    public IBinder asBinder() {
        return this.f902a;
    }

    public final Parcel b() {
        Parcel obtain = Parcel.obtain();
        obtain.writeInterfaceToken(this.f903b);
        return obtain;
    }
}
