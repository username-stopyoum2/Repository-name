package b.h.a;

import android.view.View;
import b.e.h.s;
import java.util.ArrayList;

public class M implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f730a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ ArrayList f731b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ ArrayList f732c;
    public final /* synthetic */ ArrayList d;
    public final /* synthetic */ ArrayList e;

    public M(P p, int i, ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3, ArrayList arrayList4) {
        this.f730a = i;
        this.f731b = arrayList;
        this.f732c = arrayList2;
        this.d = arrayList3;
        this.e = arrayList4;
    }

    public void run() {
        for (int i = 0; i < this.f730a; i++) {
            s.a((View) this.f731b.get(i), (String) this.f732c.get(i));
            s.a((View) this.d.get(i), (String) this.e.get(i));
        }
    }
}
