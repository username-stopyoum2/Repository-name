package c.b.a.a.e;

import android.os.IInterface;
import c.b.a.a.c.a;

public interface c extends IInterface {
    boolean getBooleanFlagValue(String str, boolean z, int i);

    int getIntFlagValue(String str, int i, int i2);

    long getLongFlagValue(String str, long j, int i);

    String getStringFlagValue(String str, String str2, int i);

    void init(a aVar);
}
