package b.h.a;

import android.os.Build;
import android.transition.Transition;
import android.transition.TransitionSet;
import android.view.View;
import b.d.b;
import b.d.h;
import b.e.a.g;
import b.e.h.s;
import b.h.a.C0076g;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class G {

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f717a = {0, 3, 0, 1, 5, 4, 7, 6, 9, 8, 10};

    /* renamed from: b  reason: collision with root package name */
    public static final P f718b = (Build.VERSION.SDK_INT >= 21 ? new L() : null);

    /* renamed from: c  reason: collision with root package name */
    public static final P f719c;

    static class a {

        /* renamed from: a  reason: collision with root package name */
        public C0076g f720a;

        /* renamed from: b  reason: collision with root package name */
        public boolean f721b;

        /* renamed from: c  reason: collision with root package name */
        public C0070a f722c;
        public C0076g d;
        public boolean e;
        public C0070a f;
    }

    static {
        P p;
        try {
            p = (P) Class.forName("androidx.transition.FragmentTransitionSupport").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Exception unused) {
            p = null;
        }
        f719c = p;
    }

    public static View a(b<String, View> bVar, a aVar, Object obj, boolean z) {
        ArrayList<String> arrayList;
        C0070a aVar2 = aVar.f722c;
        if (obj == null || bVar == null || (arrayList = aVar2.n) == null || arrayList.isEmpty()) {
            return null;
        }
        return bVar.get((z ? aVar2.n : aVar2.o).get(0));
    }

    public static void a(P p, Object obj, Object obj2, b<String, View> bVar, boolean z, C0070a aVar) {
        ArrayList<String> arrayList = aVar.n;
        if (arrayList != null && !arrayList.isEmpty()) {
            View view = bVar.get((z ? aVar.o : aVar.n).get(0));
            p.b(obj, view);
            if (obj2 != null) {
                p.b(obj2, view);
            }
        }
    }

    public static void a(C0076g gVar, C0076g gVar2, boolean z, b<String, View> bVar, boolean z2) {
        if (z) {
            gVar2.l();
        } else {
            gVar.l();
        }
    }

    public static void a(ArrayList<View> arrayList, int i) {
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                arrayList.get(size).setVisibility(i);
            }
        }
    }

    public static void a(ArrayList<View> arrayList, b<String, View> bVar, Collection<String> collection) {
        for (int i = bVar.g - 1; i >= 0; i--) {
            View d = bVar.d(i);
            if (collection.contains(s.g(d))) {
                arrayList.add(d);
            }
        }
    }

    public static boolean a(P p, List<Object> list) {
        int size = list.size();
        for (int i = 0; i < size; i++) {
            if (!p.a(list.get(i))) {
                return false;
            }
        }
        return true;
    }

    public static b<String, View> b(P p, b<String, String> bVar, Object obj, a aVar) {
        ArrayList<String> arrayList;
        if (bVar.isEmpty() || obj == null) {
            bVar.clear();
            return null;
        }
        C0076g gVar = aVar.d;
        b<String, View> bVar2 = new b<>();
        p.a((Map<String, View>) bVar2, gVar.x());
        C0070a aVar2 = aVar.f;
        if (aVar.e) {
            gVar.l();
            arrayList = aVar2.o;
        } else {
            C0076g.a aVar3 = gVar.L;
            if (aVar3 != null) {
                g gVar2 = aVar3.p;
            }
            arrayList = aVar2.n;
        }
        h.a(bVar2, (Collection<?>) arrayList);
        h.a(bVar, (Collection<?>) bVar2.keySet());
        return bVar2;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0038, code lost:
        if (r6.l != false) goto L_0x008a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x0076, code lost:
        r12 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:62:0x0088, code lost:
        if (r6.z == false) goto L_0x008a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:0x008a, code lost:
        r12 = true;
     */
    /* JADX WARNING: Removed duplicated region for block: B:100:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x0099  */
    /* JADX WARNING: Removed duplicated region for block: B:91:0x00dc  */
    /* JADX WARNING: Removed duplicated region for block: B:94:0x00ec A[ADDED_TO_REGION] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void a(b.h.a.C0070a r11, b.h.a.B.a r12, android.util.SparseArray<b.h.a.G.a> r13, boolean r14, boolean r15) {
        /*
            b.h.a.g r6 = r12.f705b
            if (r6 != 0) goto L_0x0005
            return
        L_0x0005:
            int r7 = r6.x
            if (r7 != 0) goto L_0x000a
            return
        L_0x000a:
            if (r14 == 0) goto L_0x0013
            int[] r0 = f717a
            int r12 = r12.f704a
            r12 = r0[r12]
            goto L_0x0015
        L_0x0013:
            int r12 = r12.f704a
        L_0x0015:
            r0 = 1
            r1 = 0
            if (r12 == r0) goto L_0x007d
            r2 = 3
            if (r12 == r2) goto L_0x0056
            r2 = 4
            if (r12 == r2) goto L_0x003e
            r2 = 5
            if (r12 == r2) goto L_0x002c
            r2 = 6
            if (r12 == r2) goto L_0x0056
            r2 = 7
            if (r12 == r2) goto L_0x007d
            r12 = 0
            r2 = 0
            goto L_0x008e
        L_0x002c:
            if (r15 == 0) goto L_0x003b
            boolean r12 = r6.N
            if (r12 == 0) goto L_0x008c
            boolean r12 = r6.z
            if (r12 != 0) goto L_0x008c
            boolean r12 = r6.l
            if (r12 == 0) goto L_0x008c
            goto L_0x008a
        L_0x003b:
            boolean r12 = r6.z
            goto L_0x008d
        L_0x003e:
            if (r15 == 0) goto L_0x004d
            boolean r12 = r6.N
            if (r12 == 0) goto L_0x0078
            boolean r12 = r6.l
            if (r12 == 0) goto L_0x0078
            boolean r12 = r6.z
            if (r12 == 0) goto L_0x0078
            goto L_0x0076
        L_0x004d:
            boolean r12 = r6.l
            if (r12 == 0) goto L_0x0078
            boolean r12 = r6.z
            if (r12 != 0) goto L_0x0078
            goto L_0x0076
        L_0x0056:
            if (r15 == 0) goto L_0x006e
            boolean r12 = r6.l
            if (r12 != 0) goto L_0x0078
            android.view.View r12 = r6.H
            if (r12 == 0) goto L_0x0078
            int r12 = r12.getVisibility()
            if (r12 != 0) goto L_0x0078
            float r12 = r6.O
            r2 = 0
            int r12 = (r12 > r2 ? 1 : (r12 == r2 ? 0 : -1))
            if (r12 < 0) goto L_0x0078
            goto L_0x0076
        L_0x006e:
            boolean r12 = r6.l
            if (r12 == 0) goto L_0x0078
            boolean r12 = r6.z
            if (r12 != 0) goto L_0x0078
        L_0x0076:
            r12 = 1
            goto L_0x0079
        L_0x0078:
            r12 = 0
        L_0x0079:
            r9 = r12
            r12 = 0
            r8 = 1
            goto L_0x0091
        L_0x007d:
            if (r15 == 0) goto L_0x0082
            boolean r12 = r6.M
            goto L_0x008d
        L_0x0082:
            boolean r12 = r6.l
            if (r12 != 0) goto L_0x008c
            boolean r12 = r6.z
            if (r12 != 0) goto L_0x008c
        L_0x008a:
            r12 = 1
            goto L_0x008d
        L_0x008c:
            r12 = 0
        L_0x008d:
            r2 = 1
        L_0x008e:
            r1 = r2
            r8 = 0
            r9 = 0
        L_0x0091:
            java.lang.Object r2 = r13.get(r7)
            b.h.a.G$a r2 = (b.h.a.G.a) r2
            if (r12 == 0) goto L_0x00aa
            if (r2 != 0) goto L_0x00a4
            b.h.a.G$a r12 = new b.h.a.G$a
            r12.<init>()
            r13.put(r7, r12)
            r2 = r12
        L_0x00a4:
            r2.f720a = r6
            r2.f721b = r14
            r2.f722c = r11
        L_0x00aa:
            r12 = r2
            r10 = 0
            if (r15 != 0) goto L_0x00d2
            if (r1 == 0) goto L_0x00d2
            if (r12 == 0) goto L_0x00b8
            b.h.a.g r1 = r12.d
            if (r1 != r6) goto L_0x00b8
            r12.d = r10
        L_0x00b8:
            b.h.a.u r1 = r11.r
            int r2 = r6.f745b
            if (r2 >= r0) goto L_0x00d2
            int r2 = r1.s
            if (r2 < r0) goto L_0x00d2
            boolean r0 = r11.p
            if (r0 != 0) goto L_0x00d2
            r1.g(r6)
            r2 = 1
            r3 = 0
            r4 = 0
            r5 = 0
            r0 = r1
            r1 = r6
            r0.a(r1, r2, r3, r4, r5)
        L_0x00d2:
            if (r9 == 0) goto L_0x00ea
            if (r12 == 0) goto L_0x00da
            b.h.a.g r0 = r12.d
            if (r0 != 0) goto L_0x00ea
        L_0x00da:
            if (r12 != 0) goto L_0x00e4
            b.h.a.G$a r12 = new b.h.a.G$a
            r12.<init>()
            r13.put(r7, r12)
        L_0x00e4:
            r12.d = r6
            r12.e = r14
            r12.f = r11
        L_0x00ea:
            if (r15 != 0) goto L_0x00f6
            if (r8 == 0) goto L_0x00f6
            if (r12 == 0) goto L_0x00f6
            b.h.a.g r11 = r12.f720a
            if (r11 != r6) goto L_0x00f6
            r12.f720a = r10
        L_0x00f6:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.G.a(b.h.a.a, b.h.a.B$a, android.util.SparseArray, boolean, boolean):void");
    }

    public static b<String, View> a(P p, b<String, String> bVar, Object obj, a aVar) {
        ArrayList<String> arrayList;
        C0076g gVar = aVar.f720a;
        View view = gVar.H;
        if (bVar.isEmpty() || obj == null || view == null) {
            bVar.clear();
            return null;
        }
        b<String, View> bVar2 = new b<>();
        p.a((Map<String, View>) bVar2, view);
        C0070a aVar2 = aVar.f722c;
        if (aVar.f721b) {
            C0076g.a aVar3 = gVar.L;
            if (aVar3 != null) {
                g gVar2 = aVar3.p;
            }
            arrayList = aVar2.n;
        } else {
            gVar.l();
            arrayList = aVar2.o;
        }
        if (arrayList != null) {
            h.a(bVar2, (Collection<?>) arrayList);
            h.a(bVar2, (Collection<?>) bVar.values());
        }
        int i = bVar.g;
        while (true) {
            i--;
            if (i < 0) {
                return bVar2;
            }
            if (!(bVar2.a((Object) bVar.d(i)) >= 0)) {
                bVar.c(i);
            }
        }
    }

    public static Object b(P p, C0076g gVar, boolean z) {
        Object obj = null;
        if (gVar == null) {
            return null;
        }
        if (z) {
            C0076g.a aVar = gVar.L;
            if (aVar != null) {
                Object obj2 = aVar.h;
                obj = obj2 == C0076g.f744a ? gVar.k() : obj2;
            }
        } else {
            obj = gVar.m();
        }
        return p.b(obj);
    }

    public static P a(C0076g gVar, C0076g gVar2) {
        Object obj;
        Object obj2;
        Object obj3;
        ArrayList arrayList = new ArrayList();
        if (gVar != null) {
            Object m = gVar.m();
            if (m != null) {
                arrayList.add(m);
            }
            C0076g.a aVar = gVar.L;
            if (aVar == null) {
                obj2 = null;
            } else {
                obj2 = aVar.h;
                if (obj2 == C0076g.f744a) {
                    obj2 = gVar.k();
                }
            }
            if (obj2 != null) {
                arrayList.add(obj2);
            }
            C0076g.a aVar2 = gVar.L;
            if (aVar2 == null) {
                obj3 = null;
            } else {
                Object obj4 = aVar2.l;
                obj3 = obj4 == C0076g.f744a ? gVar.q() : obj4;
            }
            if (obj3 != null) {
                arrayList.add(obj3);
            }
        }
        if (gVar2 != null) {
            Object k = gVar2.k();
            if (k != null) {
                arrayList.add(k);
            }
            C0076g.a aVar3 = gVar2.L;
            if (aVar3 == null) {
                obj = null;
            } else {
                obj = aVar3.j;
                if (obj == C0076g.f744a) {
                    obj = gVar2.m();
                }
            }
            if (obj != null) {
                arrayList.add(obj);
            }
            Object q = gVar2.q();
            if (q != null) {
                arrayList.add(q);
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        P p = f718b;
        if (p != null && a(p, (List<Object>) arrayList)) {
            return f718b;
        }
        P p2 = f719c;
        if (p2 != null && a(p2, (List<Object>) arrayList)) {
            return f719c;
        }
        if (f718b == null && f719c == null) {
            return null;
        }
        throw new IllegalArgumentException("Invalid Transition types");
    }

    public static ArrayList<View> a(P p, Object obj, C0076g gVar, ArrayList<View> arrayList, View view) {
        if (obj == null) {
            return null;
        }
        ArrayList<View> arrayList2 = new ArrayList<>();
        View view2 = gVar.H;
        if (view2 != null) {
            p.a(arrayList2, view2);
        }
        if (arrayList != null) {
            arrayList2.removeAll(arrayList);
        }
        if (arrayList2.isEmpty()) {
            return arrayList2;
        }
        arrayList2.add(view);
        p.a(obj, arrayList2);
        return arrayList2;
    }

    public static Object a(P p, C0076g gVar, boolean z) {
        Object obj = null;
        if (gVar == null) {
            return null;
        }
        if (z) {
            C0076g.a aVar = gVar.L;
            if (aVar != null) {
                Object obj2 = aVar.j;
                obj = obj2 == C0076g.f744a ? gVar.m() : obj2;
            }
        } else {
            obj = gVar.k();
        }
        return p.b(obj);
    }

    public static Object a(P p, C0076g gVar, C0076g gVar2, boolean z) {
        Object obj;
        if (gVar == null || gVar2 == null) {
            return null;
        }
        if (z) {
            C0076g.a aVar = gVar2.L;
            if (aVar == null) {
                obj = null;
            } else {
                obj = aVar.l;
                if (obj == C0076g.f744a) {
                    obj = gVar2.q();
                }
            }
        } else {
            obj = gVar.q();
        }
        Object b2 = p.b(obj);
        L l = (L) p;
        if (b2 == null) {
            return null;
        }
        TransitionSet transitionSet = new TransitionSet();
        transitionSet.addTransition((Transition) b2);
        return transitionSet;
    }

    public static Object a(P p, Object obj, Object obj2, Object obj3, C0076g gVar, boolean z) {
        Boolean bool;
        Boolean bool2;
        boolean z2 = true;
        if (!(obj == null || obj2 == null || gVar == null)) {
            if (z) {
                C0076g.a aVar = gVar.L;
                if (!(aVar == null || (bool2 = aVar.m) == null)) {
                    z2 = bool2.booleanValue();
                }
            } else {
                C0076g.a aVar2 = gVar.L;
                if (!(aVar2 == null || (bool = aVar2.n) == null)) {
                    z2 = bool.booleanValue();
                }
            }
        }
        return z2 ? p.b(obj2, obj, obj3) : p.a(obj2, obj, obj3);
    }

    /* JADX WARNING: Removed duplicated region for block: B:152:0x0400  */
    /* JADX WARNING: Removed duplicated region for block: B:155:0x0418  */
    /* JADX WARNING: Removed duplicated region for block: B:164:0x0456 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x0225 A[ADDED_TO_REGION] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void a(b.h.a.u r39, java.util.ArrayList<b.h.a.C0070a> r40, java.util.ArrayList<java.lang.Boolean> r41, int r42, int r43, boolean r44) {
        /*
            r0 = r39
            r1 = r40
            r2 = r41
            r3 = r43
            r4 = r44
            int r5 = r0.s
            r6 = 1
            if (r5 >= r6) goto L_0x0010
            return
        L_0x0010:
            android.util.SparseArray r5 = new android.util.SparseArray
            r5.<init>()
            r7 = r42
        L_0x0017:
            r8 = 0
            if (r7 >= r3) goto L_0x0068
            java.lang.Object r9 = r1.get(r7)
            b.h.a.a r9 = (b.h.a.C0070a) r9
            java.lang.Object r10 = r2.get(r7)
            java.lang.Boolean r10 = (java.lang.Boolean) r10
            boolean r10 = r10.booleanValue()
            if (r10 == 0) goto L_0x004e
            b.h.a.u r8 = r9.r
            b.h.a.i r8 = r8.u
            boolean r8 = r8.c()
            if (r8 != 0) goto L_0x0037
            goto L_0x0065
        L_0x0037:
            java.util.ArrayList<b.h.a.B$a> r8 = r9.f701a
            int r8 = r8.size()
            int r8 = r8 - r6
        L_0x003e:
            if (r8 < 0) goto L_0x0065
            java.util.ArrayList<b.h.a.B$a> r10 = r9.f701a
            java.lang.Object r10 = r10.get(r8)
            b.h.a.B$a r10 = (b.h.a.B.a) r10
            a((b.h.a.C0070a) r9, (b.h.a.B.a) r10, (android.util.SparseArray<b.h.a.G.a>) r5, (boolean) r6, (boolean) r4)
            int r8 = r8 + -1
            goto L_0x003e
        L_0x004e:
            java.util.ArrayList<b.h.a.B$a> r10 = r9.f701a
            int r10 = r10.size()
            r11 = 0
        L_0x0055:
            if (r11 >= r10) goto L_0x0065
            java.util.ArrayList<b.h.a.B$a> r12 = r9.f701a
            java.lang.Object r12 = r12.get(r11)
            b.h.a.B$a r12 = (b.h.a.B.a) r12
            a((b.h.a.C0070a) r9, (b.h.a.B.a) r12, (android.util.SparseArray<b.h.a.G.a>) r5, (boolean) r8, (boolean) r4)
            int r11 = r11 + 1
            goto L_0x0055
        L_0x0065:
            int r7 = r7 + 1
            goto L_0x0017
        L_0x0068:
            int r7 = r5.size()
            if (r7 == 0) goto L_0x046a
            android.view.View r7 = new android.view.View
            b.h.a.l r9 = r0.t
            android.content.Context r9 = r9.f753b
            r7.<init>(r9)
            int r15 = r5.size()
            r14 = 0
        L_0x007c:
            if (r14 >= r15) goto L_0x046a
            int r9 = r5.keyAt(r14)
            b.d.b r13 = new b.d.b
            r13.<init>()
            int r10 = r3 + -1
            r12 = r42
        L_0x008b:
            if (r10 < r12) goto L_0x00f6
            java.lang.Object r11 = r1.get(r10)
            b.h.a.a r11 = (b.h.a.C0070a) r11
            boolean r16 = r11.b(r9)
            if (r16 != 0) goto L_0x009a
            goto L_0x00eb
        L_0x009a:
            java.lang.Object r16 = r2.get(r10)
            java.lang.Boolean r16 = (java.lang.Boolean) r16
            boolean r16 = r16.booleanValue()
            java.util.ArrayList<java.lang.String> r6 = r11.n
            if (r6 == 0) goto L_0x00eb
            int r6 = r6.size()
            if (r16 == 0) goto L_0x00b3
            java.util.ArrayList<java.lang.String> r8 = r11.n
            java.util.ArrayList<java.lang.String> r11 = r11.o
            goto L_0x00bc
        L_0x00b3:
            java.util.ArrayList<java.lang.String> r8 = r11.n
            java.util.ArrayList<java.lang.String> r11 = r11.o
            r38 = r11
            r11 = r8
            r8 = r38
        L_0x00bc:
            r1 = 0
        L_0x00bd:
            if (r1 >= r6) goto L_0x00eb
            java.lang.Object r16 = r11.get(r1)
            r2 = r16
            java.lang.String r2 = (java.lang.String) r2
            java.lang.Object r16 = r8.get(r1)
            r3 = r16
            java.lang.String r3 = (java.lang.String) r3
            java.lang.Object r16 = r13.remove(r3)
            r17 = r6
            r6 = r16
            java.lang.String r6 = (java.lang.String) r6
            if (r6 == 0) goto L_0x00df
            r13.put(r2, r6)
            goto L_0x00e2
        L_0x00df:
            r13.put(r2, r3)
        L_0x00e2:
            int r1 = r1 + 1
            r2 = r41
            r3 = r43
            r6 = r17
            goto L_0x00bd
        L_0x00eb:
            int r10 = r10 + -1
            r1 = r40
            r2 = r41
            r3 = r43
            r6 = 1
            r8 = 0
            goto L_0x008b
        L_0x00f6:
            java.lang.Object r1 = r5.valueAt(r14)
            b.h.a.G$a r1 = (b.h.a.G.a) r1
            if (r4 == 0) goto L_0x02ed
            b.h.a.i r3 = r0.u
            boolean r3 = r3.c()
            if (r3 == 0) goto L_0x010f
            b.h.a.i r3 = r0.u
            android.view.View r3 = r3.a(r9)
            android.view.ViewGroup r3 = (android.view.ViewGroup) r3
            goto L_0x0110
        L_0x010f:
            r3 = 0
        L_0x0110:
            if (r3 != 0) goto L_0x011a
        L_0x0112:
            r31 = r5
            r32 = r14
            r33 = r15
            goto L_0x02e6
        L_0x011a:
            b.h.a.g r6 = r1.f720a
            b.h.a.g r8 = r1.d
            b.h.a.P r9 = a((b.h.a.C0076g) r8, (b.h.a.C0076g) r6)
            if (r9 != 0) goto L_0x0125
            goto L_0x0112
        L_0x0125:
            boolean r10 = r1.f721b
            boolean r11 = r1.e
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            r31 = r5
            java.lang.Object r5 = a((b.h.a.P) r9, (b.h.a.C0076g) r6, (boolean) r10)
            java.lang.Object r11 = b(r9, r8, r11)
            b.h.a.g r12 = r1.f720a
            r32 = r14
            b.h.a.g r14 = r1.d
            if (r12 == 0) goto L_0x0150
            r33 = r15
            android.view.View r15 = r12.x()
            r0 = 0
            r15.setVisibility(r0)
            goto L_0x0152
        L_0x0150:
            r33 = r15
        L_0x0152:
            if (r12 == 0) goto L_0x01f2
            if (r14 != 0) goto L_0x0158
            goto L_0x01f2
        L_0x0158:
            boolean r0 = r1.f721b
            boolean r15 = r13.isEmpty()
            if (r15 == 0) goto L_0x0164
            r34 = r10
            r15 = 0
            goto L_0x016a
        L_0x0164:
            java.lang.Object r15 = a((b.h.a.P) r9, (b.h.a.C0076g) r12, (b.h.a.C0076g) r14, (boolean) r0)
            r34 = r10
        L_0x016a:
            b.d.b r10 = b(r9, r13, r15, r1)
            r35 = r6
            b.d.b r6 = a((b.h.a.P) r9, (b.d.b<java.lang.String, java.lang.String>) r13, (java.lang.Object) r15, (b.h.a.G.a) r1)
            boolean r16 = r13.isEmpty()
            if (r16 == 0) goto L_0x0186
            if (r10 == 0) goto L_0x017f
            r10.clear()
        L_0x017f:
            if (r6 == 0) goto L_0x0184
            r6.clear()
        L_0x0184:
            r15 = 0
            goto L_0x0198
        L_0x0186:
            r16 = r15
            java.util.Set r15 = r13.keySet()
            a((java.util.ArrayList<android.view.View>) r4, (b.d.b<java.lang.String, android.view.View>) r10, (java.util.Collection<java.lang.String>) r15)
            java.util.Collection r15 = r13.values()
            a((java.util.ArrayList<android.view.View>) r2, (b.d.b<java.lang.String, android.view.View>) r6, (java.util.Collection<java.lang.String>) r15)
            r15 = r16
        L_0x0198:
            if (r5 != 0) goto L_0x01a1
            if (r11 != 0) goto L_0x01a1
            if (r15 != 0) goto L_0x01a1
            r37 = r2
            goto L_0x01f8
        L_0x01a1:
            r36 = r13
            r13 = 1
            a((b.h.a.C0076g) r12, (b.h.a.C0076g) r14, (boolean) r0, (b.d.b<java.lang.String, android.view.View>) r10, (boolean) r13)
            if (r15 == 0) goto L_0x01d7
            r2.add(r7)
            r9.b((java.lang.Object) r15, (android.view.View) r7, (java.util.ArrayList<android.view.View>) r4)
            boolean r13 = r1.e
            r37 = r2
            b.h.a.a r2 = r1.f
            r16 = r9
            r17 = r15
            r18 = r11
            r19 = r10
            r20 = r13
            r21 = r2
            a((b.h.a.P) r16, (java.lang.Object) r17, (java.lang.Object) r18, (b.d.b<java.lang.String, android.view.View>) r19, (boolean) r20, (b.h.a.C0070a) r21)
            android.graphics.Rect r2 = new android.graphics.Rect
            r2.<init>()
            android.view.View r1 = a((b.d.b<java.lang.String, android.view.View>) r6, (b.h.a.G.a) r1, (java.lang.Object) r5, (boolean) r0)
            if (r1 == 0) goto L_0x01d2
            r9.a((java.lang.Object) r5, (android.graphics.Rect) r2)
        L_0x01d2:
            r27 = r1
            r29 = r2
            goto L_0x01dd
        L_0x01d7:
            r37 = r2
            r27 = 0
            r29 = 0
        L_0x01dd:
            b.h.a.E r1 = new b.h.a.E
            r22 = r1
            r23 = r12
            r24 = r14
            r25 = r0
            r26 = r6
            r28 = r9
            r22.<init>(r23, r24, r25, r26, r27, r28, r29)
            b.e.h.l.a(r3, r1)
            goto L_0x01fb
        L_0x01f2:
            r37 = r2
            r35 = r6
            r34 = r10
        L_0x01f8:
            r36 = r13
            r15 = 0
        L_0x01fb:
            if (r5 != 0) goto L_0x0203
            if (r15 != 0) goto L_0x0203
            if (r11 != 0) goto L_0x0203
            goto L_0x02e6
        L_0x0203:
            java.util.ArrayList r0 = a((b.h.a.P) r9, (java.lang.Object) r11, (b.h.a.C0076g) r8, (java.util.ArrayList<android.view.View>) r4, (android.view.View) r7)
            r1 = r35
            r2 = r37
            java.util.ArrayList r6 = a((b.h.a.P) r9, (java.lang.Object) r5, (b.h.a.C0076g) r1, (java.util.ArrayList<android.view.View>) r2, (android.view.View) r7)
            r10 = 4
            a((java.util.ArrayList<android.view.View>) r6, (int) r10)
            r16 = r9
            r17 = r5
            r18 = r11
            r19 = r15
            r20 = r1
            r21 = r34
            java.lang.Object r1 = a((b.h.a.P) r16, (java.lang.Object) r17, (java.lang.Object) r18, (java.lang.Object) r19, (b.h.a.C0076g) r20, (boolean) r21)
            if (r1 == 0) goto L_0x02e6
            if (r8 == 0) goto L_0x0248
            if (r11 == 0) goto L_0x0248
            boolean r10 = r8.l
            if (r10 == 0) goto L_0x0248
            boolean r10 = r8.z
            if (r10 == 0) goto L_0x0248
            boolean r10 = r8.N
            if (r10 == 0) goto L_0x0248
            r10 = 1
            r8.c(r10)
            android.view.View r10 = r8.H
            r9.a((java.lang.Object) r11, (android.view.View) r10, (java.util.ArrayList<android.view.View>) r0)
            android.view.ViewGroup r8 = r8.G
            b.h.a.C r10 = new b.h.a.C
            r10.<init>(r0)
            b.e.h.l.a(r8, r10)
        L_0x0248:
            java.util.ArrayList r8 = new java.util.ArrayList
            r8.<init>()
            int r10 = r2.size()
            r12 = 0
        L_0x0252:
            if (r12 >= r10) goto L_0x0268
            java.lang.Object r13 = r2.get(r12)
            android.view.View r13 = (android.view.View) r13
            java.lang.String r14 = b.e.h.s.g(r13)
            r8.add(r14)
            r14 = 0
            b.e.h.s.a((android.view.View) r13, (java.lang.String) r14)
            int r12 = r12 + 1
            goto L_0x0252
        L_0x0268:
            r22 = r9
            r23 = r1
            r24 = r5
            r25 = r6
            r26 = r11
            r27 = r0
            r28 = r15
            r29 = r2
            r22.a(r23, r24, r25, r26, r27, r28, r29)
            r9.a((android.view.ViewGroup) r3, (java.lang.Object) r1)
            int r0 = r2.size()
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            r5 = 0
        L_0x0288:
            if (r5 >= r0) goto L_0x02c8
            java.lang.Object r10 = r4.get(r5)
            android.view.View r10 = (android.view.View) r10
            java.lang.String r11 = b.e.h.s.g(r10)
            r1.add(r11)
            if (r11 != 0) goto L_0x029c
            r13 = r36
            goto L_0x02c3
        L_0x029c:
            r14 = 0
            b.e.h.s.a((android.view.View) r10, (java.lang.String) r14)
            r13 = r36
            java.lang.Object r10 = r13.get(r11)
            java.lang.String r10 = (java.lang.String) r10
            r12 = 0
        L_0x02a9:
            if (r12 >= r0) goto L_0x02c3
            java.lang.Object r14 = r8.get(r12)
            boolean r14 = r10.equals(r14)
            if (r14 == 0) goto L_0x02bf
            java.lang.Object r10 = r2.get(r12)
            android.view.View r10 = (android.view.View) r10
            b.e.h.s.a((android.view.View) r10, (java.lang.String) r11)
            goto L_0x02c3
        L_0x02bf:
            int r12 = r12 + 1
            r14 = 0
            goto L_0x02a9
        L_0x02c3:
            int r5 = r5 + 1
            r36 = r13
            goto L_0x0288
        L_0x02c8:
            b.h.a.M r5 = new b.h.a.M
            r22 = r5
            r23 = r9
            r24 = r0
            r25 = r2
            r26 = r8
            r27 = r4
            r28 = r1
            r22.<init>(r23, r24, r25, r26, r27, r28)
            b.e.h.l.a(r3, r5)
            r0 = 0
            a((java.util.ArrayList<android.view.View>) r6, (int) r0)
            r9.b((java.lang.Object) r15, (java.util.ArrayList<android.view.View>) r4, (java.util.ArrayList<android.view.View>) r2)
            goto L_0x02e7
        L_0x02e6:
            r0 = 0
        L_0x02e7:
            r27 = r32
            r30 = r33
            goto L_0x0456
        L_0x02ed:
            r31 = r5
            r32 = r14
            r33 = r15
            r0 = 0
            r2 = r39
            b.h.a.i r3 = r2.u
            boolean r3 = r3.c()
            if (r3 == 0) goto L_0x0307
            b.h.a.i r3 = r2.u
            android.view.View r3 = r3.a(r9)
            android.view.ViewGroup r3 = (android.view.ViewGroup) r3
            goto L_0x0308
        L_0x0307:
            r3 = 0
        L_0x0308:
            if (r3 != 0) goto L_0x030b
            goto L_0x02e7
        L_0x030b:
            b.h.a.g r4 = r1.f720a
            b.h.a.g r5 = r1.d
            b.h.a.P r6 = a((b.h.a.C0076g) r5, (b.h.a.C0076g) r4)
            if (r6 != 0) goto L_0x0316
            goto L_0x02e7
        L_0x0316:
            boolean r8 = r1.f721b
            boolean r9 = r1.e
            java.lang.Object r8 = a((b.h.a.P) r6, (b.h.a.C0076g) r4, (boolean) r8)
            java.lang.Object r12 = b(r6, r5, r9)
            java.util.ArrayList r11 = new java.util.ArrayList
            r11.<init>()
            java.util.ArrayList r10 = new java.util.ArrayList
            r10.<init>()
            b.h.a.g r9 = r1.f720a
            b.h.a.g r15 = r1.d
            if (r9 == 0) goto L_0x03ce
            if (r15 != 0) goto L_0x0336
            goto L_0x03ce
        L_0x0336:
            boolean r14 = r1.f721b
            boolean r16 = r13.isEmpty()
            if (r16 == 0) goto L_0x0340
            r0 = 0
            goto L_0x0346
        L_0x0340:
            java.lang.Object r16 = a((b.h.a.P) r6, (b.h.a.C0076g) r9, (b.h.a.C0076g) r15, (boolean) r14)
            r0 = r16
        L_0x0346:
            b.d.b r2 = b(r6, r13, r0, r1)
            boolean r16 = r13.isEmpty()
            if (r16 == 0) goto L_0x0352
            r0 = 0
            goto L_0x035d
        L_0x0352:
            r16 = r0
            java.util.Collection r0 = r2.values()
            r11.addAll(r0)
            r0 = r16
        L_0x035d:
            if (r8 != 0) goto L_0x0365
            if (r12 != 0) goto L_0x0365
            if (r0 != 0) goto L_0x0365
            goto L_0x03ce
        L_0x0365:
            r22 = r4
            r4 = 1
            a((b.h.a.C0076g) r9, (b.h.a.C0076g) r15, (boolean) r14, (b.d.b<java.lang.String, android.view.View>) r2, (boolean) r4)
            if (r0 == 0) goto L_0x0394
            android.graphics.Rect r4 = new android.graphics.Rect
            r4.<init>()
            r6.b((java.lang.Object) r0, (android.view.View) r7, (java.util.ArrayList<android.view.View>) r11)
            r20 = r9
            boolean r9 = r1.e
            r21 = r10
            b.h.a.a r10 = r1.f
            r23 = r14
            r14 = r6
            r24 = r15
            r15 = r0
            r16 = r12
            r17 = r2
            r18 = r9
            r19 = r10
            a((b.h.a.P) r14, (java.lang.Object) r15, (java.lang.Object) r16, (b.d.b<java.lang.String, android.view.View>) r17, (boolean) r18, (b.h.a.C0070a) r19)
            if (r8 == 0) goto L_0x039d
            r6.a((java.lang.Object) r8, (android.graphics.Rect) r4)
            goto L_0x039d
        L_0x0394:
            r20 = r9
            r21 = r10
            r23 = r14
            r24 = r15
            r4 = 0
        L_0x039d:
            b.h.a.F r2 = new b.h.a.F
            r16 = r20
            r9 = r2
            r15 = r21
            r10 = r6
            r14 = r11
            r11 = r13
            r25 = r5
            r5 = r12
            r12 = r0
            r26 = r0
            r0 = r13
            r13 = r1
            r28 = r14
            r27 = r32
            r29 = 0
            r14 = r15
            r32 = r15
            r30 = r33
            r15 = r7
            r17 = r24
            r18 = r23
            r19 = r28
            r20 = r8
            r21 = r4
            r9.<init>(r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21)
            b.e.h.l.a(r3, r2)
            r20 = r26
            goto L_0x03e0
        L_0x03ce:
            r22 = r4
            r25 = r5
            r28 = r11
            r5 = r12
            r0 = r13
            r27 = r32
            r30 = r33
            r29 = 0
            r32 = r10
            r20 = r29
        L_0x03e0:
            if (r8 != 0) goto L_0x03e8
            if (r20 != 0) goto L_0x03e8
            if (r5 != 0) goto L_0x03e8
            goto L_0x0456
        L_0x03e8:
            r2 = r25
            r4 = r28
            java.util.ArrayList r2 = a((b.h.a.P) r6, (java.lang.Object) r5, (b.h.a.C0076g) r2, (java.util.ArrayList<android.view.View>) r4, (android.view.View) r7)
            if (r2 == 0) goto L_0x03fb
            boolean r4 = r2.isEmpty()
            if (r4 == 0) goto L_0x03f9
            goto L_0x03fb
        L_0x03f9:
            r29 = r5
        L_0x03fb:
            r4 = r6
            b.h.a.L r4 = (b.h.a.L) r4
            if (r8 == 0) goto L_0x0406
            r4 = r8
            android.transition.Transition r4 = (android.transition.Transition) r4
            r4.addTarget(r7)
        L_0x0406:
            boolean r1 = r1.f721b
            r14 = r6
            r15 = r8
            r16 = r29
            r17 = r20
            r18 = r22
            r19 = r1
            java.lang.Object r1 = a((b.h.a.P) r14, (java.lang.Object) r15, (java.lang.Object) r16, (java.lang.Object) r17, (b.h.a.C0076g) r18, (boolean) r19)
            if (r1 == 0) goto L_0x0456
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            r14 = r6
            r15 = r1
            r16 = r8
            r17 = r4
            r18 = r29
            r19 = r2
            r21 = r32
            r14.a(r15, r16, r17, r18, r19, r20, r21)
            b.h.a.D r5 = new b.h.a.D
            r9 = r5
            r10 = r8
            r11 = r6
            r12 = r7
            r13 = r22
            r14 = r32
            r15 = r4
            r16 = r2
            r17 = r29
            r9.<init>(r10, r11, r12, r13, r14, r15, r16, r17)
            b.e.h.l.a(r3, r5)
            b.h.a.N r2 = new b.h.a.N
            r4 = r32
            r2.<init>(r6, r4, r0)
            b.e.h.l.a(r3, r2)
            r6.a((android.view.ViewGroup) r3, (java.lang.Object) r1)
            b.h.a.O r1 = new b.h.a.O
            r1.<init>(r6, r4, r0)
            b.e.h.l.a(r3, r1)
        L_0x0456:
            int r14 = r27 + 1
            r0 = r39
            r1 = r40
            r2 = r41
            r3 = r43
            r4 = r44
            r15 = r30
            r5 = r31
            r6 = 1
            r8 = 0
            goto L_0x007c
        L_0x046a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.G.a(b.h.a.u, java.util.ArrayList, java.util.ArrayList, int, int, boolean):void");
    }
}
