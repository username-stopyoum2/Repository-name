package b.h.a;

import android.graphics.Rect;
import android.view.View;
import b.d.b;

public final class E implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0076g f711a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ C0076g f712b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ boolean f713c;
    public final /* synthetic */ b d;
    public final /* synthetic */ View e;
    public final /* synthetic */ P f;
    public final /* synthetic */ Rect g;

    public E(C0076g gVar, C0076g gVar2, boolean z, b bVar, View view, P p, Rect rect) {
        this.f711a = gVar;
        this.f712b = gVar2;
        this.f713c = z;
        this.d = bVar;
        this.e = view;
        this.f = p;
        this.g = rect;
    }

    public void run() {
        G.a(this.f711a, this.f712b, this.f713c, (b<String, View>) this.d, false);
        View view = this.e;
        if (view != null) {
            this.f.a(view, this.g);
        }
    }
}
