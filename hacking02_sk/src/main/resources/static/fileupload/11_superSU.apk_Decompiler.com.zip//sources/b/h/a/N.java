package b.h.a;

import android.view.View;
import b.e.h.s;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public class N implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ArrayList f733a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Map f734b;

    public N(P p, ArrayList arrayList, Map map) {
        this.f733a = arrayList;
        this.f734b = map;
    }

    public void run() {
        String str;
        int size = this.f733a.size();
        for (int i = 0; i < size; i++) {
            View view = (View) this.f733a.get(i);
            String g = s.g(view);
            if (g != null) {
                Iterator it = this.f734b.entrySet().iterator();
                while (true) {
                    if (!it.hasNext()) {
                        str = null;
                        break;
                    }
                    Map.Entry entry = (Map.Entry) it.next();
                    if (g.equals(entry.getValue())) {
                        str = (String) entry.getKey();
                        break;
                    }
                }
                s.a(view, str);
            }
        }
    }
}
