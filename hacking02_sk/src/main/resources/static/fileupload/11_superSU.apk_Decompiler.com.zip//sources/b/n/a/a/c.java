package b.n.a.a;

import android.graphics.drawable.Drawable;

class c implements Drawable.Callback {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ d f830a;

    public c(d dVar) {
        this.f830a = dVar;
    }

    public void invalidateDrawable(Drawable drawable) {
        this.f830a.invalidateSelf();
    }

    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
        this.f830a.scheduleSelf(runnable, j);
    }

    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        this.f830a.unscheduleSelf(runnable);
    }
}
