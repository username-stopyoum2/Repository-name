package b.h.a;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.activity.OnBackPressedDispatcher;
import b.a.c;
import b.a.e;
import b.d.j;
import b.e.a.a;
import b.j.e;
import b.j.i;
import b.j.u;
import b.j.v;
import b.k.a.b;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* renamed from: b.h.a.h  reason: case insensitive filesystem */
public class C0077h extends c implements a.C0011a, a.b {
    public final C0079j g;
    public final i h = new i(this);
    public boolean i;
    public boolean j;
    public boolean k = true;
    public boolean l;
    public boolean m;
    public int n;
    public j<String> o;

    /* renamed from: b.h.a.h$a */
    class a extends C0081l<C0077h> implements v, e {
        public a() {
            super(C0077h.this);
        }

        public View a(int i) {
            return C0077h.this.findViewById(i);
        }

        public b.j.e a() {
            return C0077h.this.h;
        }

        public OnBackPressedDispatcher b() {
            return C0077h.this.b();
        }

        public boolean c() {
            Window window = C0077h.this.getWindow();
            return (window == null || window.peekDecorView() == null) ? false : true;
        }

        public u d() {
            return C0077h.this.d();
        }
    }

    public C0077h() {
        a aVar = new a();
        a.a.a.a.c.a(aVar, (Object) "callbacks == null");
        this.g = new C0079j(aVar);
    }

    public static void a(int i2) {
        if ((i2 & -65536) != 0) {
            throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
        }
    }

    public final View a(View view, String str, Context context, AttributeSet attributeSet) {
        return this.g.f750a.e.onCreateView(view, str, context, attributeSet);
    }

    public void a(C0076g gVar) {
    }

    @Deprecated
    public boolean a(View view, Menu menu) {
        return super.onPreparePanel(0, view, menu);
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String str2 = str + "  ";
        printWriter.print(str2);
        printWriter.print("mCreated=");
        printWriter.print(this.i);
        printWriter.print(" mResumed=");
        printWriter.print(this.j);
        printWriter.print(" mStopped=");
        printWriter.print(this.k);
        if (getApplication() != null) {
            ((b) b.k.a.a.a(this)).f814c.a(str2, fileDescriptor, printWriter, strArr);
        }
        this.g.f750a.e.a(str, fileDescriptor, printWriter, strArr);
    }

    public C0082m g() {
        return this.g.f750a.e;
    }

    public void h() {
        this.h.b(e.a.ON_RESUME);
        this.g.f750a.e.h();
    }

    @Deprecated
    public void i() {
        invalidateOptionsMenu();
    }

    public void onActivityResult(int i2, int i3, Intent intent) {
        this.g.a();
        int i4 = i2 >> 16;
        if (i4 != 0) {
            int i5 = i4 - 1;
            String a2 = this.o.a(i5);
            this.o.c(i5);
            if (a2 == null) {
                Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
            } else if (this.g.f750a.e.a(a2) == null) {
                Log.w("FragmentActivity", "Activity result no fragment exists for who: " + a2);
            }
        } else {
            b.e.a.a.a();
            super.onActivityResult(i2, i3, intent);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.g.a();
        this.g.f750a.e.a(configuration);
    }

    public void onCreate(Bundle bundle) {
        C0081l<?> lVar = this.g.f750a;
        lVar.e.a((C0081l) lVar, (C0078i) lVar, (C0076g) null);
        if (bundle != null) {
            Parcelable parcelable = bundle.getParcelable("android:support:fragments");
            C0081l<?> lVar2 = this.g.f750a;
            if (lVar2 instanceof v) {
                lVar2.e.a(parcelable);
                if (bundle.containsKey("android:support:next_request_index")) {
                    this.n = bundle.getInt("android:support:next_request_index");
                    int[] intArray = bundle.getIntArray("android:support:request_indicies");
                    String[] stringArray = bundle.getStringArray("android:support:request_fragment_who");
                    if (intArray == null || stringArray == null || intArray.length != stringArray.length) {
                        Log.w("FragmentActivity", "Invalid requestCode mapping in savedInstanceState.");
                    } else {
                        this.o = new j<>(intArray.length);
                        for (int i2 = 0; i2 < intArray.length; i2++) {
                            this.o.c(intArray[i2], stringArray[i2]);
                        }
                    }
                }
            } else {
                throw new IllegalStateException("Your FragmentHostCallback must implement ViewModelStoreOwner to call restoreSaveState(). Call restoreAllState()  if you're still using retainNestedNonConfig().");
            }
        }
        if (this.o == null) {
            this.o = new j<>(10);
            this.n = 0;
        }
        super.onCreate(bundle);
        this.h.b(e.a.ON_CREATE);
        this.g.f750a.e.d();
    }

    public boolean onCreatePanelMenu(int i2, Menu menu) {
        if (i2 != 0) {
            return super.onCreatePanelMenu(i2, menu);
        }
        boolean onCreatePanelMenu = super.onCreatePanelMenu(i2, menu);
        C0079j jVar = this.g;
        return onCreatePanelMenu | jVar.f750a.e.a(menu, getMenuInflater());
    }

    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View a2 = a(view, str, context, attributeSet);
        return a2 == null ? super.onCreateView(view, str, context, attributeSet) : a2;
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View a2 = a((View) null, str, context, attributeSet);
        return a2 == null ? super.onCreateView(str, context, attributeSet) : a2;
    }

    public void onDestroy() {
        super.onDestroy();
        this.g.f750a.e.e();
        this.h.b(e.a.ON_DESTROY);
    }

    public void onLowMemory() {
        super.onLowMemory();
        this.g.f750a.e.f();
    }

    public boolean onMenuItemSelected(int i2, MenuItem menuItem) {
        if (super.onMenuItemSelected(i2, menuItem)) {
            return true;
        }
        if (i2 == 0) {
            return this.g.f750a.e.b(menuItem);
        }
        if (i2 != 6) {
            return false;
        }
        return this.g.f750a.e.a(menuItem);
    }

    public void onMultiWindowModeChanged(boolean z) {
        this.g.f750a.e.a(z);
    }

    public void onNewIntent(@SuppressLint({"UnknownNullness"}) Intent intent) {
        super.onNewIntent(intent);
        this.g.a();
    }

    public void onPanelClosed(int i2, Menu menu) {
        if (i2 == 0) {
            this.g.f750a.e.a(menu);
        }
        super.onPanelClosed(i2, menu);
    }

    public void onPause() {
        super.onPause();
        this.j = false;
        this.g.f750a.e.g();
        this.h.b(e.a.ON_PAUSE);
    }

    public void onPictureInPictureModeChanged(boolean z) {
        this.g.f750a.e.b(z);
    }

    public void onPostResume() {
        super.onPostResume();
        h();
    }

    public boolean onPreparePanel(int i2, View view, Menu menu) {
        if (i2 == 0) {
            return a(view, menu) | this.g.f750a.e.b(menu);
        }
        return super.onPreparePanel(i2, view, menu);
    }

    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        this.g.a();
        int i3 = (i2 >> 16) & 65535;
        if (i3 != 0) {
            int i4 = i3 - 1;
            String a2 = this.o.a(i4);
            this.o.c(i4);
            if (a2 == null) {
                Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
            } else if (this.g.f750a.e.a(a2) == null) {
                Log.w("FragmentActivity", "Activity result no fragment exists for who: " + a2);
            }
        }
    }

    public void onResume() {
        super.onResume();
        this.j = true;
        this.g.a();
        this.g.f750a.e.i();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        do {
        } while (a(g(), e.b.CREATED));
        this.h.b(e.a.ON_STOP);
        Parcelable n2 = this.g.f750a.e.n();
        if (n2 != null) {
            bundle.putParcelable("android:support:fragments", n2);
        }
        if (this.o.b() > 0) {
            bundle.putInt("android:support:next_request_index", this.n);
            int[] iArr = new int[this.o.b()];
            String[] strArr = new String[this.o.b()];
            for (int i2 = 0; i2 < this.o.b(); i2++) {
                iArr[i2] = this.o.b(i2);
                strArr[i2] = this.o.d(i2);
            }
            bundle.putIntArray("android:support:request_indicies", iArr);
            bundle.putStringArray("android:support:request_fragment_who", strArr);
        }
    }

    public void onStart() {
        super.onStart();
        this.k = false;
        if (!this.i) {
            this.i = true;
            u uVar = this.g.f750a.e;
            uVar.y = false;
            uVar.z = false;
            uVar.a(2);
        }
        this.g.a();
        this.g.f750a.e.i();
        this.h.b(e.a.ON_START);
        u uVar2 = this.g.f750a.e;
        uVar2.y = false;
        uVar2.z = false;
        uVar2.a(3);
    }

    public void onStateNotSaved() {
        this.g.a();
    }

    public void onStop() {
        super.onStop();
        this.k = true;
        do {
        } while (a(g(), e.b.CREATED));
        u uVar = this.g.f750a.e;
        uVar.z = true;
        uVar.a(2);
        this.h.b(e.a.ON_STOP);
    }

    public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent intent, int i2) {
        if (!this.m && i2 != -1) {
            a(i2);
        }
        super.startActivityForResult(intent, i2);
    }

    public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent intent, int i2, Bundle bundle) {
        if (!this.m && i2 != -1) {
            a(i2);
        }
        super.startActivityForResult(intent, i2, bundle);
    }

    public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender intentSender, int i2, Intent intent, int i3, int i4, int i5) {
        if (!this.l && i2 != -1) {
            a(i2);
        }
        super.startIntentSenderForResult(intentSender, i2, intent, i3, i4, i5);
    }

    public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender intentSender, int i2, Intent intent, int i3, int i4, int i5, Bundle bundle) {
        if (!this.l && i2 != -1) {
            a(i2);
        }
        super.startIntentSenderForResult(intentSender, i2, intent, i3, i4, i5, bundle);
    }

    public static boolean a(C0082m mVar, e.b bVar) {
        C0077h hVar;
        boolean z = false;
        for (C0076g next : mVar.a()) {
            if (next != null) {
                if (next.S.f803b.a(e.b.STARTED)) {
                    next.S.a(bVar);
                    z = true;
                }
                C0081l lVar = next.t;
                if (lVar == null) {
                    hVar = null;
                } else {
                    hVar = C0077h.this;
                }
                if (hVar != null) {
                    z |= a(next.i(), bVar);
                }
            }
        }
        return z;
    }
}
