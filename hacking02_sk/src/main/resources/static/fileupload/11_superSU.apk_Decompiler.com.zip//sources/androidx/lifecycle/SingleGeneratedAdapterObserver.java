package androidx.lifecycle;

import b.j.c;
import b.j.e;
import b.j.f;
import b.j.h;
import b.j.m;

public class SingleGeneratedAdapterObserver implements f {

    /* renamed from: a  reason: collision with root package name */
    public final c f135a;

    public SingleGeneratedAdapterObserver(c cVar) {
        this.f135a = cVar;
    }

    public void a(h hVar, e.a aVar) {
        this.f135a.a(hVar, aVar, false, (m) null);
        this.f135a.a(hVar, aVar, true, (m) null);
    }
}
