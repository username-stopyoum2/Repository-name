package c.b.a.a.e;

import android.os.IBinder;

public final class e extends f implements c {
    public e(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.flags.IFlagProvider");
    }
}
