package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import b.o.d;

public final class RemoteActionCompat implements d {

    /* renamed from: a  reason: collision with root package name */
    public IconCompat f112a;

    /* renamed from: b  reason: collision with root package name */
    public CharSequence f113b;

    /* renamed from: c  reason: collision with root package name */
    public CharSequence f114c;
    public PendingIntent d;
    public boolean e;
    public boolean f;
}
