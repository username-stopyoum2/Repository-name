package b.h.a;

import android.graphics.Rect;
import android.transition.Transition;

class H extends Transition.EpicenterCallback {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Rect f723a;

    public H(L l, Rect rect) {
        this.f723a = rect;
    }

    public Rect onGetEpicenter(Transition transition) {
        return this.f723a;
    }
}
