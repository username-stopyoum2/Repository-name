package b.g.a;

import android.os.Parcel;
import android.os.Parcelable;

class b implements Parcelable.ClassLoaderCreator<c> {
    public c createFromParcel(Parcel parcel, ClassLoader classLoader) {
        if (parcel.readParcelable(classLoader) == null) {
            return c.f696a;
        }
        throw new IllegalStateException("superState must be null");
    }

    public Object createFromParcel(Parcel parcel) {
        return createFromParcel(parcel, (ClassLoader) null);
    }

    public Object[] newArray(int i) {
        return new c[i];
    }

    /* renamed from: createFromParcel  reason: collision with other method in class */
    public Object m5createFromParcel(Parcel parcel, ClassLoader classLoader) {
        if (parcel.readParcelable(classLoader) == null) {
            return c.f696a;
        }
        throw new IllegalStateException("superState must be null");
    }
}
