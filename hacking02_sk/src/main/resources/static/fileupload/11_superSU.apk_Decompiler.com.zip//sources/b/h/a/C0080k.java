package b.h.a;

import b.d.i;
import b.h.a.C0076g;
import java.lang.reflect.InvocationTargetException;

/* renamed from: b.h.a.k  reason: case insensitive filesystem */
public class C0080k {

    /* renamed from: a  reason: collision with root package name */
    public static final i<String, Class<?>> f751a = new i<>();

    public static boolean b(ClassLoader classLoader, String str) {
        try {
            return C0076g.class.isAssignableFrom(c(classLoader, str));
        } catch (ClassNotFoundException unused) {
            return false;
        }
    }

    public static Class<?> c(ClassLoader classLoader, String str) {
        Class<?> cls = f751a.get(str);
        if (cls != null) {
            return cls;
        }
        Class<?> cls2 = Class.forName(str, false, classLoader);
        f751a.put(str, cls2);
        return cls2;
    }

    public static Class<? extends C0076g> d(ClassLoader classLoader, String str) {
        try {
            return c(classLoader, str);
        } catch (ClassNotFoundException e) {
            throw new C0076g.b("Unable to instantiate fragment " + str + ": make sure class name exists", e);
        } catch (ClassCastException e2) {
            throw new C0076g.b("Unable to instantiate fragment " + str + ": make sure class is a valid subclass of Fragment", e2);
        }
    }

    public C0076g a(ClassLoader classLoader, String str) {
        try {
            return (C0076g) d(classLoader, str).getConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (InstantiationException e) {
            throw new C0076g.b("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e);
        } catch (IllegalAccessException e2) {
            throw new C0076g.b("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e2);
        } catch (NoSuchMethodException e3) {
            throw new C0076g.b("Unable to instantiate fragment " + str + ": could not find Fragment constructor", e3);
        } catch (InvocationTargetException e4) {
            throw new C0076g.b("Unable to instantiate fragment " + str + ": calling Fragment constructor caused an exception", e4);
        }
    }
}
