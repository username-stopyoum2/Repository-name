package b.h.a;

import android.view.View;
import java.util.ArrayList;

public final class C implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ArrayList f707a;

    public C(ArrayList arrayList) {
        this.f707a = arrayList;
    }

    public void run() {
        G.a((ArrayList<View>) this.f707a, 4);
    }
}
