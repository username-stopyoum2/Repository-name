package androidx.lifecycle;

import b.j.c;
import b.j.e;
import b.j.f;
import b.j.h;
import b.j.m;

public class CompositeGeneratedAdaptersObserver implements f {

    /* renamed from: a  reason: collision with root package name */
    public final c[] f123a;

    public CompositeGeneratedAdaptersObserver(c[] cVarArr) {
        this.f123a = cVarArr;
    }

    public void a(h hVar, e.a aVar) {
        m mVar = new m();
        for (c a2 : this.f123a) {
            a2.a(hVar, aVar, false, mVar);
        }
        for (c a3 : this.f123a) {
            a3.a(hVar, aVar, true, mVar);
        }
    }
}
