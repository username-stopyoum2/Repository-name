package c.a.a.a;

import android.util.Log;
import org.xmlpull.v1.XmlPullParser;

/* compiled from: outline */
public class a {
    public static String a(String str, Object obj, String str2) {
        return str + obj + str2;
    }

    public static String a(XmlPullParser xmlPullParser, StringBuilder sb, String str) {
        sb.append(xmlPullParser.getPositionDescription());
        sb.append(str);
        return sb.toString();
    }

    public static StringBuilder a(String str) {
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        return sb;
    }

    public static void a(String str, Object obj, String str2, String str3, Throwable th) {
        Log.e(str3, str + obj + str2, th);
    }

    public static void b(String str, Object obj, String str2) {
        Log.v(str2, str + obj);
    }
}
