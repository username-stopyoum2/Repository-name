package androidx.appcompat.widget;

import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.widget.OverScroller;
import b.b.a.H;
import b.b.e.a.k;
import b.b.e.a.t;
import b.b.f;
import b.b.f.C0044g;
import b.b.f.Ea;
import b.b.f.Ka;
import b.b.f.N;
import b.b.f.O;
import b.e.h.g;
import b.e.h.h;
import b.e.h.i;
import b.e.h.j;
import b.e.h.s;

public class ActionBarOverlayLayout extends ViewGroup implements N, i, g, h {

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f80a = {b.b.a.actionBarSize, 16842841};
    public final Runnable A;
    public final j B;

    /* renamed from: b  reason: collision with root package name */
    public int f81b;

    /* renamed from: c  reason: collision with root package name */
    public int f82c;
    public ContentFrameLayout d;
    public ActionBarContainer e;
    public O f;
    public Drawable g;
    public boolean h;
    public boolean i;
    public boolean j;
    public boolean k;
    public boolean l;
    public int m;
    public int n;
    public final Rect o;
    public final Rect p;
    public final Rect q;
    public final Rect r;
    public final Rect s;
    public final Rect t;
    public final Rect u;
    public a v;
    public OverScroller w;
    public ViewPropertyAnimator x;
    public final AnimatorListenerAdapter y;
    public final Runnable z;

    public interface a {
    }

    public static class b extends ViewGroup.MarginLayoutParams {
        public b(int i, int i2) {
            super(i, i2);
        }

        public b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public b(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public ActionBarOverlayLayout(Context context) {
        this(context, (AttributeSet) null);
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f82c = 0;
        this.o = new Rect();
        this.p = new Rect();
        this.q = new Rect();
        this.r = new Rect();
        this.s = new Rect();
        this.t = new Rect();
        this.u = new Rect();
        this.y = new C0038d(this);
        this.z = new C0040e(this);
        this.A = new C0042f(this);
        a(context);
        this.B = new j(this);
    }

    public void a(int i2) {
        j();
        if (i2 == 2) {
            ((Ea) this.f).c();
        } else if (i2 == 5) {
            ((Ea) this.f).b();
        } else if (i2 == 109) {
            setOverlayMode(true);
        }
    }

    public final void a(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f80a);
        boolean z2 = false;
        this.f81b = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        this.g = obtainStyledAttributes.getDrawable(1);
        setWillNotDraw(this.g == null);
        obtainStyledAttributes.recycle();
        if (context.getApplicationInfo().targetSdkVersion < 19) {
            z2 = true;
        }
        this.h = z2;
        this.w = new OverScroller(context);
    }

    public void a(View view, int i2) {
        if (i2 == 0) {
            onStopNestedScroll(view);
        }
    }

    public void a(View view, int i2, int i3, int i4, int i5, int i6) {
        if (i6 == 0) {
            onNestedScroll(view, i2, i3, i4, i5);
        }
    }

    public void a(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        a(view, i2, i3, i4, i5, i6);
    }

    public void a(View view, int i2, int i3, int[] iArr, int i4) {
        if (i4 == 0) {
            onNestedPreScroll(view, i2, i3, iArr);
        }
    }

    public boolean a() {
        j();
        return ((Ea) this.f).f334a.n();
    }

    public final boolean a(View view, Rect rect, boolean z2, boolean z3, boolean z4, boolean z5) {
        boolean z6;
        int i2;
        int i3;
        int i4;
        int i5;
        b bVar = (b) view.getLayoutParams();
        if (!z2 || bVar.leftMargin == (i5 = rect.left)) {
            z6 = false;
        } else {
            bVar.leftMargin = i5;
            z6 = true;
        }
        if (z3 && bVar.topMargin != (i4 = rect.top)) {
            bVar.topMargin = i4;
            z6 = true;
        }
        if (z5 && bVar.rightMargin != (i3 = rect.right)) {
            bVar.rightMargin = i3;
            z6 = true;
        }
        if (!z4 || bVar.bottomMargin == (i2 = rect.bottom)) {
            return z6;
        }
        bVar.bottomMargin = i2;
        return true;
    }

    public boolean a(View view, View view2, int i2, int i3) {
        return i3 == 0 && onStartNestedScroll(view, view2, i2);
    }

    public void b() {
        j();
        ((Ea) this.f).f334a.d();
    }

    public void b(View view, View view2, int i2, int i3) {
        if (i3 == 0) {
            onNestedScrollAccepted(view, view2, i2);
        }
    }

    public void c() {
        j();
        ((Ea) this.f).m = true;
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof b;
    }

    public boolean d() {
        j();
        return ((Ea) this.f).f334a.b();
    }

    public void draw(Canvas canvas) {
        int i2;
        super.draw(canvas);
        if (this.g != null && !this.h) {
            if (this.e.getVisibility() == 0) {
                i2 = (int) (this.e.getTranslationY() + ((float) this.e.getBottom()) + 0.5f);
            } else {
                i2 = 0;
            }
            this.g.setBounds(0, i2, getWidth(), this.g.getIntrinsicHeight() + i2);
            this.g.draw(canvas);
        }
    }

    public boolean e() {
        j();
        return ((Ea) this.f).f334a.m();
    }

    public boolean f() {
        j();
        return ((Ea) this.f).f334a.l();
    }

    public boolean fitSystemWindows(Rect rect) {
        j();
        int h2 = s.h(this) & 256;
        boolean a2 = a((View) this.e, rect, true, true, false, true);
        this.r.set(rect);
        Ka.a(this, this.r, this.o);
        if (!this.s.equals(this.r)) {
            this.s.set(this.r);
            a2 = true;
        }
        if (!this.p.equals(this.o)) {
            this.p.set(this.o);
            a2 = true;
        }
        if (a2) {
            requestLayout();
        }
        return true;
    }

    public boolean g() {
        j();
        return ((Ea) this.f).f334a.p();
    }

    public b generateDefaultLayoutParams() {
        return new b(-1, -1);
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new b(layoutParams);
    }

    public b generateLayoutParams(AttributeSet attributeSet) {
        return new b(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.e;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    public int getNestedScrollAxes() {
        j jVar = this.B;
        return jVar.f657b | jVar.f656a;
    }

    public CharSequence getTitle() {
        j();
        return ((Ea) this.f).f334a.getTitle();
    }

    public void h() {
        removeCallbacks(this.z);
        removeCallbacks(this.A);
        ViewPropertyAnimator viewPropertyAnimator = this.x;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public boolean i() {
        return this.i;
    }

    public void j() {
        O o2;
        if (this.d == null) {
            this.d = (ContentFrameLayout) findViewById(f.action_bar_activity_content);
            this.e = (ActionBarContainer) findViewById(f.action_bar_container);
            View findViewById = findViewById(f.action_bar);
            if (findViewById instanceof O) {
                o2 = (O) findViewById;
            } else if (findViewById instanceof Toolbar) {
                o2 = ((Toolbar) findViewById).getWrapper();
            } else {
                StringBuilder a2 = c.a.a.a.a.a("Can't make a decor toolbar out of ");
                a2.append(findViewById.getClass().getSimpleName());
                throw new IllegalStateException(a2.toString());
            }
            this.f = o2;
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        a(getContext());
        s.o(this);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h();
    }

    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        getPaddingRight();
        int paddingTop = getPaddingTop();
        getPaddingBottom();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                b bVar = (b) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i7 = bVar.leftMargin + paddingLeft;
                int i8 = bVar.topMargin + paddingTop;
                childAt.layout(i7, i8, measuredWidth + i7, measuredHeight + i8);
            }
        }
    }

    public void onMeasure(int i2, int i3) {
        int i4;
        j();
        measureChildWithMargins(this.e, i2, 0, i3, 0);
        b bVar = (b) this.e.getLayoutParams();
        int max = Math.max(0, this.e.getMeasuredWidth() + bVar.leftMargin + bVar.rightMargin);
        int max2 = Math.max(0, this.e.getMeasuredHeight() + bVar.topMargin + bVar.bottomMargin);
        int combineMeasuredStates = View.combineMeasuredStates(0, this.e.getMeasuredState());
        boolean z2 = (s.h(this) & 256) != 0;
        if (z2) {
            i4 = this.f81b;
            if (this.j && this.e.getTabContainer() != null) {
                i4 += this.f81b;
            }
        } else {
            i4 = this.e.getVisibility() != 8 ? this.e.getMeasuredHeight() : 0;
        }
        this.q.set(this.o);
        this.t.set(this.r);
        Rect rect = (this.i || z2) ? this.t : this.q;
        rect.top += i4;
        rect.bottom += 0;
        a((View) this.d, this.q, true, true, true, true);
        if (!this.u.equals(this.t)) {
            this.u.set(this.t);
            this.d.a(this.t);
        }
        measureChildWithMargins(this.d, i2, 0, i3, 0);
        b bVar2 = (b) this.d.getLayoutParams();
        int max3 = Math.max(max, this.d.getMeasuredWidth() + bVar2.leftMargin + bVar2.rightMargin);
        int max4 = Math.max(max2, this.d.getMeasuredHeight() + bVar2.topMargin + bVar2.bottomMargin);
        int combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, this.d.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + max3, getSuggestedMinimumWidth()), i2, combineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + max4, getSuggestedMinimumHeight()), i3, combineMeasuredStates2 << 16));
    }

    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        boolean z3 = false;
        if (!this.k || !z2) {
            return false;
        }
        this.w.fling(0, 0, 0, (int) f3, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.w.getFinalY() > this.e.getHeight()) {
            z3 = true;
        }
        if (z3) {
            h();
            this.A.run();
        } else {
            h();
            this.z.run();
        }
        this.l = true;
        return true;
    }

    public boolean onNestedPreFling(View view, float f2, float f3) {
        return false;
    }

    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
    }

    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        this.m += i3;
        setActionBarHideOffset(this.m);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0013, code lost:
        r3 = (b.b.a.H) r3;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onNestedScrollAccepted(android.view.View r3, android.view.View r4, int r5) {
        /*
            r2 = this;
            b.e.h.j r0 = r2.B
            r1 = 0
            r0.a(r3, r4, r5, r1)
            int r3 = r2.getActionBarHideOffset()
            r2.m = r3
            r2.h()
            androidx.appcompat.widget.ActionBarOverlayLayout$a r3 = r2.v
            if (r3 == 0) goto L_0x001f
            b.b.a.H r3 = (b.b.a.H) r3
            b.b.e.h r4 = r3.x
            if (r4 == 0) goto L_0x001f
            r4.a()
            r4 = 0
            r3.x = r4
        L_0x001f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarOverlayLayout.onNestedScrollAccepted(android.view.View, android.view.View, int):void");
    }

    public boolean onStartNestedScroll(View view, View view2, int i2) {
        if ((i2 & 2) == 0 || this.e.getVisibility() != 0) {
            return false;
        }
        return this.k;
    }

    public void onStopNestedScroll(View view) {
        if (this.k && !this.l) {
            if (this.m <= this.e.getHeight()) {
                h();
                postDelayed(this.z, 600);
            } else {
                h();
                postDelayed(this.A, 600);
            }
        }
        a aVar = this.v;
        if (aVar != null) {
            ((H) aVar).d();
        }
    }

    public void onWindowSystemUiVisibilityChanged(int i2) {
        int i3 = Build.VERSION.SDK_INT;
        super.onWindowSystemUiVisibilityChanged(i2);
        j();
        int i4 = this.n ^ i2;
        this.n = i2;
        boolean z2 = (i2 & 4) == 0;
        boolean z3 = (i2 & 256) != 0;
        a aVar = this.v;
        if (aVar != null) {
            ((H) aVar).s = !z3;
            if (z2 || !z3) {
                H h2 = (H) this.v;
                if (h2.u) {
                    h2.u = false;
                    h2.f(true);
                }
            } else {
                H h3 = (H) aVar;
                if (!h3.u) {
                    h3.u = true;
                    h3.f(true);
                }
            }
        }
        if ((i4 & 256) != 0 && this.v != null) {
            s.o(this);
        }
    }

    public void onWindowVisibilityChanged(int i2) {
        super.onWindowVisibilityChanged(i2);
        this.f82c = i2;
        a aVar = this.v;
        if (aVar != null) {
            ((H) aVar).r = i2;
        }
    }

    public void setActionBarHideOffset(int i2) {
        h();
        this.e.setTranslationY((float) (-Math.max(0, Math.min(i2, this.e.getHeight()))));
    }

    public void setActionBarVisibilityCallback(a aVar) {
        this.v = aVar;
        if (getWindowToken() != null) {
            ((H) this.v).r = this.f82c;
            int i2 = this.n;
            if (i2 != 0) {
                onWindowSystemUiVisibilityChanged(i2);
                s.o(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z2) {
        this.j = z2;
    }

    public void setHideOnContentScrollEnabled(boolean z2) {
        if (z2 != this.k) {
            this.k = z2;
            if (!z2) {
                h();
                setActionBarHideOffset(0);
            }
        }
    }

    public void setIcon(int i2) {
        j();
        Ea ea = (Ea) this.f;
        ea.e = i2 != 0 ? b.b.b.a.a.c(ea.a(), i2) : null;
        ea.f();
    }

    public void setLogo(int i2) {
        j();
        Ea ea = (Ea) this.f;
        ea.a(i2 != 0 ? b.b.b.a.a.c(ea.a(), i2) : null);
    }

    public void setOverlayMode(boolean z2) {
        this.i = z2;
        this.h = z2 && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z2) {
    }

    public void setUiOptions(int i2) {
    }

    public void setWindowCallback(Window.Callback callback) {
        j();
        ((Ea) this.f).l = callback;
    }

    public void setWindowTitle(CharSequence charSequence) {
        j();
        ((Ea) this.f).b(charSequence);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public void a(Menu menu, t.a aVar) {
        j();
        Ea ea = (Ea) this.f;
        if (ea.n == null) {
            ea.n = new C0044g(ea.f334a.getContext());
            ea.n.a(f.action_menu_presenter);
        }
        ea.n.a(aVar);
        ea.f334a.a((k) menu, ea.n);
    }

    public void setIcon(Drawable drawable) {
        j();
        Ea ea = (Ea) this.f;
        ea.e = drawable;
        ea.f();
    }
}
