package com.sahani2020.suCheckerRoot;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertController;
import b.b.a.l;
import b.b.a.m;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.R;
import java.io.File;

public class MainActivity extends m {
    public LinearLayout A;
    public InterstitialAd B;
    public AdView C;
    public AdView D;
    public final String E = MainActivity.class.getSimpleName();
    public TranslateAnimation r;
    public ImageView s;
    public ImageView t;
    public Animation u;
    public ImageView v;
    public TextView w;
    public TextView x;
    public TextView y;
    public LinearLayout z;

    public void n() {
        this.B.loadAd();
    }

    public void o() {
        this.C = new AdView((Context) this, "425225822111528_425225952111515", AdSize.BANNER_HEIGHT_50);
        this.z.addView(this.C);
        this.C.loadAd();
    }

    public void onCheckRootingButtonClick(View view) {
        boolean z2;
        String str;
        TextView textView;
        String str2;
        TextView textView2;
        String str3;
        boolean z3;
        try {
            Runtime.getRuntime().exec("su");
            z2 = true;
        } catch (Exception unused) {
            z2 = false;
        }
        String[] strArr = {"/system/bin/su", "/system/xbin/su", "/system/xbin/sudo", "/system/sbin/su", "/temp/fakesu", "/system/test/su", "/sbin/su"};
        int i = 0;
        while (true) {
            if (i >= strArr.length) {
                str = null;
                break;
            }
            String str4 = strArr[i];
            File file = new File(str4);
            if (!file.exists() || !file.isFile()) {
                z3 = false;
            } else {
                Log.d("codetronikLog", str4);
                z3 = true;
            }
            if (z3) {
                str = strArr[i];
                break;
            }
            i++;
        }
        if (z2) {
            this.C.destroy();
            this.D.loadAd();
            Toast.makeText(getApplicationContext(), "This Device Is Rooted!", 1).show();
            this.t.setVisibility(0);
            this.t.startAnimation(this.u);
            this.w.setVisibility(0);
            this.x.setVisibility(0);
            this.y.setVisibility(0);
            this.y.setTextColor(Color.parseColor("#00FF00"));
            textView = this.y;
            str2 = "# ROOTED";
        } else {
            this.C.destroy();
            this.D.loadAd();
            Toast.makeText(getApplicationContext(), "This Device Is Not Rooted!", 1).show();
            this.s.setVisibility(0);
            this.s.startAnimation(this.u);
            this.w.setVisibility(0);
            this.x.setVisibility(0);
            this.y.setVisibility(0);
            this.y.setTextColor(Color.parseColor("#FF0000"));
            textView = this.y;
            str2 = "NOT ROOTED!";
        }
        textView.setText(str2);
        n();
        if (z2) {
            textView2 = this.w;
            str3 = "Check execute su : YES";
        } else {
            textView2 = this.w;
            str3 = "Check execute su : NO";
        }
        textView2.setText(str3);
        TextView textView3 = this.x;
        textView3.setText("Check existing su file : " + str);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        AudienceNetworkAds.initialize(this);
        setContentView((int) R.layout.activity_main);
        this.z = (LinearLayout) findViewById(R.id.banner_container);
        this.A = (LinearLayout) findViewById(R.id.banner_container2);
        o();
        p();
        this.D = new AdView((Context) this, "425225822111528_425225952111515", AdSize.BANNER_HEIGHT_50);
        this.A.addView(this.D);
        this.B = new InterstitialAd(this, "425225822111528_425226052111505");
        this.B.setAdListener(new a(this));
        this.v = (ImageView) findViewById(R.id.button);
        this.w = (TextView) findViewById(R.id.textView);
        this.x = (TextView) findViewById(R.id.textView2);
        this.y = (TextView) findViewById(R.id.rootStatus);
        this.s = (ImageView) findViewById(R.id.imageRed);
        this.t = (ImageView) findViewById(R.id.imageGreen);
        this.u = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.anim_bounce);
        this.r = new TranslateAnimation(0.0f, 0.0f, 11.0f, -11.0f);
        this.r.setDuration(1000);
        this.r.setFillAfter(true);
        this.r.setRepeatMode(2);
        this.r.setRepeatCount(-1);
        this.v.startAnimation(this.r);
    }

    public void p() {
        l.a aVar = new l.a(this);
        AlertController.a aVar2 = aVar.f188a;
        aVar2.h = "Tap the #-Icon to check Root access properties.";
        aVar2.r = false;
        b bVar = new b(this);
        AlertController.a aVar3 = aVar.f188a;
        aVar3.i = "OK";
        aVar3.k = bVar;
        aVar.a().show();
    }
}
