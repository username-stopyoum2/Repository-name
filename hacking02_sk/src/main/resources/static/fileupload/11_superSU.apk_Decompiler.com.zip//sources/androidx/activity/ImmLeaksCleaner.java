package androidx.activity;

import android.app.Activity;
import b.j.f;
import java.lang.reflect.Field;

public final class ImmLeaksCleaner implements f {

    /* renamed from: a  reason: collision with root package name */
    public static int f46a;

    /* renamed from: b  reason: collision with root package name */
    public static Field f47b;

    /* renamed from: c  reason: collision with root package name */
    public static Field f48c;
    public static Field d;
    public Activity e;

    public ImmLeaksCleaner(Activity activity) {
        this.e = activity;
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(3:32|33|34) */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0074, code lost:
        return;
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:32:0x0073 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void a(b.j.h r3, b.j.e.a r4) {
        /*
            r2 = this;
            b.j.e$a r3 = b.j.e.a.ON_DESTROY
            if (r4 == r3) goto L_0x0005
            return
        L_0x0005:
            int r3 = f46a
            r4 = 1
            if (r3 != 0) goto L_0x003c
            r3 = 2
            f46a = r3     // Catch:{ NoSuchFieldException -> 0x003c }
            java.lang.Class<android.view.inputmethod.InputMethodManager> r3 = android.view.inputmethod.InputMethodManager.class
            java.lang.String r0 = "mServedView"
            java.lang.reflect.Field r3 = r3.getDeclaredField(r0)     // Catch:{ NoSuchFieldException -> 0x003c }
            f48c = r3     // Catch:{ NoSuchFieldException -> 0x003c }
            java.lang.reflect.Field r3 = f48c     // Catch:{ NoSuchFieldException -> 0x003c }
            r3.setAccessible(r4)     // Catch:{ NoSuchFieldException -> 0x003c }
            java.lang.Class<android.view.inputmethod.InputMethodManager> r3 = android.view.inputmethod.InputMethodManager.class
            java.lang.String r0 = "mNextServedView"
            java.lang.reflect.Field r3 = r3.getDeclaredField(r0)     // Catch:{ NoSuchFieldException -> 0x003c }
            d = r3     // Catch:{ NoSuchFieldException -> 0x003c }
            java.lang.reflect.Field r3 = d     // Catch:{ NoSuchFieldException -> 0x003c }
            r3.setAccessible(r4)     // Catch:{ NoSuchFieldException -> 0x003c }
            java.lang.Class<android.view.inputmethod.InputMethodManager> r3 = android.view.inputmethod.InputMethodManager.class
            java.lang.String r0 = "mH"
            java.lang.reflect.Field r3 = r3.getDeclaredField(r0)     // Catch:{ NoSuchFieldException -> 0x003c }
            f47b = r3     // Catch:{ NoSuchFieldException -> 0x003c }
            java.lang.reflect.Field r3 = f47b     // Catch:{ NoSuchFieldException -> 0x003c }
            r3.setAccessible(r4)     // Catch:{ NoSuchFieldException -> 0x003c }
            f46a = r4     // Catch:{ NoSuchFieldException -> 0x003c }
        L_0x003c:
            int r3 = f46a
            if (r3 != r4) goto L_0x007d
            android.app.Activity r3 = r2.e
            java.lang.String r4 = "input_method"
            java.lang.Object r3 = r3.getSystemService(r4)
            android.view.inputmethod.InputMethodManager r3 = (android.view.inputmethod.InputMethodManager) r3
            java.lang.reflect.Field r4 = f47b     // Catch:{ IllegalAccessException -> 0x007d }
            java.lang.Object r4 = r4.get(r3)     // Catch:{ IllegalAccessException -> 0x007d }
            if (r4 != 0) goto L_0x0053
            return
        L_0x0053:
            monitor-enter(r4)
            java.lang.reflect.Field r0 = f48c     // Catch:{ IllegalAccessException -> 0x0079, ClassCastException -> 0x0077 }
            java.lang.Object r0 = r0.get(r3)     // Catch:{ IllegalAccessException -> 0x0079, ClassCastException -> 0x0077 }
            android.view.View r0 = (android.view.View) r0     // Catch:{ IllegalAccessException -> 0x0079, ClassCastException -> 0x0077 }
            if (r0 != 0) goto L_0x0060
            monitor-exit(r4)     // Catch:{ all -> 0x0075 }
            return
        L_0x0060:
            boolean r0 = r0.isAttachedToWindow()     // Catch:{ all -> 0x0075 }
            if (r0 == 0) goto L_0x0068
            monitor-exit(r4)     // Catch:{ all -> 0x0075 }
            return
        L_0x0068:
            java.lang.reflect.Field r0 = d     // Catch:{ IllegalAccessException -> 0x0073 }
            r1 = 0
            r0.set(r3, r1)     // Catch:{ IllegalAccessException -> 0x0073 }
            monitor-exit(r4)     // Catch:{ all -> 0x0075 }
            r3.isActive()
            goto L_0x007d
        L_0x0073:
            monitor-exit(r4)     // Catch:{ all -> 0x0075 }
            return
        L_0x0075:
            r3 = move-exception
            goto L_0x007b
        L_0x0077:
            monitor-exit(r4)     // Catch:{ all -> 0x0075 }
            return
        L_0x0079:
            monitor-exit(r4)     // Catch:{ all -> 0x0075 }
            return
        L_0x007b:
            monitor-exit(r4)     // Catch:{ all -> 0x0075 }
            throw r3
        L_0x007d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.activity.ImmLeaksCleaner.a(b.j.h, b.j.e$a):void");
    }
}
