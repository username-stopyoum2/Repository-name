package b.g.a;

import android.os.Parcel;
import android.os.Parcelable;

public abstract class c implements Parcelable {
    public static final Parcelable.Creator<c> CREATOR = new b();

    /* renamed from: a  reason: collision with root package name */
    public static final c f696a = new a();

    /* renamed from: b  reason: collision with root package name */
    public final Parcelable f697b;

    public c(Parcel parcel, ClassLoader classLoader) {
        Parcelable readParcelable = parcel.readParcelable(classLoader);
        this.f697b = readParcelable == null ? f696a : readParcelable;
    }

    public c(Parcelable parcelable) {
        if (parcelable != null) {
            this.f697b = parcelable == f696a ? null : parcelable;
            return;
        }
        throw new IllegalArgumentException("superState must not be null");
    }

    public /* synthetic */ c(a aVar) {
        this.f697b = null;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.f697b, i);
    }
}
