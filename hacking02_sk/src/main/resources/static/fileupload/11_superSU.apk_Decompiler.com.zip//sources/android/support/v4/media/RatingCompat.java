package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable;
import c.a.a.a.a;

public final class RatingCompat implements Parcelable {
    public static final Parcelable.Creator<RatingCompat> CREATOR = new e();

    /* renamed from: a  reason: collision with root package name */
    public final int f24a;

    /* renamed from: b  reason: collision with root package name */
    public final float f25b;

    public RatingCompat(int i, float f) {
        this.f24a = i;
        this.f25b = f;
    }

    public int describeContents() {
        return this.f24a;
    }

    public String toString() {
        StringBuilder a2 = a.a("Rating:style=");
        a2.append(this.f24a);
        a2.append(" rating=");
        float f = this.f25b;
        a2.append(f < 0.0f ? "unrated" : String.valueOf(f));
        return a2.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f24a);
        parcel.writeFloat(this.f25b);
    }
}
