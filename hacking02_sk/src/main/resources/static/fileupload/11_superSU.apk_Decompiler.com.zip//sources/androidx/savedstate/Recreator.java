package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import b.j.d;
import b.j.e;
import b.j.h;
import b.m.a;
import b.m.c;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Iterator;

@SuppressLint({"RestrictedApi"})
public final class Recreator implements d {

    /* renamed from: a  reason: collision with root package name */
    public final c f138a;

    public Recreator(c cVar) {
        this.f138a = cVar;
    }

    public void a(h hVar, e.a aVar) {
        Bundle bundle;
        if (aVar == e.a.ON_CREATE) {
            hVar.a().b(this);
            a c2 = this.f138a.c();
            if (c2.f824c) {
                Bundle bundle2 = c2.f823b;
                if (bundle2 != null) {
                    bundle = bundle2.getBundle("androidx.savedstate.Restarter");
                    c2.f823b.remove("androidx.savedstate.Restarter");
                    if (c2.f823b.isEmpty()) {
                        c2.f823b = null;
                    }
                } else {
                    bundle = null;
                }
                if (bundle != null) {
                    ArrayList<String> stringArrayList = bundle.getStringArrayList("classes_to_restore");
                    if (stringArrayList != null) {
                        Iterator<String> it = stringArrayList.iterator();
                        while (it.hasNext()) {
                            String next = it.next();
                            try {
                                Class<? extends U> asSubclass = Class.forName(next, false, Recreator.class.getClassLoader()).asSubclass(a.C0019a.class);
                                try {
                                    Constructor<? extends U> declaredConstructor = asSubclass.getDeclaredConstructor(new Class[0]);
                                    declaredConstructor.setAccessible(true);
                                    try {
                                        ((a.C0019a) declaredConstructor.newInstance(new Object[0])).a(this.f138a);
                                    } catch (Exception e) {
                                        throw new RuntimeException("Failed to instantiate " + next, e);
                                    }
                                } catch (NoSuchMethodException e2) {
                                    StringBuilder a2 = c.a.a.a.a.a("Class");
                                    a2.append(asSubclass.getSimpleName());
                                    a2.append(" must have default constructor in order to be automatically recreated");
                                    throw new IllegalStateException(a2.toString(), e2);
                                }
                            } catch (ClassNotFoundException e3) {
                                throw new RuntimeException("Class " + next + " wasn't found", e3);
                            }
                        }
                        return;
                    }
                    throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
                }
                return;
            }
            throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component");
        }
        throw new AssertionError("Next event must be ON_CREATE");
    }
}
