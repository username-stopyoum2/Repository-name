package b.g.a;

class a extends c {
    public a() {
        super((a) null);
    }
}
