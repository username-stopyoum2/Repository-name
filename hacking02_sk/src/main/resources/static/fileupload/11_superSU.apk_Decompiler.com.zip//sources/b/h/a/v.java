package b.h.a;

import android.os.Parcel;
import android.os.Parcelable;

class v implements Parcelable.Creator<w> {
    public Object createFromParcel(Parcel parcel) {
        return new w(parcel);
    }

    public Object[] newArray(int i) {
        return new w[i];
    }
}
