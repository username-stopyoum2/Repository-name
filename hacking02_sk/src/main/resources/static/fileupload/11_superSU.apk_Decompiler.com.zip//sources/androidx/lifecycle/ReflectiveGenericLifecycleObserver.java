package androidx.lifecycle;

import b.j.a;
import b.j.e;
import b.j.f;
import b.j.h;

public class ReflectiveGenericLifecycleObserver implements f {

    /* renamed from: a  reason: collision with root package name */
    public final Object f133a;

    /* renamed from: b  reason: collision with root package name */
    public final a.C0017a f134b = a.f792a.b(this.f133a.getClass());

    public ReflectiveGenericLifecycleObserver(Object obj) {
        this.f133a = obj;
    }

    public void a(h hVar, e.a aVar) {
        a.C0017a aVar2 = this.f134b;
        Object obj = this.f133a;
        a.C0017a.a(aVar2.f795a.get(aVar), hVar, aVar, obj);
        a.C0017a.a(aVar2.f795a.get(e.a.ON_ANY), hVar, aVar, obj);
    }
}
