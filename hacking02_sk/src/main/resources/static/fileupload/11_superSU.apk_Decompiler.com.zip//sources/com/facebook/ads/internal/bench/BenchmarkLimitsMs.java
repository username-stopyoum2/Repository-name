package com.facebook.ads.internal.bench;

public class BenchmarkLimitsMs {
    public static final int GSF = 5;
    public static final int GSW = 1;
}
