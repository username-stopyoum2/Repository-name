package c.b.a.a.b.a;

import android.os.IInterface;

public interface a extends IInterface {
}
