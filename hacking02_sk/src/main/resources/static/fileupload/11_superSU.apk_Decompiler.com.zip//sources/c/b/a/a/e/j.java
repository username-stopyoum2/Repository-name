package c.b.a.a.e;

import android.os.IBinder;
import android.os.IInterface;

public abstract class j extends g implements i {
    public static i a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
        return queryLocalInterface instanceof i ? (i) queryLocalInterface : new k(iBinder);
    }
}
