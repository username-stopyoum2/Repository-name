package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import b.b.e.a.k;
import b.b.e.a.o;
import b.b.e.a.t;
import b.b.e.a.u;
import b.b.f.C0044g;
import b.b.f.Ka;
import b.b.f.U;

public class ActionMenuView extends U implements k.b, u {
    public e A;
    public k p;
    public Context q;
    public int r;
    public boolean s;
    public C0044g t;
    public t.a u;
    public k.a v;
    public boolean w;
    public int x;
    public int y;
    public int z;

    public interface a {
        boolean a();

        boolean b();
    }

    private static class b implements t.a {
        public void a(k kVar, boolean z) {
        }

        public boolean a(k kVar) {
            return false;
        }
    }

    public static class c extends U.a {
        @ViewDebug.ExportedProperty

        /* renamed from: c  reason: collision with root package name */
        public boolean f83c;
        @ViewDebug.ExportedProperty
        public int d;
        @ViewDebug.ExportedProperty
        public int e;
        @ViewDebug.ExportedProperty
        public boolean f;
        @ViewDebug.ExportedProperty
        public boolean g;
        public boolean h;

        public c(int i, int i2) {
            super(i, i2);
            this.f83c = false;
        }

        public c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public c(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public c(c cVar) {
            super(cVar);
            this.f83c = cVar.f83c;
        }
    }

    private class d implements k.a {
        public d() {
        }

        public void a(k kVar) {
            k.a aVar = ActionMenuView.this.v;
            if (aVar != null) {
                aVar.a(kVar);
            }
        }

        public boolean a(k kVar, MenuItem menuItem) {
            e eVar = ActionMenuView.this.A;
            if (eVar == null) {
                return false;
            }
            Toolbar toolbar = ((ya) eVar).f499a;
            return false;
        }
    }

    public interface e {
    }

    public ActionMenuView(Context context) {
        this(context, (AttributeSet) null);
    }

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        setBaselineAligned(false);
        float f = context.getResources().getDisplayMetrics().density;
        this.y = (int) (56.0f * f);
        this.z = (int) (f * 4.0f);
        this.q = context;
        this.r = 0;
    }

    public static int a(View view, int i, int i2, int i3, int i4) {
        c cVar = (c) view.getLayoutParams();
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(i3) - i4, View.MeasureSpec.getMode(i3));
        ActionMenuItemView actionMenuItemView = view instanceof ActionMenuItemView ? (ActionMenuItemView) view : null;
        boolean z2 = true;
        boolean z3 = actionMenuItemView != null && actionMenuItemView.d();
        int i5 = 2;
        if (i2 <= 0 || (z3 && i2 < 2)) {
            i5 = 0;
        } else {
            view.measure(View.MeasureSpec.makeMeasureSpec(i2 * i, Integer.MIN_VALUE), makeMeasureSpec);
            int measuredWidth = view.getMeasuredWidth();
            int i6 = measuredWidth / i;
            if (measuredWidth % i != 0) {
                i6++;
            }
            if (!z3 || i6 >= 2) {
                i5 = i6;
            }
        }
        if (cVar.f83c || !z3) {
            z2 = false;
        }
        cVar.f = z2;
        cVar.d = i5;
        view.measure(View.MeasureSpec.makeMeasureSpec(i * i5, 1073741824), makeMeasureSpec);
        return i5;
    }

    public void a() {
        C0044g gVar = this.t;
        if (gVar != null) {
            gVar.b();
        }
    }

    public void a(k kVar) {
        this.p = kVar;
    }

    public void a(t.a aVar, k.a aVar2) {
        this.u = aVar;
        this.v = aVar2;
    }

    public boolean a(o oVar) {
        return this.p.a((MenuItem) oVar, (t) null, 0);
    }

    public c b() {
        c generateDefaultLayoutParams = generateDefaultLayoutParams();
        generateDefaultLayoutParams.f83c = true;
        return generateDefaultLayoutParams;
    }

    public boolean c() {
        C0044g gVar = this.t;
        return gVar != null && gVar.c();
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof c;
    }

    public boolean d() {
        C0044g gVar = this.t;
        if (gVar != null) {
            if (gVar.y != null || gVar.e()) {
                return true;
            }
        }
        return false;
    }

    public boolean d(int i) {
        boolean z2 = false;
        if (i == 0) {
            return false;
        }
        View childAt = getChildAt(i - 1);
        View childAt2 = getChildAt(i);
        if (i < getChildCount() && (childAt instanceof a)) {
            z2 = false | ((a) childAt).a();
        }
        return (i <= 0 || !(childAt2 instanceof a)) ? z2 : z2 | ((a) childAt2).b();
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    public boolean e() {
        C0044g gVar = this.t;
        return gVar != null && gVar.e();
    }

    public boolean f() {
        return this.s;
    }

    public k g() {
        return this.p;
    }

    public c generateDefaultLayoutParams() {
        c cVar = new c(-2, -2);
        cVar.f384b = 16;
        return cVar;
    }

    public c generateLayoutParams(AttributeSet attributeSet) {
        return new c(getContext(), attributeSet);
    }

    public c generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams == null) {
            return generateDefaultLayoutParams();
        }
        c cVar = layoutParams instanceof c ? new c((c) layoutParams) : new c(layoutParams);
        if (cVar.f384b <= 0) {
            cVar.f384b = 16;
        }
        return cVar;
    }

    public Menu getMenu() {
        if (this.p == null) {
            Context context = getContext();
            this.p = new k(context);
            this.p.a((k.a) new d());
            this.t = new C0044g(context);
            C0044g gVar = this.t;
            gVar.l = true;
            gVar.m = true;
            t.a aVar = this.u;
            if (aVar == null) {
                aVar = new b();
            }
            gVar.e = aVar;
            this.p.a((t) this.t, this.q);
            C0044g gVar2 = this.t;
            gVar2.h = this;
            a(gVar2.f243c);
        }
        return this.p;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        C0044g gVar = this.t;
        C0044g.d dVar = gVar.i;
        if (dVar != null) {
            return dVar.getDrawable();
        }
        if (gVar.k) {
            return gVar.j;
        }
        return null;
    }

    public int getPopupTheme() {
        return this.r;
    }

    public int getWindowAnimations() {
        return 0;
    }

    public boolean h() {
        C0044g gVar = this.t;
        return gVar != null && gVar.f();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        C0044g gVar = this.t;
        if (gVar != null) {
            gVar.a(false);
            if (this.t.e()) {
                this.t.c();
                this.t.f();
            }
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        a();
    }

    public void onLayout(boolean z2, int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        int i7;
        int i8;
        int i9 = i;
        int i10 = i2;
        int i11 = i3;
        int i12 = i4;
        if (this.w) {
            int childCount = getChildCount();
            int i13 = (i12 - i10) / 2;
            int dividerWidth = getDividerWidth();
            int i14 = i11 - i9;
            int paddingRight = (i14 - getPaddingRight()) - getPaddingLeft();
            boolean a2 = Ka.a(this);
            int i15 = paddingRight;
            int i16 = 0;
            int i17 = 0;
            for (int i18 = 0; i18 < childCount; i18++) {
                View childAt = getChildAt(i18);
                if (childAt.getVisibility() != 8) {
                    c cVar = (c) childAt.getLayoutParams();
                    if (cVar.f83c) {
                        int measuredWidth = childAt.getMeasuredWidth();
                        if (d(i18)) {
                            measuredWidth += dividerWidth;
                        }
                        int measuredHeight = childAt.getMeasuredHeight();
                        if (a2) {
                            i7 = getPaddingLeft() + cVar.leftMargin;
                            i8 = i7 + measuredWidth;
                        } else {
                            i8 = (getWidth() - getPaddingRight()) - cVar.rightMargin;
                            i7 = i8 - measuredWidth;
                        }
                        int i19 = i13 - (measuredHeight / 2);
                        childAt.layout(i7, i19, i8, measuredHeight + i19);
                        i15 -= measuredWidth;
                        i16 = 1;
                    } else {
                        i15 -= (childAt.getMeasuredWidth() + cVar.leftMargin) + cVar.rightMargin;
                        d(i18);
                        i17++;
                    }
                }
            }
            if (childCount == 1 && i16 == 0) {
                View childAt2 = getChildAt(0);
                int measuredWidth2 = childAt2.getMeasuredWidth();
                int measuredHeight2 = childAt2.getMeasuredHeight();
                int i20 = (i14 / 2) - (measuredWidth2 / 2);
                int i21 = i13 - (measuredHeight2 / 2);
                childAt2.layout(i20, i21, measuredWidth2 + i20, measuredHeight2 + i21);
                return;
            }
            int i22 = i17 - (i16 ^ 1);
            if (i22 > 0) {
                i5 = i15 / i22;
                i6 = 0;
            } else {
                i6 = 0;
                i5 = 0;
            }
            int max = Math.max(i6, i5);
            if (a2) {
                int width = getWidth() - getPaddingRight();
                while (i6 < childCount) {
                    View childAt3 = getChildAt(i6);
                    c cVar2 = (c) childAt3.getLayoutParams();
                    if (childAt3.getVisibility() != 8 && !cVar2.f83c) {
                        int i23 = width - cVar2.rightMargin;
                        int measuredWidth3 = childAt3.getMeasuredWidth();
                        int measuredHeight3 = childAt3.getMeasuredHeight();
                        int i24 = i13 - (measuredHeight3 / 2);
                        childAt3.layout(i23 - measuredWidth3, i24, i23, measuredHeight3 + i24);
                        width = i23 - ((measuredWidth3 + cVar2.leftMargin) + max);
                    }
                    i6++;
                }
                return;
            }
            int paddingLeft = getPaddingLeft();
            while (i6 < childCount) {
                View childAt4 = getChildAt(i6);
                c cVar3 = (c) childAt4.getLayoutParams();
                if (childAt4.getVisibility() != 8 && !cVar3.f83c) {
                    int i25 = paddingLeft + cVar3.leftMargin;
                    int measuredWidth4 = childAt4.getMeasuredWidth();
                    int measuredHeight4 = childAt4.getMeasuredHeight();
                    int i26 = i13 - (measuredHeight4 / 2);
                    childAt4.layout(i25, i26, i25 + measuredWidth4, measuredHeight4 + i26);
                    paddingLeft = measuredWidth4 + cVar3.rightMargin + max + i25;
                }
                i6++;
            }
        } else if (this.d == 1) {
            b(i9, i10, i11, i12);
        } else {
            a(i9, i10, i11, i12);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:106:0x01ce  */
    /* JADX WARNING: Removed duplicated region for block: B:118:0x020a  */
    /* JADX WARNING: Removed duplicated region for block: B:119:0x0210  */
    /* JADX WARNING: Removed duplicated region for block: B:122:0x0216  */
    /* JADX WARNING: Removed duplicated region for block: B:146:0x026a  */
    /* JADX WARNING: Removed duplicated region for block: B:155:0x0296  */
    /* JADX WARNING: Removed duplicated region for block: B:156:0x0299  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r31, int r32) {
        /*
            r30 = this;
            r0 = r30
            boolean r1 = r0.w
            int r2 = android.view.View.MeasureSpec.getMode(r31)
            r3 = 1073741824(0x40000000, float:2.0)
            r4 = 0
            r5 = 1
            if (r2 != r3) goto L_0x0010
            r2 = 1
            goto L_0x0011
        L_0x0010:
            r2 = 0
        L_0x0011:
            r0.w = r2
            boolean r2 = r0.w
            if (r1 == r2) goto L_0x0019
            r0.x = r4
        L_0x0019:
            int r1 = android.view.View.MeasureSpec.getSize(r31)
            boolean r2 = r0.w
            if (r2 == 0) goto L_0x002e
            b.b.e.a.k r2 = r0.p
            if (r2 == 0) goto L_0x002e
            int r6 = r0.x
            if (r1 == r6) goto L_0x002e
            r0.x = r1
            r2.b((boolean) r5)
        L_0x002e:
            int r1 = r30.getChildCount()
            boolean r2 = r0.w
            if (r2 == 0) goto L_0x02a1
            if (r1 <= 0) goto L_0x02a1
            int r1 = android.view.View.MeasureSpec.getMode(r32)
            int r2 = android.view.View.MeasureSpec.getSize(r31)
            int r6 = android.view.View.MeasureSpec.getSize(r32)
            int r7 = r30.getPaddingLeft()
            int r8 = r30.getPaddingRight()
            int r8 = r8 + r7
            int r7 = r30.getPaddingTop()
            int r9 = r30.getPaddingBottom()
            int r9 = r9 + r7
            r7 = -2
            r10 = r32
            int r7 = android.view.ViewGroup.getChildMeasureSpec(r10, r9, r7)
            int r2 = r2 - r8
            int r8 = r0.y
            int r10 = r2 / r8
            int r11 = r2 % r8
            if (r10 != 0) goto L_0x006b
            r0.setMeasuredDimension(r2, r4)
            goto L_0x02c4
        L_0x006b:
            int r11 = r11 / r10
            int r11 = r11 + r8
            int r8 = r30.getChildCount()
            r16 = r10
            r3 = 0
            r10 = 0
            r12 = 0
            r14 = 0
            r15 = 0
            r17 = 0
            r18 = 0
        L_0x007c:
            if (r10 >= r8) goto L_0x00f6
            android.view.View r13 = r0.getChildAt(r10)
            int r5 = r13.getVisibility()
            r4 = 8
            if (r5 != r4) goto L_0x008d
            r20 = r6
            goto L_0x00ef
        L_0x008d:
            boolean r4 = r13 instanceof androidx.appcompat.view.menu.ActionMenuItemView
            int r15 = r15 + 1
            if (r4 == 0) goto L_0x009c
            int r5 = r0.z
            r20 = r6
            r6 = 0
            r13.setPadding(r5, r6, r5, r6)
            goto L_0x009f
        L_0x009c:
            r20 = r6
            r6 = 0
        L_0x009f:
            android.view.ViewGroup$LayoutParams r5 = r13.getLayoutParams()
            androidx.appcompat.widget.ActionMenuView$c r5 = (androidx.appcompat.widget.ActionMenuView.c) r5
            r5.h = r6
            r5.e = r6
            r5.d = r6
            r5.f = r6
            r5.leftMargin = r6
            r5.rightMargin = r6
            if (r4 == 0) goto L_0x00be
            r4 = r13
            androidx.appcompat.view.menu.ActionMenuItemView r4 = (androidx.appcompat.view.menu.ActionMenuItemView) r4
            boolean r4 = r4.d()
            if (r4 == 0) goto L_0x00be
            r4 = 1
            goto L_0x00bf
        L_0x00be:
            r4 = 0
        L_0x00bf:
            r5.g = r4
            boolean r4 = r5.f83c
            if (r4 == 0) goto L_0x00c7
            r4 = 1
            goto L_0x00c9
        L_0x00c7:
            r4 = r16
        L_0x00c9:
            int r4 = a(r13, r11, r4, r7, r9)
            int r3 = java.lang.Math.max(r3, r4)
            boolean r6 = r5.f
            if (r6 == 0) goto L_0x00d7
            int r17 = r17 + 1
        L_0x00d7:
            boolean r5 = r5.f83c
            if (r5 == 0) goto L_0x00dc
            r14 = 1
        L_0x00dc:
            int r16 = r16 - r4
            int r5 = r13.getMeasuredHeight()
            int r5 = java.lang.Math.max(r12, r5)
            r6 = 1
            if (r4 != r6) goto L_0x00ee
            int r4 = r6 << r10
            long r12 = (long) r4
            long r18 = r18 | r12
        L_0x00ee:
            r12 = r5
        L_0x00ef:
            int r10 = r10 + 1
            r6 = r20
            r4 = 0
            r5 = 1
            goto L_0x007c
        L_0x00f6:
            r20 = r6
            r4 = 2
            if (r14 == 0) goto L_0x00ff
            if (r15 != r4) goto L_0x00ff
            r5 = 1
            goto L_0x0100
        L_0x00ff:
            r5 = 0
        L_0x0100:
            r6 = r16
            r9 = 0
        L_0x0103:
            r21 = 1
            if (r17 <= 0) goto L_0x01a8
            if (r6 <= 0) goto L_0x01a8
            r10 = 2147483647(0x7fffffff, float:NaN)
            r4 = 2147483647(0x7fffffff, float:NaN)
            r10 = 0
            r13 = 0
            r23 = 0
        L_0x0113:
            if (r10 >= r8) goto L_0x0144
            android.view.View r25 = r0.getChildAt(r10)
            android.view.ViewGroup$LayoutParams r25 = r25.getLayoutParams()
            r26 = r9
            r9 = r25
            androidx.appcompat.widget.ActionMenuView$c r9 = (androidx.appcompat.widget.ActionMenuView.c) r9
            r25 = r12
            boolean r12 = r9.f
            if (r12 != 0) goto L_0x012a
            goto L_0x013d
        L_0x012a:
            int r9 = r9.d
            if (r9 >= r4) goto L_0x0135
            long r12 = r21 << r10
            r4 = r9
            r23 = r12
            r13 = 1
            goto L_0x013d
        L_0x0135:
            if (r9 != r4) goto L_0x013d
            long r27 = r21 << r10
            long r23 = r23 | r27
            int r13 = r13 + 1
        L_0x013d:
            int r10 = r10 + 1
            r12 = r25
            r9 = r26
            goto L_0x0113
        L_0x0144:
            r26 = r9
            r25 = r12
            long r18 = r18 | r23
            if (r13 <= r6) goto L_0x0151
            r13 = r1
            r27 = r2
            goto L_0x01af
        L_0x0151:
            int r4 = r4 + 1
            r9 = r6
            r6 = 0
        L_0x0155:
            if (r6 >= r8) goto L_0x01a1
            android.view.View r10 = r0.getChildAt(r6)
            android.view.ViewGroup$LayoutParams r12 = r10.getLayoutParams()
            androidx.appcompat.widget.ActionMenuView$c r12 = (androidx.appcompat.widget.ActionMenuView.c) r12
            r27 = r2
            r13 = 1
            int r2 = r13 << r6
            r13 = r1
            long r1 = (long) r2
            long r21 = r23 & r1
            r28 = 0
            int r26 = (r21 > r28 ? 1 : (r21 == r28 ? 0 : -1))
            if (r26 != 0) goto L_0x0179
            int r10 = r12.d
            if (r10 != r4) goto L_0x0176
            long r18 = r18 | r1
        L_0x0176:
            r21 = r4
            goto L_0x0199
        L_0x0179:
            if (r5 == 0) goto L_0x018d
            boolean r1 = r12.g
            if (r1 == 0) goto L_0x018d
            r1 = 1
            if (r9 != r1) goto L_0x018d
            int r2 = r0.z
            int r1 = r2 + r11
            r21 = r4
            r4 = 0
            r10.setPadding(r1, r4, r2, r4)
            goto L_0x018f
        L_0x018d:
            r21 = r4
        L_0x018f:
            int r1 = r12.d
            r2 = 1
            int r1 = r1 + r2
            r12.d = r1
            r12.h = r2
            int r9 = r9 + -1
        L_0x0199:
            int r6 = r6 + 1
            r1 = r13
            r4 = r21
            r2 = r27
            goto L_0x0155
        L_0x01a1:
            r6 = r9
            r12 = r25
            r4 = 2
            r9 = 1
            goto L_0x0103
        L_0x01a8:
            r13 = r1
            r27 = r2
            r26 = r9
            r25 = r12
        L_0x01af:
            if (r14 != 0) goto L_0x01b6
            r1 = 1
            if (r15 != r1) goto L_0x01b7
            r2 = 1
            goto L_0x01b8
        L_0x01b6:
            r1 = 1
        L_0x01b7:
            r2 = 0
        L_0x01b8:
            if (r6 <= 0) goto L_0x0268
            r4 = 0
            int r9 = (r18 > r4 ? 1 : (r18 == r4 ? 0 : -1))
            if (r9 == 0) goto L_0x0268
            int r15 = r15 - r1
            if (r6 < r15) goto L_0x01c7
            if (r2 != 0) goto L_0x01c7
            if (r3 <= r1) goto L_0x0268
        L_0x01c7:
            int r1 = java.lang.Long.bitCount(r18)
            float r1 = (float) r1
            if (r2 != 0) goto L_0x0205
            long r2 = r18 & r21
            r4 = 1056964608(0x3f000000, float:0.5)
            r9 = 0
            int r5 = (r2 > r9 ? 1 : (r2 == r9 ? 0 : -1))
            if (r5 == 0) goto L_0x01e8
            r2 = 0
            android.view.View r3 = r0.getChildAt(r2)
            android.view.ViewGroup$LayoutParams r2 = r3.getLayoutParams()
            androidx.appcompat.widget.ActionMenuView$c r2 = (androidx.appcompat.widget.ActionMenuView.c) r2
            boolean r2 = r2.g
            if (r2 != 0) goto L_0x01e8
            float r1 = r1 - r4
        L_0x01e8:
            int r2 = r8 + -1
            r3 = 1
            int r5 = r3 << r2
            long r9 = (long) r5
            long r9 = r18 & r9
            r14 = 0
            int r3 = (r9 > r14 ? 1 : (r9 == r14 ? 0 : -1))
            if (r3 == 0) goto L_0x0205
            android.view.View r2 = r0.getChildAt(r2)
            android.view.ViewGroup$LayoutParams r2 = r2.getLayoutParams()
            androidx.appcompat.widget.ActionMenuView$c r2 = (androidx.appcompat.widget.ActionMenuView.c) r2
            boolean r2 = r2.g
            if (r2 != 0) goto L_0x0205
            float r1 = r1 - r4
        L_0x0205:
            r2 = 0
            int r2 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r2 <= 0) goto L_0x0210
            int r6 = r6 * r11
            float r2 = (float) r6
            float r2 = r2 / r1
            int r4 = (int) r2
            goto L_0x0211
        L_0x0210:
            r4 = 0
        L_0x0211:
            r5 = r26
            r1 = 0
        L_0x0214:
            if (r1 >= r8) goto L_0x0266
            r2 = 1
            int r3 = r2 << r1
            long r2 = (long) r3
            long r2 = r18 & r2
            r9 = 0
            int r6 = (r2 > r9 ? 1 : (r2 == r9 ? 0 : -1))
            if (r6 != 0) goto L_0x0224
            r6 = 2
            goto L_0x0263
        L_0x0224:
            android.view.View r2 = r0.getChildAt(r1)
            android.view.ViewGroup$LayoutParams r3 = r2.getLayoutParams()
            androidx.appcompat.widget.ActionMenuView$c r3 = (androidx.appcompat.widget.ActionMenuView.c) r3
            boolean r2 = r2 instanceof androidx.appcompat.view.menu.ActionMenuItemView
            if (r2 == 0) goto L_0x0244
            r3.e = r4
            r2 = 1
            r3.h = r2
            if (r1 != 0) goto L_0x0242
            boolean r2 = r3.g
            if (r2 != 0) goto L_0x0242
            int r2 = -r4
            r5 = 2
            int r2 = r2 / r5
            r3.leftMargin = r2
        L_0x0242:
            r6 = 2
            goto L_0x0252
        L_0x0244:
            boolean r2 = r3.f83c
            if (r2 == 0) goto L_0x0254
            r3.e = r4
            r2 = 1
            r3.h = r2
            int r2 = -r4
            r6 = 2
            int r2 = r2 / r6
            r3.rightMargin = r2
        L_0x0252:
            r5 = 1
            goto L_0x0263
        L_0x0254:
            r6 = 2
            if (r1 == 0) goto L_0x025b
            int r2 = r4 / 2
            r3.leftMargin = r2
        L_0x025b:
            int r2 = r8 + -1
            if (r1 == r2) goto L_0x0263
            int r2 = r4 / 2
            r3.rightMargin = r2
        L_0x0263:
            int r1 = r1 + 1
            goto L_0x0214
        L_0x0266:
            r26 = r5
        L_0x0268:
            if (r26 == 0) goto L_0x0291
            r1 = 0
        L_0x026b:
            if (r1 >= r8) goto L_0x0291
            android.view.View r2 = r0.getChildAt(r1)
            android.view.ViewGroup$LayoutParams r3 = r2.getLayoutParams()
            androidx.appcompat.widget.ActionMenuView$c r3 = (androidx.appcompat.widget.ActionMenuView.c) r3
            boolean r4 = r3.h
            if (r4 != 0) goto L_0x027e
            r3 = 1073741824(0x40000000, float:2.0)
            goto L_0x028e
        L_0x027e:
            int r4 = r3.d
            int r4 = r4 * r11
            int r3 = r3.e
            int r4 = r4 + r3
            r3 = 1073741824(0x40000000, float:2.0)
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r3)
            r2.measure(r4, r7)
        L_0x028e:
            int r1 = r1 + 1
            goto L_0x026b
        L_0x0291:
            r3 = 1073741824(0x40000000, float:2.0)
            r1 = r13
            if (r1 == r3) goto L_0x0299
            r1 = r25
            goto L_0x029b
        L_0x0299:
            r1 = r20
        L_0x029b:
            r2 = r27
            r0.setMeasuredDimension(r2, r1)
            goto L_0x02c4
        L_0x02a1:
            r10 = r32
            r2 = 0
        L_0x02a4:
            if (r2 >= r1) goto L_0x02b8
            android.view.View r3 = r0.getChildAt(r2)
            android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
            androidx.appcompat.widget.ActionMenuView$c r3 = (androidx.appcompat.widget.ActionMenuView.c) r3
            r4 = 0
            r3.rightMargin = r4
            r3.leftMargin = r4
            int r2 = r2 + 1
            goto L_0x02a4
        L_0x02b8:
            int r1 = r0.d
            r2 = 1
            if (r1 != r2) goto L_0x02c1
            r30.d(r31, r32)
            goto L_0x02c4
        L_0x02c1:
            r30.c(r31, r32)
        L_0x02c4:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionMenuView.onMeasure(int, int):void");
    }

    public void setExpandedActionViewsExclusive(boolean z2) {
        this.t.t = z2;
    }

    public void setOnMenuItemClickListener(e eVar) {
        this.A = eVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        C0044g gVar = this.t;
        C0044g.d dVar = gVar.i;
        if (dVar != null) {
            dVar.setImageDrawable(drawable);
            return;
        }
        gVar.k = true;
        gVar.j = drawable;
    }

    public void setOverflowReserved(boolean z2) {
        this.s = z2;
    }

    public void setPopupTheme(int i) {
        if (this.r != i) {
            this.r = i;
            if (i == 0) {
                this.q = getContext();
            } else {
                this.q = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public void setPresenter(C0044g gVar) {
        this.t = gVar;
        C0044g gVar2 = this.t;
        gVar2.h = this;
        a(gVar2.f243c);
    }
}
