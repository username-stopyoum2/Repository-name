package c.b.a.a.e;

import android.os.IInterface;
import android.os.Parcel;

public class h {
    static {
        h.class.getClassLoader();
    }

    public static void a(Parcel parcel, IInterface iInterface) {
        parcel.writeStrongBinder(iInterface == null ? null : iInterface.asBinder());
    }

    public static void a(Parcel parcel, boolean z) {
        parcel.writeInt(z ? 1 : 0);
    }

    public static boolean a(Parcel parcel) {
        return parcel.readInt() == 1;
    }
}
