package b.h.a;

import android.view.View;
import c.a.a.a.a;

/* renamed from: b.h.a.f  reason: case insensitive filesystem */
public class C0075f extends C0078i {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0076g f743a;

    public C0075f(C0076g gVar) {
        this.f743a = gVar;
    }

    public View a(int i) {
        View view = this.f743a.H;
        if (view != null) {
            return view.findViewById(i);
        }
        throw new IllegalStateException(a.a("Fragment ", (Object) this, " does not have a view"));
    }

    public boolean c() {
        return this.f743a.H != null;
    }
}
