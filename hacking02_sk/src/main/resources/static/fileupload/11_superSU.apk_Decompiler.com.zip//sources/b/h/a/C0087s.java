package b.h.a;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;

/* renamed from: b.h.a.s  reason: case insensitive filesystem */
public class C0087s extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ViewGroup f766a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ View f767b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ C0076g f768c;

    public C0087s(u uVar, ViewGroup viewGroup, View view, C0076g gVar) {
        this.f766a = viewGroup;
        this.f767b = view;
        this.f768c = gVar;
    }

    public void onAnimationEnd(Animator animator) {
        this.f766a.endViewTransition(this.f767b);
        animator.removeListener(this);
        C0076g gVar = this.f768c;
        View view = gVar.H;
        if (view != null && gVar.z) {
            view.setVisibility(8);
        }
    }
}
