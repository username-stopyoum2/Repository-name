package com.facebook.ads;

import androidx.annotation.Keep;

@Keep
public interface S2SRewardedVideoAdExtendedListener extends RewardedVideoAdExtendedListener, S2SRewardedVideoAdListener {
}
