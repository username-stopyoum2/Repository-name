package androidx.media;

import android.media.AudioAttributes;
import android.os.Parcelable;
import b.l.b;

public final class AudioAttributesImplApi21Parcelizer {
    public static b read(b.o.b bVar) {
        b bVar2 = new b();
        bVar2.f817a = (AudioAttributes) bVar.a(bVar2.f817a, 1);
        bVar2.f818b = bVar.a(bVar2.f818b, 2);
        return bVar2;
    }

    public static void write(b bVar, b.o.b bVar2) {
        bVar2.a(false, false);
        bVar2.b((Parcelable) bVar.f817a, 1);
        bVar2.b(bVar.f818b, 2);
    }
}
