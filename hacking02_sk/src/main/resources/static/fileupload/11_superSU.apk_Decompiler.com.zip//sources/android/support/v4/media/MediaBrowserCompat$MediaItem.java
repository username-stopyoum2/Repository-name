package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable;

public class MediaBrowserCompat$MediaItem implements Parcelable {
    public static final Parcelable.Creator<MediaBrowserCompat$MediaItem> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    public final int f16a;

    /* renamed from: b  reason: collision with root package name */
    public final MediaDescriptionCompat f17b;

    public MediaBrowserCompat$MediaItem(Parcel parcel) {
        this.f16a = parcel.readInt();
        this.f17b = MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return "MediaItem{" + "mFlags=" + this.f16a + ", mDescription=" + this.f17b + '}';
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f16a);
        this.f17b.writeToParcel(parcel, i);
    }
}
