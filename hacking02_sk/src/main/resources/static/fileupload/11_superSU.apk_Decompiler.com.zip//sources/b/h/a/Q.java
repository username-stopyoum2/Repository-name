package b.h.a;

import b.j.e;
import b.j.h;
import b.j.i;

public class Q implements h {

    /* renamed from: a  reason: collision with root package name */
    public i f737a = null;

    public e a() {
        if (this.f737a == null) {
            this.f737a = new i(this);
        }
        return this.f737a;
    }
}
