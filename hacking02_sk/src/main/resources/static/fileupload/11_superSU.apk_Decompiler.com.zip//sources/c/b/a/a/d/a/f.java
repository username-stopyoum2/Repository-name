package c.b.a.a.d.a;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.concurrent.Callable;

public final class f implements Callable<SharedPreferences> {

    /* renamed from: a  reason: collision with root package name */
    public /* synthetic */ Context f898a;

    public f(Context context) {
        this.f898a = context;
    }

    public final /* synthetic */ Object call() {
        return this.f898a.getSharedPreferences("google_sdk_flags", 0);
    }
}
