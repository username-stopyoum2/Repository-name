package androidx.lifecycle;

import b.j.d;
import b.j.e;
import b.j.f;
import b.j.h;

public final class Lifecycling$1 implements d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ f f126a;

    public void a(h hVar, e.a aVar) {
        this.f126a.a(hVar, aVar);
    }
}
