package b.h.a;

import android.view.ViewGroup;
import android.view.animation.Animation;

/* renamed from: b.h.a.q  reason: case insensitive filesystem */
public class C0086q implements Animation.AnimationListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ViewGroup f760a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ C0076g f761b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ u f762c;

    public C0086q(u uVar, ViewGroup viewGroup, C0076g gVar) {
        this.f762c = uVar;
        this.f760a = viewGroup;
        this.f761b = gVar;
    }

    public void onAnimationEnd(Animation animation) {
        this.f760a.post(new C0085p(this));
    }

    public void onAnimationRepeat(Animation animation) {
    }

    public void onAnimationStart(Animation animation) {
    }
}
