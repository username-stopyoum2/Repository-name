package b.h.a;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: b.h.a.b  reason: case insensitive filesystem */
class C0071b implements Parcelable.Creator<C0072c> {
    public Object createFromParcel(Parcel parcel) {
        return new C0072c(parcel);
    }

    public Object[] newArray(int i) {
        return new C0072c[i];
    }
}
