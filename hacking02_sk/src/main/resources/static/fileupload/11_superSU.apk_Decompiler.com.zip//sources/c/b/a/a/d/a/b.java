package c.b.a.a.d.a;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

public final class b implements Callable<Integer> {

    /* renamed from: a  reason: collision with root package name */
    public /* synthetic */ SharedPreferences f888a;

    /* renamed from: b  reason: collision with root package name */
    public /* synthetic */ String f889b;

    /* renamed from: c  reason: collision with root package name */
    public /* synthetic */ Integer f890c;

    public b(SharedPreferences sharedPreferences, String str, Integer num) {
        this.f888a = sharedPreferences;
        this.f889b = str;
        this.f890c = num;
    }

    public final /* synthetic */ Object call() {
        return Integer.valueOf(this.f888a.getInt(this.f889b, this.f890c.intValue()));
    }
}
