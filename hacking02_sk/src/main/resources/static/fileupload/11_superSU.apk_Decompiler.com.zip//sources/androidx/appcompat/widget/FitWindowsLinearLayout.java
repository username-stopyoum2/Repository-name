package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import b.b.a.s;
import b.b.f.S;

public class FitWindowsLinearLayout extends LinearLayout implements S {

    /* renamed from: a  reason: collision with root package name */
    public S.a f93a;

    public FitWindowsLinearLayout(Context context) {
        super(context);
    }

    public FitWindowsLinearLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean fitSystemWindows(Rect rect) {
        S.a aVar = this.f93a;
        if (aVar != null) {
            rect.top = ((s) aVar).f196a.g(rect.top);
        }
        return super.fitSystemWindows(rect);
    }

    public void setOnFitSystemWindowsListener(S.a aVar) {
        this.f93a = aVar;
    }
}
