package androidx.fragment.app;

import android.view.View;
import b.h.a.C0076g;
import b.j.e;
import b.j.f;
import b.j.h;

class Fragment$2 implements f {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0076g f122a;

    public Fragment$2(C0076g gVar) {
        this.f122a = gVar;
    }

    public void a(h hVar, e.a aVar) {
        View view;
        if (aVar == e.a.ON_STOP && (view = this.f122a.H) != null) {
            view.cancelPendingInputEvents();
        }
    }
}
