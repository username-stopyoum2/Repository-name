package c.b.a.a.d.a;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

public final class d implements Callable<String> {

    /* renamed from: a  reason: collision with root package name */
    public /* synthetic */ SharedPreferences f894a;

    /* renamed from: b  reason: collision with root package name */
    public /* synthetic */ String f895b;

    /* renamed from: c  reason: collision with root package name */
    public /* synthetic */ String f896c;

    public d(SharedPreferences sharedPreferences, String str, String str2) {
        this.f894a = sharedPreferences;
        this.f895b = str;
        this.f896c = str2;
    }

    public final /* synthetic */ Object call() {
        return this.f894a.getString(this.f895b, this.f896c);
    }
}
