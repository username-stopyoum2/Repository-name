package androidx.activity;

import b.a.c;
import b.j.e;
import b.j.f;
import b.j.h;

class ComponentActivity$3 implements f {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c f45a;

    public ComponentActivity$3(c cVar) {
        this.f45a = cVar;
    }

    public void a(h hVar, e.a aVar) {
        if (aVar == e.a.ON_DESTROY && !this.f45a.isChangingConfigurations()) {
            this.f45a.d().a();
        }
    }
}
