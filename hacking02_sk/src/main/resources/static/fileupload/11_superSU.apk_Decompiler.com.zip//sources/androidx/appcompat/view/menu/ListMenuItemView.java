package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import b.b.a;
import b.b.e.a.o;
import b.b.e.a.u;
import b.b.f;
import b.b.f.xa;
import b.b.g;
import b.b.h;
import b.b.j;
import b.e.h.s;

public class ListMenuItemView extends LinearLayout implements u.a, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: a  reason: collision with root package name */
    public o f74a;

    /* renamed from: b  reason: collision with root package name */
    public ImageView f75b;

    /* renamed from: c  reason: collision with root package name */
    public RadioButton f76c;
    public TextView d;
    public CheckBox e;
    public TextView f;
    public ImageView g;
    public ImageView h;
    public LinearLayout i;
    public Drawable j;
    public int k;
    public Context l;
    public boolean m;
    public Drawable n;
    public boolean o;
    public LayoutInflater p;
    public boolean q;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, a.listMenuViewStyle);
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet);
        xa a2 = xa.a(getContext(), attributeSet, j.MenuView, i2, 0);
        this.j = a2.b(j.MenuView_android_itemBackground);
        this.k = a2.e(j.MenuView_android_itemTextAppearance, -1);
        this.m = a2.a(j.MenuView_preserveIconSpacing, false);
        this.l = context;
        this.n = a2.b(j.MenuView_subMenuArrow);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes((AttributeSet) null, new int[]{16843049}, a.dropDownListViewStyle, 0);
        this.o = obtainStyledAttributes.hasValue(0);
        a2.f496b.recycle();
        obtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.p == null) {
            this.p = LayoutInflater.from(getContext());
        }
        return this.p;
    }

    private void setSubMenuArrowVisible(boolean z) {
        ImageView imageView = this.g;
        if (imageView != null) {
            imageView.setVisibility(z ? 0 : 8);
        }
    }

    public final void a() {
        this.e = (CheckBox) getInflater().inflate(g.abc_list_menu_item_checkbox, this, false);
        a(this.e);
    }

    public final void a(View view) {
        LinearLayout linearLayout = this.i;
        if (linearLayout != null) {
            linearLayout.addView(view, -1);
        } else {
            addView(view, -1);
        }
    }

    public final void a(View view, int i2) {
        LinearLayout linearLayout = this.i;
        if (linearLayout != null) {
            linearLayout.addView(view, i2);
        } else {
            addView(view, i2);
        }
    }

    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.h;
        if (imageView != null && imageView.getVisibility() == 0) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.h.getLayoutParams();
            rect.top = this.h.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
        }
    }

    public final void b() {
        this.f76c = (RadioButton) getInflater().inflate(g.abc_list_menu_item_radio, this, false);
        a(this.f76c);
    }

    public boolean c() {
        return false;
    }

    public o getItemData() {
        return this.f74a;
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        s.a((View) this, this.j);
        this.d = (TextView) findViewById(f.title);
        int i2 = this.k;
        if (i2 != -1) {
            this.d.setTextAppearance(this.l, i2);
        }
        this.f = (TextView) findViewById(f.shortcut);
        this.g = (ImageView) findViewById(f.submenuarrow);
        ImageView imageView = this.g;
        if (imageView != null) {
            imageView.setImageDrawable(this.n);
        }
        this.h = (ImageView) findViewById(f.group_divider);
        this.i = (LinearLayout) findViewById(f.content);
    }

    public void onMeasure(int i2, int i3) {
        if (this.f75b != null && this.m) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f75b.getLayoutParams();
            if (layoutParams.height > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = layoutParams.height;
            }
        }
        super.onMeasure(i2, i3);
    }

    public void setCheckable(boolean z) {
        CompoundButton compoundButton;
        CompoundButton compoundButton2;
        if (z || this.f76c != null || this.e != null) {
            if (this.f74a.e()) {
                if (this.f76c == null) {
                    b();
                }
                compoundButton2 = this.f76c;
                compoundButton = this.e;
            } else {
                if (this.e == null) {
                    a();
                }
                compoundButton2 = this.e;
                compoundButton = this.f76c;
            }
            if (z) {
                compoundButton2.setChecked((this.f74a.y & 2) == 2);
                if (compoundButton2.getVisibility() != 0) {
                    compoundButton2.setVisibility(0);
                }
                if (compoundButton != null && compoundButton.getVisibility() != 8) {
                    compoundButton.setVisibility(8);
                    return;
                }
                return;
            }
            CheckBox checkBox = this.e;
            if (checkBox != null) {
                checkBox.setVisibility(8);
            }
            RadioButton radioButton = this.f76c;
            if (radioButton != null) {
                radioButton.setVisibility(8);
            }
        }
    }

    public void setChecked(boolean z) {
        CompoundButton compoundButton;
        if (this.f74a.e()) {
            if (this.f76c == null) {
                b();
            }
            compoundButton = this.f76c;
        } else {
            if (this.e == null) {
                a();
            }
            compoundButton = this.e;
        }
        compoundButton.setChecked(z);
    }

    public void setForceShowIcon(boolean z) {
        this.q = z;
        this.m = z;
    }

    public void setGroupDividerEnabled(boolean z) {
        ImageView imageView = this.h;
        if (imageView != null) {
            imageView.setVisibility((this.o || !z) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        boolean z = this.f74a.n.u || this.q;
        if (!z && !this.m) {
            return;
        }
        if (this.f75b != null || drawable != null || this.m) {
            if (this.f75b == null) {
                this.f75b = (ImageView) getInflater().inflate(g.abc_list_menu_item_icon, this, false);
                a((View) this.f75b, 0);
            }
            if (drawable != null || this.m) {
                ImageView imageView = this.f75b;
                if (!z) {
                    drawable = null;
                }
                imageView.setImageDrawable(drawable);
                if (this.f75b.getVisibility() != 0) {
                    this.f75b.setVisibility(0);
                    return;
                }
                return;
            }
            this.f75b.setVisibility(8);
        }
    }

    public void setTitle(CharSequence charSequence) {
        TextView textView;
        int i2;
        if (charSequence != null) {
            this.d.setText(charSequence);
            if (this.d.getVisibility() != 0) {
                textView = this.d;
                i2 = 0;
            } else {
                return;
            }
        } else {
            i2 = 8;
            if (this.d.getVisibility() != 8) {
                textView = this.d;
            } else {
                return;
            }
        }
        textView.setVisibility(i2);
    }

    public void a(o oVar, int i2) {
        this.f74a = oVar;
        boolean z = false;
        setVisibility(oVar.isVisible() ? 0 : 8);
        setTitle(oVar.a((u.a) this));
        if ((oVar.y & 1) == 1) {
            z = true;
        }
        setCheckable(z);
        a(oVar.f(), oVar.b());
        setIcon(oVar.getIcon());
        setEnabled(oVar.isEnabled());
        setSubMenuArrowVisible(oVar.hasSubMenu());
        setContentDescription(oVar.r);
    }

    public void a(boolean z, char c2) {
        String str;
        int i2;
        int i3 = (!z || !this.f74a.f()) ? 8 : 0;
        if (i3 == 0) {
            TextView textView = this.f;
            o oVar = this.f74a;
            char b2 = oVar.b();
            if (b2 == 0) {
                str = "";
            } else {
                Resources resources = oVar.n.f267b.getResources();
                StringBuilder sb = new StringBuilder();
                if (ViewConfiguration.get(oVar.n.f267b).hasPermanentMenuKey()) {
                    sb.append(resources.getString(h.abc_prepend_shortcut_label));
                }
                int i4 = oVar.n.f() ? oVar.k : oVar.i;
                o.a(sb, i4, 65536, resources.getString(h.abc_menu_meta_shortcut_label));
                o.a(sb, i4, 4096, resources.getString(h.abc_menu_ctrl_shortcut_label));
                o.a(sb, i4, 2, resources.getString(h.abc_menu_alt_shortcut_label));
                o.a(sb, i4, 1, resources.getString(h.abc_menu_shift_shortcut_label));
                o.a(sb, i4, 4, resources.getString(h.abc_menu_sym_shortcut_label));
                o.a(sb, i4, 8, resources.getString(h.abc_menu_function_shortcut_label));
                if (b2 == 8) {
                    i2 = h.abc_menu_delete_shortcut_label;
                } else if (b2 == 10) {
                    i2 = h.abc_menu_enter_shortcut_label;
                } else if (b2 != ' ') {
                    sb.append(b2);
                    str = sb.toString();
                } else {
                    i2 = h.abc_menu_space_shortcut_label;
                }
                sb.append(resources.getString(i2));
                str = sb.toString();
            }
            textView.setText(str);
        }
        if (this.f.getVisibility() != i3) {
            this.f.setVisibility(i3);
        }
    }
}
