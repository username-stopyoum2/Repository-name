package c.b.a.a.b.b;

import java.util.Collections;
import java.util.List;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public static final Object f874a = new Object();

    /* renamed from: b  reason: collision with root package name */
    public static volatile a f875b;

    public a() {
        List list = Collections.EMPTY_LIST;
    }

    public static a a() {
        if (f875b == null) {
            synchronized (f874a) {
                if (f875b == null) {
                    f875b = new a();
                }
            }
        }
        return f875b;
    }

    /* JADX WARNING: Removed duplicated region for block: B:11:0x002c  */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0034  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean a(android.content.Context r4, android.content.Intent r5, android.content.ServiceConnection r6, int r7) {
        /*
            r3 = this;
            java.lang.Class r0 = r4.getClass()
            r0.getName()
            android.content.ComponentName r0 = r5.getComponent()
            r1 = 0
            if (r0 != 0) goto L_0x000f
            goto L_0x0029
        L_0x000f:
            java.lang.String r0 = r0.getPackageName()
            java.lang.String r2 = "com.google.android.gms"
            r2.equals(r0)
            c.b.a.a.e.a r2 = c.b.a.a.e.b.b(r4)     // Catch:{ NameNotFoundException -> 0x0029 }
            android.content.pm.ApplicationInfo r0 = r2.a(r0, r1)     // Catch:{ NameNotFoundException -> 0x0029 }
            int r0 = r0.flags     // Catch:{ NameNotFoundException -> 0x0029 }
            r2 = 2097152(0x200000, float:2.938736E-39)
            r0 = r0 & r2
            if (r0 == 0) goto L_0x0029
            r0 = 1
            goto L_0x002a
        L_0x0029:
            r0 = 0
        L_0x002a:
            if (r0 == 0) goto L_0x0034
            java.lang.String r4 = "ConnectionTracker"
            java.lang.String r5 = "Attempted to bind to a service in a STOPPED package."
            android.util.Log.w(r4, r5)
            goto L_0x0038
        L_0x0034:
            boolean r1 = r4.bindService(r5, r6, r7)
        L_0x0038:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.a.a.b.b.a.a(android.content.Context, android.content.Intent, android.content.ServiceConnection, int):boolean");
    }
}
