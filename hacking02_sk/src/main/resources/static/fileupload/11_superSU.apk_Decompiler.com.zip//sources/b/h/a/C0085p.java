package b.h.a;

import android.view.View;

/* renamed from: b.h.a.p  reason: case insensitive filesystem */
class C0085p implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0086q f759a;

    public C0085p(C0086q qVar) {
        this.f759a = qVar;
    }

    public void run() {
        if (this.f759a.f761b.g() != null) {
            this.f759a.f761b.a((View) null);
            C0086q qVar = this.f759a;
            u uVar = qVar.f762c;
            C0076g gVar = qVar.f761b;
            uVar.a(gVar, gVar.r(), 0, 0, false);
        }
    }
}
