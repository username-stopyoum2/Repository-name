package c.b.a.a.b;

public final class a extends Exception {
    public a(int i) {
    }
}
