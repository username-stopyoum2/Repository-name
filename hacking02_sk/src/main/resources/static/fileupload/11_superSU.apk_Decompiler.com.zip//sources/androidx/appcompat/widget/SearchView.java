package androidx.appcompat.widget;

import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import b.b.f.C0048i;
import b.b.f.Ka;
import b.b.f.U;
import b.b.f.ra;
import b.b.f.xa;
import b.b.g;
import b.b.h;
import b.b.j;
import b.e.h.s;
import java.lang.reflect.Method;
import java.util.WeakHashMap;

public class SearchView extends U implements b.b.e.b {
    public static final a p = new a();
    public Rect A;
    public Rect B;
    public int[] C;
    public int[] D;
    public final ImageView E;
    public final Drawable F;
    public final int G;
    public final int H;
    public final Intent I;
    public final Intent J;
    public final CharSequence K;
    public View.OnFocusChangeListener L;
    public View.OnClickListener M;
    public boolean N;
    public boolean O;
    public b.f.a.a P;
    public boolean Q;
    public CharSequence R;
    public boolean S;
    public boolean T;
    public int U;
    public boolean V;
    public CharSequence W;
    public CharSequence aa;
    public boolean ba;
    public int ca;
    public SearchableInfo da;
    public Bundle ea;
    public final Runnable fa;
    public Runnable ga;
    public final WeakHashMap<String, Drawable.ConstantState> ha;
    public final View.OnClickListener ia;
    public View.OnKeyListener ja;
    public final TextView.OnEditorActionListener ka;
    public final AdapterView.OnItemClickListener la;
    public final AdapterView.OnItemSelectedListener ma;
    public TextWatcher na;
    public final SearchAutoComplete q;
    public final View r;
    public final View s;
    public final View t;
    public final ImageView u;
    public final ImageView v;
    public final ImageView w;
    public final ImageView x;
    public final View y;
    public f z;

    public static class SearchAutoComplete extends C0048i {
        public int d;
        public SearchView e;
        public boolean f;
        public final Runnable g;

        public SearchAutoComplete(Context context) {
            this(context, (AttributeSet) null, b.b.a.autoCompleteTextViewStyle);
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            this(context, attributeSet, b.b.a.autoCompleteTextViewStyle);
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet, int i) {
            super(context, attributeSet, i);
            this.g = new qa(this);
            this.d = getThreshold();
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i = configuration.screenWidthDp;
            int i2 = configuration.screenHeightDp;
            if (i >= 960 && i2 >= 720 && configuration.orientation == 2) {
                return 256;
            }
            if (i < 600) {
                return (i < 640 || i2 < 480) ? 160 : 192;
            }
            return 192;
        }

        public boolean a() {
            return TextUtils.getTrimmedLength(getText()) == 0;
        }

        public void b() {
            if (this.f) {
                ((InputMethodManager) getContext().getSystemService("input_method")).showSoftInput(this, 0);
                this.f = false;
            }
        }

        public boolean enoughToFilter() {
            return this.d <= 0 || super.enoughToFilter();
        }

        public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.f) {
                removeCallbacks(this.g);
                post(this.g);
            }
            return onCreateInputConnection;
        }

        public void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, (float) getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        public void onFocusChanged(boolean z, int i, Rect rect) {
            super.onFocusChanged(z, i, rect);
            this.e.h();
        }

        public boolean onKeyPreIme(int i, KeyEvent keyEvent) {
            if (i == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                } else if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.e.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i, keyEvent);
        }

        public void onWindowFocusChanged(boolean z) {
            Method method;
            super.onWindowFocusChanged(z);
            if (z && this.e.hasFocus() && getVisibility() == 0) {
                this.f = true;
                if (SearchView.a(getContext()) && (method = SearchView.p.f96c) != null) {
                    try {
                        method.invoke(this, new Object[]{true});
                    } catch (Exception unused) {
                    }
                }
            }
        }

        public void performCompletion() {
        }

        public void replaceText(CharSequence charSequence) {
        }

        public void setImeVisibility(boolean z) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            if (!z) {
                this.f = false;
                removeCallbacks(this.g);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else if (inputMethodManager.isActive(this)) {
                this.f = false;
                removeCallbacks(this.g);
                inputMethodManager.showSoftInput(this, 0);
            } else {
                this.f = true;
            }
        }

        public void setSearchView(SearchView searchView) {
            this.e = searchView;
        }

        public void setThreshold(int i) {
            super.setThreshold(i);
            this.d = i;
        }
    }

    private static class a {

        /* renamed from: a  reason: collision with root package name */
        public Method f94a;

        /* renamed from: b  reason: collision with root package name */
        public Method f95b;

        /* renamed from: c  reason: collision with root package name */
        public Method f96c;

        public a() {
            try {
                this.f94a = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
                this.f94a.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                this.f95b = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
                this.f95b.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            Class<AutoCompleteTextView> cls = AutoCompleteTextView.class;
            try {
                this.f96c = cls.getMethod("ensureImeVisible", new Class[]{Boolean.TYPE});
                this.f96c.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
        }
    }

    public interface b {
    }

    public interface c {
    }

    public interface d {
    }

    static class e extends b.g.a.c {
        public static final Parcelable.Creator<e> CREATOR = new pa();

        /* renamed from: c  reason: collision with root package name */
        public boolean f97c;

        public e(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f97c = ((Boolean) parcel.readValue((ClassLoader) null)).booleanValue();
        }

        public e(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder a2 = c.a.a.a.a.a("SearchView.SavedState{");
            a2.append(Integer.toHexString(System.identityHashCode(this)));
            a2.append(" isIconified=");
            a2.append(this.f97c);
            a2.append("}");
            return a2.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f697b, i);
            parcel.writeValue(Boolean.valueOf(this.f97c));
        }
    }

    private static class f extends TouchDelegate {

        /* renamed from: a  reason: collision with root package name */
        public final View f98a;

        /* renamed from: b  reason: collision with root package name */
        public final Rect f99b = new Rect();

        /* renamed from: c  reason: collision with root package name */
        public final Rect f100c = new Rect();
        public final Rect d = new Rect();
        public final int e;
        public boolean f;

        public f(Rect rect, Rect rect2, View view) {
            super(rect, view);
            this.e = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
            a(rect, rect2);
            this.f98a = view;
        }

        public void a(Rect rect, Rect rect2) {
            this.f99b.set(rect);
            this.d.set(rect);
            Rect rect3 = this.d;
            int i = this.e;
            rect3.inset(-i, -i);
            this.f100c.set(rect2);
        }

        /* JADX WARNING: Removed duplicated region for block: B:17:0x003d  */
        /* JADX WARNING: Removed duplicated region for block: B:24:? A[RETURN, SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean onTouchEvent(android.view.MotionEvent r8) {
            /*
                r7 = this;
                float r0 = r8.getX()
                int r0 = (int) r0
                float r1 = r8.getY()
                int r1 = (int) r1
                int r2 = r8.getAction()
                r3 = 2
                r4 = 1
                r5 = 0
                if (r2 == 0) goto L_0x002e
                if (r2 == r4) goto L_0x0020
                if (r2 == r3) goto L_0x0020
                r6 = 3
                if (r2 == r6) goto L_0x001b
                goto L_0x003a
            L_0x001b:
                boolean r2 = r7.f
                r7.f = r5
                goto L_0x003b
            L_0x0020:
                boolean r2 = r7.f
                if (r2 == 0) goto L_0x003b
                android.graphics.Rect r6 = r7.d
                boolean r6 = r6.contains(r0, r1)
                if (r6 != 0) goto L_0x003b
                r4 = 0
                goto L_0x003b
            L_0x002e:
                android.graphics.Rect r2 = r7.f99b
                boolean r2 = r2.contains(r0, r1)
                if (r2 == 0) goto L_0x003a
                r7.f = r4
                r2 = 1
                goto L_0x003b
            L_0x003a:
                r2 = 0
            L_0x003b:
                if (r2 == 0) goto L_0x006a
                if (r4 == 0) goto L_0x0057
                android.graphics.Rect r2 = r7.f100c
                boolean r2 = r2.contains(r0, r1)
                if (r2 != 0) goto L_0x0057
                android.view.View r0 = r7.f98a
                int r0 = r0.getWidth()
                int r0 = r0 / r3
                float r0 = (float) r0
                android.view.View r1 = r7.f98a
                int r1 = r1.getHeight()
                int r1 = r1 / r3
                goto L_0x0060
            L_0x0057:
                android.graphics.Rect r2 = r7.f100c
                int r3 = r2.left
                int r0 = r0 - r3
                float r0 = (float) r0
                int r2 = r2.top
                int r1 = r1 - r2
            L_0x0060:
                float r1 = (float) r1
                r8.setLocation(r0, r1)
                android.view.View r0 = r7.f98a
                boolean r5 = r0.dispatchTouchEvent(r8)
            L_0x006a:
                return r5
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.f.onTouchEvent(android.view.MotionEvent):boolean");
        }
    }

    public SearchView(Context context) {
        this(context, (AttributeSet) null, b.b.a.searchViewStyle);
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b.b.a.searchViewStyle);
    }

    public static boolean a(Context context) {
        return context.getResources().getConfiguration().orientation == 2;
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(b.b.d.abc_search_view_preferred_height);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(b.b.d.abc_search_view_preferred_width);
    }

    private void setQuery(CharSequence charSequence) {
        this.q.setText(charSequence);
        this.q.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    public final Intent a(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1073741824);
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.ea;
        if (bundle2 != null) {
            bundle.putParcelable("app_data", bundle2);
        }
        Intent intent3 = new Intent(intent);
        int i = 1;
        Resources resources = getResources();
        String string = searchableInfo.getVoiceLanguageModeId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageModeId()) : "free_form";
        String str = null;
        String string2 = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string3 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        if (searchableInfo.getVoiceMaxResults() != 0) {
            i = searchableInfo.getVoiceMaxResults();
        }
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", string);
        intent3.putExtra("android.speech.extra.PROMPT", string2);
        intent3.putExtra("android.speech.extra.LANGUAGE", string3);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", i);
        if (searchActivity != null) {
            str = searchActivity.flattenToShortString();
        }
        intent3.putExtra("calling_package", str);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    public final Intent a(String str, Uri uri, String str2, String str3, int i, String str4) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.aa);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.ea;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        if (i != 0) {
            intent.putExtra("action_key", i);
            intent.putExtra("action_msg", str4);
        }
        intent.setComponent(this.da.getSearchActivity());
        return intent;
    }

    public void a() {
        if (this.y.getWidth() > 1) {
            Resources resources = getContext().getResources();
            int paddingLeft = this.s.getPaddingLeft();
            Rect rect = new Rect();
            boolean a2 = Ka.a(this);
            int dimensionPixelSize = this.N ? resources.getDimensionPixelSize(b.b.d.abc_dropdownitem_text_padding_left) + resources.getDimensionPixelSize(b.b.d.abc_dropdownitem_icon_width) : 0;
            this.q.getDropDownBackground().getPadding(rect);
            this.q.setDropDownHorizontalOffset(a2 ? -rect.left : paddingLeft - (rect.left + dimensionPixelSize));
            this.q.setDropDownWidth((((this.y.getWidth() + rect.left) + rect.right) + dimensionPixelSize) - paddingLeft);
        }
    }

    public void a(int i, String str, String str2) {
        getContext().startActivity(a("android.intent.action.SEARCH", (Uri) null, (String) null, str2, i, str));
    }

    public void a(CharSequence charSequence) {
        setQuery(charSequence);
    }

    public void a(CharSequence charSequence, boolean z2) {
        this.q.setText(charSequence);
        if (charSequence != null) {
            SearchAutoComplete searchAutoComplete = this.q;
            searchAutoComplete.setSelection(searchAutoComplete.length());
            this.aa = charSequence;
        }
        if (z2 && !TextUtils.isEmpty(charSequence)) {
            g();
        }
    }

    public final void a(boolean z2) {
        this.v.setVisibility((!this.Q || !d() || !hasFocus() || (!z2 && this.V)) ? 8 : 0);
    }

    public boolean a(int i, int i2, String str) {
        int i3;
        String a2;
        Cursor cursor = this.P.f692c;
        if (cursor != null && cursor.moveToPosition(i)) {
            Intent intent = null;
            try {
                String a3 = ra.a(cursor, "suggest_intent_action");
                if (a3 == null) {
                    a3 = this.da.getSuggestIntentAction();
                }
                if (a3 == null) {
                    a3 = "android.intent.action.SEARCH";
                }
                String str2 = a3;
                String a4 = ra.a(cursor, "suggest_intent_data");
                if (a4 == null) {
                    a4 = this.da.getSuggestIntentData();
                }
                if (!(a4 == null || (a2 = ra.a(cursor, "suggest_intent_data_id")) == null)) {
                    a4 = a4 + "/" + Uri.encode(a2);
                }
                intent = a(str2, a4 == null ? null : Uri.parse(a4), ra.a(cursor, "suggest_intent_extra_data"), ra.a(cursor, "suggest_intent_query"), 0, (String) null);
            } catch (RuntimeException e2) {
                try {
                    i3 = cursor.getPosition();
                } catch (RuntimeException unused) {
                    i3 = -1;
                }
                Log.w("SearchView", "Search suggestions cursor at row " + i3 + " returned exception.", e2);
            }
            if (intent != null) {
                try {
                    getContext().startActivity(intent);
                } catch (RuntimeException e3) {
                    Log.e("SearchView", "Failed launch activity: " + intent, e3);
                }
            }
        }
        this.q.setImeVisibility(false);
        this.q.dismissDropDown();
        return true;
    }

    public void b() {
        if (Build.VERSION.SDK_INT >= 29) {
            this.q.refreshAutoCompleteResults();
            return;
        }
        a aVar = p;
        SearchAutoComplete searchAutoComplete = this.q;
        Method method = aVar.f94a;
        if (method != null) {
            try {
                method.invoke(searchAutoComplete, new Object[0]);
            } catch (Exception unused) {
            }
        }
        a aVar2 = p;
        SearchAutoComplete searchAutoComplete2 = this.q;
        Method method2 = aVar2.f95b;
        if (method2 != null) {
            try {
                method2.invoke(searchAutoComplete2, new Object[0]);
            } catch (Exception unused2) {
            }
        }
    }

    public void b(CharSequence charSequence) {
        Editable text = this.q.getText();
        this.aa = text;
        boolean z2 = true;
        boolean z3 = !TextUtils.isEmpty(text);
        a(z3);
        if (z3) {
            z2 = false;
        }
        c(z2);
        j();
        m();
        this.W = charSequence.toString();
    }

    public final void b(boolean z2) {
        this.O = z2;
        int i = 8;
        boolean z3 = false;
        int i2 = z2 ? 0 : 8;
        boolean z4 = !TextUtils.isEmpty(this.q.getText());
        this.u.setVisibility(i2);
        a(z4);
        this.r.setVisibility(z2 ? 8 : 0);
        if (this.E.getDrawable() != null && !this.N) {
            i = 0;
        }
        this.E.setVisibility(i);
        j();
        if (!z4) {
            z3 = true;
        }
        c(z3);
        m();
    }

    public final void c(boolean z2) {
        int i;
        if (!this.V || c() || !z2) {
            i = 8;
        } else {
            i = 0;
            this.v.setVisibility(8);
        }
        this.x.setVisibility(i);
    }

    public boolean c() {
        return this.O;
    }

    public void clearFocus() {
        this.T = true;
        super.clearFocus();
        this.q.clearFocus();
        this.q.setImeVisibility(false);
        this.T = false;
    }

    public final boolean d() {
        return (this.Q || this.V) && !c();
    }

    public boolean d(int i) {
        CharSequence b2;
        Editable text = this.q.getText();
        Cursor cursor = this.P.f692c;
        if (cursor == null) {
            return true;
        }
        if (!cursor.moveToPosition(i) || (b2 = this.P.b(cursor)) == null) {
            setQuery(text);
            return true;
        }
        setQuery(b2);
        return true;
    }

    public void e() {
        if (!TextUtils.isEmpty(this.q.getText())) {
            this.q.setText("");
            this.q.requestFocus();
            this.q.setImeVisibility(true);
        } else if (this.N) {
            clearFocus();
            b(true);
        }
    }

    public void f() {
        b(false);
        this.q.requestFocus();
        this.q.setImeVisibility(true);
        View.OnClickListener onClickListener = this.M;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    public void g() {
        Editable text = this.q.getText();
        if (text != null && TextUtils.getTrimmedLength(text) > 0) {
            if (this.da != null) {
                a(0, (String) null, text.toString());
            }
            this.q.setImeVisibility(false);
            this.q.dismissDropDown();
        }
    }

    public int getImeOptions() {
        return this.q.getImeOptions();
    }

    public int getInputType() {
        return this.q.getInputType();
    }

    public int getMaxWidth() {
        return this.U;
    }

    public CharSequence getQuery() {
        return this.q.getText();
    }

    public CharSequence getQueryHint() {
        CharSequence charSequence = this.R;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.da;
        return (searchableInfo == null || searchableInfo.getHintId() == 0) ? this.K : getContext().getText(this.da.getHintId());
    }

    public int getSuggestionCommitIconResId() {
        return this.H;
    }

    public int getSuggestionRowLayout() {
        return this.G;
    }

    public b.f.a.a getSuggestionsAdapter() {
        return this.P;
    }

    public void h() {
        b(c());
        post(this.fa);
        if (this.q.hasFocus()) {
            b();
        }
    }

    public void i() {
        SearchableInfo searchableInfo = this.da;
        if (searchableInfo != null) {
            try {
                if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
                    Intent intent = new Intent(this.I);
                    ComponentName searchActivity = searchableInfo.getSearchActivity();
                    intent.putExtra("calling_package", searchActivity == null ? null : searchActivity.flattenToShortString());
                    getContext().startActivity(intent);
                } else if (searchableInfo.getVoiceSearchLaunchRecognizer()) {
                    getContext().startActivity(a(this.J, searchableInfo));
                }
            } catch (ActivityNotFoundException unused) {
                Log.w("SearchView", "Could not find voice search activity");
            }
        }
    }

    public final void j() {
        boolean z2 = true;
        boolean z3 = !TextUtils.isEmpty(this.q.getText());
        int i = 0;
        if (!z3 && (!this.N || this.ba)) {
            z2 = false;
        }
        ImageView imageView = this.w;
        if (!z2) {
            i = 8;
        }
        imageView.setVisibility(i);
        Drawable drawable = this.w.getDrawable();
        if (drawable != null) {
            drawable.setState(z3 ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    public void k() {
        int[] iArr = this.q.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.s.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.t.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    public final void l() {
        SpannableStringBuilder queryHint = getQueryHint();
        SearchAutoComplete searchAutoComplete = this.q;
        if (queryHint == null) {
            queryHint = "";
        }
        if (this.N && this.F != null) {
            double textSize = (double) this.q.getTextSize();
            Double.isNaN(textSize);
            Double.isNaN(textSize);
            int i = (int) (textSize * 1.25d);
            this.F.setBounds(0, 0, i, i);
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
            spannableStringBuilder.setSpan(new ImageSpan(this.F), 1, 2, 33);
            spannableStringBuilder.append(queryHint);
            queryHint = spannableStringBuilder;
        }
        searchAutoComplete.setHint(queryHint);
    }

    public final void m() {
        this.t.setVisibility((!d() || !(this.v.getVisibility() == 0 || this.x.getVisibility() == 0)) ? 8 : 0);
    }

    public void onActionViewCollapsed() {
        a((CharSequence) "", false);
        clearFocus();
        b(true);
        this.q.setImeOptions(this.ca);
        this.ba = false;
    }

    public void onActionViewExpanded() {
        if (!this.ba) {
            this.ba = true;
            this.ca = this.q.getImeOptions();
            this.q.setImeOptions(this.ca | 33554432);
            this.q.setText("");
            setIconified(false);
        }
    }

    public void onDetachedFromWindow() {
        removeCallbacks(this.fa);
        post(this.ga);
        super.onDetachedFromWindow();
    }

    public void onLayout(boolean z2, int i, int i2, int i3, int i4) {
        if (this.d == 1) {
            b(i, i2, i3, i4);
        } else {
            a(i, i2, i3, i4);
        }
        if (z2) {
            SearchAutoComplete searchAutoComplete = this.q;
            Rect rect = this.A;
            searchAutoComplete.getLocationInWindow(this.C);
            getLocationInWindow(this.D);
            int[] iArr = this.C;
            int i5 = iArr[1];
            int[] iArr2 = this.D;
            int i6 = i5 - iArr2[1];
            int i7 = iArr[0] - iArr2[0];
            rect.set(i7, i6, searchAutoComplete.getWidth() + i7, searchAutoComplete.getHeight() + i6);
            Rect rect2 = this.B;
            Rect rect3 = this.A;
            rect2.set(rect3.left, 0, rect3.right, i4 - i2);
            f fVar = this.z;
            if (fVar == null) {
                this.z = new f(this.B, this.A, this.q);
                setTouchDelegate(this.z);
                return;
            }
            fVar.a(this.B, this.A);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0028, code lost:
        if (r0 <= 0) goto L_0x0042;
     */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x004c  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0054  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r4, int r5) {
        /*
            r3 = this;
            boolean r0 = r3.c()
            if (r0 == 0) goto L_0x0013
            int r0 = r3.d
            r1 = 1
            if (r0 != r1) goto L_0x000f
            r3.d(r4, r5)
            goto L_0x0012
        L_0x000f:
            r3.c(r4, r5)
        L_0x0012:
            return
        L_0x0013:
            int r0 = android.view.View.MeasureSpec.getMode(r4)
            int r4 = android.view.View.MeasureSpec.getSize(r4)
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            r2 = 1073741824(0x40000000, float:2.0)
            if (r0 == r1) goto L_0x0035
            if (r0 == 0) goto L_0x002b
            if (r0 == r2) goto L_0x0026
            goto L_0x0042
        L_0x0026:
            int r0 = r3.U
            if (r0 <= 0) goto L_0x0042
            goto L_0x0039
        L_0x002b:
            int r4 = r3.U
            if (r4 <= 0) goto L_0x0030
            goto L_0x0042
        L_0x0030:
            int r4 = r3.getPreferredWidth()
            goto L_0x0042
        L_0x0035:
            int r0 = r3.U
            if (r0 <= 0) goto L_0x003a
        L_0x0039:
            goto L_0x003e
        L_0x003a:
            int r0 = r3.getPreferredWidth()
        L_0x003e:
            int r4 = java.lang.Math.min(r0, r4)
        L_0x0042:
            int r0 = android.view.View.MeasureSpec.getMode(r5)
            int r5 = android.view.View.MeasureSpec.getSize(r5)
            if (r0 == r1) goto L_0x0054
            if (r0 == 0) goto L_0x004f
            goto L_0x005c
        L_0x004f:
            int r5 = r3.getPreferredHeight()
            goto L_0x005c
        L_0x0054:
            int r0 = r3.getPreferredHeight()
            int r5 = java.lang.Math.min(r0, r5)
        L_0x005c:
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r2)
            int r5 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r2)
            super.onMeasure(r4, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.onMeasure(int, int):void");
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof e)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        e eVar = (e) parcelable;
        super.onRestoreInstanceState(eVar.f697b);
        b(eVar.f97c);
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        e eVar = new e(super.onSaveInstanceState());
        eVar.f97c = c();
        return eVar;
    }

    public void onWindowFocusChanged(boolean z2) {
        super.onWindowFocusChanged(z2);
        post(this.fa);
    }

    public boolean requestFocus(int i, Rect rect) {
        if (this.T || !isFocusable()) {
            return false;
        }
        if (c()) {
            return super.requestFocus(i, rect);
        }
        boolean requestFocus = this.q.requestFocus(i, rect);
        if (requestFocus) {
            b(false);
        }
        return requestFocus;
    }

    public void setAppSearchData(Bundle bundle) {
        this.ea = bundle;
    }

    public void setIconified(boolean z2) {
        if (z2) {
            e();
        } else {
            f();
        }
    }

    public void setIconifiedByDefault(boolean z2) {
        if (this.N != z2) {
            this.N = z2;
            b(z2);
            l();
        }
    }

    public void setImeOptions(int i) {
        this.q.setImeOptions(i);
    }

    public void setInputType(int i) {
        this.q.setInputType(i);
    }

    public void setMaxWidth(int i) {
        this.U = i;
        requestLayout();
    }

    public void setOnCloseListener(b bVar) {
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.L = onFocusChangeListener;
    }

    public void setOnQueryTextListener(c cVar) {
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.M = onClickListener;
    }

    public void setOnSuggestionListener(d dVar) {
    }

    public void setQueryHint(CharSequence charSequence) {
        this.R = charSequence;
        l();
    }

    public void setQueryRefinementEnabled(boolean z2) {
        this.S = z2;
        b.f.a.a aVar = this.P;
        if (aVar instanceof ra) {
            ((ra) aVar).r = z2 ? 2 : 1;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:30:0x00a1, code lost:
        if (getContext().getPackageManager().resolveActivity(r2, 65536) != null) goto L_0x00a5;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setSearchableInfo(android.app.SearchableInfo r7) {
        /*
            r6 = this;
            r6.da = r7
            android.app.SearchableInfo r7 = r6.da
            r0 = 1
            r1 = 65536(0x10000, float:9.18355E-41)
            r2 = 0
            if (r7 == 0) goto L_0x0073
            androidx.appcompat.widget.SearchView$SearchAutoComplete r3 = r6.q
            int r7 = r7.getSuggestThreshold()
            r3.setThreshold(r7)
            androidx.appcompat.widget.SearchView$SearchAutoComplete r7 = r6.q
            android.app.SearchableInfo r3 = r6.da
            int r3 = r3.getImeOptions()
            r7.setImeOptions(r3)
            android.app.SearchableInfo r7 = r6.da
            int r7 = r7.getInputType()
            r3 = r7 & 15
            if (r3 != r0) goto L_0x0038
            r3 = -65537(0xfffffffffffeffff, float:NaN)
            r7 = r7 & r3
            android.app.SearchableInfo r3 = r6.da
            java.lang.String r3 = r3.getSuggestAuthority()
            if (r3 == 0) goto L_0x0038
            r7 = r7 | r1
            r3 = 524288(0x80000, float:7.34684E-40)
            r7 = r7 | r3
        L_0x0038:
            androidx.appcompat.widget.SearchView$SearchAutoComplete r3 = r6.q
            r3.setInputType(r7)
            b.f.a.a r7 = r6.P
            if (r7 == 0) goto L_0x0044
            r7.a(r2)
        L_0x0044:
            android.app.SearchableInfo r7 = r6.da
            java.lang.String r7 = r7.getSuggestAuthority()
            if (r7 == 0) goto L_0x0070
            b.b.f.ra r7 = new b.b.f.ra
            android.content.Context r3 = r6.getContext()
            android.app.SearchableInfo r4 = r6.da
            java.util.WeakHashMap<java.lang.String, android.graphics.drawable.Drawable$ConstantState> r5 = r6.ha
            r7.<init>(r3, r6, r4, r5)
            r6.P = r7
            androidx.appcompat.widget.SearchView$SearchAutoComplete r7 = r6.q
            b.f.a.a r3 = r6.P
            r7.setAdapter(r3)
            b.f.a.a r7 = r6.P
            b.b.f.ra r7 = (b.b.f.ra) r7
            boolean r3 = r6.S
            if (r3 == 0) goto L_0x006c
            r3 = 2
            goto L_0x006d
        L_0x006c:
            r3 = 1
        L_0x006d:
            r7.a((int) r3)
        L_0x0070:
            r6.l()
        L_0x0073:
            android.app.SearchableInfo r7 = r6.da
            r3 = 0
            if (r7 == 0) goto L_0x00a4
            boolean r7 = r7.getVoiceSearchEnabled()
            if (r7 == 0) goto L_0x00a4
            android.app.SearchableInfo r7 = r6.da
            boolean r7 = r7.getVoiceSearchLaunchWebSearch()
            if (r7 == 0) goto L_0x0089
            android.content.Intent r2 = r6.I
            goto L_0x0093
        L_0x0089:
            android.app.SearchableInfo r7 = r6.da
            boolean r7 = r7.getVoiceSearchLaunchRecognizer()
            if (r7 == 0) goto L_0x0093
            android.content.Intent r2 = r6.J
        L_0x0093:
            if (r2 == 0) goto L_0x00a4
            android.content.Context r7 = r6.getContext()
            android.content.pm.PackageManager r7 = r7.getPackageManager()
            android.content.pm.ResolveInfo r7 = r7.resolveActivity(r2, r1)
            if (r7 == 0) goto L_0x00a4
            goto L_0x00a5
        L_0x00a4:
            r0 = 0
        L_0x00a5:
            r6.V = r0
            boolean r7 = r6.V
            if (r7 == 0) goto L_0x00b2
            androidx.appcompat.widget.SearchView$SearchAutoComplete r7 = r6.q
            java.lang.String r0 = "nm"
            r7.setPrivateImeOptions(r0)
        L_0x00b2:
            boolean r7 = r6.c()
            r6.b((boolean) r7)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.setSearchableInfo(android.app.SearchableInfo):void");
    }

    public void setSubmitButtonEnabled(boolean z2) {
        this.Q = z2;
        b(c());
    }

    public void setSuggestionsAdapter(b.f.a.a aVar) {
        this.P = aVar;
        this.q.setAdapter(this.P);
    }

    public SearchView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.A = new Rect();
        this.B = new Rect();
        this.C = new int[2];
        this.D = new int[2];
        this.fa = new C0045ga(this);
        this.ga = new C0047ha(this);
        this.ha = new WeakHashMap<>();
        this.ia = new C0053ka(this);
        this.ja = new C0055la(this);
        this.ka = new ma(this);
        this.la = new na(this);
        this.ma = new oa(this);
        this.na = new C0043fa(this);
        xa a2 = xa.a(context, attributeSet, j.SearchView, i, 0);
        LayoutInflater.from(context).inflate(a2.e(j.SearchView_layout, g.abc_search_view), this, true);
        this.q = (SearchAutoComplete) findViewById(b.b.f.search_src_text);
        this.q.setSearchView(this);
        this.r = findViewById(b.b.f.search_edit_frame);
        this.s = findViewById(b.b.f.search_plate);
        this.t = findViewById(b.b.f.submit_area);
        this.u = (ImageView) findViewById(b.b.f.search_button);
        this.v = (ImageView) findViewById(b.b.f.search_go_btn);
        this.w = (ImageView) findViewById(b.b.f.search_close_btn);
        this.x = (ImageView) findViewById(b.b.f.search_voice_btn);
        this.E = (ImageView) findViewById(b.b.f.search_mag_icon);
        s.a(this.s, a2.b(j.SearchView_queryBackground));
        s.a(this.t, a2.b(j.SearchView_submitBackground));
        this.u.setImageDrawable(a2.b(j.SearchView_searchIcon));
        this.v.setImageDrawable(a2.b(j.SearchView_goIcon));
        this.w.setImageDrawable(a2.b(j.SearchView_closeIcon));
        this.x.setImageDrawable(a2.b(j.SearchView_voiceIcon));
        this.E.setImageDrawable(a2.b(j.SearchView_searchIcon));
        this.F = a2.b(j.SearchView_searchHintIcon);
        a.a.a.a.c.a((View) this.u, (CharSequence) getResources().getString(h.abc_searchview_description_search));
        this.G = a2.e(j.SearchView_suggestionRowLayout, g.abc_search_dropdown_item_icons_2line);
        this.H = a2.e(j.SearchView_commitIcon, 0);
        this.u.setOnClickListener(this.ia);
        this.w.setOnClickListener(this.ia);
        this.v.setOnClickListener(this.ia);
        this.x.setOnClickListener(this.ia);
        this.q.setOnClickListener(this.ia);
        this.q.addTextChangedListener(this.na);
        this.q.setOnEditorActionListener(this.ka);
        this.q.setOnItemClickListener(this.la);
        this.q.setOnItemSelectedListener(this.ma);
        this.q.setOnKeyListener(this.ja);
        this.q.setOnFocusChangeListener(new C0049ia(this));
        setIconifiedByDefault(a2.a(j.SearchView_iconifiedByDefault, true));
        int b2 = a2.b(j.SearchView_android_maxWidth, -1);
        if (b2 != -1) {
            setMaxWidth(b2);
        }
        this.K = a2.e(j.SearchView_defaultQueryHint);
        this.R = a2.e(j.SearchView_queryHint);
        int c2 = a2.c(j.SearchView_android_imeOptions, -1);
        if (c2 != -1) {
            setImeOptions(c2);
        }
        int c3 = a2.c(j.SearchView_android_inputType, -1);
        if (c3 != -1) {
            setInputType(c3);
        }
        setFocusable(a2.a(j.SearchView_android_focusable, true));
        a2.f496b.recycle();
        this.I = new Intent("android.speech.action.WEB_SEARCH");
        this.I.addFlags(268435456);
        this.I.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        this.J = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.J.addFlags(268435456);
        this.y = findViewById(this.q.getDropDownAnchor());
        View view = this.y;
        if (view != null) {
            view.addOnLayoutChangeListener(new C0051ja(this));
        }
        b(this.N);
        l();
    }

    public boolean a(View view, int i, KeyEvent keyEvent) {
        if (this.da != null && this.P != null && keyEvent.getAction() == 0 && keyEvent.hasNoModifiers()) {
            if (i == 66 || i == 84 || i == 61) {
                return a(this.q.getListSelection(), 0, (String) null);
            }
            if (i == 21 || i == 22) {
                this.q.setSelection(i == 21 ? 0 : this.q.length());
                this.q.setListSelection(0);
                this.q.clearListSelection();
                a aVar = p;
                SearchAutoComplete searchAutoComplete = this.q;
                Method method = aVar.f96c;
                if (method != null) {
                    try {
                        method.invoke(searchAutoComplete, new Object[]{true});
                    } catch (Exception unused) {
                    }
                }
                return true;
            } else if (i != 19 || this.q.getListSelection() == 0) {
                return false;
            }
        }
        return false;
    }
}
