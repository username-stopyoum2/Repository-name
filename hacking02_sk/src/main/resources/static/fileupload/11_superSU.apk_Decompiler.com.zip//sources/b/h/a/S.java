package b.h.a;

import android.util.AndroidRuntimeException;

public final class S extends AndroidRuntimeException {
    public S(String str) {
        super(str);
    }
}
