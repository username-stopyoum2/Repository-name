package c.b.a.a.c;

import android.os.IBinder;
import c.b.a.a.e.f;

public final class b extends f implements a {
    public b(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.dynamic.IObjectWrapper");
    }
}
