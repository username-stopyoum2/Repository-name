package b.h.a;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import b.h.a.B;
import b.j.e;
import java.util.ArrayList;

@SuppressLint({"BanParcelableUsage"})
/* renamed from: b.h.a.c  reason: case insensitive filesystem */
public final class C0072c implements Parcelable {
    public static final Parcelable.Creator<C0072c> CREATOR = new C0071b();

    /* renamed from: a  reason: collision with root package name */
    public final int[] f738a;

    /* renamed from: b  reason: collision with root package name */
    public final ArrayList<String> f739b;

    /* renamed from: c  reason: collision with root package name */
    public final int[] f740c;
    public final int[] d;
    public final int e;
    public final int f;
    public final String g;
    public final int h;
    public final int i;
    public final CharSequence j;
    public final int k;
    public final CharSequence l;
    public final ArrayList<String> m;
    public final ArrayList<String> n;
    public final boolean o;

    public C0072c(Parcel parcel) {
        this.f738a = parcel.createIntArray();
        this.f739b = parcel.createStringArrayList();
        this.f740c = parcel.createIntArray();
        this.d = parcel.createIntArray();
        this.e = parcel.readInt();
        this.f = parcel.readInt();
        this.g = parcel.readString();
        this.h = parcel.readInt();
        this.i = parcel.readInt();
        this.j = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.k = parcel.readInt();
        this.l = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.m = parcel.createStringArrayList();
        this.n = parcel.createStringArrayList();
        this.o = parcel.readInt() != 0;
    }

    public C0072c(C0070a aVar) {
        int size = aVar.f701a.size();
        this.f738a = new int[(size * 5)];
        if (aVar.h) {
            this.f739b = new ArrayList<>(size);
            this.f740c = new int[size];
            this.d = new int[size];
            int i2 = 0;
            int i3 = 0;
            while (i2 < size) {
                B.a aVar2 = aVar.f701a.get(i2);
                int i4 = i3 + 1;
                this.f738a[i3] = aVar2.f704a;
                ArrayList<String> arrayList = this.f739b;
                C0076g gVar = aVar2.f705b;
                arrayList.add(gVar != null ? gVar.f : null);
                int[] iArr = this.f738a;
                int i5 = i4 + 1;
                iArr[i4] = aVar2.f706c;
                int i6 = i5 + 1;
                iArr[i5] = aVar2.d;
                int i7 = i6 + 1;
                iArr[i6] = aVar2.e;
                iArr[i7] = aVar2.f;
                this.f740c[i2] = aVar2.g.ordinal();
                this.d[i2] = aVar2.h.ordinal();
                i2++;
                i3 = i7 + 1;
            }
            this.e = aVar.f;
            this.f = aVar.g;
            this.g = aVar.i;
            this.h = aVar.t;
            this.i = aVar.j;
            this.j = aVar.k;
            this.k = aVar.l;
            this.l = aVar.m;
            this.m = aVar.n;
            this.n = aVar.o;
            this.o = aVar.p;
            return;
        }
        throw new IllegalStateException("Not on back stack");
    }

    public C0070a a(u uVar) {
        C0070a aVar = new C0070a(uVar);
        int i2 = 0;
        int i3 = 0;
        while (i2 < this.f738a.length) {
            B.a aVar2 = new B.a();
            int i4 = i2 + 1;
            aVar2.f704a = this.f738a[i2];
            if (u.f770c) {
                Log.v("FragmentManager", "Instantiate " + aVar + " op #" + i3 + " base fragment #" + this.f738a[i4]);
            }
            String str = this.f739b.get(i3);
            aVar2.f705b = str != null ? uVar.j.get(str) : null;
            aVar2.g = e.b.values()[this.f740c[i3]];
            aVar2.h = e.b.values()[this.d[i3]];
            int[] iArr = this.f738a;
            int i5 = i4 + 1;
            aVar2.f706c = iArr[i4];
            int i6 = i5 + 1;
            aVar2.d = iArr[i5];
            int i7 = i6 + 1;
            aVar2.e = iArr[i6];
            aVar2.f = iArr[i7];
            aVar.f702b = aVar2.f706c;
            aVar.f703c = aVar2.d;
            aVar.d = aVar2.e;
            aVar.e = aVar2.f;
            aVar.f701a.add(aVar2);
            aVar2.f706c = aVar.f702b;
            aVar2.d = aVar.f703c;
            aVar2.e = aVar.d;
            aVar2.f = aVar.e;
            i3++;
            i2 = i7 + 1;
        }
        aVar.f = this.e;
        aVar.g = this.f;
        aVar.i = this.g;
        aVar.t = this.h;
        aVar.h = true;
        aVar.j = this.i;
        aVar.k = this.j;
        aVar.l = this.k;
        aVar.m = this.l;
        aVar.n = this.m;
        aVar.o = this.n;
        aVar.p = this.o;
        aVar.a(1);
        return aVar;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeIntArray(this.f738a);
        parcel.writeStringList(this.f739b);
        parcel.writeIntArray(this.f740c);
        parcel.writeIntArray(this.d);
        parcel.writeInt(this.e);
        parcel.writeInt(this.f);
        parcel.writeString(this.g);
        parcel.writeInt(this.h);
        parcel.writeInt(this.i);
        TextUtils.writeToParcel(this.j, parcel, 0);
        parcel.writeInt(this.k);
        TextUtils.writeToParcel(this.l, parcel, 0);
        parcel.writeStringList(this.m);
        parcel.writeStringList(this.n);
        parcel.writeInt(this.o ? 1 : 0);
    }
}
