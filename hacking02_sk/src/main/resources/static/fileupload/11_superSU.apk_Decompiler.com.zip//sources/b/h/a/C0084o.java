package b.h.a;

/* renamed from: b.h.a.o  reason: case insensitive filesystem */
class C0084o implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ u f758a;

    public C0084o(u uVar) {
        this.f758a = uVar;
    }

    public void run() {
        this.f758a.i();
    }
}
