package c.b.a.a.d.a;

import a.a.a.a.c;
import android.content.Context;
import android.content.SharedPreferences;

public final class e {

    /* renamed from: a  reason: collision with root package name */
    public static SharedPreferences f897a;

    public static SharedPreferences a(Context context) {
        SharedPreferences sharedPreferences;
        synchronized (SharedPreferences.class) {
            if (f897a == null) {
                f897a = (SharedPreferences) c.a(new f(context));
            }
            sharedPreferences = f897a;
        }
        return sharedPreferences;
    }
}
