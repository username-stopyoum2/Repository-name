package androidx.media;

import b.l.a;
import b.o.b;
import b.o.d;

public final class AudioAttributesCompatParcelizer {
    public static AudioAttributesCompat read(b bVar) {
        AudioAttributesCompat audioAttributesCompat = new AudioAttributesCompat();
        Object obj = audioAttributesCompat.f137b;
        if (bVar.a(1)) {
            obj = bVar.d();
        }
        audioAttributesCompat.f137b = (a) obj;
        return audioAttributesCompat;
    }

    public static void write(AudioAttributesCompat audioAttributesCompat, b bVar) {
        bVar.a(false, false);
        a aVar = audioAttributesCompat.f137b;
        bVar.b(1);
        bVar.a((d) aVar);
    }
}
