package c.b.a.a.b;

public final class g {

    /* renamed from: a  reason: collision with root package name */
    public static final d[] f881a = {new h(d.a("0\u0004C0\u0003+ \u0003\u0002\u0001\u0002\u0002\t\u0000ÂàFdJ00")), new i(d.a("0\u0004¨0\u0003 \u0003\u0002\u0001\u0002\u0002\t\u0000Õ¸l}ÓNõ0"))};
}
