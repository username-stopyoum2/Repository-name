package b.h.a;

import android.graphics.Rect;
import android.view.View;
import b.d.b;
import b.h.a.G;
import java.util.ArrayList;

public final class F implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ P f714a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ b f715b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Object f716c;
    public final /* synthetic */ G.a d;
    public final /* synthetic */ ArrayList e;
    public final /* synthetic */ View f;
    public final /* synthetic */ C0076g g;
    public final /* synthetic */ C0076g h;
    public final /* synthetic */ boolean i;
    public final /* synthetic */ ArrayList j;
    public final /* synthetic */ Object k;
    public final /* synthetic */ Rect l;

    public F(P p, b bVar, Object obj, G.a aVar, ArrayList arrayList, View view, C0076g gVar, C0076g gVar2, boolean z, ArrayList arrayList2, Object obj2, Rect rect) {
        this.f714a = p;
        this.f715b = bVar;
        this.f716c = obj;
        this.d = aVar;
        this.e = arrayList;
        this.f = view;
        this.g = gVar;
        this.h = gVar2;
        this.i = z;
        this.j = arrayList2;
        this.k = obj2;
        this.l = rect;
    }

    public void run() {
        b<String, View> a2 = G.a(this.f714a, (b<String, String>) this.f715b, this.f716c, this.d);
        if (a2 != null) {
            this.e.addAll(a2.values());
            this.e.add(this.f);
        }
        G.a(this.g, this.h, this.i, a2, false);
        Object obj = this.f716c;
        if (obj != null) {
            this.f714a.b(obj, (ArrayList<View>) this.j, (ArrayList<View>) this.e);
            View a3 = G.a(a2, this.d, this.k, this.i);
            if (a3 != null) {
                this.f714a.a(a3, this.l);
            }
        }
    }
}
