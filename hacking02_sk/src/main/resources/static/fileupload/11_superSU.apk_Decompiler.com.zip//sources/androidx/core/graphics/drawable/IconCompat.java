package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;

public class IconCompat extends CustomVersionedParcelable {

    /* renamed from: a  reason: collision with root package name */
    public static final PorterDuff.Mode f115a = PorterDuff.Mode.SRC_IN;

    /* renamed from: b  reason: collision with root package name */
    public int f116b = -1;

    /* renamed from: c  reason: collision with root package name */
    public Object f117c;
    public byte[] d = null;
    public Parcelable e = null;
    public int f = 0;
    public int g = 0;
    public ColorStateList h = null;
    public PorterDuff.Mode i = f115a;
    public String j = null;

    public int a() {
        int i2;
        if (this.f116b == -1 && (i2 = Build.VERSION.SDK_INT) >= 23) {
            Icon icon = (Icon) this.f117c;
            if (i2 >= 28) {
                return icon.getResId();
            }
            try {
                return ((Integer) icon.getClass().getMethod("getResId", new Class[0]).invoke(icon, new Object[0])).intValue();
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e2) {
                Log.e("IconCompat", "Unable to get icon resource", e2);
                return 0;
            }
        } else if (this.f116b == 2) {
            return this.f;
        } else {
            throw new IllegalStateException("called getResId() on " + this);
        }
    }

    public void a(boolean z) {
        this.j = this.i.name();
        int i2 = this.f116b;
        if (i2 != -1) {
            if (i2 != 1) {
                if (i2 == 2) {
                    this.d = ((String) this.f117c).getBytes(Charset.forName("UTF-16"));
                    return;
                } else if (i2 == 3) {
                    this.d = (byte[]) this.f117c;
                    return;
                } else if (i2 == 4) {
                    this.d = this.f117c.toString().getBytes(Charset.forName("UTF-16"));
                    return;
                } else if (i2 != 5) {
                    return;
                }
            }
            if (z) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                ((Bitmap) this.f117c).compress(Bitmap.CompressFormat.PNG, 90, byteArrayOutputStream);
                this.d = byteArrayOutputStream.toByteArray();
                return;
            }
        } else if (z) {
            throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
        }
        this.e = (Parcelable) this.f117c;
    }

    public String b() {
        int i2;
        if (this.f116b == -1 && (i2 = Build.VERSION.SDK_INT) >= 23) {
            Icon icon = (Icon) this.f117c;
            if (i2 >= 28) {
                return icon.getResPackage();
            }
            try {
                return (String) icon.getClass().getMethod("getResPackage", new Class[0]).invoke(icon, new Object[0]);
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e2) {
                Log.e("IconCompat", "Unable to get icon package", e2);
                return null;
            }
        } else if (this.f116b == 2) {
            return ((String) this.f117c).split(":", -1)[0];
        } else {
            throw new IllegalStateException("called getResPackage() on " + this);
        }
    }

    public void c() {
        Parcelable parcelable;
        this.i = PorterDuff.Mode.valueOf(this.j);
        int i2 = this.f116b;
        if (i2 != -1) {
            if (i2 != 1) {
                if (i2 != 2) {
                    if (i2 == 3) {
                        this.f117c = this.d;
                        return;
                    } else if (i2 != 4) {
                        if (i2 != 5) {
                            return;
                        }
                    }
                }
                this.f117c = new String(this.d, Charset.forName("UTF-16"));
                return;
            }
            parcelable = this.e;
            if (parcelable == null) {
                byte[] bArr = this.d;
                this.f117c = bArr;
                this.f116b = 3;
                this.f = 0;
                this.g = bArr.length;
                return;
            }
        } else {
            parcelable = this.e;
            if (parcelable == null) {
                throw new IllegalArgumentException("Invalid icon");
            }
        }
        this.f117c = parcelable;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0042, code lost:
        if (r1 != 5) goto L_0x00ae;
     */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x00b2  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00c2  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String toString() {
        /*
            r7 = this;
            int r0 = r7.f116b
            r1 = -1
            if (r0 != r1) goto L_0x000c
            java.lang.Object r0 = r7.f117c
            java.lang.String r0 = java.lang.String.valueOf(r0)
            return r0
        L_0x000c:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "Icon(typ="
            r0.<init>(r1)
            int r1 = r7.f116b
            r2 = 5
            r3 = 4
            r4 = 3
            r5 = 2
            r6 = 1
            if (r1 == r6) goto L_0x0033
            if (r1 == r5) goto L_0x0030
            if (r1 == r4) goto L_0x002d
            if (r1 == r3) goto L_0x002a
            if (r1 == r2) goto L_0x0027
            java.lang.String r1 = "UNKNOWN"
            goto L_0x0035
        L_0x0027:
            java.lang.String r1 = "BITMAP_MASKABLE"
            goto L_0x0035
        L_0x002a:
            java.lang.String r1 = "URI"
            goto L_0x0035
        L_0x002d:
            java.lang.String r1 = "DATA"
            goto L_0x0035
        L_0x0030:
            java.lang.String r1 = "RESOURCE"
            goto L_0x0035
        L_0x0033:
            java.lang.String r1 = "BITMAP"
        L_0x0035:
            r0.append(r1)
            int r1 = r7.f116b
            if (r1 == r6) goto L_0x008e
            if (r1 == r5) goto L_0x0066
            if (r1 == r4) goto L_0x0050
            if (r1 == r3) goto L_0x0045
            if (r1 == r2) goto L_0x008e
            goto L_0x00ae
        L_0x0045:
            java.lang.String r1 = " uri="
            r0.append(r1)
            java.lang.Object r1 = r7.f117c
            r0.append(r1)
            goto L_0x00ae
        L_0x0050:
            java.lang.String r1 = " len="
            r0.append(r1)
            int r1 = r7.f
            r0.append(r1)
            int r1 = r7.g
            if (r1 == 0) goto L_0x00ae
            java.lang.String r1 = " off="
            r0.append(r1)
            int r1 = r7.g
            goto L_0x00ab
        L_0x0066:
            java.lang.String r1 = " pkg="
            r0.append(r1)
            java.lang.String r1 = r7.b()
            r0.append(r1)
            java.lang.String r1 = " id="
            r0.append(r1)
            java.lang.Object[] r1 = new java.lang.Object[r6]
            r2 = 0
            int r3 = r7.a()
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r1[r2] = r3
            java.lang.String r2 = "0x%08x"
            java.lang.String r1 = java.lang.String.format(r2, r1)
            r0.append(r1)
            goto L_0x00ae
        L_0x008e:
            java.lang.String r1 = " size="
            r0.append(r1)
            java.lang.Object r1 = r7.f117c
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getWidth()
            r0.append(r1)
            java.lang.String r1 = "x"
            r0.append(r1)
            java.lang.Object r1 = r7.f117c
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getHeight()
        L_0x00ab:
            r0.append(r1)
        L_0x00ae:
            android.content.res.ColorStateList r1 = r7.h
            if (r1 == 0) goto L_0x00bc
            java.lang.String r1 = " tint="
            r0.append(r1)
            android.content.res.ColorStateList r1 = r7.h
            r0.append(r1)
        L_0x00bc:
            android.graphics.PorterDuff$Mode r1 = r7.i
            android.graphics.PorterDuff$Mode r2 = f115a
            if (r1 == r2) goto L_0x00cc
            java.lang.String r1 = " mode="
            r0.append(r1)
            android.graphics.PorterDuff$Mode r1 = r7.i
            r0.append(r1)
        L_0x00cc:
            java.lang.String r1 = ")"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompat.toString():java.lang.String");
    }
}
