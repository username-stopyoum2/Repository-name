package b.h.a;

import android.animation.Animator;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import androidx.activity.OnBackPressedDispatcher;
import b.e.h.l;
import b.h.a.B;
import b.h.a.C0076g;
import b.h.a.C0082m;
import b.j.e;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public final class u extends C0082m implements LayoutInflater.Factory2 {

    /* renamed from: c  reason: collision with root package name */
    public static boolean f770c;
    public static final Interpolator d = new DecelerateInterpolator(2.5f);
    public static final Interpolator e = new DecelerateInterpolator(1.5f);
    public boolean A;
    public boolean B;
    public ArrayList<C0070a> C;
    public ArrayList<Boolean> D;
    public ArrayList<C0076g> E;
    public Bundle F = null;
    public SparseArray<Parcelable> G = null;
    public ArrayList<f> H;
    public y I;
    public Runnable J = new C0084o(this);
    public ArrayList<e> f;
    public boolean g;
    public int h = 0;
    public final ArrayList<C0076g> i = new ArrayList<>();
    public final HashMap<String, C0076g> j = new HashMap<>();
    public ArrayList<C0070a> k;
    public ArrayList<C0076g> l;
    public OnBackPressedDispatcher m;
    public final b.a.d n = new C0083n(this, false);
    public ArrayList<C0070a> o;
    public ArrayList<Integer> p;
    public ArrayList<C0082m.c> q;
    public final CopyOnWriteArrayList<c> r = new CopyOnWriteArrayList<>();
    public int s = 0;
    public C0081l t;
    public C0078i u;
    public C0076g v;
    public C0076g w;
    public boolean x;
    public boolean y;
    public boolean z;

    private static class a {

        /* renamed from: a  reason: collision with root package name */
        public final Animation f771a;

        /* renamed from: b  reason: collision with root package name */
        public final Animator f772b;

        public a(Animator animator) {
            this.f771a = null;
            this.f772b = animator;
            if (animator == null) {
                throw new IllegalStateException("Animator cannot be null");
            }
        }

        public a(Animation animation) {
            this.f771a = animation;
            this.f772b = null;
            if (animation == null) {
                throw new IllegalStateException("Animation cannot be null");
            }
        }
    }

    private static class b extends AnimationSet implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        public final ViewGroup f773a;

        /* renamed from: b  reason: collision with root package name */
        public final View f774b;

        /* renamed from: c  reason: collision with root package name */
        public boolean f775c;
        public boolean d;
        public boolean e = true;

        public b(Animation animation, ViewGroup viewGroup, View view) {
            super(false);
            this.f773a = viewGroup;
            this.f774b = view;
            addAnimation(animation);
            this.f773a.post(this);
        }

        public boolean getTransformation(long j, Transformation transformation) {
            this.e = true;
            if (this.f775c) {
                return !this.d;
            }
            if (!super.getTransformation(j, transformation)) {
                this.f775c = true;
                l.a(this.f773a, this);
            }
            return true;
        }

        public boolean getTransformation(long j, Transformation transformation, float f) {
            this.e = true;
            if (this.f775c) {
                return !this.d;
            }
            if (!super.getTransformation(j, transformation, f)) {
                this.f775c = true;
                l.a(this.f773a, this);
            }
            return true;
        }

        public void run() {
            if (this.f775c || !this.e) {
                this.f773a.endViewTransition(this.f774b);
                this.d = true;
                return;
            }
            this.e = false;
            this.f773a.post(this);
        }
    }

    private static final class c {

        /* renamed from: a  reason: collision with root package name */
        public final C0082m.b f776a;

        /* renamed from: b  reason: collision with root package name */
        public final boolean f777b;
    }

    static class d {

        /* renamed from: a  reason: collision with root package name */
        public static final int[] f778a = {16842755, 16842960, 16842961};
    }

    interface e {
    }

    static class f implements C0076g.c {

        /* renamed from: a  reason: collision with root package name */
        public final boolean f779a;

        /* renamed from: b  reason: collision with root package name */
        public final C0070a f780b;

        /* renamed from: c  reason: collision with root package name */
        public int f781c;

        public f(C0070a aVar, boolean z) {
            this.f779a = z;
            this.f780b = aVar;
        }

        public void a() {
            boolean z = this.f781c > 0;
            u uVar = this.f780b.r;
            int size = uVar.i.size();
            for (int i = 0; i < size; i++) {
                C0076g gVar = uVar.i.get(i);
                gVar.a((C0076g.c) null);
                if (z) {
                    C0076g.a aVar = gVar.L;
                    if (aVar == null ? false : aVar.q) {
                        gVar.y();
                    }
                }
            }
            C0070a aVar2 = this.f780b;
            aVar2.r.a(aVar2, this.f779a, !z, true);
        }
    }

    public static a a(float f2, float f3, float f4, float f5) {
        AnimationSet animationSet = new AnimationSet(false);
        ScaleAnimation scaleAnimation = new ScaleAnimation(f2, f3, f2, f3, 1, 0.5f, 1, 0.5f);
        scaleAnimation.setInterpolator(d);
        scaleAnimation.setDuration(220);
        animationSet.addAnimation(scaleAnimation);
        AlphaAnimation alphaAnimation = new AlphaAnimation(f4, f5);
        alphaAnimation.setInterpolator(e);
        alphaAnimation.setDuration(220);
        animationSet.addAnimation(alphaAnimation);
        return new a((Animation) animationSet);
    }

    public static int d(int i2) {
        if (i2 == 4097) {
            return 8194;
        }
        if (i2 != 4099) {
            return i2 != 8194 ? 0 : 4097;
        }
        return 4099;
    }

    public C0076g a(String str) {
        C0076g a2;
        for (C0076g next : this.j.values()) {
            if (next != null && (a2 = next.a(str)) != null) {
                return a2;
            }
        }
        return null;
    }

    public List<C0076g> a() {
        List<C0076g> list;
        if (this.i.isEmpty()) {
            return Collections.emptyList();
        }
        synchronized (this.i) {
            list = (List) this.i.clone();
        }
        return list;
    }

    /* JADX INFO: finally extract failed */
    public final void a(int i2) {
        try {
            this.g = true;
            a(i2, false);
            this.g = false;
            i();
        } catch (Throwable th) {
            this.g = false;
            throw th;
        }
    }

    public void a(int i2, C0070a aVar) {
        synchronized (this) {
            if (this.o == null) {
                this.o = new ArrayList<>();
            }
            int size = this.o.size();
            if (i2 < size) {
                if (f770c) {
                    Log.v("FragmentManager", "Setting back stack index " + i2 + " to " + aVar);
                }
                this.o.set(i2, aVar);
            } else {
                while (size < i2) {
                    this.o.add((Object) null);
                    if (this.p == null) {
                        this.p = new ArrayList<>();
                    }
                    if (f770c) {
                        Log.v("FragmentManager", "Adding available back stack index " + size);
                    }
                    this.p.add(Integer.valueOf(size));
                    size++;
                }
                if (f770c) {
                    Log.v("FragmentManager", "Adding back stack index " + i2 + " with " + aVar);
                }
                this.o.add(aVar);
            }
        }
    }

    public final void a(b.d.d<C0076g> dVar) {
        int i2 = this.s;
        if (i2 >= 1) {
            int min = Math.min(i2, 3);
            int size = this.i.size();
            for (int i3 = 0; i3 < size; i3++) {
                C0076g gVar = this.i.get(i3);
                if (gVar.f745b < min) {
                    a(gVar, min, gVar.n(), gVar.o(), false);
                    if (gVar.H != null && !gVar.z && gVar.M) {
                        dVar.add(gVar);
                    }
                }
            }
        }
    }

    public void a(C0070a aVar, boolean z2, boolean z3, boolean z4) {
        if (z2) {
            aVar.a(z4);
        } else {
            aVar.a();
        }
        ArrayList arrayList = new ArrayList(1);
        ArrayList arrayList2 = new ArrayList(1);
        arrayList.add(aVar);
        arrayList2.add(Boolean.valueOf(z2));
        if (z3) {
            G.a(this, (ArrayList<C0070a>) arrayList, (ArrayList<Boolean>) arrayList2, 0, 1, true);
        }
        if (z4) {
            a(this.s, true);
        }
        for (C0076g next : this.j.values()) {
            if (next != null && next.H != null && next.M && aVar.b(next.x)) {
                float f2 = next.O;
                if (f2 > 0.0f) {
                    next.H.setAlpha(f2);
                }
                if (z4) {
                    next.O = 0.0f;
                } else {
                    next.O = -1.0f;
                    next.M = false;
                }
            }
        }
    }

    public void a(C0076g gVar) {
        if (f770c) {
            c.a.a.a.a.b("attach: ", gVar, "FragmentManager");
        }
        if (gVar.A) {
            gVar.A = false;
            if (gVar.l) {
                return;
            }
            if (!this.i.contains(gVar)) {
                if (f770c) {
                    c.a.a.a.a.b("add from attach: ", gVar, "FragmentManager");
                }
                synchronized (this.i) {
                    this.i.add(gVar);
                }
                gVar.l = true;
                if (e(gVar)) {
                    this.x = true;
                    return;
                }
                return;
            }
            throw new IllegalStateException("Fragment already added: " + gVar);
        }
    }

    public void a(C0076g gVar, boolean z2) {
        if (f770c) {
            c.a.a.a.a.b("add: ", gVar, "FragmentManager");
        }
        g(gVar);
        if (gVar.A) {
            return;
        }
        if (!this.i.contains(gVar)) {
            synchronized (this.i) {
                this.i.add(gVar);
            }
            gVar.l = true;
            gVar.m = false;
            if (gVar.H == null) {
                gVar.N = false;
            }
            if (e(gVar)) {
                this.x = true;
            }
            if (z2) {
                a(gVar, this.s, 0, 0, false);
                return;
            }
            return;
        }
        throw new IllegalStateException("Fragment already added: " + gVar);
    }

    public void a(boolean z2) {
        for (int size = this.i.size() - 1; size >= 0; size--) {
            C0076g gVar = this.i.get(size);
            if (gVar != null) {
                gVar.a(z2);
            }
        }
    }

    public boolean a(Menu menu, MenuInflater menuInflater) {
        if (this.s < 1) {
            return false;
        }
        ArrayList<C0076g> arrayList = null;
        boolean z2 = false;
        for (int i2 = 0; i2 < this.i.size(); i2++) {
            C0076g gVar = this.i.get(i2);
            if (gVar != null && gVar.a(menu, menuInflater)) {
                if (arrayList == null) {
                    arrayList = new ArrayList<>();
                }
                arrayList.add(gVar);
                z2 = true;
            }
        }
        if (this.l != null) {
            for (int i3 = 0; i3 < this.l.size(); i3++) {
                C0076g gVar2 = this.l.get(i3);
                if (arrayList == null || !arrayList.contains(gVar2)) {
                    gVar2.v();
                }
            }
        }
        this.l = arrayList;
        return z2;
    }

    public C0076g b(int i2) {
        for (int size = this.i.size() - 1; size >= 0; size--) {
            C0076g gVar = this.i.get(size);
            if (gVar != null && gVar.w == i2) {
                return gVar;
            }
        }
        for (C0076g next : this.j.values()) {
            if (next != null && next.w == i2) {
                return next;
            }
        }
        return null;
    }

    public void b(C0076g gVar) {
        if (f770c) {
            c.a.a.a.a.b("detach: ", gVar, "FragmentManager");
        }
        if (!gVar.A) {
            gVar.A = true;
            if (gVar.l) {
                if (f770c) {
                    c.a.a.a.a.b("remove from detach: ", gVar, "FragmentManager");
                }
                synchronized (this.i) {
                    this.i.remove(gVar);
                }
                if (e(gVar)) {
                    this.x = true;
                }
                gVar.l = false;
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void b(b.h.a.C0076g r3, android.os.Bundle r4, boolean r5) {
        /*
            r2 = this;
            b.h.a.g r0 = r2.v
            if (r0 == 0) goto L_0x000e
            b.h.a.u r0 = r0.s
            boolean r1 = r0 instanceof b.h.a.u
            if (r1 == 0) goto L_0x000e
            r1 = 1
            r0.b((b.h.a.C0076g) r3, (android.os.Bundle) r4, (boolean) r1)
        L_0x000e:
            java.util.concurrent.CopyOnWriteArrayList<b.h.a.u$c> r3 = r2.r
            java.util.Iterator r3 = r3.iterator()
        L_0x0014:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x002b
            java.lang.Object r4 = r3.next()
            b.h.a.u$c r4 = (b.h.a.u.c) r4
            if (r5 == 0) goto L_0x0027
            boolean r0 = r4.f777b
            if (r0 != 0) goto L_0x0027
            goto L_0x0014
        L_0x0027:
            b.h.a.m$b r3 = r4.f776a
            r3 = 0
            throw r3
        L_0x002b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.b(b.h.a.g, android.os.Bundle, boolean):void");
    }

    public void b(boolean z2) {
        for (int size = this.i.size() - 1; size >= 0; size--) {
            C0076g gVar = this.i.get(size);
            if (gVar != null) {
                gVar.b(z2);
            }
        }
    }

    public boolean b(Menu menu) {
        if (this.s < 1) {
            return false;
        }
        boolean z2 = false;
        for (int i2 = 0; i2 < this.i.size(); i2++) {
            C0076g gVar = this.i.get(i2);
            if (gVar != null && gVar.a(menu)) {
                z2 = true;
            }
        }
        return z2;
    }

    public final void c() {
        this.g = false;
        this.D.clear();
        this.C.clear();
    }

    public void c(int i2) {
        synchronized (this) {
            this.o.set(i2, (Object) null);
            if (this.p == null) {
                this.p = new ArrayList<>();
            }
            if (f770c) {
                Log.v("FragmentManager", "Freeing back stack index " + i2);
            }
            this.p.add(Integer.valueOf(i2));
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void c(b.h.a.C0076g r3, boolean r4) {
        /*
            r2 = this;
            b.h.a.g r0 = r2.v
            if (r0 == 0) goto L_0x000e
            b.h.a.u r0 = r0.s
            boolean r1 = r0 instanceof b.h.a.u
            if (r1 == 0) goto L_0x000e
            r1 = 1
            r0.c((b.h.a.C0076g) r3, (boolean) r1)
        L_0x000e:
            java.util.concurrent.CopyOnWriteArrayList<b.h.a.u$c> r3 = r2.r
            java.util.Iterator r3 = r3.iterator()
        L_0x0014:
            boolean r0 = r3.hasNext()
            if (r0 == 0) goto L_0x002b
            java.lang.Object r0 = r3.next()
            b.h.a.u$c r0 = (b.h.a.u.c) r0
            if (r4 == 0) goto L_0x0027
            boolean r1 = r0.f777b
            if (r1 != 0) goto L_0x0027
            goto L_0x0014
        L_0x0027:
            b.h.a.m$b r3 = r0.f776a
            r3 = 0
            throw r3
        L_0x002b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.c(b.h.a.g, boolean):void");
    }

    public final void c(ArrayList<C0070a> arrayList, ArrayList<Boolean> arrayList2) {
        if (arrayList != null && !arrayList.isEmpty()) {
            if (arrayList2 == null || arrayList.size() != arrayList2.size()) {
                throw new IllegalStateException("Internal error with the back stack records");
            }
            a(arrayList, arrayList2);
            int size = arrayList.size();
            int i2 = 0;
            int i3 = 0;
            while (i2 < size) {
                if (!arrayList.get(i2).p) {
                    if (i3 != i2) {
                        a(arrayList, arrayList2, i3, i2);
                    }
                    i3 = i2 + 1;
                    if (arrayList2.get(i2).booleanValue()) {
                        while (i3 < size && arrayList2.get(i3).booleanValue() && !arrayList.get(i3).p) {
                            i3++;
                        }
                    }
                    a(arrayList, arrayList2, i2, i3);
                    i2 = i3 - 1;
                }
                i2++;
            }
            if (i3 != size) {
                a(arrayList, arrayList2, i3, size);
            }
        }
    }

    public void d() {
        this.y = false;
        this.z = false;
        a(1);
    }

    public void d(C0076g gVar) {
        if (f770c) {
            c.a.a.a.a.b("hide: ", gVar, "FragmentManager");
        }
        if (!gVar.z) {
            gVar.z = true;
            gVar.N = true ^ gVar.N;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void d(b.h.a.C0076g r3, boolean r4) {
        /*
            r2 = this;
            b.h.a.g r0 = r2.v
            if (r0 == 0) goto L_0x000e
            b.h.a.u r0 = r0.s
            boolean r1 = r0 instanceof b.h.a.u
            if (r1 == 0) goto L_0x000e
            r1 = 1
            r0.d(r3, r1)
        L_0x000e:
            java.util.concurrent.CopyOnWriteArrayList<b.h.a.u$c> r3 = r2.r
            java.util.Iterator r3 = r3.iterator()
        L_0x0014:
            boolean r0 = r3.hasNext()
            if (r0 == 0) goto L_0x002b
            java.lang.Object r0 = r3.next()
            b.h.a.u$c r0 = (b.h.a.u.c) r0
            if (r4 == 0) goto L_0x0027
            boolean r1 = r0.f777b
            if (r1 != 0) goto L_0x0027
            goto L_0x0014
        L_0x0027:
            b.h.a.m$b r3 = r0.f776a
            r3 = 0
            throw r3
        L_0x002b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.d(b.h.a.g, boolean):void");
    }

    public void e() {
        this.A = true;
        i();
        a(0);
        this.t = null;
        this.u = null;
        this.v = null;
        if (this.m != null) {
            Iterator<b.a.a> it = this.n.f146b.iterator();
            while (it.hasNext()) {
                it.next().cancel();
            }
            this.m = null;
        }
    }

    public void f() {
        for (int i2 = 0; i2 < this.i.size(); i2++) {
            C0076g gVar = this.i.get(i2);
            if (gVar != null) {
                gVar.w();
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void f(b.h.a.C0076g r3, boolean r4) {
        /*
            r2 = this;
            b.h.a.g r0 = r2.v
            if (r0 == 0) goto L_0x000e
            b.h.a.u r0 = r0.s
            boolean r1 = r0 instanceof b.h.a.u
            if (r1 == 0) goto L_0x000e
            r1 = 1
            r0.f(r3, r1)
        L_0x000e:
            java.util.concurrent.CopyOnWriteArrayList<b.h.a.u$c> r3 = r2.r
            java.util.Iterator r3 = r3.iterator()
        L_0x0014:
            boolean r0 = r3.hasNext()
            if (r0 == 0) goto L_0x002b
            java.lang.Object r0 = r3.next()
            b.h.a.u$c r0 = (b.h.a.u.c) r0
            if (r4 == 0) goto L_0x0027
            boolean r1 = r0.f777b
            if (r1 != 0) goto L_0x0027
            goto L_0x0014
        L_0x0027:
            b.h.a.m$b r3 = r0.f776a
            r3 = 0
            throw r3
        L_0x002b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.f(b.h.a.g, boolean):void");
    }

    public void g() {
        a(3);
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void g(b.h.a.C0076g r3, boolean r4) {
        /*
            r2 = this;
            b.h.a.g r0 = r2.v
            if (r0 == 0) goto L_0x000e
            b.h.a.u r0 = r0.s
            boolean r1 = r0 instanceof b.h.a.u
            if (r1 == 0) goto L_0x000e
            r1 = 1
            r0.g(r3, r1)
        L_0x000e:
            java.util.concurrent.CopyOnWriteArrayList<b.h.a.u$c> r3 = r2.r
            java.util.Iterator r3 = r3.iterator()
        L_0x0014:
            boolean r0 = r3.hasNext()
            if (r0 == 0) goto L_0x002b
            java.lang.Object r0 = r3.next()
            b.h.a.u$c r0 = (b.h.a.u.c) r0
            if (r4 == 0) goto L_0x0027
            boolean r1 = r0.f777b
            if (r1 != 0) goto L_0x0027
            goto L_0x0014
        L_0x0027:
            b.h.a.m$b r3 = r0.f776a
            r3 = 0
            throw r3
        L_0x002b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.g(b.h.a.g, boolean):void");
    }

    public void h() {
        this.y = false;
        this.z = false;
        a(4);
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void h(b.h.a.C0076g r3, boolean r4) {
        /*
            r2 = this;
            b.h.a.g r0 = r2.v
            if (r0 == 0) goto L_0x000e
            b.h.a.u r0 = r0.s
            boolean r1 = r0 instanceof b.h.a.u
            if (r1 == 0) goto L_0x000e
            r1 = 1
            r0.h(r3, r1)
        L_0x000e:
            java.util.concurrent.CopyOnWriteArrayList<b.h.a.u$c> r3 = r2.r
            java.util.Iterator r3 = r3.iterator()
        L_0x0014:
            boolean r0 = r3.hasNext()
            if (r0 == 0) goto L_0x002b
            java.lang.Object r0 = r3.next()
            b.h.a.u$c r0 = (b.h.a.u.c) r0
            if (r4 == 0) goto L_0x0027
            boolean r1 = r0.f777b
            if (r1 != 0) goto L_0x0027
            goto L_0x0014
        L_0x0027:
            b.h.a.m$b r3 = r0.f776a
            r3 = 0
            throw r3
        L_0x002b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.h(b.h.a.g, boolean):void");
    }

    public void i(C0076g gVar) {
        if (f770c) {
            Log.v("FragmentManager", "remove: " + gVar + " nesting=" + gVar.r);
        }
        boolean z2 = !gVar.u();
        if (!gVar.A || z2) {
            synchronized (this.i) {
                this.i.remove(gVar);
            }
            if (e(gVar)) {
                this.x = true;
            }
            gVar.l = false;
            gVar.m = true;
        }
    }

    /* JADX INFO: finally extract failed */
    public boolean i() {
        c(true);
        boolean z2 = false;
        while (b(this.C, this.D)) {
            this.g = true;
            try {
                c(this.C, this.D);
                c();
                z2 = true;
            } catch (Throwable th) {
                c();
                throw th;
            }
        }
        q();
        if (this.B) {
            this.B = false;
            p();
        }
        this.j.values().removeAll(Collections.singleton((Object) null));
        return z2;
    }

    public C0080k j() {
        if (this.f756b == null) {
            this.f756b = C0082m.f755a;
        }
        if (this.f756b == C0082m.f755a) {
            C0076g gVar = this.v;
            if (gVar != null) {
                return gVar.s.j();
            }
            this.f756b = new t(this);
        }
        if (this.f756b == null) {
            this.f756b = C0082m.f755a;
        }
        return this.f756b;
    }

    public void j(C0076g gVar) {
        if (l()) {
            if (f770c) {
                Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved");
            }
        } else if (this.I.e(gVar) && f770c) {
            c.a.a.a.a.b("Updating retained Fragments: Removed ", gVar, "FragmentManager");
        }
    }

    public LayoutInflater.Factory2 k() {
        return this;
    }

    public void k(C0076g gVar) {
        if (gVar.I != null) {
            SparseArray<Parcelable> sparseArray = this.G;
            if (sparseArray == null) {
                this.G = new SparseArray<>();
            } else {
                sparseArray.clear();
            }
            gVar.I.saveHierarchyState(this.G);
            if (this.G.size() > 0) {
                gVar.d = this.G;
                this.G = null;
            }
        }
    }

    public void l(C0076g gVar) {
        if (gVar == null || (this.j.get(gVar.f) == gVar && (gVar.t == null || gVar.s == this))) {
            C0076g gVar2 = this.w;
            this.w = gVar;
            c(gVar2);
            c(this.w);
            return;
        }
        throw new IllegalArgumentException("Fragment " + gVar + " is not an active fragment of FragmentManager " + this);
    }

    public boolean l() {
        return this.y || this.z;
    }

    public void m() {
        this.y = false;
        this.z = false;
        int size = this.i.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0076g gVar = this.i.get(i2);
            if (gVar != null) {
                gVar.u.m();
            }
        }
    }

    public void m(C0076g gVar) {
        if (f770c) {
            c.a.a.a.a.b("show: ", gVar, "FragmentManager");
        }
        if (gVar.z) {
            gVar.z = false;
            gVar.N = !gVar.N;
        }
    }

    public Parcelable n() {
        C0072c[] cVarArr;
        ArrayList<String> arrayList;
        int size;
        Bundle bundle;
        if (this.H != null) {
            while (!this.H.isEmpty()) {
                this.H.remove(0).a();
            }
        }
        Iterator<C0076g> it = this.j.values().iterator();
        while (true) {
            cVarArr = null;
            if (!it.hasNext()) {
                break;
            }
            C0076g next = it.next();
            if (next != null) {
                if (next.g() != null) {
                    int r2 = next.r();
                    View g2 = next.g();
                    Animation animation = g2.getAnimation();
                    if (animation != null) {
                        animation.cancel();
                        g2.clearAnimation();
                    }
                    next.a((View) null);
                    a(next, r2, 0, 0, false);
                } else if (next.h() != null) {
                    next.h().end();
                }
            }
        }
        i();
        this.y = true;
        if (this.j.isEmpty()) {
            return null;
        }
        ArrayList<A> arrayList2 = new ArrayList<>(this.j.size());
        boolean z2 = false;
        for (C0076g next2 : this.j.values()) {
            if (next2 != null) {
                if (next2.s == this) {
                    A a2 = new A(next2);
                    arrayList2.add(a2);
                    if (next2.f745b <= 0 || a2.m != null) {
                        a2.m = next2.f746c;
                    } else {
                        if (this.F == null) {
                            this.F = new Bundle();
                        }
                        Bundle bundle2 = this.F;
                        next2.V.b(bundle2);
                        Parcelable n2 = next2.u.n();
                        if (n2 != null) {
                            bundle2.putParcelable("android:support:fragments", n2);
                        }
                        d(next2, this.F, false);
                        if (!this.F.isEmpty()) {
                            bundle = this.F;
                            this.F = null;
                        } else {
                            bundle = null;
                        }
                        if (next2.H != null) {
                            k(next2);
                        }
                        if (next2.d != null) {
                            if (bundle == null) {
                                bundle = new Bundle();
                            }
                            bundle.putSparseParcelableArray("android:view_state", next2.d);
                        }
                        if (!next2.K) {
                            if (bundle == null) {
                                bundle = new Bundle();
                            }
                            bundle.putBoolean("android:user_visible_hint", next2.K);
                        }
                        a2.m = bundle;
                        String str = next2.i;
                        if (str != null) {
                            C0076g gVar = this.j.get(str);
                            if (gVar != null) {
                                if (a2.m == null) {
                                    a2.m = new Bundle();
                                }
                                Bundle bundle3 = a2.m;
                                if (gVar.s == this) {
                                    bundle3.putString("android:target_state", gVar.f);
                                    int i2 = next2.j;
                                    if (i2 != 0) {
                                        a2.m.putInt("android:target_req_state", i2);
                                    }
                                } else {
                                    a((RuntimeException) new IllegalStateException(c.a.a.a.a.a("Fragment ", (Object) gVar, " is not currently in the FragmentManager")));
                                    throw null;
                                }
                            } else {
                                a((RuntimeException) new IllegalStateException("Failure saving state: " + next2 + " has target not in fragment manager: " + next2.i));
                                throw null;
                            }
                        }
                    }
                    if (f770c) {
                        Log.v("FragmentManager", "Saved state of " + next2 + ": " + a2.m);
                    }
                    z2 = true;
                } else {
                    a((RuntimeException) new IllegalStateException(c.a.a.a.a.a("Failure saving state: active ", (Object) next2, " was removed from the FragmentManager")));
                    throw null;
                }
            }
        }
        if (!z2) {
            if (f770c) {
                Log.v("FragmentManager", "saveAllState: no fragments!");
            }
            return null;
        }
        int size2 = this.i.size();
        if (size2 > 0) {
            arrayList = new ArrayList<>(size2);
            Iterator<C0076g> it2 = this.i.iterator();
            while (it2.hasNext()) {
                C0076g next3 = it2.next();
                arrayList.add(next3.f);
                if (next3.s != this) {
                    a((RuntimeException) new IllegalStateException(c.a.a.a.a.a("Failure saving state: active ", (Object) next3, " was removed from the FragmentManager")));
                    throw null;
                } else if (f770c) {
                    StringBuilder a3 = c.a.a.a.a.a("saveAllState: adding fragment (");
                    a3.append(next3.f);
                    a3.append("): ");
                    a3.append(next3);
                    Log.v("FragmentManager", a3.toString());
                }
            }
        } else {
            arrayList = null;
        }
        ArrayList<C0070a> arrayList3 = this.k;
        if (arrayList3 != null && (size = arrayList3.size()) > 0) {
            cVarArr = new C0072c[size];
            for (int i3 = 0; i3 < size; i3++) {
                cVarArr[i3] = new C0072c(this.k.get(i3));
                if (f770c) {
                    Log.v("FragmentManager", "saveAllState: adding back stack #" + i3 + ": " + this.k.get(i3));
                }
            }
        }
        w wVar = new w();
        wVar.f782a = arrayList2;
        wVar.f783b = arrayList;
        wVar.f784c = cVarArr;
        C0076g gVar2 = this.w;
        if (gVar2 != null) {
            wVar.d = gVar2.f;
        }
        wVar.e = this.h;
        return wVar;
    }

    public void o() {
        synchronized (this) {
            boolean z2 = false;
            boolean z3 = this.H != null && !this.H.isEmpty();
            if (this.f != null && this.f.size() == 1) {
                z2 = true;
            }
            if (z3 || z2) {
                this.t.f754c.removeCallbacks(this.J);
                this.t.f754c.post(this.J);
                q();
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0092, code lost:
        r2 = r11;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View onCreateView(android.view.View r14, java.lang.String r15, android.content.Context r16, android.util.AttributeSet r17) {
        /*
            r13 = this;
            r6 = r13
            r0 = r17
            java.lang.String r1 = "fragment"
            r2 = r15
            boolean r1 = r1.equals(r15)
            r2 = 0
            if (r1 != 0) goto L_0x000e
            return r2
        L_0x000e:
            java.lang.String r1 = "class"
            java.lang.String r1 = r0.getAttributeValue(r2, r1)
            int[] r3 = b.h.a.u.d.f778a
            r4 = r16
            android.content.res.TypedArray r3 = r4.obtainStyledAttributes(r0, r3)
            r5 = 0
            if (r1 != 0) goto L_0x0023
            java.lang.String r1 = r3.getString(r5)
        L_0x0023:
            r7 = r1
            r1 = 1
            r8 = -1
            int r9 = r3.getResourceId(r1, r8)
            r10 = 2
            java.lang.String r10 = r3.getString(r10)
            r3.recycle()
            if (r7 == 0) goto L_0x01ba
            java.lang.ClassLoader r3 = r16.getClassLoader()
            boolean r3 = b.h.a.C0080k.b(r3, r7)
            if (r3 != 0) goto L_0x0040
            goto L_0x01ba
        L_0x0040:
            if (r14 == 0) goto L_0x0046
            int r5 = r14.getId()
        L_0x0046:
            if (r5 != r8) goto L_0x006b
            if (r9 != r8) goto L_0x006b
            if (r10 == 0) goto L_0x004d
            goto L_0x006b
        L_0x004d:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r0 = r17.getPositionDescription()
            r2.append(r0)
            java.lang.String r0 = ": Must specify unique android:id, android:tag, or have a parent with an id for "
            r2.append(r0)
            r2.append(r7)
            java.lang.String r0 = r2.toString()
            r1.<init>(r0)
            throw r1
        L_0x006b:
            if (r9 == r8) goto L_0x0072
            b.h.a.g r3 = r13.b((int) r9)
            goto L_0x0073
        L_0x0072:
            r3 = r2
        L_0x0073:
            if (r3 != 0) goto L_0x00b8
            if (r10 == 0) goto L_0x00b8
            java.util.ArrayList<b.h.a.g> r3 = r6.i
            int r3 = r3.size()
            int r3 = r3 + r8
        L_0x007e:
            if (r3 < 0) goto L_0x0097
            java.util.ArrayList<b.h.a.g> r11 = r6.i
            java.lang.Object r11 = r11.get(r3)
            b.h.a.g r11 = (b.h.a.C0076g) r11
            if (r11 == 0) goto L_0x0094
            java.lang.String r12 = r11.y
            boolean r12 = r10.equals(r12)
            if (r12 == 0) goto L_0x0094
        L_0x0092:
            r2 = r11
            goto L_0x00b9
        L_0x0094:
            int r3 = r3 + -1
            goto L_0x007e
        L_0x0097:
            java.util.HashMap<java.lang.String, b.h.a.g> r3 = r6.j
            java.util.Collection r3 = r3.values()
            java.util.Iterator r3 = r3.iterator()
        L_0x00a1:
            boolean r11 = r3.hasNext()
            if (r11 == 0) goto L_0x00b9
            java.lang.Object r11 = r3.next()
            b.h.a.g r11 = (b.h.a.C0076g) r11
            if (r11 == 0) goto L_0x00a1
            java.lang.String r12 = r11.y
            boolean r12 = r10.equals(r12)
            if (r12 == 0) goto L_0x00a1
            goto L_0x0092
        L_0x00b8:
            r2 = r3
        L_0x00b9:
            if (r2 != 0) goto L_0x00c1
            if (r5 == r8) goto L_0x00c1
            b.h.a.g r2 = r13.b((int) r5)
        L_0x00c1:
            boolean r3 = f770c
            if (r3 == 0) goto L_0x00eb
            java.lang.String r3 = "onCreateView: id=0x"
            java.lang.StringBuilder r3 = c.a.a.a.a.a(r3)
            java.lang.String r8 = java.lang.Integer.toHexString(r9)
            r3.append(r8)
            java.lang.String r8 = " fname="
            r3.append(r8)
            r3.append(r7)
            java.lang.String r8 = " existing="
            r3.append(r8)
            r3.append(r2)
            java.lang.String r3 = r3.toString()
            java.lang.String r8 = "FragmentManager"
            android.util.Log.v(r8, r3)
        L_0x00eb:
            if (r2 != 0) goto L_0x0119
            b.h.a.k r2 = r13.j()
            java.lang.ClassLoader r3 = r16.getClassLoader()
            b.h.a.g r2 = r2.a(r3, r7)
            r2.n = r1
            if (r9 == 0) goto L_0x00ff
            r3 = r9
            goto L_0x0100
        L_0x00ff:
            r3 = r5
        L_0x0100:
            r2.w = r3
            r2.x = r5
            r2.y = r10
            r2.o = r1
            r2.s = r6
            b.h.a.l r3 = r6.t
            r2.t = r3
            android.content.Context r3 = r3.f753b
            android.os.Bundle r4 = r2.f746c
            r2.a((android.content.Context) r3, (android.util.AttributeSet) r0, (android.os.Bundle) r4)
            r13.a((b.h.a.C0076g) r2, (boolean) r1)
            goto L_0x012a
        L_0x0119:
            boolean r3 = r2.o
            if (r3 != 0) goto L_0x017c
            r2.o = r1
            b.h.a.l r3 = r6.t
            r2.t = r3
            android.content.Context r3 = r3.f753b
            android.os.Bundle r4 = r2.f746c
            r2.a((android.content.Context) r3, (android.util.AttributeSet) r0, (android.os.Bundle) r4)
        L_0x012a:
            r8 = r2
            int r0 = r6.s
            if (r0 >= r1) goto L_0x013d
            boolean r0 = r8.n
            if (r0 == 0) goto L_0x013d
            r2 = 1
            r3 = 0
            r4 = 0
            r5 = 0
            r0 = r13
            r1 = r8
            r0.a(r1, r2, r3, r4, r5)
            goto L_0x0147
        L_0x013d:
            int r2 = r6.s
            r3 = 0
            r4 = 0
            r5 = 0
            r0 = r13
            r1 = r8
            r0.a(r1, r2, r3, r4, r5)
        L_0x0147:
            android.view.View r0 = r8.H
            if (r0 == 0) goto L_0x0160
            if (r9 == 0) goto L_0x0150
            r0.setId(r9)
        L_0x0150:
            android.view.View r0 = r8.H
            java.lang.Object r0 = r0.getTag()
            if (r0 != 0) goto L_0x015d
            android.view.View r0 = r8.H
            r0.setTag(r10)
        L_0x015d:
            android.view.View r0 = r8.H
            return r0
        L_0x0160:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Fragment "
            r1.append(r2)
            r1.append(r7)
            java.lang.String r2 = " did not create a view."
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x017c:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r0 = r17.getPositionDescription()
            r2.append(r0)
            java.lang.String r0 = ": Duplicate id 0x"
            r2.append(r0)
            java.lang.String r0 = java.lang.Integer.toHexString(r9)
            r2.append(r0)
            java.lang.String r0 = ", tag "
            r2.append(r0)
            r2.append(r10)
            java.lang.String r0 = ", or parent id 0x"
            r2.append(r0)
            java.lang.String r0 = java.lang.Integer.toHexString(r5)
            r2.append(r0)
            java.lang.String r0 = " with another fragment for "
            r2.append(r0)
            r2.append(r7)
            java.lang.String r0 = r2.toString()
            r1.<init>(r0)
            throw r1
        L_0x01ba:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.onCreateView(android.view.View, java.lang.String, android.content.Context, android.util.AttributeSet):android.view.View");
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView((View) null, str, context, attributeSet);
    }

    public void p() {
        for (C0076g next : this.j.values()) {
            if (next != null && next.J) {
                if (this.g) {
                    this.B = true;
                } else {
                    next.J = false;
                    a(next, this.s, 0, 0, false);
                }
            }
        }
    }

    public final void q() {
        ArrayList<e> arrayList = this.f;
        boolean z2 = true;
        if (arrayList == null || arrayList.isEmpty()) {
            b.a.d dVar = this.n;
            ArrayList<C0070a> arrayList2 = this.k;
            if ((arrayList2 != null ? arrayList2.size() : 0) <= 0 || !f(this.v)) {
                z2 = false;
            }
            dVar.f145a = z2;
            return;
        }
        this.n.f145a = true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        Object obj = this.v;
        if (obj == null) {
            obj = this.t;
        }
        a.a.a.a.c.a(obj, sb);
        sb.append("}}");
        return sb.toString();
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v7, resolved type: b.a.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v8, resolved type: b.h.a.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v9, resolved type: b.h.a.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v10, resolved type: b.h.a.g} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void a(b.h.a.C0081l r3, b.h.a.C0078i r4, b.h.a.C0076g r5) {
        /*
            r2 = this;
            b.h.a.l r0 = r2.t
            if (r0 != 0) goto L_0x004c
            r2.t = r3
            r2.u = r4
            r2.v = r5
            b.h.a.g r4 = r2.v
            if (r4 == 0) goto L_0x0011
            r2.q()
        L_0x0011:
            boolean r4 = r3 instanceof b.a.e
            if (r4 == 0) goto L_0x0028
            r4 = r3
            b.a.e r4 = (b.a.e) r4
            androidx.activity.OnBackPressedDispatcher r0 = r4.b()
            r2.m = r0
            if (r5 == 0) goto L_0x0021
            r4 = r5
        L_0x0021:
            androidx.activity.OnBackPressedDispatcher r0 = r2.m
            b.a.d r1 = r2.n
            r0.a(r4, r1)
        L_0x0028:
            if (r5 == 0) goto L_0x0035
            b.h.a.u r3 = r5.s
            b.h.a.y r3 = r3.I
            b.h.a.y r3 = r3.c(r5)
        L_0x0032:
            r2.I = r3
            goto L_0x004b
        L_0x0035:
            boolean r4 = r3 instanceof b.j.v
            if (r4 == 0) goto L_0x0044
            b.j.v r3 = (b.j.v) r3
            b.j.u r3 = r3.d()
            b.h.a.y r3 = b.h.a.y.a((b.j.u) r3)
            goto L_0x0032
        L_0x0044:
            b.h.a.y r3 = new b.h.a.y
            r4 = 0
            r3.<init>(r4)
            goto L_0x0032
        L_0x004b:
            return
        L_0x004c:
            java.lang.IllegalStateException r3 = new java.lang.IllegalStateException
            java.lang.String r4 = "Already attached"
            r3.<init>(r4)
            goto L_0x0055
        L_0x0054:
            throw r3
        L_0x0055:
            goto L_0x0054
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.a(b.h.a.l, b.h.a.i, b.h.a.g):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void b(b.h.a.C0076g r3, boolean r4) {
        /*
            r2 = this;
            b.h.a.g r0 = r2.v
            if (r0 == 0) goto L_0x000e
            b.h.a.u r0 = r0.s
            boolean r1 = r0 instanceof b.h.a.u
            if (r1 == 0) goto L_0x000e
            r1 = 1
            r0.b((b.h.a.C0076g) r3, (boolean) r1)
        L_0x000e:
            java.util.concurrent.CopyOnWriteArrayList<b.h.a.u$c> r3 = r2.r
            java.util.Iterator r3 = r3.iterator()
        L_0x0014:
            boolean r0 = r3.hasNext()
            if (r0 == 0) goto L_0x002b
            java.lang.Object r0 = r3.next()
            b.h.a.u$c r0 = (b.h.a.u.c) r0
            if (r4 == 0) goto L_0x0027
            boolean r1 = r0.f777b
            if (r1 != 0) goto L_0x0027
            goto L_0x0014
        L_0x0027:
            b.h.a.m$b r3 = r0.f776a
            r3 = 0
            throw r3
        L_0x002b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.b(b.h.a.g, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void c(b.h.a.C0076g r3, android.os.Bundle r4, boolean r5) {
        /*
            r2 = this;
            b.h.a.g r0 = r2.v
            if (r0 == 0) goto L_0x000e
            b.h.a.u r0 = r0.s
            boolean r1 = r0 instanceof b.h.a.u
            if (r1 == 0) goto L_0x000e
            r1 = 1
            r0.c(r3, r4, r1)
        L_0x000e:
            java.util.concurrent.CopyOnWriteArrayList<b.h.a.u$c> r3 = r2.r
            java.util.Iterator r3 = r3.iterator()
        L_0x0014:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x002b
            java.lang.Object r4 = r3.next()
            b.h.a.u$c r4 = (b.h.a.u.c) r4
            if (r5 == 0) goto L_0x0027
            boolean r0 = r4.f777b
            if (r0 != 0) goto L_0x0027
            goto L_0x0014
        L_0x0027:
            b.h.a.m$b r3 = r4.f776a
            r3 = 0
            throw r3
        L_0x002b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.c(b.h.a.g, android.os.Bundle, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void d(b.h.a.C0076g r3, android.os.Bundle r4, boolean r5) {
        /*
            r2 = this;
            b.h.a.g r0 = r2.v
            if (r0 == 0) goto L_0x000e
            b.h.a.u r0 = r0.s
            boolean r1 = r0 instanceof b.h.a.u
            if (r1 == 0) goto L_0x000e
            r1 = 1
            r0.d(r3, r4, r1)
        L_0x000e:
            java.util.concurrent.CopyOnWriteArrayList<b.h.a.u$c> r3 = r2.r
            java.util.Iterator r3 = r3.iterator()
        L_0x0014:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x002b
            java.lang.Object r4 = r3.next()
            b.h.a.u$c r4 = (b.h.a.u.c) r4
            if (r5 == 0) goto L_0x0027
            boolean r0 = r4.f777b
            if (r0 != 0) goto L_0x0027
            goto L_0x0014
        L_0x0027:
            b.h.a.m$b r3 = r4.f776a
            r3 = 0
            throw r3
        L_0x002b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.d(b.h.a.g, android.os.Bundle, boolean):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void e(b.h.a.C0076g r3, boolean r4) {
        /*
            r2 = this;
            b.h.a.g r0 = r2.v
            if (r0 == 0) goto L_0x000e
            b.h.a.u r0 = r0.s
            boolean r1 = r0 instanceof b.h.a.u
            if (r1 == 0) goto L_0x000e
            r1 = 1
            r0.e(r3, r1)
        L_0x000e:
            java.util.concurrent.CopyOnWriteArrayList<b.h.a.u$c> r3 = r2.r
            java.util.Iterator r3 = r3.iterator()
        L_0x0014:
            boolean r0 = r3.hasNext()
            if (r0 == 0) goto L_0x002b
            java.lang.Object r0 = r3.next()
            b.h.a.u$c r0 = (b.h.a.u.c) r0
            if (r4 == 0) goto L_0x0027
            boolean r1 = r0.f777b
            if (r1 != 0) goto L_0x0027
            goto L_0x0014
        L_0x0027:
            b.h.a.m$b r3 = r0.f776a
            r3 = 0
            throw r3
        L_0x002b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.e(b.h.a.g, boolean):void");
    }

    public boolean f(C0076g gVar) {
        if (gVar == null) {
            return true;
        }
        u uVar = gVar.s;
        if (gVar != uVar.w || !f(uVar.v)) {
            return false;
        }
        return true;
    }

    public void g(C0076g gVar) {
        String str;
        if (this.j.get(gVar.f) == null) {
            this.j.put(gVar.f, gVar);
            if (gVar.C) {
                if (gVar.B) {
                    if (l()) {
                        if (f770c) {
                            str = "Ignoring addRetainedFragment as the state is already saved";
                        }
                    } else if (this.I.a(gVar) && f770c) {
                        str = "Updating retained Fragments: Added " + gVar;
                    }
                    Log.v("FragmentManager", str);
                } else {
                    j(gVar);
                }
                gVar.C = false;
            }
            if (f770c) {
                c.a.a.a.a.b("Added fragment to active set ", gVar, "FragmentManager");
            }
        }
    }

    public void h(C0076g gVar) {
        Animator animator;
        ViewGroup viewGroup;
        int indexOfChild;
        int indexOfChild2;
        if (gVar != null) {
            if (this.j.containsKey(gVar.f)) {
                int i2 = this.s;
                if (gVar.m) {
                    i2 = gVar.u() ? Math.min(i2, 1) : Math.min(i2, 0);
                }
                a(gVar, i2, gVar.o(), gVar.p(), false);
                View view = gVar.H;
                if (view != null) {
                    ViewGroup viewGroup2 = gVar.G;
                    C0076g gVar2 = null;
                    if (viewGroup2 != null && view != null) {
                        int indexOf = this.i.indexOf(gVar);
                        while (true) {
                            indexOf--;
                            if (indexOf < 0) {
                                break;
                            }
                            C0076g gVar3 = this.i.get(indexOf);
                            if (gVar3.G == viewGroup2 && gVar3.H != null) {
                                gVar2 = gVar3;
                                break;
                            }
                        }
                    }
                    if (gVar2 != null && (indexOfChild2 = viewGroup.indexOfChild(gVar.H)) < (indexOfChild = viewGroup.indexOfChild(gVar2.H))) {
                        (viewGroup = gVar.G).removeViewAt(indexOfChild2);
                        viewGroup.addView(gVar.H, indexOfChild);
                    }
                    if (gVar.M && gVar.G != null) {
                        float f2 = gVar.O;
                        if (f2 > 0.0f) {
                            gVar.H.setAlpha(f2);
                        }
                        gVar.O = 0.0f;
                        gVar.M = false;
                        a a2 = a(gVar, gVar.o(), true, gVar.p());
                        if (a2 != null) {
                            Animation animation = a2.f771a;
                            if (animation != null) {
                                gVar.H.startAnimation(animation);
                            } else {
                                a2.f772b.setTarget(gVar.H);
                                a2.f772b.start();
                            }
                        }
                    }
                }
                if (gVar.N) {
                    if (gVar.H != null) {
                        a a3 = a(gVar, gVar.o(), !gVar.z, gVar.p());
                        if (a3 == null || (animator = a3.f772b) == null) {
                            if (a3 != null) {
                                gVar.H.startAnimation(a3.f771a);
                                a3.f771a.start();
                            }
                            gVar.H.setVisibility((!gVar.z || gVar.t()) ? 0 : 8);
                            if (gVar.t()) {
                                gVar.c(false);
                            }
                        } else {
                            animator.setTarget(gVar.H);
                            if (!gVar.z) {
                                gVar.H.setVisibility(0);
                            } else if (gVar.t()) {
                                gVar.c(false);
                            } else {
                                ViewGroup viewGroup3 = gVar.G;
                                View view2 = gVar.H;
                                viewGroup3.startViewTransition(view2);
                                a3.f772b.addListener(new C0087s(this, viewGroup3, view2, gVar));
                            }
                            a3.f772b.start();
                        }
                    }
                    if (gVar.l && e(gVar)) {
                        this.x = true;
                    }
                    gVar.N = false;
                    boolean z2 = gVar.z;
                }
            } else if (f770c) {
                Log.v("FragmentManager", "Ignoring moving " + gVar + " to state " + this.s + "since it is not added to " + this);
            }
        }
    }

    public void a(Configuration configuration) {
        for (int i2 = 0; i2 < this.i.size(); i2++) {
            C0076g gVar = this.i.get(i2);
            if (gVar != null) {
                gVar.F = true;
                gVar.u.a(configuration);
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void b(b.h.a.C0076g r3, android.content.Context r4, boolean r5) {
        /*
            r2 = this;
            b.h.a.g r0 = r2.v
            if (r0 == 0) goto L_0x000e
            b.h.a.u r0 = r0.s
            boolean r1 = r0 instanceof b.h.a.u
            if (r1 == 0) goto L_0x000e
            r1 = 1
            r0.b((b.h.a.C0076g) r3, (android.content.Context) r4, (boolean) r1)
        L_0x000e:
            java.util.concurrent.CopyOnWriteArrayList<b.h.a.u$c> r3 = r2.r
            java.util.Iterator r3 = r3.iterator()
        L_0x0014:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x002b
            java.lang.Object r4 = r3.next()
            b.h.a.u$c r4 = (b.h.a.u.c) r4
            if (r5 == 0) goto L_0x0027
            boolean r0 = r4.f777b
            if (r0 != 0) goto L_0x0027
            goto L_0x0014
        L_0x0027:
            b.h.a.m$b r3 = r4.f776a
            r3 = 0
            throw r3
        L_0x002b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.b(b.h.a.g, android.content.Context, boolean):void");
    }

    public final void c(C0076g gVar) {
        if (gVar != null && this.j.get(gVar.f) == gVar) {
            boolean f2 = gVar.s.f(gVar);
            Boolean bool = gVar.k;
            if (bool == null || bool.booleanValue() != f2) {
                gVar.k = Boolean.valueOf(f2);
                u uVar = gVar.u;
                uVar.q();
                uVar.c(uVar.w);
            }
        }
    }

    public final boolean e(C0076g gVar) {
        boolean z2;
        if (gVar.D && gVar.E) {
            return true;
        }
        u uVar = gVar.u;
        Iterator<C0076g> it = uVar.j.values().iterator();
        boolean z3 = false;
        while (true) {
            if (!it.hasNext()) {
                z2 = false;
                break;
            }
            C0076g next = it.next();
            if (next != null) {
                z3 = uVar.e(next);
                continue;
            }
            if (z3) {
                z2 = true;
                break;
            }
        }
        return z2;
    }

    public boolean a(MenuItem menuItem) {
        if (this.s < 1) {
            return false;
        }
        for (int i2 = 0; i2 < this.i.size(); i2++) {
            C0076g gVar = this.i.get(i2);
            if (gVar != null) {
                if (!gVar.z && gVar.u.a(menuItem)) {
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x0031 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0032 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean b(android.view.MenuItem r6) {
        /*
            r5 = this;
            int r0 = r5.s
            r1 = 0
            r2 = 1
            if (r0 >= r2) goto L_0x0007
            return r1
        L_0x0007:
            r0 = 0
        L_0x0008:
            java.util.ArrayList<b.h.a.g> r3 = r5.i
            int r3 = r3.size()
            if (r0 >= r3) goto L_0x0035
            java.util.ArrayList<b.h.a.g> r3 = r5.i
            java.lang.Object r3 = r3.get(r0)
            b.h.a.g r3 = (b.h.a.C0076g) r3
            if (r3 == 0) goto L_0x0032
            boolean r4 = r3.z
            if (r4 != 0) goto L_0x002e
            boolean r4 = r3.D
            if (r4 == 0) goto L_0x0024
            boolean r4 = r3.E
        L_0x0024:
            b.h.a.u r3 = r3.u
            boolean r3 = r3.b((android.view.MenuItem) r6)
            if (r3 == 0) goto L_0x002e
            r3 = 1
            goto L_0x002f
        L_0x002e:
            r3 = 0
        L_0x002f:
            if (r3 == 0) goto L_0x0032
            return r2
        L_0x0032:
            int r0 = r0 + 1
            goto L_0x0008
        L_0x0035:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.b(android.view.MenuItem):boolean");
    }

    public final void c(boolean z2) {
        if (this.g) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        } else if (this.t == null) {
            throw new IllegalStateException("Fragment host has been destroyed");
        } else if (Looper.myLooper() != this.t.f754c.getLooper()) {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        } else if (z2 || !l()) {
            if (this.C == null) {
                this.C = new ArrayList<>();
                this.D = new ArrayList<>();
            }
            this.g = true;
            try {
                a((ArrayList<C0070a>) null, (ArrayList<Boolean>) null);
            } finally {
                this.g = false;
            }
        } else {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void a(b.h.a.C0076g r3, android.os.Bundle r4, boolean r5) {
        /*
            r2 = this;
            b.h.a.g r0 = r2.v
            if (r0 == 0) goto L_0x000e
            b.h.a.u r0 = r0.s
            boolean r1 = r0 instanceof b.h.a.u
            if (r1 == 0) goto L_0x000e
            r1 = 1
            r0.a((b.h.a.C0076g) r3, (android.os.Bundle) r4, (boolean) r1)
        L_0x000e:
            java.util.concurrent.CopyOnWriteArrayList<b.h.a.u$c> r3 = r2.r
            java.util.Iterator r3 = r3.iterator()
        L_0x0014:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x002b
            java.lang.Object r4 = r3.next()
            b.h.a.u$c r4 = (b.h.a.u.c) r4
            if (r5 == 0) goto L_0x0027
            boolean r0 = r4.f777b
            if (r0 != 0) goto L_0x0027
            goto L_0x0014
        L_0x0027:
            b.h.a.m$b r3 = r4.f776a
            r3 = 0
            throw r3
        L_0x002b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.a(b.h.a.g, android.os.Bundle, boolean):void");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x003b, code lost:
        return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean b(java.util.ArrayList<b.h.a.C0070a> r5, java.util.ArrayList<java.lang.Boolean> r6) {
        /*
            r4 = this;
            monitor-enter(r4)
            java.util.ArrayList<b.h.a.u$e> r0 = r4.f     // Catch:{ all -> 0x003c }
            r1 = 0
            if (r0 == 0) goto L_0x003a
            java.util.ArrayList<b.h.a.u$e> r0 = r4.f     // Catch:{ all -> 0x003c }
            int r0 = r0.size()     // Catch:{ all -> 0x003c }
            if (r0 != 0) goto L_0x000f
            goto L_0x003a
        L_0x000f:
            java.util.ArrayList<b.h.a.u$e> r0 = r4.f     // Catch:{ all -> 0x003c }
            int r0 = r0.size()     // Catch:{ all -> 0x003c }
            r2 = 0
        L_0x0016:
            if (r1 >= r0) goto L_0x002a
            java.util.ArrayList<b.h.a.u$e> r3 = r4.f     // Catch:{ all -> 0x003c }
            java.lang.Object r3 = r3.get(r1)     // Catch:{ all -> 0x003c }
            b.h.a.u$e r3 = (b.h.a.u.e) r3     // Catch:{ all -> 0x003c }
            b.h.a.a r3 = (b.h.a.C0070a) r3
            r3.a(r5, r6)     // Catch:{ all -> 0x003c }
            r2 = r2 | 1
            int r1 = r1 + 1
            goto L_0x0016
        L_0x002a:
            java.util.ArrayList<b.h.a.u$e> r5 = r4.f     // Catch:{ all -> 0x003c }
            r5.clear()     // Catch:{ all -> 0x003c }
            b.h.a.l r5 = r4.t     // Catch:{ all -> 0x003c }
            android.os.Handler r5 = r5.f754c     // Catch:{ all -> 0x003c }
            java.lang.Runnable r6 = r4.J     // Catch:{ all -> 0x003c }
            r5.removeCallbacks(r6)     // Catch:{ all -> 0x003c }
            monitor-exit(r4)     // Catch:{ all -> 0x003c }
            return r2
        L_0x003a:
            monitor-exit(r4)     // Catch:{ all -> 0x003c }
            return r1
        L_0x003c:
            r5 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x003c }
            goto L_0x0040
        L_0x003f:
            throw r5
        L_0x0040:
            goto L_0x003f
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.b(java.util.ArrayList, java.util.ArrayList):boolean");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void a(b.h.a.C0076g r3, android.content.Context r4, boolean r5) {
        /*
            r2 = this;
            b.h.a.g r0 = r2.v
            if (r0 == 0) goto L_0x000e
            b.h.a.u r0 = r0.s
            boolean r1 = r0 instanceof b.h.a.u
            if (r1 == 0) goto L_0x000e
            r1 = 1
            r0.a((b.h.a.C0076g) r3, (android.content.Context) r4, (boolean) r1)
        L_0x000e:
            java.util.concurrent.CopyOnWriteArrayList<b.h.a.u$c> r3 = r2.r
            java.util.Iterator r3 = r3.iterator()
        L_0x0014:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x002b
            java.lang.Object r4 = r3.next()
            b.h.a.u$c r4 = (b.h.a.u.c) r4
            if (r5 == 0) goto L_0x0027
            boolean r0 = r4.f777b
            if (r0 != 0) goto L_0x0027
            goto L_0x0014
        L_0x0027:
            b.h.a.m$b r3 = r4.f776a
            r3 = 0
            throw r3
        L_0x002b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.a(b.h.a.g, android.content.Context, boolean):void");
    }

    public boolean b() {
        boolean z2;
        int size;
        if (!l()) {
            i();
            c(true);
            C0076g gVar = this.w;
            if (gVar != null && gVar.i().b()) {
                return true;
            }
            ArrayList<C0070a> arrayList = this.C;
            ArrayList<Boolean> arrayList2 = this.D;
            ArrayList<C0070a> arrayList3 = this.k;
            if (arrayList3 != null && (size = arrayList3.size() - 1) >= 0) {
                arrayList.add(this.k.remove(size));
                arrayList2.add(true);
                z2 = true;
            } else {
                z2 = false;
            }
            if (z2) {
                this.g = true;
                try {
                    c(this.C, this.D);
                } finally {
                    c();
                }
            }
            q();
            if (this.B) {
                this.B = false;
                p();
            }
            this.j.values().removeAll(Collections.singleton((Object) null));
            return z2;
        }
        throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x001a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void a(b.h.a.C0076g r3, android.view.View r4, android.os.Bundle r5, boolean r6) {
        /*
            r2 = this;
            b.h.a.g r0 = r2.v
            if (r0 == 0) goto L_0x000e
            b.h.a.u r0 = r0.s
            boolean r1 = r0 instanceof b.h.a.u
            if (r1 == 0) goto L_0x000e
            r1 = 1
            r0.a((b.h.a.C0076g) r3, (android.view.View) r4, (android.os.Bundle) r5, (boolean) r1)
        L_0x000e:
            java.util.concurrent.CopyOnWriteArrayList<b.h.a.u$c> r3 = r2.r
            java.util.Iterator r3 = r3.iterator()
        L_0x0014:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x002b
            java.lang.Object r4 = r3.next()
            b.h.a.u$c r4 = (b.h.a.u.c) r4
            if (r6 == 0) goto L_0x0027
            boolean r5 = r4.f777b
            if (r5 != 0) goto L_0x0027
            goto L_0x0014
        L_0x0027:
            b.h.a.m$b r3 = r4.f776a
            r3 = 0
            throw r3
        L_0x002b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.a(b.h.a.g, android.view.View, android.os.Bundle, boolean):void");
    }

    public void a(Menu menu) {
        if (this.s >= 1) {
            for (int i2 = 0; i2 < this.i.size(); i2++) {
                C0076g gVar = this.i.get(i2);
                if (gVar != null && !gVar.z) {
                    if (gVar.D) {
                        boolean z2 = gVar.E;
                    }
                    gVar.u.a(menu);
                }
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0175, code lost:
        r4 = r2.i;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void a(java.lang.String r6, java.io.FileDescriptor r7, java.io.PrintWriter r8, java.lang.String[] r9) {
        /*
            r5 = this;
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            r0.append(r6)
            java.lang.String r1 = "    "
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            java.util.HashMap<java.lang.String, b.h.a.g> r1 = r5.j
            boolean r1 = r1.isEmpty()
            if (r1 != 0) goto L_0x0249
            r8.print(r6)
            java.lang.String r1 = "Active Fragments in "
            r8.print(r1)
            int r1 = java.lang.System.identityHashCode(r5)
            java.lang.String r1 = java.lang.Integer.toHexString(r1)
            r8.print(r1)
            java.lang.String r1 = ":"
            r8.println(r1)
            java.util.HashMap<java.lang.String, b.h.a.g> r1 = r5.j
            java.util.Collection r1 = r1.values()
            java.util.Iterator r1 = r1.iterator()
        L_0x003b:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x0249
            java.lang.Object r2 = r1.next()
            b.h.a.g r2 = (b.h.a.C0076g) r2
            r8.print(r6)
            r8.println(r2)
            if (r2 == 0) goto L_0x003b
            r8.print(r0)
            java.lang.String r3 = "mFragmentId=#"
            r8.print(r3)
            int r3 = r2.w
            java.lang.String r3 = java.lang.Integer.toHexString(r3)
            r8.print(r3)
            java.lang.String r3 = " mContainerId=#"
            r8.print(r3)
            int r3 = r2.x
            java.lang.String r3 = java.lang.Integer.toHexString(r3)
            r8.print(r3)
            java.lang.String r3 = " mTag="
            r8.print(r3)
            java.lang.String r3 = r2.y
            r8.println(r3)
            r8.print(r0)
            java.lang.String r3 = "mState="
            r8.print(r3)
            int r3 = r2.f745b
            r8.print(r3)
            java.lang.String r3 = " mWho="
            r8.print(r3)
            java.lang.String r3 = r2.f
            r8.print(r3)
            java.lang.String r3 = " mBackStackNesting="
            r8.print(r3)
            int r3 = r2.r
            r8.println(r3)
            r8.print(r0)
            java.lang.String r3 = "mAdded="
            r8.print(r3)
            boolean r3 = r2.l
            r8.print(r3)
            java.lang.String r3 = " mRemoving="
            r8.print(r3)
            boolean r3 = r2.m
            r8.print(r3)
            java.lang.String r3 = " mFromLayout="
            r8.print(r3)
            boolean r3 = r2.n
            r8.print(r3)
            java.lang.String r3 = " mInLayout="
            r8.print(r3)
            boolean r3 = r2.o
            r8.println(r3)
            r8.print(r0)
            java.lang.String r3 = "mHidden="
            r8.print(r3)
            boolean r3 = r2.z
            r8.print(r3)
            java.lang.String r3 = " mDetached="
            r8.print(r3)
            boolean r3 = r2.A
            r8.print(r3)
            java.lang.String r3 = " mMenuVisible="
            r8.print(r3)
            boolean r3 = r2.E
            r8.print(r3)
            java.lang.String r3 = " mHasMenu="
            r8.print(r3)
            boolean r3 = r2.D
            r8.println(r3)
            r8.print(r0)
            java.lang.String r3 = "mRetainInstance="
            r8.print(r3)
            boolean r3 = r2.B
            r8.print(r3)
            java.lang.String r3 = " mUserVisibleHint="
            r8.print(r3)
            boolean r3 = r2.K
            r8.println(r3)
            b.h.a.u r3 = r2.s
            if (r3 == 0) goto L_0x0117
            r8.print(r0)
            java.lang.String r3 = "mFragmentManager="
            r8.print(r3)
            b.h.a.u r3 = r2.s
            r8.println(r3)
        L_0x0117:
            b.h.a.l r3 = r2.t
            if (r3 == 0) goto L_0x0128
            r8.print(r0)
            java.lang.String r3 = "mHost="
            r8.print(r3)
            b.h.a.l r3 = r2.t
            r8.println(r3)
        L_0x0128:
            b.h.a.g r3 = r2.v
            if (r3 == 0) goto L_0x0139
            r8.print(r0)
            java.lang.String r3 = "mParentFragment="
            r8.print(r3)
            b.h.a.g r3 = r2.v
            r8.println(r3)
        L_0x0139:
            android.os.Bundle r3 = r2.g
            if (r3 == 0) goto L_0x014a
            r8.print(r0)
            java.lang.String r3 = "mArguments="
            r8.print(r3)
            android.os.Bundle r3 = r2.g
            r8.println(r3)
        L_0x014a:
            android.os.Bundle r3 = r2.f746c
            if (r3 == 0) goto L_0x015b
            r8.print(r0)
            java.lang.String r3 = "mSavedFragmentState="
            r8.print(r3)
            android.os.Bundle r3 = r2.f746c
            r8.println(r3)
        L_0x015b:
            android.util.SparseArray<android.os.Parcelable> r3 = r2.d
            if (r3 == 0) goto L_0x016c
            r8.print(r0)
            java.lang.String r3 = "mSavedViewState="
            r8.print(r3)
            android.util.SparseArray<android.os.Parcelable> r3 = r2.d
            r8.println(r3)
        L_0x016c:
            b.h.a.g r3 = r2.h
            if (r3 == 0) goto L_0x0171
            goto L_0x0183
        L_0x0171:
            b.h.a.u r3 = r2.s
            if (r3 == 0) goto L_0x0182
            java.lang.String r4 = r2.i
            if (r4 == 0) goto L_0x0182
            java.util.HashMap<java.lang.String, b.h.a.g> r3 = r3.j
            java.lang.Object r3 = r3.get(r4)
            b.h.a.g r3 = (b.h.a.C0076g) r3
            goto L_0x0183
        L_0x0182:
            r3 = 0
        L_0x0183:
            if (r3 == 0) goto L_0x019a
            r8.print(r0)
            java.lang.String r4 = "mTarget="
            r8.print(r4)
            r8.print(r3)
            java.lang.String r3 = " mTargetRequestCode="
            r8.print(r3)
            int r3 = r2.j
            r8.println(r3)
        L_0x019a:
            int r3 = r2.n()
            if (r3 == 0) goto L_0x01af
            r8.print(r0)
            java.lang.String r3 = "mNextAnim="
            r8.print(r3)
            int r3 = r2.n()
            r8.println(r3)
        L_0x01af:
            android.view.ViewGroup r3 = r2.G
            if (r3 == 0) goto L_0x01c0
            r8.print(r0)
            java.lang.String r3 = "mContainer="
            r8.print(r3)
            android.view.ViewGroup r3 = r2.G
            r8.println(r3)
        L_0x01c0:
            android.view.View r3 = r2.H
            if (r3 == 0) goto L_0x01d1
            r8.print(r0)
            java.lang.String r3 = "mView="
            r8.print(r3)
            android.view.View r3 = r2.H
            r8.println(r3)
        L_0x01d1:
            android.view.View r3 = r2.I
            if (r3 == 0) goto L_0x01e2
            r8.print(r0)
            java.lang.String r3 = "mInnerView="
            r8.print(r3)
            android.view.View r3 = r2.H
            r8.println(r3)
        L_0x01e2:
            android.view.View r3 = r2.g()
            if (r3 == 0) goto L_0x0206
            r8.print(r0)
            java.lang.String r3 = "mAnimatingAway="
            r8.print(r3)
            android.view.View r3 = r2.g()
            r8.println(r3)
            r8.print(r0)
            java.lang.String r3 = "mStateAfterAnimating="
            r8.print(r3)
            int r3 = r2.r()
            r8.println(r3)
        L_0x0206:
            android.content.Context r3 = r2.j()
            if (r3 == 0) goto L_0x0213
            b.k.a.a r3 = b.k.a.a.a(r2)
            r3.a(r0, r7, r8, r9)
        L_0x0213:
            r8.print(r0)
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "Child "
            r3.append(r4)
            b.h.a.u r4 = r2.u
            r3.append(r4)
            java.lang.String r4 = ":"
            r3.append(r4)
            java.lang.String r3 = r3.toString()
            r8.println(r3)
            b.h.a.u r2 = r2.u
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            r3.append(r0)
            java.lang.String r4 = "  "
            r3.append(r4)
            java.lang.String r3 = r3.toString()
            r2.a((java.lang.String) r3, (java.io.FileDescriptor) r7, (java.io.PrintWriter) r8, (java.lang.String[]) r9)
            goto L_0x003b
        L_0x0249:
            java.util.ArrayList<b.h.a.g> r7 = r5.i
            int r7 = r7.size()
            r9 = 0
            if (r7 <= 0) goto L_0x027f
            r8.print(r6)
            java.lang.String r1 = "Added Fragments:"
            r8.println(r1)
            r1 = 0
        L_0x025b:
            if (r1 >= r7) goto L_0x027f
            java.util.ArrayList<b.h.a.g> r2 = r5.i
            java.lang.Object r2 = r2.get(r1)
            b.h.a.g r2 = (b.h.a.C0076g) r2
            r8.print(r6)
            java.lang.String r3 = "  #"
            r8.print(r3)
            r8.print(r1)
            java.lang.String r3 = ": "
            r8.print(r3)
            java.lang.String r2 = r2.toString()
            r8.println(r2)
            int r1 = r1 + 1
            goto L_0x025b
        L_0x027f:
            java.util.ArrayList<b.h.a.g> r7 = r5.l
            if (r7 == 0) goto L_0x02b6
            int r7 = r7.size()
            if (r7 <= 0) goto L_0x02b6
            r8.print(r6)
            java.lang.String r1 = "Fragments Created Menus:"
            r8.println(r1)
            r1 = 0
        L_0x0292:
            if (r1 >= r7) goto L_0x02b6
            java.util.ArrayList<b.h.a.g> r2 = r5.l
            java.lang.Object r2 = r2.get(r1)
            b.h.a.g r2 = (b.h.a.C0076g) r2
            r8.print(r6)
            java.lang.String r3 = "  #"
            r8.print(r3)
            r8.print(r1)
            java.lang.String r3 = ": "
            r8.print(r3)
            java.lang.String r2 = r2.toString()
            r8.println(r2)
            int r1 = r1 + 1
            goto L_0x0292
        L_0x02b6:
            java.util.ArrayList<b.h.a.a> r7 = r5.k
            if (r7 == 0) goto L_0x02f1
            int r7 = r7.size()
            if (r7 <= 0) goto L_0x02f1
            r8.print(r6)
            java.lang.String r1 = "Back Stack:"
            r8.println(r1)
            r1 = 0
        L_0x02c9:
            if (r1 >= r7) goto L_0x02f1
            java.util.ArrayList<b.h.a.a> r2 = r5.k
            java.lang.Object r2 = r2.get(r1)
            b.h.a.a r2 = (b.h.a.C0070a) r2
            r8.print(r6)
            java.lang.String r3 = "  #"
            r8.print(r3)
            r8.print(r1)
            java.lang.String r3 = ": "
            r8.print(r3)
            java.lang.String r3 = r2.toString()
            r8.println(r3)
            r3 = 1
            r2.a((java.lang.String) r0, (java.io.PrintWriter) r8, (boolean) r3)
            int r1 = r1 + 1
            goto L_0x02c9
        L_0x02f1:
            monitor-enter(r5)
            java.util.ArrayList<b.h.a.a> r7 = r5.o     // Catch:{ all -> 0x03eb }
            if (r7 == 0) goto L_0x0327
            java.util.ArrayList<b.h.a.a> r7 = r5.o     // Catch:{ all -> 0x03eb }
            int r7 = r7.size()     // Catch:{ all -> 0x03eb }
            if (r7 <= 0) goto L_0x0327
            r8.print(r6)     // Catch:{ all -> 0x03eb }
            java.lang.String r0 = "Back Stack Indices:"
            r8.println(r0)     // Catch:{ all -> 0x03eb }
            r0 = 0
        L_0x0307:
            if (r0 >= r7) goto L_0x0327
            java.util.ArrayList<b.h.a.a> r1 = r5.o     // Catch:{ all -> 0x03eb }
            java.lang.Object r1 = r1.get(r0)     // Catch:{ all -> 0x03eb }
            b.h.a.a r1 = (b.h.a.C0070a) r1     // Catch:{ all -> 0x03eb }
            r8.print(r6)     // Catch:{ all -> 0x03eb }
            java.lang.String r2 = "  #"
            r8.print(r2)     // Catch:{ all -> 0x03eb }
            r8.print(r0)     // Catch:{ all -> 0x03eb }
            java.lang.String r2 = ": "
            r8.print(r2)     // Catch:{ all -> 0x03eb }
            r8.println(r1)     // Catch:{ all -> 0x03eb }
            int r0 = r0 + 1
            goto L_0x0307
        L_0x0327:
            java.util.ArrayList<java.lang.Integer> r7 = r5.p     // Catch:{ all -> 0x03eb }
            if (r7 == 0) goto L_0x0348
            java.util.ArrayList<java.lang.Integer> r7 = r5.p     // Catch:{ all -> 0x03eb }
            int r7 = r7.size()     // Catch:{ all -> 0x03eb }
            if (r7 <= 0) goto L_0x0348
            r8.print(r6)     // Catch:{ all -> 0x03eb }
            java.lang.String r7 = "mAvailBackStackIndices: "
            r8.print(r7)     // Catch:{ all -> 0x03eb }
            java.util.ArrayList<java.lang.Integer> r7 = r5.p     // Catch:{ all -> 0x03eb }
            java.lang.Object[] r7 = r7.toArray()     // Catch:{ all -> 0x03eb }
            java.lang.String r7 = java.util.Arrays.toString(r7)     // Catch:{ all -> 0x03eb }
            r8.println(r7)     // Catch:{ all -> 0x03eb }
        L_0x0348:
            monitor-exit(r5)     // Catch:{ all -> 0x03eb }
            java.util.ArrayList<b.h.a.u$e> r7 = r5.f
            if (r7 == 0) goto L_0x037b
            int r7 = r7.size()
            if (r7 <= 0) goto L_0x037b
            r8.print(r6)
            java.lang.String r0 = "Pending Actions:"
            r8.println(r0)
        L_0x035b:
            if (r9 >= r7) goto L_0x037b
            java.util.ArrayList<b.h.a.u$e> r0 = r5.f
            java.lang.Object r0 = r0.get(r9)
            b.h.a.u$e r0 = (b.h.a.u.e) r0
            r8.print(r6)
            java.lang.String r1 = "  #"
            r8.print(r1)
            r8.print(r9)
            java.lang.String r1 = ": "
            r8.print(r1)
            r8.println(r0)
            int r9 = r9 + 1
            goto L_0x035b
        L_0x037b:
            r8.print(r6)
            java.lang.String r7 = "FragmentManager misc state:"
            r8.println(r7)
            r8.print(r6)
            java.lang.String r7 = "  mHost="
            r8.print(r7)
            b.h.a.l r7 = r5.t
            r8.println(r7)
            r8.print(r6)
            java.lang.String r7 = "  mContainer="
            r8.print(r7)
            b.h.a.i r7 = r5.u
            r8.println(r7)
            b.h.a.g r7 = r5.v
            if (r7 == 0) goto L_0x03ae
            r8.print(r6)
            java.lang.String r7 = "  mParent="
            r8.print(r7)
            b.h.a.g r7 = r5.v
            r8.println(r7)
        L_0x03ae:
            r8.print(r6)
            java.lang.String r7 = "  mCurState="
            r8.print(r7)
            int r7 = r5.s
            r8.print(r7)
            java.lang.String r7 = " mStateSaved="
            r8.print(r7)
            boolean r7 = r5.y
            r8.print(r7)
            java.lang.String r7 = " mStopped="
            r8.print(r7)
            boolean r7 = r5.z
            r8.print(r7)
            java.lang.String r7 = " mDestroyed="
            r8.print(r7)
            boolean r7 = r5.A
            r8.println(r7)
            boolean r7 = r5.x
            if (r7 == 0) goto L_0x03ea
            r8.print(r6)
            java.lang.String r6 = "  mNeedMenuInvalidate="
            r8.print(r6)
            boolean r6 = r5.x
            r8.println(r6)
        L_0x03ea:
            return
        L_0x03eb:
            r6 = move-exception
            monitor-exit(r5)     // Catch:{ all -> 0x03eb }
            goto L_0x03ef
        L_0x03ee:
            throw r6
        L_0x03ef:
            goto L_0x03ee
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.a(java.lang.String, java.io.FileDescriptor, java.io.PrintWriter, java.lang.String[]):void");
    }

    public final void a(ArrayList<C0070a> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3) {
        int i4;
        int i5;
        int i6;
        int i7;
        boolean z2;
        int i8;
        int i9;
        int i10;
        ArrayList<C0070a> arrayList3 = arrayList;
        ArrayList<Boolean> arrayList4 = arrayList2;
        int i11 = i2;
        int i12 = i3;
        boolean z3 = arrayList3.get(i11).p;
        ArrayList<C0076g> arrayList5 = this.E;
        if (arrayList5 == null) {
            this.E = new ArrayList<>();
        } else {
            arrayList5.clear();
        }
        this.E.addAll(this.i);
        C0076g gVar = this.w;
        int i13 = i11;
        boolean z4 = false;
        while (true) {
            int i14 = 1;
            if (i13 < i12) {
                C0070a aVar = arrayList3.get(i13);
                int i15 = 3;
                if (!arrayList4.get(i13).booleanValue()) {
                    ArrayList<C0076g> arrayList6 = this.E;
                    C0076g gVar2 = gVar;
                    int i16 = 0;
                    while (i8 < aVar.f701a.size()) {
                        B.a aVar2 = aVar.f701a.get(i8);
                        int i17 = aVar2.f704a;
                        if (i17 != i14) {
                            if (i17 != 2) {
                                if (i17 == i15 || i17 == 6) {
                                    arrayList6.remove(aVar2.f705b);
                                    C0076g gVar3 = aVar2.f705b;
                                    if (gVar3 == gVar2) {
                                        aVar.f701a.add(i8, new B.a(9, gVar3));
                                        i8++;
                                        gVar2 = null;
                                    }
                                } else if (i17 != 7) {
                                    if (i17 == 8) {
                                        aVar.f701a.add(i8, new B.a(9, gVar2));
                                        i8++;
                                        gVar2 = aVar2.f705b;
                                    }
                                }
                                i9 = 1;
                            } else {
                                C0076g gVar4 = aVar2.f705b;
                                int i18 = gVar4.x;
                                int i19 = i8;
                                C0076g gVar5 = gVar2;
                                int size = arrayList6.size() - 1;
                                boolean z5 = false;
                                while (size >= 0) {
                                    C0076g gVar6 = arrayList6.get(size);
                                    if (gVar6.x != i18) {
                                        i10 = i18;
                                    } else if (gVar6 == gVar4) {
                                        i10 = i18;
                                        z5 = true;
                                    } else {
                                        if (gVar6 == gVar5) {
                                            i10 = i18;
                                            aVar.f701a.add(i19, new B.a(9, gVar6));
                                            i19++;
                                            gVar5 = null;
                                        } else {
                                            i10 = i18;
                                        }
                                        B.a aVar3 = new B.a(3, gVar6);
                                        aVar3.f706c = aVar2.f706c;
                                        aVar3.e = aVar2.e;
                                        aVar3.d = aVar2.d;
                                        aVar3.f = aVar2.f;
                                        aVar.f701a.add(i19, aVar3);
                                        arrayList6.remove(gVar6);
                                        i19++;
                                    }
                                    size--;
                                    ArrayList<C0070a> arrayList7 = arrayList;
                                    ArrayList<Boolean> arrayList8 = arrayList2;
                                    i18 = i10;
                                }
                                if (z5) {
                                    aVar.f701a.remove(i19);
                                    i8 = i19 - 1;
                                    i9 = 1;
                                } else {
                                    i9 = 1;
                                    aVar2.f704a = 1;
                                    arrayList6.add(gVar4);
                                    i8 = i19;
                                }
                                gVar2 = gVar5;
                            }
                            i16 = i8 + i9;
                            ArrayList<C0070a> arrayList9 = arrayList;
                            ArrayList<Boolean> arrayList10 = arrayList2;
                            int i20 = i2;
                            i15 = 3;
                            i14 = 1;
                        }
                        i9 = 1;
                        arrayList6.add(aVar2.f705b);
                        i16 = i8 + i9;
                        ArrayList<C0070a> arrayList92 = arrayList;
                        ArrayList<Boolean> arrayList102 = arrayList2;
                        int i202 = i2;
                        i15 = 3;
                        i14 = 1;
                    }
                    gVar = gVar2;
                } else {
                    ArrayList<C0076g> arrayList11 = this.E;
                    for (int size2 = aVar.f701a.size() - 1; size2 >= 0; size2--) {
                        B.a aVar4 = aVar.f701a.get(size2);
                        int i21 = aVar4.f704a;
                        if (i21 != 1) {
                            if (i21 != 3) {
                                switch (i21) {
                                    case 6:
                                        break;
                                    case 7:
                                        break;
                                    case 8:
                                        gVar = null;
                                        break;
                                    case 9:
                                        gVar = aVar4.f705b;
                                        break;
                                    case 10:
                                        aVar4.h = aVar4.g;
                                        break;
                                }
                            }
                            arrayList11.add(aVar4.f705b);
                        }
                        arrayList11.remove(aVar4.f705b);
                    }
                }
                z4 = z4 || aVar.h;
                i13++;
                arrayList3 = arrayList;
                arrayList4 = arrayList2;
                int i22 = i2;
            } else {
                this.E.clear();
                if (!z3) {
                    G.a(this, arrayList, arrayList2, i2, i3, false);
                }
                int i23 = i2;
                while (i23 < i12) {
                    C0070a aVar5 = arrayList.get(i23);
                    if (arrayList2.get(i23).booleanValue()) {
                        aVar5.a(-1);
                        aVar5.a(i23 == i12 + -1);
                    } else {
                        aVar5.a(1);
                        aVar5.a();
                    }
                    i23++;
                }
                ArrayList<C0070a> arrayList12 = arrayList;
                ArrayList<Boolean> arrayList13 = arrayList2;
                if (z3) {
                    b.d.d dVar = new b.d.d();
                    a((b.d.d<C0076g>) dVar);
                    i5 = i2;
                    int i24 = i12;
                    for (int i25 = i12 - 1; i25 >= i5; i25--) {
                        C0070a aVar6 = arrayList12.get(i25);
                        boolean booleanValue = arrayList13.get(i25).booleanValue();
                        int i26 = 0;
                        while (true) {
                            if (i26 >= aVar6.f701a.size()) {
                                z2 = false;
                            } else if (C0070a.a(aVar6.f701a.get(i26))) {
                                z2 = true;
                            } else {
                                i26++;
                            }
                        }
                        if (z2 && !aVar6.a(arrayList12, i25 + 1, i12)) {
                            if (this.H == null) {
                                this.H = new ArrayList<>();
                            }
                            f fVar = new f(aVar6, booleanValue);
                            this.H.add(fVar);
                            for (int i27 = 0; i27 < aVar6.f701a.size(); i27++) {
                                B.a aVar7 = aVar6.f701a.get(i27);
                                if (C0070a.a(aVar7)) {
                                    aVar7.f705b.a((C0076g.c) fVar);
                                }
                            }
                            if (booleanValue) {
                                aVar6.a();
                            } else {
                                aVar6.a(false);
                            }
                            i24--;
                            if (i25 != i24) {
                                arrayList12.remove(i25);
                                arrayList12.add(i24, aVar6);
                            }
                            a((b.d.d<C0076g>) dVar);
                        }
                    }
                    i4 = 0;
                    int i28 = dVar.i;
                    for (int i29 = 0; i29 < i28; i29++) {
                        C0076g gVar7 = (C0076g) dVar.h[i29];
                        if (!gVar7.l) {
                            View x2 = gVar7.x();
                            gVar7.O = x2.getAlpha();
                            x2.setAlpha(0.0f);
                        }
                    }
                    i6 = i24;
                } else {
                    i5 = i2;
                    i4 = 0;
                    i6 = i12;
                }
                if (i6 != i5 && z3) {
                    G.a(this, arrayList, arrayList2, i2, i6, true);
                    a(this.s, true);
                }
                while (i5 < i12) {
                    C0070a aVar8 = arrayList12.get(i5);
                    if (arrayList13.get(i5).booleanValue() && (i7 = aVar8.t) >= 0) {
                        c(i7);
                        aVar8.t = -1;
                    }
                    if (aVar8.q != null) {
                        for (int i30 = 0; i30 < aVar8.q.size(); i30++) {
                            aVar8.q.get(i30).run();
                        }
                        aVar8.q = null;
                    }
                    i5++;
                }
                if (z4 && this.q != null) {
                    while (i4 < this.q.size()) {
                        this.q.get(i4).onBackStackChanged();
                        i4++;
                    }
                    return;
                }
                return;
            }
        }
    }

    public final void a(ArrayList<C0070a> arrayList, ArrayList<Boolean> arrayList2) {
        int indexOf;
        int indexOf2;
        ArrayList<f> arrayList3 = this.H;
        int size = arrayList3 == null ? 0 : arrayList3.size();
        int i2 = 0;
        while (i2 < size) {
            f fVar = this.H.get(i2);
            if (arrayList == null || fVar.f779a || (indexOf2 = arrayList.indexOf(fVar.f780b)) == -1 || !arrayList2.get(indexOf2).booleanValue()) {
                if ((fVar.f781c == 0) || (arrayList != null && fVar.f780b.a(arrayList, 0, arrayList.size()))) {
                    this.H.remove(i2);
                    i2--;
                    size--;
                    if (arrayList == null || fVar.f779a || (indexOf = arrayList.indexOf(fVar.f780b)) == -1 || !arrayList2.get(indexOf).booleanValue()) {
                        fVar.a();
                    }
                }
                i2++;
            } else {
                this.H.remove(i2);
                i2--;
                size--;
            }
            C0070a aVar = fVar.f780b;
            aVar.r.a(aVar, fVar.f779a, false, false);
            i2++;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x0042 A[SYNTHETIC, Splitter:B:20:0x0042] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public b.h.a.u.a a(b.h.a.C0076g r7, int r8, boolean r9, int r10) {
        /*
            r6 = this;
            int r0 = r7.n()
            r1 = 0
            r7.a((int) r1)
            android.view.ViewGroup r7 = r7.G
            r2 = 0
            if (r7 == 0) goto L_0x0014
            android.animation.LayoutTransition r7 = r7.getLayoutTransition()
            if (r7 == 0) goto L_0x0014
            return r2
        L_0x0014:
            r7 = 1
            if (r0 == 0) goto L_0x0066
            b.h.a.l r3 = r6.t
            android.content.Context r3 = r3.f753b
            android.content.res.Resources r3 = r3.getResources()
            java.lang.String r3 = r3.getResourceTypeName(r0)
            java.lang.String r4 = "anim"
            boolean r3 = r4.equals(r3)
            if (r3 == 0) goto L_0x003f
            b.h.a.l r4 = r6.t     // Catch:{ NotFoundException -> 0x003d, RuntimeException -> 0x003f }
            android.content.Context r4 = r4.f753b     // Catch:{ NotFoundException -> 0x003d, RuntimeException -> 0x003f }
            android.view.animation.Animation r4 = android.view.animation.AnimationUtils.loadAnimation(r4, r0)     // Catch:{ NotFoundException -> 0x003d, RuntimeException -> 0x003f }
            if (r4 == 0) goto L_0x003b
            b.h.a.u$a r5 = new b.h.a.u$a     // Catch:{ NotFoundException -> 0x003d, RuntimeException -> 0x003f }
            r5.<init>((android.view.animation.Animation) r4)     // Catch:{ NotFoundException -> 0x003d, RuntimeException -> 0x003f }
            return r5
        L_0x003b:
            r4 = 1
            goto L_0x0040
        L_0x003d:
            r7 = move-exception
            throw r7
        L_0x003f:
            r4 = 0
        L_0x0040:
            if (r4 != 0) goto L_0x0066
            b.h.a.l r4 = r6.t     // Catch:{ RuntimeException -> 0x0052 }
            android.content.Context r4 = r4.f753b     // Catch:{ RuntimeException -> 0x0052 }
            android.animation.Animator r4 = android.animation.AnimatorInflater.loadAnimator(r4, r0)     // Catch:{ RuntimeException -> 0x0052 }
            if (r4 == 0) goto L_0x0066
            b.h.a.u$a r5 = new b.h.a.u$a     // Catch:{ RuntimeException -> 0x0052 }
            r5.<init>((android.animation.Animator) r4)     // Catch:{ RuntimeException -> 0x0052 }
            return r5
        L_0x0052:
            r4 = move-exception
            if (r3 != 0) goto L_0x0065
            b.h.a.l r3 = r6.t
            android.content.Context r3 = r3.f753b
            android.view.animation.Animation r0 = android.view.animation.AnimationUtils.loadAnimation(r3, r0)
            if (r0 == 0) goto L_0x0066
            b.h.a.u$a r7 = new b.h.a.u$a
            r7.<init>((android.view.animation.Animation) r0)
            return r7
        L_0x0065:
            throw r4
        L_0x0066:
            if (r8 != 0) goto L_0x0069
            return r2
        L_0x0069:
            r0 = 4097(0x1001, float:5.741E-42)
            if (r8 == r0) goto L_0x0083
            r0 = 4099(0x1003, float:5.744E-42)
            if (r8 == r0) goto L_0x007d
            r0 = 8194(0x2002, float:1.1482E-41)
            if (r8 == r0) goto L_0x0077
            r8 = -1
            goto L_0x0088
        L_0x0077:
            if (r9 == 0) goto L_0x007b
            r8 = 3
            goto L_0x0088
        L_0x007b:
            r8 = 4
            goto L_0x0088
        L_0x007d:
            if (r9 == 0) goto L_0x0081
            r8 = 5
            goto L_0x0088
        L_0x0081:
            r8 = 6
            goto L_0x0088
        L_0x0083:
            if (r9 == 0) goto L_0x0087
            r8 = 1
            goto L_0x0088
        L_0x0087:
            r8 = 2
        L_0x0088:
            if (r8 >= 0) goto L_0x008b
            return r2
        L_0x008b:
            r9 = 1064933786(0x3f79999a, float:0.975)
            r0 = 0
            r3 = 1065353216(0x3f800000, float:1.0)
            r4 = 220(0xdc, double:1.087E-321)
            switch(r8) {
                case 1: goto L_0x00d3;
                case 2: goto L_0x00ce;
                case 3: goto L_0x00c9;
                case 4: goto L_0x00c1;
                case 5: goto L_0x00ae;
                case 6: goto L_0x009b;
                default: goto L_0x0096;
            }
        L_0x0096:
            if (r10 != 0) goto L_0x00fb
            b.h.a.l r8 = r6.t
            goto L_0x00da
        L_0x009b:
            android.view.animation.AlphaAnimation r7 = new android.view.animation.AlphaAnimation
            r7.<init>(r3, r0)
            android.view.animation.Interpolator r8 = e
            r7.setInterpolator(r8)
            r7.setDuration(r4)
            b.h.a.u$a r8 = new b.h.a.u$a
            r8.<init>((android.view.animation.Animation) r7)
            return r8
        L_0x00ae:
            android.view.animation.AlphaAnimation r7 = new android.view.animation.AlphaAnimation
            r7.<init>(r0, r3)
            android.view.animation.Interpolator r8 = e
            r7.setInterpolator(r8)
            r7.setDuration(r4)
            b.h.a.u$a r8 = new b.h.a.u$a
            r8.<init>((android.view.animation.Animation) r7)
            return r8
        L_0x00c1:
            r7 = 1065982362(0x3f89999a, float:1.075)
            b.h.a.u$a r7 = a((float) r3, (float) r7, (float) r3, (float) r0)
            return r7
        L_0x00c9:
            b.h.a.u$a r7 = a((float) r9, (float) r3, (float) r0, (float) r3)
            return r7
        L_0x00ce:
            b.h.a.u$a r7 = a((float) r3, (float) r9, (float) r3, (float) r0)
            return r7
        L_0x00d3:
            r7 = 1066401792(0x3f900000, float:1.125)
            b.h.a.u$a r7 = a((float) r7, (float) r3, (float) r0, (float) r3)
            return r7
        L_0x00da:
            b.h.a.h$a r8 = (b.h.a.C0077h.a) r8
            b.h.a.h r8 = b.h.a.C0077h.this
            android.view.Window r8 = r8.getWindow()
            if (r8 == 0) goto L_0x00e5
            goto L_0x00e6
        L_0x00e5:
            r7 = 0
        L_0x00e6:
            if (r7 == 0) goto L_0x00fb
            b.h.a.l r7 = r6.t
            b.h.a.h$a r7 = (b.h.a.C0077h.a) r7
            b.h.a.h r7 = b.h.a.C0077h.this
            android.view.Window r7 = r7.getWindow()
            if (r7 != 0) goto L_0x00f5
            goto L_0x00fb
        L_0x00f5:
            android.view.WindowManager$LayoutParams r7 = r7.getAttributes()
            int r7 = r7.windowAnimations
        L_0x00fb:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.a(b.h.a.g, int, boolean, int):b.h.a.u$a");
    }

    public void a(int i2, boolean z2) {
        C0081l lVar;
        if (this.t == null && i2 != 0) {
            throw new IllegalStateException("No activity");
        } else if (z2 || i2 != this.s) {
            this.s = i2;
            int size = this.i.size();
            for (int i3 = 0; i3 < size; i3++) {
                h(this.i.get(i3));
            }
            for (C0076g next : this.j.values()) {
                if (next != null && ((next.m || next.A) && !next.M)) {
                    h(next);
                }
            }
            p();
            if (this.x && (lVar = this.t) != null && this.s == 4) {
                C0077h.this.i();
                this.x = false;
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:44:0x008a, code lost:
        if (r0 != 3) goto L_0x0788;
     */
    /* JADX WARNING: Removed duplicated region for block: B:208:0x03e1  */
    /* JADX WARNING: Removed duplicated region for block: B:221:0x0430  */
    /* JADX WARNING: Removed duplicated region for block: B:392:0x078d  */
    /* JADX WARNING: Removed duplicated region for block: B:399:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void a(b.h.a.C0076g r17, int r18, int r19, int r20, boolean r21) {
        /*
            r16 = this;
            r6 = r16
            r7 = r17
            boolean r0 = r7.l
            r8 = 1
            if (r0 == 0) goto L_0x0011
            boolean r0 = r7.A
            if (r0 == 0) goto L_0x000e
            goto L_0x0011
        L_0x000e:
            r0 = r18
            goto L_0x0016
        L_0x0011:
            r0 = r18
            if (r0 <= r8) goto L_0x0016
            r0 = 1
        L_0x0016:
            boolean r1 = r7.m
            if (r1 == 0) goto L_0x002a
            int r1 = r7.f745b
            if (r0 <= r1) goto L_0x002a
            if (r1 != 0) goto L_0x0028
            boolean r0 = r17.u()
            if (r0 == 0) goto L_0x0028
            r0 = 1
            goto L_0x002a
        L_0x0028:
            int r0 = r7.f745b
        L_0x002a:
            boolean r1 = r7.J
            r9 = 3
            r10 = 2
            if (r1 == 0) goto L_0x0037
            int r1 = r7.f745b
            if (r1 >= r9) goto L_0x0037
            if (r0 <= r10) goto L_0x0037
            r0 = 2
        L_0x0037:
            b.j.e$b r1 = r7.R
            b.j.e$b r2 = b.j.e.b.CREATED
            if (r1 != r2) goto L_0x0042
            int r0 = java.lang.Math.min(r0, r8)
            goto L_0x004a
        L_0x0042:
            int r1 = r1.ordinal()
            int r0 = java.lang.Math.min(r0, r1)
        L_0x004a:
            r11 = r0
            int r0 = r7.f745b
            java.lang.String r12 = "FragmentManager"
            java.lang.String r13 = "Fragment "
            r14 = 0
            if (r0 > r11) goto L_0x0486
            boolean r0 = r7.n
            if (r0 == 0) goto L_0x005d
            boolean r0 = r7.o
            if (r0 != 0) goto L_0x005d
            return
        L_0x005d:
            android.view.View r0 = r17.g()
            if (r0 != 0) goto L_0x006d
            android.animation.Animator r0 = r17.h()
            if (r0 == 0) goto L_0x006a
            goto L_0x006d
        L_0x006a:
            r0 = 0
            r15 = 0
            goto L_0x0082
        L_0x006d:
            r7.a((android.view.View) r14)
            r7.a((android.animation.Animator) r14)
            int r2 = r17.r()
            r3 = 0
            r4 = 0
            r5 = 1
            r15 = 0
            r0 = r16
            r1 = r17
            r0.a(r1, r2, r3, r4, r5)
        L_0x0082:
            int r0 = r7.f745b
            if (r0 == 0) goto L_0x008e
            if (r0 == r8) goto L_0x0275
            if (r0 == r10) goto L_0x03de
            if (r0 == r9) goto L_0x042d
            goto L_0x0788
        L_0x008e:
            if (r11 <= 0) goto L_0x0275
            boolean r0 = f770c
            if (r0 == 0) goto L_0x0099
            java.lang.String r0 = "moveto CREATED: "
            c.a.a.a.a.b(r0, r7, r12)
        L_0x0099:
            android.os.Bundle r0 = r7.f746c
            if (r0 == 0) goto L_0x0121
            b.h.a.l r1 = r6.t
            android.content.Context r1 = r1.f753b
            java.lang.ClassLoader r1 = r1.getClassLoader()
            r0.setClassLoader(r1)
            android.os.Bundle r0 = r7.f746c
            java.lang.String r1 = "android:view_state"
            android.util.SparseArray r0 = r0.getSparseParcelableArray(r1)
            r7.d = r0
            android.os.Bundle r0 = r7.f746c
            java.lang.String r1 = "android:target_state"
            java.lang.String r0 = r0.getString(r1)
            if (r0 != 0) goto L_0x00be
            r2 = r14
            goto L_0x00c8
        L_0x00be:
            java.util.HashMap<java.lang.String, b.h.a.g> r2 = r6.j
            java.lang.Object r2 = r2.get(r0)
            b.h.a.g r2 = (b.h.a.C0076g) r2
            if (r2 == 0) goto L_0x00ff
        L_0x00c8:
            if (r2 == 0) goto L_0x00cd
            java.lang.String r0 = r2.f
            goto L_0x00ce
        L_0x00cd:
            r0 = r14
        L_0x00ce:
            r7.i = r0
            java.lang.String r0 = r7.i
            if (r0 == 0) goto L_0x00de
            android.os.Bundle r0 = r7.f746c
            java.lang.String r1 = "android:target_req_state"
            int r0 = r0.getInt(r1, r15)
            r7.j = r0
        L_0x00de:
            java.lang.Boolean r0 = r7.e
            if (r0 == 0) goto L_0x00eb
            boolean r0 = r0.booleanValue()
            r7.K = r0
            r7.e = r14
            goto L_0x00f5
        L_0x00eb:
            android.os.Bundle r0 = r7.f746c
            java.lang.String r1 = "android:user_visible_hint"
            boolean r0 = r0.getBoolean(r1, r8)
            r7.K = r0
        L_0x00f5:
            boolean r0 = r7.K
            if (r0 != 0) goto L_0x0121
            r7.J = r8
            if (r11 <= r10) goto L_0x0121
            r11 = 2
            goto L_0x0121
        L_0x00ff:
            java.lang.IllegalStateException r2 = new java.lang.IllegalStateException
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "Fragment no longer exists for key "
            r3.append(r4)
            r3.append(r1)
            java.lang.String r1 = ": unique id "
            r3.append(r1)
            r3.append(r0)
            java.lang.String r0 = r3.toString()
            r2.<init>(r0)
            r6.a((java.lang.RuntimeException) r2)
            throw r14
        L_0x0121:
            b.h.a.l r0 = r6.t
            r7.t = r0
            b.h.a.g r1 = r6.v
            r7.v = r1
            if (r1 == 0) goto L_0x012e
            b.h.a.u r0 = r1.u
            goto L_0x0130
        L_0x012e:
            b.h.a.u r0 = r0.e
        L_0x0130:
            r7.s = r0
            b.h.a.g r0 = r7.h
            java.lang.String r9 = " that does not belong to this FragmentManager!"
            java.lang.String r10 = " declared target fragment "
            if (r0 == 0) goto L_0x017c
            java.util.HashMap<java.lang.String, b.h.a.g> r1 = r6.j
            java.lang.String r0 = r0.f
            java.lang.Object r0 = r1.get(r0)
            b.h.a.g r1 = r7.h
            if (r0 != r1) goto L_0x015c
            int r0 = r1.f745b
            if (r0 >= r8) goto L_0x0153
            r2 = 1
            r3 = 0
            r4 = 0
            r5 = 1
            r0 = r16
            r0.a(r1, r2, r3, r4, r5)
        L_0x0153:
            b.h.a.g r0 = r7.h
            java.lang.String r0 = r0.f
            r7.i = r0
            r7.h = r14
            goto L_0x017c
        L_0x015c:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r13)
            r1.append(r7)
            r1.append(r10)
            b.h.a.g r2 = r7.h
            r1.append(r2)
            r1.append(r9)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x017c:
            java.lang.String r0 = r7.i
            if (r0 == 0) goto L_0x01b9
            java.util.HashMap<java.lang.String, b.h.a.g> r1 = r6.j
            java.lang.Object r0 = r1.get(r0)
            r1 = r0
            b.h.a.g r1 = (b.h.a.C0076g) r1
            if (r1 == 0) goto L_0x0199
            int r0 = r1.f745b
            if (r0 >= r8) goto L_0x01b9
            r2 = 1
            r3 = 0
            r4 = 0
            r5 = 1
            r0 = r16
            r0.a(r1, r2, r3, r4, r5)
            goto L_0x01b9
        L_0x0199:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r13)
            r1.append(r7)
            r1.append(r10)
            java.lang.String r2 = r7.i
            r1.append(r2)
            r1.append(r9)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x01b9:
            b.h.a.l r0 = r6.t
            android.content.Context r0 = r0.f753b
            r6.b((b.h.a.C0076g) r7, (android.content.Context) r0, (boolean) r15)
            b.h.a.u r0 = r7.u
            b.h.a.l r1 = r7.t
            b.h.a.f r2 = new b.h.a.f
            r2.<init>(r7)
            r0.a((b.h.a.C0081l) r1, (b.h.a.C0078i) r2, (b.h.a.C0076g) r7)
            r7.F = r15
            b.h.a.l r0 = r7.t
            android.content.Context r1 = r0.f753b
            r7.F = r8
            android.app.Activity r0 = r0.f752a
            if (r0 == 0) goto L_0x01dc
            r7.F = r15
            r7.F = r8
        L_0x01dc:
            boolean r0 = r7.F
            if (r0 == 0) goto L_0x0269
            b.h.a.g r0 = r7.v
            if (r0 != 0) goto L_0x01ed
            b.h.a.l r0 = r6.t
            b.h.a.h$a r0 = (b.h.a.C0077h.a) r0
            b.h.a.h r0 = b.h.a.C0077h.this
            r0.a((b.h.a.C0076g) r7)
        L_0x01ed:
            b.h.a.l r0 = r6.t
            android.content.Context r0 = r0.f753b
            r6.a((b.h.a.C0076g) r7, (android.content.Context) r0, (boolean) r15)
            boolean r0 = r7.Q
            java.lang.String r1 = "android:support:fragments"
            if (r0 != 0) goto L_0x0252
            android.os.Bundle r0 = r7.f746c
            r6.c(r7, r0, r15)
            android.os.Bundle r0 = r7.f746c
            b.h.a.u r2 = r7.u
            r2.m()
            r7.f745b = r8
            r7.F = r15
            b.m.b r2 = r7.V
            r2.a(r0)
            r7.F = r8
            if (r0 == 0) goto L_0x0223
            android.os.Parcelable r0 = r0.getParcelable(r1)
            if (r0 == 0) goto L_0x0223
            b.h.a.u r1 = r7.u
            r1.a((android.os.Parcelable) r0)
            b.h.a.u r0 = r7.u
            r0.d()
        L_0x0223:
            b.h.a.u r0 = r7.u
            int r0 = r0.s
            if (r0 < r8) goto L_0x022b
            r0 = 1
            goto L_0x022c
        L_0x022b:
            r0 = 0
        L_0x022c:
            if (r0 != 0) goto L_0x0233
            b.h.a.u r0 = r7.u
            r0.d()
        L_0x0233:
            r7.Q = r8
            boolean r0 = r7.F
            if (r0 == 0) goto L_0x0246
            b.j.i r0 = r7.S
            b.j.e$a r1 = b.j.e.a.ON_CREATE
            r0.b((b.j.e.a) r1)
            android.os.Bundle r0 = r7.f746c
            r6.b((b.h.a.C0076g) r7, (android.os.Bundle) r0, (boolean) r15)
            goto L_0x0275
        L_0x0246:
            b.h.a.S r0 = new b.h.a.S
            java.lang.String r1 = " did not call through to super.onCreate()"
            java.lang.String r1 = c.a.a.a.a.a((java.lang.String) r13, (java.lang.Object) r7, (java.lang.String) r1)
            r0.<init>(r1)
            throw r0
        L_0x0252:
            android.os.Bundle r0 = r7.f746c
            if (r0 == 0) goto L_0x0266
            android.os.Parcelable r0 = r0.getParcelable(r1)
            if (r0 == 0) goto L_0x0266
            b.h.a.u r1 = r7.u
            r1.a((android.os.Parcelable) r0)
            b.h.a.u r0 = r7.u
            r0.d()
        L_0x0266:
            r7.f745b = r8
            goto L_0x0275
        L_0x0269:
            b.h.a.S r0 = new b.h.a.S
            java.lang.String r1 = " did not call through to super.onAttach()"
            java.lang.String r1 = c.a.a.a.a.a((java.lang.String) r13, (java.lang.Object) r7, (java.lang.String) r1)
            r0.<init>(r1)
            throw r0
        L_0x0275:
            r0 = 8
            if (r11 <= 0) goto L_0x02a8
            boolean r1 = r7.n
            if (r1 == 0) goto L_0x02a8
            boolean r1 = r7.q
            if (r1 != 0) goto L_0x02a8
            android.os.Bundle r1 = r7.f746c
            android.view.LayoutInflater r1 = r7.a((android.os.Bundle) r1)
            android.os.Bundle r2 = r7.f746c
            r7.a((android.view.LayoutInflater) r1, (android.view.ViewGroup) r14, (android.os.Bundle) r2)
            android.view.View r1 = r7.H
            if (r1 == 0) goto L_0x02a6
            r7.I = r1
            r1.setSaveFromParentEnabled(r15)
            boolean r1 = r7.z
            if (r1 == 0) goto L_0x029e
            android.view.View r1 = r7.H
            r1.setVisibility(r0)
        L_0x029e:
            android.view.View r1 = r7.H
            android.os.Bundle r2 = r7.f746c
            r6.a((b.h.a.C0076g) r7, (android.view.View) r1, (android.os.Bundle) r2, (boolean) r15)
            goto L_0x02a8
        L_0x02a6:
            r7.I = r14
        L_0x02a8:
            if (r11 <= r8) goto L_0x03de
            boolean r1 = f770c
            if (r1 == 0) goto L_0x02b3
            java.lang.String r1 = "moveto ACTIVITY_CREATED: "
            c.a.a.a.a.b(r1, r7, r12)
        L_0x02b3:
            boolean r1 = r7.n
            if (r1 != 0) goto L_0x037c
            int r1 = r7.x
            if (r1 == 0) goto L_0x033a
            r2 = -1
            if (r1 == r2) goto L_0x0329
            b.h.a.i r2 = r6.u
            android.view.View r1 = r2.a(r1)
            android.view.ViewGroup r1 = (android.view.ViewGroup) r1
            if (r1 != 0) goto L_0x033b
            boolean r2 = r7.p
            if (r2 != 0) goto L_0x033b
            b.h.a.l r0 = r7.t     // Catch:{ NotFoundException -> 0x02fb }
            if (r0 != 0) goto L_0x02d2
            r0 = r14
            goto L_0x02d4
        L_0x02d2:
            android.content.Context r0 = r0.f753b     // Catch:{ NotFoundException -> 0x02fb }
        L_0x02d4:
            if (r0 == 0) goto L_0x02e1
            android.content.res.Resources r0 = r0.getResources()     // Catch:{ NotFoundException -> 0x02fb }
            int r1 = r7.x     // Catch:{ NotFoundException -> 0x02fb }
            java.lang.String r0 = r0.getResourceName(r1)     // Catch:{ NotFoundException -> 0x02fb }
            goto L_0x02fd
        L_0x02e1:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException     // Catch:{ NotFoundException -> 0x02fb }
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ NotFoundException -> 0x02fb }
            r1.<init>()     // Catch:{ NotFoundException -> 0x02fb }
            r1.append(r13)     // Catch:{ NotFoundException -> 0x02fb }
            r1.append(r7)     // Catch:{ NotFoundException -> 0x02fb }
            java.lang.String r2 = " not attached to a context."
            r1.append(r2)     // Catch:{ NotFoundException -> 0x02fb }
            java.lang.String r1 = r1.toString()     // Catch:{ NotFoundException -> 0x02fb }
            r0.<init>(r1)     // Catch:{ NotFoundException -> 0x02fb }
            throw r0     // Catch:{ NotFoundException -> 0x02fb }
        L_0x02fb:
            java.lang.String r0 = "unknown"
        L_0x02fd:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "No view found for id 0x"
            java.lang.StringBuilder r2 = c.a.a.a.a.a(r2)
            int r3 = r7.x
            java.lang.String r3 = java.lang.Integer.toHexString(r3)
            r2.append(r3)
            java.lang.String r3 = " ("
            r2.append(r3)
            r2.append(r0)
            java.lang.String r0 = ") for fragment "
            r2.append(r0)
            r2.append(r7)
            java.lang.String r0 = r2.toString()
            r1.<init>(r0)
            r6.a((java.lang.RuntimeException) r1)
            throw r14
        L_0x0329:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "Cannot create fragment "
            java.lang.String r2 = " for a container view with no id"
            java.lang.String r1 = c.a.a.a.a.a((java.lang.String) r1, (java.lang.Object) r7, (java.lang.String) r2)
            r0.<init>(r1)
            r6.a((java.lang.RuntimeException) r0)
            throw r14
        L_0x033a:
            r1 = r14
        L_0x033b:
            r7.G = r1
            android.os.Bundle r2 = r7.f746c
            android.view.LayoutInflater r2 = r7.a((android.os.Bundle) r2)
            android.os.Bundle r3 = r7.f746c
            r7.a((android.view.LayoutInflater) r2, (android.view.ViewGroup) r1, (android.os.Bundle) r3)
            android.view.View r2 = r7.H
            if (r2 == 0) goto L_0x037a
            r7.I = r2
            r2.setSaveFromParentEnabled(r15)
            if (r1 == 0) goto L_0x0358
            android.view.View r2 = r7.H
            r1.addView(r2)
        L_0x0358:
            boolean r1 = r7.z
            if (r1 == 0) goto L_0x0361
            android.view.View r1 = r7.H
            r1.setVisibility(r0)
        L_0x0361:
            android.view.View r0 = r7.H
            android.os.Bundle r1 = r7.f746c
            r6.a((b.h.a.C0076g) r7, (android.view.View) r0, (android.os.Bundle) r1, (boolean) r15)
            android.view.View r0 = r7.H
            int r0 = r0.getVisibility()
            if (r0 != 0) goto L_0x0376
            android.view.ViewGroup r0 = r7.G
            if (r0 == 0) goto L_0x0376
            r0 = 1
            goto L_0x0377
        L_0x0376:
            r0 = 0
        L_0x0377:
            r7.M = r0
            goto L_0x037c
        L_0x037a:
            r7.I = r14
        L_0x037c:
            android.os.Bundle r0 = r7.f746c
            b.h.a.u r0 = r7.u
            r0.m()
            r0 = 2
            r7.f745b = r0
            r7.F = r15
            r7.F = r8
            boolean r1 = r7.F
            if (r1 == 0) goto L_0x03d2
            b.h.a.u r1 = r7.u
            r1.y = r15
            r1.z = r15
            r1.a((int) r0)
            android.os.Bundle r0 = r7.f746c
            r6.a((b.h.a.C0076g) r7, (android.os.Bundle) r0, (boolean) r15)
            android.view.View r0 = r7.H
            if (r0 == 0) goto L_0x03cf
            android.os.Bundle r0 = r7.f746c
            android.util.SparseArray<android.os.Parcelable> r0 = r7.d
            if (r0 == 0) goto L_0x03ad
            android.view.View r1 = r7.I
            r1.restoreHierarchyState(r0)
            r7.d = r14
        L_0x03ad:
            r7.F = r15
            r7.F = r8
            boolean r0 = r7.F
            if (r0 == 0) goto L_0x03c3
            android.view.View r0 = r7.H
            if (r0 == 0) goto L_0x03cf
            b.h.a.Q r0 = r7.T
            b.j.e$a r1 = b.j.e.a.ON_CREATE
            b.j.i r0 = r0.f737a
            r0.b((b.j.e.a) r1)
            goto L_0x03cf
        L_0x03c3:
            b.h.a.S r0 = new b.h.a.S
            java.lang.String r1 = " did not call through to super.onViewStateRestored()"
            java.lang.String r1 = c.a.a.a.a.a((java.lang.String) r13, (java.lang.Object) r7, (java.lang.String) r1)
            r0.<init>(r1)
            throw r0
        L_0x03cf:
            r7.f746c = r14
            goto L_0x03de
        L_0x03d2:
            b.h.a.S r0 = new b.h.a.S
            java.lang.String r1 = " did not call through to super.onActivityCreated()"
            java.lang.String r1 = c.a.a.a.a.a((java.lang.String) r13, (java.lang.Object) r7, (java.lang.String) r1)
            r0.<init>(r1)
            throw r0
        L_0x03de:
            r0 = 2
            if (r11 <= r0) goto L_0x042d
            boolean r0 = f770c
            if (r0 == 0) goto L_0x03ea
            java.lang.String r0 = "moveto STARTED: "
            c.a.a.a.a.b(r0, r7, r12)
        L_0x03ea:
            b.h.a.u r0 = r7.u
            r0.m()
            b.h.a.u r0 = r7.u
            r0.i()
            r0 = 3
            r7.f745b = r0
            r7.F = r15
            r7.F = r8
            boolean r0 = r7.F
            if (r0 == 0) goto L_0x0421
            b.j.i r0 = r7.S
            b.j.e$a r1 = b.j.e.a.ON_START
            r0.b((b.j.e.a) r1)
            android.view.View r0 = r7.H
            if (r0 == 0) goto L_0x0413
            b.h.a.Q r0 = r7.T
            b.j.e$a r1 = b.j.e.a.ON_START
            b.j.i r0 = r0.f737a
            r0.b((b.j.e.a) r1)
        L_0x0413:
            b.h.a.u r0 = r7.u
            r0.y = r15
            r0.z = r15
            r1 = 3
            r0.a((int) r1)
            r6.f(r7, r15)
            goto L_0x042d
        L_0x0421:
            b.h.a.S r0 = new b.h.a.S
            java.lang.String r1 = " did not call through to super.onStart()"
            java.lang.String r1 = c.a.a.a.a.a((java.lang.String) r13, (java.lang.Object) r7, (java.lang.String) r1)
            r0.<init>(r1)
            throw r0
        L_0x042d:
            r0 = 3
            if (r11 <= r0) goto L_0x0788
            boolean r0 = f770c
            if (r0 == 0) goto L_0x0439
            java.lang.String r0 = "moveto RESUMED: "
            c.a.a.a.a.b(r0, r7, r12)
        L_0x0439:
            b.h.a.u r0 = r7.u
            r0.m()
            b.h.a.u r0 = r7.u
            r0.i()
            r0 = 4
            r7.f745b = r0
            r7.F = r15
            r7.F = r8
            boolean r0 = r7.F
            if (r0 == 0) goto L_0x047a
            b.j.i r0 = r7.S
            b.j.e$a r1 = b.j.e.a.ON_RESUME
            r0.b((b.j.e.a) r1)
            android.view.View r0 = r7.H
            if (r0 == 0) goto L_0x0462
            b.h.a.Q r0 = r7.T
            b.j.e$a r1 = b.j.e.a.ON_RESUME
            b.j.i r0 = r0.f737a
            r0.b((b.j.e.a) r1)
        L_0x0462:
            b.h.a.u r0 = r7.u
            r0.y = r15
            r0.z = r15
            r1 = 4
            r0.a((int) r1)
            b.h.a.u r0 = r7.u
            r0.i()
            r6.e(r7, r15)
            r7.f746c = r14
            r7.d = r14
            goto L_0x0788
        L_0x047a:
            b.h.a.S r0 = new b.h.a.S
            java.lang.String r1 = " did not call through to super.onResume()"
            java.lang.String r1 = c.a.a.a.a.a((java.lang.String) r13, (java.lang.Object) r7, (java.lang.String) r1)
            r0.<init>(r1)
            throw r0
        L_0x0486:
            r1 = 0
            if (r0 <= r11) goto L_0x0788
            if (r0 == r8) goto L_0x0607
            r2 = 2
            if (r0 == r2) goto L_0x0519
            r2 = 3
            if (r0 == r2) goto L_0x04d6
            r2 = 4
            if (r0 == r2) goto L_0x0496
            goto L_0x0788
        L_0x0496:
            if (r11 >= r2) goto L_0x04d6
            boolean r0 = f770c
            if (r0 == 0) goto L_0x04a1
            java.lang.String r0 = "movefrom RESUMED: "
            c.a.a.a.a.b(r0, r7, r12)
        L_0x04a1:
            b.h.a.u r0 = r7.u
            r2 = 3
            r0.a((int) r2)
            android.view.View r0 = r7.H
            if (r0 == 0) goto L_0x04b4
            b.h.a.Q r0 = r7.T
            b.j.e$a r2 = b.j.e.a.ON_PAUSE
            b.j.i r0 = r0.f737a
            r0.b((b.j.e.a) r2)
        L_0x04b4:
            b.j.i r0 = r7.S
            b.j.e$a r2 = b.j.e.a.ON_PAUSE
            r0.b((b.j.e.a) r2)
            r0 = 3
            r7.f745b = r0
            r7.F = r1
            r7.F = r8
            boolean r0 = r7.F
            if (r0 == 0) goto L_0x04ca
            r6.d(r7, r1)
            goto L_0x04d6
        L_0x04ca:
            b.h.a.S r0 = new b.h.a.S
            java.lang.String r1 = " did not call through to super.onPause()"
            java.lang.String r1 = c.a.a.a.a.a((java.lang.String) r13, (java.lang.Object) r7, (java.lang.String) r1)
            r0.<init>(r1)
            throw r0
        L_0x04d6:
            r0 = 3
            if (r11 >= r0) goto L_0x0519
            boolean r0 = f770c
            if (r0 == 0) goto L_0x04e2
            java.lang.String r0 = "movefrom STARTED: "
            c.a.a.a.a.b(r0, r7, r12)
        L_0x04e2:
            b.h.a.u r0 = r7.u
            r0.z = r8
            r2 = 2
            r0.a((int) r2)
            android.view.View r0 = r7.H
            if (r0 == 0) goto L_0x04f7
            b.h.a.Q r0 = r7.T
            b.j.e$a r2 = b.j.e.a.ON_STOP
            b.j.i r0 = r0.f737a
            r0.b((b.j.e.a) r2)
        L_0x04f7:
            b.j.i r0 = r7.S
            b.j.e$a r2 = b.j.e.a.ON_STOP
            r0.b((b.j.e.a) r2)
            r0 = 2
            r7.f745b = r0
            r7.F = r1
            r7.F = r8
            boolean r0 = r7.F
            if (r0 == 0) goto L_0x050d
            r6.g(r7, r1)
            goto L_0x0519
        L_0x050d:
            b.h.a.S r0 = new b.h.a.S
            java.lang.String r1 = " did not call through to super.onStop()"
            java.lang.String r1 = c.a.a.a.a.a((java.lang.String) r13, (java.lang.Object) r7, (java.lang.String) r1)
            r0.<init>(r1)
            throw r0
        L_0x0519:
            r0 = 2
            if (r11 >= r0) goto L_0x0607
            boolean r0 = f770c
            if (r0 == 0) goto L_0x0525
            java.lang.String r0 = "movefrom ACTIVITY_CREATED: "
            c.a.a.a.a.b(r0, r7, r12)
        L_0x0525:
            android.view.View r0 = r7.H
            if (r0 == 0) goto L_0x053d
            b.h.a.l r0 = r6.t
            b.h.a.h$a r0 = (b.h.a.C0077h.a) r0
            b.h.a.h r0 = b.h.a.C0077h.this
            boolean r0 = r0.isFinishing()
            r0 = r0 ^ r8
            if (r0 == 0) goto L_0x053d
            android.util.SparseArray<android.os.Parcelable> r0 = r7.d
            if (r0 != 0) goto L_0x053d
            r16.k(r17)
        L_0x053d:
            b.h.a.u r0 = r7.u
            r0.a((int) r8)
            android.view.View r0 = r7.H
            if (r0 == 0) goto L_0x054f
            b.h.a.Q r0 = r7.T
            b.j.e$a r2 = b.j.e.a.ON_DESTROY
            b.j.i r0 = r0.f737a
            r0.b((b.j.e.a) r2)
        L_0x054f:
            r7.f745b = r8
            r7.F = r1
            r7.F = r8
            boolean r0 = r7.F
            if (r0 == 0) goto L_0x05fb
            b.k.a.a r0 = b.k.a.a.a(r17)
            b.k.a.b r0 = (b.k.a.b) r0
            b.k.a.b$b r0 = r0.f814c
            r0.c()
            r7.q = r1
            r6.h(r7, r1)
            android.view.View r0 = r7.H
            if (r0 == 0) goto L_0x05eb
            android.view.ViewGroup r2 = r7.G
            if (r2 == 0) goto L_0x05eb
            r2.endViewTransition(r0)
            android.view.View r0 = r7.H
            r0.clearAnimation()
            b.h.a.g r0 = r7.v
            if (r0 == 0) goto L_0x0581
            boolean r0 = r0.m
            if (r0 != 0) goto L_0x05eb
        L_0x0581:
            int r0 = r6.s
            r2 = 0
            if (r0 <= 0) goto L_0x05a1
            boolean r0 = r6.A
            if (r0 != 0) goto L_0x05a1
            android.view.View r0 = r7.H
            int r0 = r0.getVisibility()
            if (r0 != 0) goto L_0x05a1
            float r0 = r7.O
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 < 0) goto L_0x05a1
            r0 = r19
            r3 = r20
            b.h.a.u$a r0 = r6.a((b.h.a.C0076g) r7, (int) r0, (boolean) r1, (int) r3)
            goto L_0x05a2
        L_0x05a1:
            r0 = r14
        L_0x05a2:
            r7.O = r2
            if (r0 == 0) goto L_0x05e4
            android.view.View r2 = r7.H
            android.view.ViewGroup r3 = r7.G
            r3.startViewTransition(r2)
            b.h.a.g$a r4 = r17.f()
            r4.f749c = r11
            android.view.animation.Animation r4 = r0.f771a
            if (r4 == 0) goto L_0x05cf
            b.h.a.u$b r0 = new b.h.a.u$b
            r0.<init>(r4, r3, r2)
            android.view.View r2 = r7.H
            r7.a((android.view.View) r2)
            b.h.a.q r2 = new b.h.a.q
            r2.<init>(r6, r3, r7)
            r0.setAnimationListener(r2)
            android.view.View r2 = r7.H
            r2.startAnimation(r0)
            goto L_0x05e4
        L_0x05cf:
            android.animation.Animator r0 = r0.f772b
            r7.a((android.animation.Animator) r0)
            b.h.a.r r4 = new b.h.a.r
            r4.<init>(r6, r3, r2, r7)
            r0.addListener(r4)
            android.view.View r2 = r7.H
            r0.setTarget(r2)
            r0.start()
        L_0x05e4:
            android.view.ViewGroup r0 = r7.G
            android.view.View r2 = r7.H
            r0.removeView(r2)
        L_0x05eb:
            r7.G = r14
            r7.H = r14
            r7.T = r14
            b.j.n<b.j.h> r0 = r7.U
            r0.a(r14)
            r7.I = r14
            r7.o = r1
            goto L_0x0607
        L_0x05fb:
            b.h.a.S r0 = new b.h.a.S
            java.lang.String r1 = " did not call through to super.onDestroyView()"
            java.lang.String r1 = c.a.a.a.a.a((java.lang.String) r13, (java.lang.Object) r7, (java.lang.String) r1)
            r0.<init>(r1)
            throw r0
        L_0x0607:
            if (r11 >= r8) goto L_0x0788
            boolean r0 = r6.A
            if (r0 == 0) goto L_0x062e
            android.view.View r0 = r17.g()
            if (r0 == 0) goto L_0x061e
            android.view.View r0 = r17.g()
            r7.a((android.view.View) r14)
            r0.clearAnimation()
            goto L_0x062e
        L_0x061e:
            android.animation.Animator r0 = r17.h()
            if (r0 == 0) goto L_0x062e
            android.animation.Animator r0 = r17.h()
            r7.a((android.animation.Animator) r14)
            r0.cancel()
        L_0x062e:
            android.view.View r0 = r17.g()
            if (r0 != 0) goto L_0x0781
            android.animation.Animator r0 = r17.h()
            if (r0 == 0) goto L_0x063c
            goto L_0x0781
        L_0x063c:
            boolean r0 = f770c
            if (r0 == 0) goto L_0x0645
            java.lang.String r0 = "movefrom CREATED: "
            c.a.a.a.a.b(r0, r7, r12)
        L_0x0645:
            boolean r0 = r7.m
            if (r0 == 0) goto L_0x0651
            boolean r0 = r17.u()
            if (r0 != 0) goto L_0x0651
            r0 = 1
            goto L_0x0652
        L_0x0651:
            r0 = 0
        L_0x0652:
            if (r0 != 0) goto L_0x0660
            b.h.a.y r2 = r6.I
            boolean r2 = r2.f(r7)
            if (r2 == 0) goto L_0x065d
            goto L_0x0660
        L_0x065d:
            r7.f745b = r1
            goto L_0x06a0
        L_0x0660:
            b.h.a.l r2 = r6.t
            boolean r3 = r2 instanceof b.j.v
            if (r3 == 0) goto L_0x066d
            b.h.a.y r2 = r6.I
            boolean r2 = r2.d()
            goto L_0x067c
        L_0x066d:
            android.content.Context r2 = r2.f753b
            boolean r3 = r2 instanceof android.app.Activity
            if (r3 == 0) goto L_0x067b
            android.app.Activity r2 = (android.app.Activity) r2
            boolean r2 = r2.isChangingConfigurations()
            r2 = r2 ^ r8
            goto L_0x067c
        L_0x067b:
            r2 = 1
        L_0x067c:
            if (r0 != 0) goto L_0x0680
            if (r2 == 0) goto L_0x0685
        L_0x0680:
            b.h.a.y r2 = r6.I
            r2.b(r7)
        L_0x0685:
            b.h.a.u r2 = r7.u
            r2.e()
            b.j.i r2 = r7.S
            b.j.e$a r3 = b.j.e.a.ON_DESTROY
            r2.b((b.j.e.a) r3)
            r7.f745b = r1
            r7.F = r1
            r7.Q = r1
            r7.F = r8
            boolean r2 = r7.F
            if (r2 == 0) goto L_0x0775
            r6.b((b.h.a.C0076g) r7, (boolean) r1)
        L_0x06a0:
            r7.F = r1
            r7.F = r8
            r7.P = r14
            boolean r2 = r7.F
            if (r2 == 0) goto L_0x0769
            b.h.a.u r2 = r7.u
            boolean r3 = r2.A
            if (r3 != 0) goto L_0x06ba
            r2.e()
            b.h.a.u r2 = new b.h.a.u
            r2.<init>()
            r7.u = r2
        L_0x06ba:
            r6.c((b.h.a.C0076g) r7, (boolean) r1)
            if (r21 != 0) goto L_0x0788
            if (r0 != 0) goto L_0x06e6
            b.h.a.y r0 = r6.I
            boolean r0 = r0.f(r7)
            if (r0 == 0) goto L_0x06ca
            goto L_0x06e6
        L_0x06ca:
            r7.t = r14
            r7.v = r14
            r7.s = r14
            java.lang.String r0 = r7.i
            if (r0 == 0) goto L_0x0788
            java.util.HashMap<java.lang.String, b.h.a.g> r1 = r6.j
            java.lang.Object r0 = r1.get(r0)
            b.h.a.g r0 = (b.h.a.C0076g) r0
            if (r0 == 0) goto L_0x0788
            boolean r1 = r0.B
            if (r1 == 0) goto L_0x0788
            r7.h = r0
            goto L_0x0788
        L_0x06e6:
            java.util.HashMap<java.lang.String, b.h.a.g> r0 = r6.j
            java.lang.String r2 = r7.f
            java.lang.Object r0 = r0.get(r2)
            if (r0 != 0) goto L_0x06f2
            goto L_0x0788
        L_0x06f2:
            boolean r0 = f770c
            if (r0 == 0) goto L_0x06fb
            java.lang.String r0 = "Removed fragment from active set "
            c.a.a.a.a.b(r0, r7, r12)
        L_0x06fb:
            java.util.HashMap<java.lang.String, b.h.a.g> r0 = r6.j
            java.util.Collection r0 = r0.values()
            java.util.Iterator r0 = r0.iterator()
        L_0x0705:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L_0x0722
            java.lang.Object r2 = r0.next()
            b.h.a.g r2 = (b.h.a.C0076g) r2
            if (r2 == 0) goto L_0x0705
            java.lang.String r3 = r7.f
            java.lang.String r4 = r2.i
            boolean r3 = r3.equals(r4)
            if (r3 == 0) goto L_0x0705
            r2.h = r7
            r2.i = r14
            goto L_0x0705
        L_0x0722:
            java.util.HashMap<java.lang.String, b.h.a.g> r0 = r6.j
            java.lang.String r2 = r7.f
            r0.put(r2, r14)
            r16.j(r17)
            java.lang.String r0 = r7.i
            if (r0 == 0) goto L_0x073a
            java.util.HashMap<java.lang.String, b.h.a.g> r2 = r6.j
            java.lang.Object r0 = r2.get(r0)
            b.h.a.g r0 = (b.h.a.C0076g) r0
            r7.h = r0
        L_0x073a:
            r17.s()
            java.util.UUID r0 = java.util.UUID.randomUUID()
            java.lang.String r0 = r0.toString()
            r7.f = r0
            r7.l = r1
            r7.m = r1
            r7.n = r1
            r7.o = r1
            r7.p = r1
            r7.r = r1
            r7.s = r14
            b.h.a.u r0 = new b.h.a.u
            r0.<init>()
            r7.u = r0
            r7.t = r14
            r7.w = r1
            r7.x = r1
            r7.y = r14
            r7.z = r1
            r7.A = r1
            goto L_0x0788
        L_0x0769:
            b.h.a.S r0 = new b.h.a.S
            java.lang.String r1 = " did not call through to super.onDetach()"
            java.lang.String r1 = c.a.a.a.a.a((java.lang.String) r13, (java.lang.Object) r7, (java.lang.String) r1)
            r0.<init>(r1)
            throw r0
        L_0x0775:
            b.h.a.S r0 = new b.h.a.S
            java.lang.String r1 = " did not call through to super.onDestroy()"
            java.lang.String r1 = c.a.a.a.a.a((java.lang.String) r13, (java.lang.Object) r7, (java.lang.String) r1)
            r0.<init>(r1)
            throw r0
        L_0x0781:
            b.h.a.g$a r0 = r17.f()
            r0.f749c = r11
            goto L_0x0789
        L_0x0788:
            r8 = r11
        L_0x0789:
            int r0 = r7.f745b
            if (r0 == r8) goto L_0x07b5
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = "moveToState: Fragment state for "
            r0.append(r1)
            r0.append(r7)
            java.lang.String r1 = " not updated inline; expected state "
            r0.append(r1)
            r0.append(r8)
            java.lang.String r1 = " found "
            r0.append(r1)
            int r1 = r7.f745b
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            android.util.Log.w(r12, r0)
            r7.f745b = r8
        L_0x07b5:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.u.a(b.h.a.g, int, int, int, boolean):void");
    }

    public void a(Parcelable parcelable) {
        Bundle bundle;
        C0076g gVar;
        A a2;
        if (parcelable != null) {
            w wVar = (w) parcelable;
            if (wVar.f782a != null) {
                for (C0076g next : this.I.c()) {
                    if (f770c) {
                        c.a.a.a.a.b("restoreSaveState: re-attaching retained ", next, "FragmentManager");
                    }
                    Iterator<A> it = wVar.f782a.iterator();
                    while (true) {
                        if (!it.hasNext()) {
                            a2 = null;
                            break;
                        }
                        a2 = it.next();
                        if (a2.f699b.equals(next.f)) {
                            break;
                        }
                    }
                    if (a2 == null) {
                        if (f770c) {
                            Log.v("FragmentManager", "Discarding retained Fragment " + next + " that was not found in the set of active Fragments " + wVar.f782a);
                        }
                        C0076g gVar2 = next;
                        a(gVar2, 1, 0, 0, false);
                        next.m = true;
                        a(gVar2, 0, 0, 0, false);
                    } else {
                        a2.n = next;
                        next.d = null;
                        next.r = 0;
                        next.o = false;
                        next.l = false;
                        C0076g gVar3 = next.h;
                        next.i = gVar3 != null ? gVar3.f : null;
                        next.h = null;
                        Bundle bundle2 = a2.m;
                        if (bundle2 != null) {
                            bundle2.setClassLoader(this.t.f753b.getClassLoader());
                            next.d = a2.m.getSparseParcelableArray("android:view_state");
                            next.f746c = a2.m;
                        }
                    }
                }
                this.j.clear();
                Iterator<A> it2 = wVar.f782a.iterator();
                while (it2.hasNext()) {
                    A next2 = it2.next();
                    if (next2 != null) {
                        ClassLoader classLoader = this.t.f753b.getClassLoader();
                        C0080k j2 = j();
                        if (next2.n == null) {
                            Bundle bundle3 = next2.j;
                            if (bundle3 != null) {
                                bundle3.setClassLoader(classLoader);
                            }
                            next2.n = j2.a(classLoader, next2.f698a);
                            next2.n.b(next2.j);
                            Bundle bundle4 = next2.m;
                            if (bundle4 != null) {
                                bundle4.setClassLoader(classLoader);
                                gVar = next2.n;
                                bundle = next2.m;
                            } else {
                                gVar = next2.n;
                                bundle = new Bundle();
                            }
                            gVar.f746c = bundle;
                            C0076g gVar4 = next2.n;
                            gVar4.f = next2.f699b;
                            gVar4.n = next2.f700c;
                            gVar4.p = true;
                            gVar4.w = next2.d;
                            gVar4.x = next2.e;
                            gVar4.y = next2.f;
                            gVar4.B = next2.g;
                            gVar4.m = next2.h;
                            gVar4.A = next2.i;
                            gVar4.z = next2.k;
                            gVar4.R = e.b.values()[next2.l];
                            if (f770c) {
                                StringBuilder a3 = c.a.a.a.a.a("Instantiated fragment ");
                                a3.append(next2.n);
                                Log.v("FragmentManager", a3.toString());
                            }
                        }
                        C0076g gVar5 = next2.n;
                        gVar5.s = this;
                        if (f770c) {
                            StringBuilder a4 = c.a.a.a.a.a("restoreSaveState: active (");
                            a4.append(gVar5.f);
                            a4.append("): ");
                            a4.append(gVar5);
                            Log.v("FragmentManager", a4.toString());
                        }
                        this.j.put(gVar5.f, gVar5);
                        next2.n = null;
                    }
                }
                this.i.clear();
                ArrayList<String> arrayList = wVar.f783b;
                if (arrayList != null) {
                    Iterator<String> it3 = arrayList.iterator();
                    while (it3.hasNext()) {
                        String next3 = it3.next();
                        C0076g gVar6 = this.j.get(next3);
                        if (gVar6 != null) {
                            gVar6.l = true;
                            if (f770c) {
                                Log.v("FragmentManager", "restoreSaveState: added (" + next3 + "): " + gVar6);
                            }
                            if (!this.i.contains(gVar6)) {
                                synchronized (this.i) {
                                    this.i.add(gVar6);
                                }
                            } else {
                                throw new IllegalStateException("Already added " + gVar6);
                            }
                        } else {
                            a((RuntimeException) new IllegalStateException("No instantiated fragment for (" + next3 + ")"));
                            throw null;
                        }
                    }
                }
                C0072c[] cVarArr = wVar.f784c;
                if (cVarArr != null) {
                    this.k = new ArrayList<>(cVarArr.length);
                    int i2 = 0;
                    while (true) {
                        C0072c[] cVarArr2 = wVar.f784c;
                        if (i2 >= cVarArr2.length) {
                            break;
                        }
                        C0070a a5 = cVarArr2[i2].a(this);
                        if (f770c) {
                            Log.v("FragmentManager", "restoreAllState: back stack #" + i2 + " (index " + a5.t + "): " + a5);
                            PrintWriter printWriter = new PrintWriter(new b.e.g.a("FragmentManager"));
                            a5.a("  ", printWriter, false);
                            printWriter.close();
                        }
                        this.k.add(a5);
                        int i3 = a5.t;
                        if (i3 >= 0) {
                            a(i3, a5);
                        }
                        i2++;
                    }
                } else {
                    this.k = null;
                }
                String str = wVar.d;
                if (str != null) {
                    this.w = this.j.get(str);
                    c(this.w);
                }
                this.h = wVar.e;
            }
        }
    }

    public void a(C0076g gVar, e.b bVar) {
        if (this.j.get(gVar.f) == gVar && (gVar.t == null || gVar.s == this)) {
            gVar.R = bVar;
            return;
        }
        throw new IllegalArgumentException("Fragment " + gVar + " is not an active fragment of FragmentManager " + this);
    }

    public final void a(RuntimeException runtimeException) {
        Log.e("FragmentManager", runtimeException.getMessage());
        Log.e("FragmentManager", "Activity state:");
        PrintWriter printWriter = new PrintWriter(new b.e.g.a("FragmentManager"));
        C0081l lVar = this.t;
        if (lVar != null) {
            try {
                C0077h.this.dump("  ", (FileDescriptor) null, printWriter, new String[0]);
            } catch (Exception e2) {
                Log.e("FragmentManager", "Failed dumping state", e2);
            }
        } else {
            a("  ", (FileDescriptor) null, printWriter, new String[0]);
        }
        throw runtimeException;
    }
}
