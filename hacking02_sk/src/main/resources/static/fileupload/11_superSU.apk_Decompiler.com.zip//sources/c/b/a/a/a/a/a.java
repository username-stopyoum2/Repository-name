package c.b.a.a.a.a;

import a.a.a.a.c;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;
import c.b.a.a.b.j;
import c.b.a.a.e.h;
import c.b.a.a.e.i;
import c.b.a.a.e.k;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class a {

    /* renamed from: a  reason: collision with root package name */
    public c.b.a.a.b.b f860a;

    /* renamed from: b  reason: collision with root package name */
    public i f861b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f862c;
    public Object d = new Object();
    public b e;
    public final Context f;
    public long g;

    /* renamed from: c.b.a.a.a.a.a$a  reason: collision with other inner class name */
    public static final class C0020a {

        /* renamed from: a  reason: collision with root package name */
        public final String f863a;

        /* renamed from: b  reason: collision with root package name */
        public final boolean f864b;

        public C0020a(String str, boolean z) {
            this.f863a = str;
            this.f864b = z;
        }

        public final String toString() {
            String str = this.f863a;
            boolean z = this.f864b;
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 7);
            sb.append("{");
            sb.append(str);
            sb.append("}");
            sb.append(z);
            return sb.toString();
        }
    }

    static class b extends Thread {

        /* renamed from: a  reason: collision with root package name */
        public WeakReference<a> f865a;

        /* renamed from: b  reason: collision with root package name */
        public long f866b;

        /* renamed from: c  reason: collision with root package name */
        public CountDownLatch f867c = new CountDownLatch(1);
        public boolean d = false;

        public b(a aVar, long j) {
            this.f865a = new WeakReference<>(aVar);
            this.f866b = j;
            start();
        }

        public final void run() {
            a aVar;
            try {
                if (!this.f867c.await(this.f866b, TimeUnit.MILLISECONDS) && (aVar = (a) this.f865a.get()) != null) {
                    aVar.a();
                    this.d = true;
                }
            } catch (InterruptedException unused) {
                a aVar2 = (a) this.f865a.get();
                if (aVar2 != null) {
                    aVar2.a();
                    this.d = true;
                }
            }
        }
    }

    public a(Context context, long j, boolean z) {
        Context applicationContext;
        c.b(context);
        if (z && (applicationContext = context.getApplicationContext()) != null) {
            context = applicationContext;
        }
        this.f = context;
        this.f862c = false;
        this.g = j;
    }

    public static C0020a a(Context context) {
        boolean z;
        a aVar;
        float f2 = 0.0f;
        try {
            Context a2 = j.a(context);
            if (a2 != null) {
                SharedPreferences sharedPreferences = a2.getSharedPreferences("google_ads_flags", 0);
                z = sharedPreferences.getBoolean("gads:ad_id_app_context:enabled", false);
                try {
                    f2 = sharedPreferences.getFloat("gads:ad_id_app_context:ping_ratio", 0.0f);
                } catch (Exception e2) {
                    e = e2;
                    Log.w("AdvertisingIdClient", "Error while reading from SharedPreferences ", e);
                    aVar = new a(context, -1, z);
                    aVar.a(false);
                    C0020a b2 = aVar.b();
                    aVar.a(b2, z, f2, (Throwable) null);
                    return b2;
                }
            } else {
                z = false;
            }
        } catch (Exception e3) {
            e = e3;
            z = false;
            Log.w("AdvertisingIdClient", "Error while reading from SharedPreferences ", e);
            aVar = new a(context, -1, z);
            aVar.a(false);
            C0020a b22 = aVar.b();
            aVar.a(b22, z, f2, (Throwable) null);
            return b22;
        }
        aVar = new a(context, -1, z);
        try {
            aVar.a(false);
            C0020a b222 = aVar.b();
            aVar.a(b222, z, f2, (Throwable) null);
            return b222;
        } catch (Throwable th) {
            aVar.a((C0020a) null, z, f2, th);
            return null;
        } finally {
            aVar.a();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0038, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void a() {
        /*
            r3 = this;
            java.lang.String r0 = "Calling this from your main thread can lead to deadlock"
            a.a.a.a.c.c((java.lang.String) r0)
            monitor-enter(r3)
            android.content.Context r0 = r3.f     // Catch:{ all -> 0x0039 }
            if (r0 == 0) goto L_0x0037
            c.b.a.a.b.b r0 = r3.f860a     // Catch:{ all -> 0x0039 }
            if (r0 != 0) goto L_0x000f
            goto L_0x0037
        L_0x000f:
            boolean r0 = r3.f862c     // Catch:{ IllegalArgumentException -> 0x0027, Throwable -> 0x001e }
            if (r0 == 0) goto L_0x002d
            c.b.a.a.b.b.a.a()     // Catch:{ IllegalArgumentException -> 0x0027, Throwable -> 0x001e }
            android.content.Context r0 = r3.f     // Catch:{ IllegalArgumentException -> 0x0027, Throwable -> 0x001e }
            c.b.a.a.b.b r1 = r3.f860a     // Catch:{ IllegalArgumentException -> 0x0027, Throwable -> 0x001e }
            r0.unbindService(r1)     // Catch:{ IllegalArgumentException -> 0x0027, Throwable -> 0x001e }
            goto L_0x002d
        L_0x001e:
            r0 = move-exception
            java.lang.String r1 = "AdvertisingIdClient"
            java.lang.String r2 = "AdvertisingIdClient unbindService failed."
        L_0x0023:
            android.util.Log.i(r1, r2, r0)     // Catch:{ all -> 0x0039 }
            goto L_0x002d
        L_0x0027:
            r0 = move-exception
            java.lang.String r1 = "AdvertisingIdClient"
            java.lang.String r2 = "AdvertisingIdClient unbindService failed."
            goto L_0x0023
        L_0x002d:
            r0 = 0
            r3.f862c = r0     // Catch:{ all -> 0x0039 }
            r0 = 0
            r3.f861b = r0     // Catch:{ all -> 0x0039 }
            r3.f860a = r0     // Catch:{ all -> 0x0039 }
            monitor-exit(r3)     // Catch:{ all -> 0x0039 }
            return
        L_0x0037:
            monitor-exit(r3)     // Catch:{ all -> 0x0039 }
            return
        L_0x0039:
            r0 = move-exception
            monitor-exit(r3)     // Catch:{ all -> 0x0039 }
            goto L_0x003d
        L_0x003c:
            throw r0
        L_0x003d:
            goto L_0x003c
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.a.a.a.a.a.a():void");
    }

    public final void a(boolean z) {
        c.c("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            if (this.f862c) {
                a();
            }
            this.f860a = b(this.f);
            Context context = this.f;
            try {
                this.f861b = c.b.a.a.e.j.a(this.f860a.a(10000, TimeUnit.MILLISECONDS));
                this.f862c = true;
                if (z) {
                    c();
                }
            } catch (InterruptedException unused) {
                throw new IOException("Interrupted exception");
            } catch (Throwable th) {
                throw new IOException(th);
            }
        }
    }

    public C0020a b() {
        C0020a aVar;
        c.c("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            if (!this.f862c) {
                synchronized (this.d) {
                    if (this.e == null || !this.e.d) {
                        throw new IOException("AdvertisingIdClient is not connected.");
                    }
                }
                try {
                    a(false);
                    if (!this.f862c) {
                        throw new IOException("AdvertisingIdClient cannot reconnect.");
                    }
                } catch (RemoteException e2) {
                    Log.i("AdvertisingIdClient", "GMS remote exception ", e2);
                    throw new IOException("Remote exception");
                } catch (Exception e3) {
                    throw new IOException("AdvertisingIdClient cannot reconnect.", e3);
                }
            }
            c.b(this.f860a);
            c.b(this.f861b);
            k kVar = (k) this.f861b;
            Parcel a2 = kVar.a(1, kVar.b());
            String readString = a2.readString();
            a2.recycle();
            k kVar2 = (k) this.f861b;
            Parcel b2 = kVar2.b();
            h.a(b2, true);
            Parcel a3 = kVar2.a(2, b2);
            boolean a4 = h.a(a3);
            a3.recycle();
            aVar = new C0020a(readString, a4);
        }
        c();
        return aVar;
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(7:2|3|(3:5|6|7)|8|9|(1:11)|12) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:8:0x0013 */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x001b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c() {
        /*
            r6 = this;
            java.lang.Object r0 = r6.d
            monitor-enter(r0)
            c.b.a.a.a.a.a$b r1 = r6.e     // Catch:{ all -> 0x0026 }
            if (r1 == 0) goto L_0x0013
            c.b.a.a.a.a.a$b r1 = r6.e     // Catch:{ all -> 0x0026 }
            java.util.concurrent.CountDownLatch r1 = r1.f867c     // Catch:{ all -> 0x0026 }
            r1.countDown()     // Catch:{ all -> 0x0026 }
            c.b.a.a.a.a.a$b r1 = r6.e     // Catch:{ InterruptedException -> 0x0013 }
            r1.join()     // Catch:{ InterruptedException -> 0x0013 }
        L_0x0013:
            long r1 = r6.g     // Catch:{ all -> 0x0026 }
            r3 = 0
            int r5 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r5 <= 0) goto L_0x0024
            c.b.a.a.a.a.a$b r1 = new c.b.a.a.a.a.a$b     // Catch:{ all -> 0x0026 }
            long r2 = r6.g     // Catch:{ all -> 0x0026 }
            r1.<init>(r6, r2)     // Catch:{ all -> 0x0026 }
            r6.e = r1     // Catch:{ all -> 0x0026 }
        L_0x0024:
            monitor-exit(r0)     // Catch:{ all -> 0x0026 }
            return
        L_0x0026:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0026 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.a.a.a.a.a.c():void");
    }

    public void finalize() {
        a();
        super.finalize();
    }

    public static c.b.a.a.b.b b(Context context) {
        try {
            context.getPackageManager().getPackageInfo("com.android.vending", 0);
            int b2 = j.b(context);
            if (j.a(context, b2)) {
                b2 = 18;
            }
            if (b2 == 0 || b2 == 2) {
                c.b.a.a.b.b bVar = new c.b.a.a.b.b();
                Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
                intent.setPackage("com.google.android.gms");
                try {
                    if (c.b.a.a.b.b.a.a().a(context, intent, bVar, 1)) {
                        return bVar;
                    }
                    throw new IOException("Connection failure");
                } catch (Throwable th) {
                    throw new IOException(th);
                }
            } else {
                throw new IOException("Google Play services not available");
            }
        } catch (PackageManager.NameNotFoundException unused) {
            throw new c.b.a.a.b.a(9);
        }
    }

    public final void a(C0020a aVar, boolean z, float f2, Throwable th) {
        String str;
        if (Math.random() <= ((double) f2)) {
            Bundle bundle = new Bundle();
            String str2 = "1";
            bundle.putString("app_context", z ? str2 : "0");
            if (aVar != null) {
                if (!aVar.f864b) {
                    str2 = "0";
                }
                bundle.putString("limit_ad_tracking", str2);
            }
            if (!(aVar == null || (str = aVar.f863a) == null)) {
                bundle.putString("ad_id_size", Integer.toString(str.length()));
            }
            if (th != null) {
                bundle.putString("error", th.getClass().getName());
            }
            Uri.Builder buildUpon = Uri.parse("https://pagead2.googlesyndication.com/pagead/gen_204?id=gmob-apps").buildUpon();
            for (String str3 : bundle.keySet()) {
                buildUpon.appendQueryParameter(str3, bundle.getString(str3));
            }
            new b(this, buildUpon.build().toString()).start();
        }
    }
}
