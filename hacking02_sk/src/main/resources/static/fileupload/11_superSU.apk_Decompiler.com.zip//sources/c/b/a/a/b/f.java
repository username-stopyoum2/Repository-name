package c.b.a.a.b;

import java.lang.ref.WeakReference;

public abstract class f extends d {

    /* renamed from: b  reason: collision with root package name */
    public static final WeakReference<byte[]> f879b = new WeakReference<>((Object) null);

    /* renamed from: c  reason: collision with root package name */
    public WeakReference<byte[]> f880c = f879b;

    public f(byte[] bArr) {
        super(bArr);
    }

    public final byte[] b() {
        byte[] bArr;
        synchronized (this) {
            bArr = (byte[]) this.f880c.get();
            if (bArr == null) {
                bArr = e();
                this.f880c = new WeakReference<>(bArr);
            }
        }
        return bArr;
    }

    public abstract byte[] e();
}
