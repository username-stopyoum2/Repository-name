package androidx.activity;

import android.view.View;
import android.view.Window;
import b.a.c;
import b.j.e;
import b.j.f;
import b.j.h;

class ComponentActivity$2 implements f {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c f44a;

    public ComponentActivity$2(c cVar) {
        this.f44a = cVar;
    }

    public void a(h hVar, e.a aVar) {
        if (aVar == e.a.ON_STOP) {
            Window window = this.f44a.getWindow();
            View peekDecorView = window != null ? window.peekDecorView() : null;
            if (peekDecorView != null) {
                peekDecorView.cancelPendingInputEvents();
            }
        }
    }
}
