package androidx.lifecycle;

import b.c.a.a.c;
import b.c.a.b.b;
import b.j.d;
import b.j.e;
import b.j.h;
import b.j.i;
import b.j.o;
import java.util.Map;

public abstract class LiveData<T> {

    /* renamed from: a  reason: collision with root package name */
    public static final Object f127a = new Object();

    /* renamed from: b  reason: collision with root package name */
    public final Object f128b = new Object();

    /* renamed from: c  reason: collision with root package name */
    public b<o<? super T>, LiveData<T>.a> f129c = new b<>();
    public int d = 0;
    public volatile Object e;
    public volatile Object f;
    public int g;
    public boolean h;
    public boolean i;

    class LifecycleBoundObserver extends LiveData<T>.a implements d {
        public final h e;
        public final /* synthetic */ LiveData f;

        public void a() {
            this.e.a().b(this);
        }

        public void a(h hVar, e.a aVar) {
            if (((i) this.e.a()).f803b == e.b.DESTROYED) {
                this.f.a((o) null);
            } else {
                a(b());
            }
        }

        public boolean b() {
            return ((i) this.e.a()).f803b.a(e.b.STARTED);
        }
    }

    private abstract class a {

        /* renamed from: a  reason: collision with root package name */
        public final o<? super T> f130a;

        /* renamed from: b  reason: collision with root package name */
        public boolean f131b;

        /* renamed from: c  reason: collision with root package name */
        public int f132c;
        public final /* synthetic */ LiveData d;

        public void a() {
        }

        public void a(boolean z) {
            if (z != this.f131b) {
                this.f131b = z;
                int i = 1;
                boolean z2 = this.d.d == 0;
                LiveData liveData = this.d;
                int i2 = liveData.d;
                if (!this.f131b) {
                    i = -1;
                }
                liveData.d = i2 + i;
                if (z2 && this.f131b) {
                    this.d.a();
                }
                LiveData liveData2 = this.d;
                if (liveData2.d == 0 && !this.f131b) {
                    liveData2.b();
                }
                if (this.f131b) {
                    this.d.b(this);
                }
            }
        }

        public abstract boolean b();
    }

    public LiveData() {
        Object obj = f127a;
        this.e = obj;
        this.f = obj;
        this.g = -1;
        new l(this);
    }

    public static void a(String str) {
        if (!c.b().f503b.a()) {
            throw new IllegalStateException("Cannot invoke " + str + " on a background" + " thread");
        }
    }

    public void a() {
    }

    public final void a(LiveData<T>.a aVar) {
        if (aVar.f131b) {
            if (!aVar.b()) {
                aVar.a(false);
                return;
            }
            int i2 = aVar.f132c;
            int i3 = this.g;
            if (i2 < i3) {
                aVar.f132c = i3;
                aVar.f130a.a(this.e);
            }
        }
    }

    public void a(o<? super T> oVar) {
        a("removeObserver");
        a remove = this.f129c.remove(oVar);
        if (remove != null) {
            remove.a();
            remove.a(false);
        }
    }

    public abstract void a(T t);

    public void b() {
    }

    public void b(LiveData<T>.a aVar) {
        if (this.h) {
            this.i = true;
            return;
        }
        this.h = true;
        do {
            this.i = false;
            if (aVar == null) {
                b<K, V>.d a2 = this.f129c.a();
                while (a2.hasNext()) {
                    a((LiveData<T>.a) (a) ((Map.Entry) a2.next()).getValue());
                    if (this.i) {
                        break;
                    }
                }
            } else {
                a(aVar);
                aVar = null;
            }
        } while (this.i);
        this.h = false;
    }
}
