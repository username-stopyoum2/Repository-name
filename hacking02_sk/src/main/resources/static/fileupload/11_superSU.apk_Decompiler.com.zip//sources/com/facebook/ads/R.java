package com.facebook.ads;

public final class R {

    /* added by JADX */
    public static final class anim {
        /* added by JADX */
        public static final int abc_fade_in = 2130771968;
        /* added by JADX */
        public static final int abc_fade_out = 2130771969;
        /* added by JADX */
        public static final int abc_grow_fade_in_from_bottom = 2130771970;
        /* added by JADX */
        public static final int abc_popup_enter = 2130771971;
        /* added by JADX */
        public static final int abc_popup_exit = 2130771972;
        /* added by JADX */
        public static final int abc_shrink_fade_out_from_bottom = 2130771973;
        /* added by JADX */
        public static final int abc_slide_in_bottom = 2130771974;
        /* added by JADX */
        public static final int abc_slide_in_top = 2130771975;
        /* added by JADX */
        public static final int abc_slide_out_bottom = 2130771976;
        /* added by JADX */
        public static final int abc_slide_out_top = 2130771977;
        /* added by JADX */
        public static final int abc_tooltip_enter = 2130771978;
        /* added by JADX */
        public static final int abc_tooltip_exit = 2130771979;
        /* added by JADX */
        public static final int anim_bounce = 2130771980;
        /* added by JADX */
        public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771981;
        /* added by JADX */
        public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771982;
        /* added by JADX */
        public static final int btn_checkbox_to_checked_icon_null_animation = 2130771983;
        /* added by JADX */
        public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771984;
        /* added by JADX */
        public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771985;
        /* added by JADX */
        public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771986;
        /* added by JADX */
        public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771987;
        /* added by JADX */
        public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771988;
        /* added by JADX */
        public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771989;
        /* added by JADX */
        public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771990;
        /* added by JADX */
        public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771991;
        /* added by JADX */
        public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771992;
    }

    /* added by JADX */
    public static final class attr {
        /* added by JADX */
        public static final int actionBarDivider = 2130837504;
        /* added by JADX */
        public static final int actionBarItemBackground = 2130837505;
        /* added by JADX */
        public static final int actionBarPopupTheme = 2130837506;
        /* added by JADX */
        public static final int actionBarSize = 2130837507;
        /* added by JADX */
        public static final int actionBarSplitStyle = 2130837508;
        /* added by JADX */
        public static final int actionBarStyle = 2130837509;
        /* added by JADX */
        public static final int actionBarTabBarStyle = 2130837510;
        /* added by JADX */
        public static final int actionBarTabStyle = 2130837511;
        /* added by JADX */
        public static final int actionBarTabTextStyle = 2130837512;
        /* added by JADX */
        public static final int actionBarTheme = 2130837513;
        /* added by JADX */
        public static final int actionBarWidgetTheme = 2130837514;
        /* added by JADX */
        public static final int actionButtonStyle = 2130837515;
        /* added by JADX */
        public static final int actionDropDownStyle = 2130837516;
        /* added by JADX */
        public static final int actionLayout = 2130837517;
        /* added by JADX */
        public static final int actionMenuTextAppearance = 2130837518;
        /* added by JADX */
        public static final int actionMenuTextColor = 2130837519;
        /* added by JADX */
        public static final int actionModeBackground = 2130837520;
        /* added by JADX */
        public static final int actionModeCloseButtonStyle = 2130837521;
        /* added by JADX */
        public static final int actionModeCloseDrawable = 2130837522;
        /* added by JADX */
        public static final int actionModeCopyDrawable = 2130837523;
        /* added by JADX */
        public static final int actionModeCutDrawable = 2130837524;
        /* added by JADX */
        public static final int actionModeFindDrawable = 2130837525;
        /* added by JADX */
        public static final int actionModePasteDrawable = 2130837526;
        /* added by JADX */
        public static final int actionModePopupWindowStyle = 2130837527;
        /* added by JADX */
        public static final int actionModeSelectAllDrawable = 2130837528;
        /* added by JADX */
        public static final int actionModeShareDrawable = 2130837529;
        /* added by JADX */
        public static final int actionModeSplitBackground = 2130837530;
        /* added by JADX */
        public static final int actionModeStyle = 2130837531;
        /* added by JADX */
        public static final int actionModeWebSearchDrawable = 2130837532;
        /* added by JADX */
        public static final int actionOverflowButtonStyle = 2130837533;
        /* added by JADX */
        public static final int actionOverflowMenuStyle = 2130837534;
        /* added by JADX */
        public static final int actionProviderClass = 2130837535;
        /* added by JADX */
        public static final int actionViewClass = 2130837536;
        /* added by JADX */
        public static final int activityChooserViewStyle = 2130837537;
        /* added by JADX */
        public static final int alertDialogButtonGroupStyle = 2130837538;
        /* added by JADX */
        public static final int alertDialogCenterButtons = 2130837539;
        /* added by JADX */
        public static final int alertDialogStyle = 2130837540;
        /* added by JADX */
        public static final int alertDialogTheme = 2130837541;
        /* added by JADX */
        public static final int allowStacking = 2130837542;
        /* added by JADX */
        public static final int alpha = 2130837543;
        /* added by JADX */
        public static final int alphabeticModifiers = 2130837544;
        /* added by JADX */
        public static final int arrowHeadLength = 2130837545;
        /* added by JADX */
        public static final int arrowShaftLength = 2130837546;
        /* added by JADX */
        public static final int autoCompleteTextViewStyle = 2130837547;
        /* added by JADX */
        public static final int autoSizeMaxTextSize = 2130837548;
        /* added by JADX */
        public static final int autoSizeMinTextSize = 2130837549;
        /* added by JADX */
        public static final int autoSizePresetSizes = 2130837550;
        /* added by JADX */
        public static final int autoSizeStepGranularity = 2130837551;
        /* added by JADX */
        public static final int autoSizeTextType = 2130837552;
        /* added by JADX */
        public static final int background = 2130837553;
        /* added by JADX */
        public static final int backgroundSplit = 2130837554;
        /* added by JADX */
        public static final int backgroundStacked = 2130837555;
        /* added by JADX */
        public static final int backgroundTint = 2130837556;
        /* added by JADX */
        public static final int backgroundTintMode = 2130837557;
        /* added by JADX */
        public static final int barLength = 2130837558;
        /* added by JADX */
        public static final int borderlessButtonStyle = 2130837559;
        /* added by JADX */
        public static final int buttonBarButtonStyle = 2130837560;
        /* added by JADX */
        public static final int buttonBarNegativeButtonStyle = 2130837561;
        /* added by JADX */
        public static final int buttonBarNeutralButtonStyle = 2130837562;
        /* added by JADX */
        public static final int buttonBarPositiveButtonStyle = 2130837563;
        /* added by JADX */
        public static final int buttonBarStyle = 2130837564;
        /* added by JADX */
        public static final int buttonCompat = 2130837565;
        /* added by JADX */
        public static final int buttonGravity = 2130837566;
        /* added by JADX */
        public static final int buttonIconDimen = 2130837567;
        /* added by JADX */
        public static final int buttonPanelSideLayout = 2130837568;
        /* added by JADX */
        public static final int buttonStyle = 2130837569;
        /* added by JADX */
        public static final int buttonStyleSmall = 2130837570;
        /* added by JADX */
        public static final int buttonTint = 2130837571;
        /* added by JADX */
        public static final int buttonTintMode = 2130837572;
        /* added by JADX */
        public static final int checkboxStyle = 2130837573;
        /* added by JADX */
        public static final int checkedTextViewStyle = 2130837574;
        /* added by JADX */
        public static final int closeIcon = 2130837575;
        /* added by JADX */
        public static final int closeItemLayout = 2130837576;
        /* added by JADX */
        public static final int collapseContentDescription = 2130837577;
        /* added by JADX */
        public static final int collapseIcon = 2130837578;
        /* added by JADX */
        public static final int color = 2130837579;
        /* added by JADX */
        public static final int colorAccent = 2130837580;
        /* added by JADX */
        public static final int colorBackgroundFloating = 2130837581;
        /* added by JADX */
        public static final int colorButtonNormal = 2130837582;
        /* added by JADX */
        public static final int colorControlActivated = 2130837583;
        /* added by JADX */
        public static final int colorControlHighlight = 2130837584;
        /* added by JADX */
        public static final int colorControlNormal = 2130837585;
        /* added by JADX */
        public static final int colorError = 2130837586;
        /* added by JADX */
        public static final int colorPrimary = 2130837587;
        /* added by JADX */
        public static final int colorPrimaryDark = 2130837588;
        /* added by JADX */
        public static final int colorSwitchThumbNormal = 2130837589;
        /* added by JADX */
        public static final int commitIcon = 2130837590;
        /* added by JADX */
        public static final int contentDescription = 2130837591;
        /* added by JADX */
        public static final int contentInsetEnd = 2130837592;
        /* added by JADX */
        public static final int contentInsetEndWithActions = 2130837593;
        /* added by JADX */
        public static final int contentInsetLeft = 2130837594;
        /* added by JADX */
        public static final int contentInsetRight = 2130837595;
        /* added by JADX */
        public static final int contentInsetStart = 2130837596;
        /* added by JADX */
        public static final int contentInsetStartWithNavigation = 2130837597;
        /* added by JADX */
        public static final int controlBackground = 2130837598;
        /* added by JADX */
        public static final int coordinatorLayoutStyle = 2130837599;
        /* added by JADX */
        public static final int customNavigationLayout = 2130837600;
        /* added by JADX */
        public static final int defaultQueryHint = 2130837601;
        /* added by JADX */
        public static final int dialogCornerRadius = 2130837602;
        /* added by JADX */
        public static final int dialogPreferredPadding = 2130837603;
        /* added by JADX */
        public static final int dialogTheme = 2130837604;
        /* added by JADX */
        public static final int displayOptions = 2130837605;
        /* added by JADX */
        public static final int divider = 2130837606;
        /* added by JADX */
        public static final int dividerHorizontal = 2130837607;
        /* added by JADX */
        public static final int dividerPadding = 2130837608;
        /* added by JADX */
        public static final int dividerVertical = 2130837609;
        /* added by JADX */
        public static final int drawableBottomCompat = 2130837610;
        /* added by JADX */
        public static final int drawableEndCompat = 2130837611;
        /* added by JADX */
        public static final int drawableLeftCompat = 2130837612;
        /* added by JADX */
        public static final int drawableRightCompat = 2130837613;
        /* added by JADX */
        public static final int drawableSize = 2130837614;
        /* added by JADX */
        public static final int drawableStartCompat = 2130837615;
        /* added by JADX */
        public static final int drawableTint = 2130837616;
        /* added by JADX */
        public static final int drawableTintMode = 2130837617;
        /* added by JADX */
        public static final int drawableTopCompat = 2130837618;
        /* added by JADX */
        public static final int drawerArrowStyle = 2130837619;
        /* added by JADX */
        public static final int dropDownListViewStyle = 2130837620;
        /* added by JADX */
        public static final int dropdownListPreferredItemHeight = 2130837621;
        /* added by JADX */
        public static final int editTextBackground = 2130837622;
        /* added by JADX */
        public static final int editTextColor = 2130837623;
        /* added by JADX */
        public static final int editTextStyle = 2130837624;
        /* added by JADX */
        public static final int elevation = 2130837625;
        /* added by JADX */
        public static final int expandActivityOverflowButtonDrawable = 2130837626;
        /* added by JADX */
        public static final int firstBaselineToTopHeight = 2130837627;
        /* added by JADX */
        public static final int font = 2130837628;
        /* added by JADX */
        public static final int fontFamily = 2130837629;
        /* added by JADX */
        public static final int fontProviderAuthority = 2130837630;
        /* added by JADX */
        public static final int fontProviderCerts = 2130837631;
        /* added by JADX */
        public static final int fontProviderFetchStrategy = 2130837632;
        /* added by JADX */
        public static final int fontProviderFetchTimeout = 2130837633;
        /* added by JADX */
        public static final int fontProviderPackage = 2130837634;
        /* added by JADX */
        public static final int fontProviderQuery = 2130837635;
        /* added by JADX */
        public static final int fontStyle = 2130837636;
        /* added by JADX */
        public static final int fontVariationSettings = 2130837637;
        /* added by JADX */
        public static final int fontWeight = 2130837638;
        /* added by JADX */
        public static final int gapBetweenBars = 2130837639;
        /* added by JADX */
        public static final int goIcon = 2130837640;
        /* added by JADX */
        public static final int height = 2130837641;
        /* added by JADX */
        public static final int hideOnContentScroll = 2130837642;
        /* added by JADX */
        public static final int homeAsUpIndicator = 2130837643;
        /* added by JADX */
        public static final int homeLayout = 2130837644;
        /* added by JADX */
        public static final int icon = 2130837645;
        /* added by JADX */
        public static final int iconTint = 2130837646;
        /* added by JADX */
        public static final int iconTintMode = 2130837647;
        /* added by JADX */
        public static final int iconifiedByDefault = 2130837648;
        /* added by JADX */
        public static final int imageButtonStyle = 2130837649;
        /* added by JADX */
        public static final int indeterminateProgressStyle = 2130837650;
        /* added by JADX */
        public static final int initialActivityCount = 2130837651;
        /* added by JADX */
        public static final int isLightTheme = 2130837652;
        /* added by JADX */
        public static final int itemPadding = 2130837653;
        /* added by JADX */
        public static final int keylines = 2130837654;
        /* added by JADX */
        public static final int lastBaselineToBottomHeight = 2130837655;
        /* added by JADX */
        public static final int layout = 2130837656;
        /* added by JADX */
        public static final int layout_anchor = 2130837657;
        /* added by JADX */
        public static final int layout_anchorGravity = 2130837658;
        /* added by JADX */
        public static final int layout_behavior = 2130837659;
        /* added by JADX */
        public static final int layout_dodgeInsetEdges = 2130837660;
        /* added by JADX */
        public static final int layout_insetEdge = 2130837661;
        /* added by JADX */
        public static final int layout_keyline = 2130837662;
        /* added by JADX */
        public static final int lineHeight = 2130837663;
        /* added by JADX */
        public static final int listChoiceBackgroundIndicator = 2130837664;
        /* added by JADX */
        public static final int listChoiceIndicatorMultipleAnimated = 2130837665;
        /* added by JADX */
        public static final int listChoiceIndicatorSingleAnimated = 2130837666;
        /* added by JADX */
        public static final int listDividerAlertDialog = 2130837667;
        /* added by JADX */
        public static final int listItemLayout = 2130837668;
        /* added by JADX */
        public static final int listLayout = 2130837669;
        /* added by JADX */
        public static final int listMenuViewStyle = 2130837670;
        /* added by JADX */
        public static final int listPopupWindowStyle = 2130837671;
        /* added by JADX */
        public static final int listPreferredItemHeight = 2130837672;
        /* added by JADX */
        public static final int listPreferredItemHeightLarge = 2130837673;
        /* added by JADX */
        public static final int listPreferredItemHeightSmall = 2130837674;
        /* added by JADX */
        public static final int listPreferredItemPaddingEnd = 2130837675;
        /* added by JADX */
        public static final int listPreferredItemPaddingLeft = 2130837676;
        /* added by JADX */
        public static final int listPreferredItemPaddingRight = 2130837677;
        /* added by JADX */
        public static final int listPreferredItemPaddingStart = 2130837678;
        /* added by JADX */
        public static final int logo = 2130837679;
        /* added by JADX */
        public static final int logoDescription = 2130837680;
        /* added by JADX */
        public static final int maxButtonHeight = 2130837681;
        /* added by JADX */
        public static final int measureWithLargestChild = 2130837682;
        /* added by JADX */
        public static final int menu = 2130837683;
        /* added by JADX */
        public static final int multiChoiceItemLayout = 2130837684;
        /* added by JADX */
        public static final int navigationContentDescription = 2130837685;
        /* added by JADX */
        public static final int navigationIcon = 2130837686;
        /* added by JADX */
        public static final int navigationMode = 2130837687;
        /* added by JADX */
        public static final int numericModifiers = 2130837688;
        /* added by JADX */
        public static final int overlapAnchor = 2130837689;
        /* added by JADX */
        public static final int paddingBottomNoButtons = 2130837690;
        /* added by JADX */
        public static final int paddingEnd = 2130837691;
        /* added by JADX */
        public static final int paddingStart = 2130837692;
        /* added by JADX */
        public static final int paddingTopNoTitle = 2130837693;
        /* added by JADX */
        public static final int panelBackground = 2130837694;
        /* added by JADX */
        public static final int panelMenuListTheme = 2130837695;
        /* added by JADX */
        public static final int panelMenuListWidth = 2130837696;
        /* added by JADX */
        public static final int popupMenuStyle = 2130837697;
        /* added by JADX */
        public static final int popupTheme = 2130837698;
        /* added by JADX */
        public static final int popupWindowStyle = 2130837699;
        /* added by JADX */
        public static final int preserveIconSpacing = 2130837700;
        /* added by JADX */
        public static final int progressBarPadding = 2130837701;
        /* added by JADX */
        public static final int progressBarStyle = 2130837702;
        /* added by JADX */
        public static final int queryBackground = 2130837703;
        /* added by JADX */
        public static final int queryHint = 2130837704;
        /* added by JADX */
        public static final int radioButtonStyle = 2130837705;
        /* added by JADX */
        public static final int ratingBarStyle = 2130837706;
        /* added by JADX */
        public static final int ratingBarStyleIndicator = 2130837707;
        /* added by JADX */
        public static final int ratingBarStyleSmall = 2130837708;
        /* added by JADX */
        public static final int searchHintIcon = 2130837709;
        /* added by JADX */
        public static final int searchIcon = 2130837710;
        /* added by JADX */
        public static final int searchViewStyle = 2130837711;
        /* added by JADX */
        public static final int seekBarStyle = 2130837712;
        /* added by JADX */
        public static final int selectableItemBackground = 2130837713;
        /* added by JADX */
        public static final int selectableItemBackgroundBorderless = 2130837714;
        /* added by JADX */
        public static final int showAsAction = 2130837715;
        /* added by JADX */
        public static final int showDividers = 2130837716;
        /* added by JADX */
        public static final int showText = 2130837717;
        /* added by JADX */
        public static final int showTitle = 2130837718;
        /* added by JADX */
        public static final int singleChoiceItemLayout = 2130837719;
        /* added by JADX */
        public static final int spinBars = 2130837720;
        /* added by JADX */
        public static final int spinnerDropDownItemStyle = 2130837721;
        /* added by JADX */
        public static final int spinnerStyle = 2130837722;
        /* added by JADX */
        public static final int splitTrack = 2130837723;
        /* added by JADX */
        public static final int srcCompat = 2130837724;
        /* added by JADX */
        public static final int state_above_anchor = 2130837725;
        /* added by JADX */
        public static final int statusBarBackground = 2130837726;
        /* added by JADX */
        public static final int subMenuArrow = 2130837727;
        /* added by JADX */
        public static final int submitBackground = 2130837728;
        /* added by JADX */
        public static final int subtitle = 2130837729;
        /* added by JADX */
        public static final int subtitleTextAppearance = 2130837730;
        /* added by JADX */
        public static final int subtitleTextColor = 2130837731;
        /* added by JADX */
        public static final int subtitleTextStyle = 2130837732;
        /* added by JADX */
        public static final int suggestionRowLayout = 2130837733;
        /* added by JADX */
        public static final int switchMinWidth = 2130837734;
        /* added by JADX */
        public static final int switchPadding = 2130837735;
        /* added by JADX */
        public static final int switchStyle = 2130837736;
        /* added by JADX */
        public static final int switchTextAppearance = 2130837737;
        /* added by JADX */
        public static final int textAllCaps = 2130837738;
        /* added by JADX */
        public static final int textAppearanceLargePopupMenu = 2130837739;
        /* added by JADX */
        public static final int textAppearanceListItem = 2130837740;
        /* added by JADX */
        public static final int textAppearanceListItemSecondary = 2130837741;
        /* added by JADX */
        public static final int textAppearanceListItemSmall = 2130837742;
        /* added by JADX */
        public static final int textAppearancePopupMenuHeader = 2130837743;
        /* added by JADX */
        public static final int textAppearanceSearchResultSubtitle = 2130837744;
        /* added by JADX */
        public static final int textAppearanceSearchResultTitle = 2130837745;
        /* added by JADX */
        public static final int textAppearanceSmallPopupMenu = 2130837746;
        /* added by JADX */
        public static final int textColorAlertDialogListItem = 2130837747;
        /* added by JADX */
        public static final int textColorSearchUrl = 2130837748;
        /* added by JADX */
        public static final int textLocale = 2130837749;
        /* added by JADX */
        public static final int theme = 2130837750;
        /* added by JADX */
        public static final int thickness = 2130837751;
        /* added by JADX */
        public static final int thumbTextPadding = 2130837752;
        /* added by JADX */
        public static final int thumbTint = 2130837753;
        /* added by JADX */
        public static final int thumbTintMode = 2130837754;
        /* added by JADX */
        public static final int tickMark = 2130837755;
        /* added by JADX */
        public static final int tickMarkTint = 2130837756;
        /* added by JADX */
        public static final int tickMarkTintMode = 2130837757;
        /* added by JADX */
        public static final int tint = 2130837758;
        /* added by JADX */
        public static final int tintMode = 2130837759;
        /* added by JADX */
        public static final int title = 2130837760;
        /* added by JADX */
        public static final int titleMargin = 2130837761;
        /* added by JADX */
        public static final int titleMarginBottom = 2130837762;
        /* added by JADX */
        public static final int titleMarginEnd = 2130837763;
        /* added by JADX */
        public static final int titleMarginStart = 2130837764;
        /* added by JADX */
        public static final int titleMarginTop = 2130837765;
        /* added by JADX */
        public static final int titleMargins = 2130837766;
        /* added by JADX */
        public static final int titleTextAppearance = 2130837767;
        /* added by JADX */
        public static final int titleTextColor = 2130837768;
        /* added by JADX */
        public static final int titleTextStyle = 2130837769;
        /* added by JADX */
        public static final int toolbarNavigationButtonStyle = 2130837770;
        /* added by JADX */
        public static final int toolbarStyle = 2130837771;
        /* added by JADX */
        public static final int tooltipForegroundColor = 2130837772;
        /* added by JADX */
        public static final int tooltipFrameBackground = 2130837773;
        /* added by JADX */
        public static final int tooltipText = 2130837774;
        /* added by JADX */
        public static final int track = 2130837775;
        /* added by JADX */
        public static final int trackTint = 2130837776;
        /* added by JADX */
        public static final int trackTintMode = 2130837777;
        /* added by JADX */
        public static final int ttcIndex = 2130837778;
        /* added by JADX */
        public static final int viewInflaterClass = 2130837779;
        /* added by JADX */
        public static final int voiceIcon = 2130837780;
        /* added by JADX */
        public static final int windowActionBar = 2130837781;
        /* added by JADX */
        public static final int windowActionBarOverlay = 2130837782;
        /* added by JADX */
        public static final int windowActionModeOverlay = 2130837783;
        /* added by JADX */
        public static final int windowFixedHeightMajor = 2130837784;
        /* added by JADX */
        public static final int windowFixedHeightMinor = 2130837785;
        /* added by JADX */
        public static final int windowFixedWidthMajor = 2130837786;
        /* added by JADX */
        public static final int windowFixedWidthMinor = 2130837787;
        /* added by JADX */
        public static final int windowMinWidthMajor = 2130837788;
        /* added by JADX */
        public static final int windowMinWidthMinor = 2130837789;
        /* added by JADX */
        public static final int windowNoTitle = 2130837790;
    }

    /* added by JADX */
    public static final class bool {
        /* added by JADX */
        public static final int abc_action_bar_embed_tabs = 2130903040;
        /* added by JADX */
        public static final int abc_allow_stacked_button_bar = 2130903041;
        /* added by JADX */
        public static final int abc_config_actionMenuItemAllCaps = 2130903042;
    }

    /* added by JADX */
    public static final class color {
        /* added by JADX */
        public static final int abc_background_cache_hint_selector_material_dark = 2130968576;
        /* added by JADX */
        public static final int abc_background_cache_hint_selector_material_light = 2130968577;
        /* added by JADX */
        public static final int abc_btn_colored_borderless_text_material = 2130968578;
        /* added by JADX */
        public static final int abc_btn_colored_text_material = 2130968579;
        /* added by JADX */
        public static final int abc_color_highlight_material = 2130968580;
        /* added by JADX */
        public static final int abc_hint_foreground_material_dark = 2130968581;
        /* added by JADX */
        public static final int abc_hint_foreground_material_light = 2130968582;
        /* added by JADX */
        public static final int abc_input_method_navigation_guard = 2130968583;
        /* added by JADX */
        public static final int abc_primary_text_disable_only_material_dark = 2130968584;
        /* added by JADX */
        public static final int abc_primary_text_disable_only_material_light = 2130968585;
        /* added by JADX */
        public static final int abc_primary_text_material_dark = 2130968586;
        /* added by JADX */
        public static final int abc_primary_text_material_light = 2130968587;
        /* added by JADX */
        public static final int abc_search_url_text = 2130968588;
        /* added by JADX */
        public static final int abc_search_url_text_normal = 2130968589;
        /* added by JADX */
        public static final int abc_search_url_text_pressed = 2130968590;
        /* added by JADX */
        public static final int abc_search_url_text_selected = 2130968591;
        /* added by JADX */
        public static final int abc_secondary_text_material_dark = 2130968592;
        /* added by JADX */
        public static final int abc_secondary_text_material_light = 2130968593;
        /* added by JADX */
        public static final int abc_tint_btn_checkable = 2130968594;
        /* added by JADX */
        public static final int abc_tint_default = 2130968595;
        /* added by JADX */
        public static final int abc_tint_edittext = 2130968596;
        /* added by JADX */
        public static final int abc_tint_seek_thumb = 2130968597;
        /* added by JADX */
        public static final int abc_tint_spinner = 2130968598;
        /* added by JADX */
        public static final int abc_tint_switch_track = 2130968599;
        /* added by JADX */
        public static final int accent_material_dark = 2130968600;
        /* added by JADX */
        public static final int accent_material_light = 2130968601;
        /* added by JADX */
        public static final int background_floating_material_dark = 2130968602;
        /* added by JADX */
        public static final int background_floating_material_light = 2130968603;
        /* added by JADX */
        public static final int background_material_dark = 2130968604;
        /* added by JADX */
        public static final int background_material_light = 2130968605;
        /* added by JADX */
        public static final int bright_foreground_disabled_material_dark = 2130968606;
        /* added by JADX */
        public static final int bright_foreground_disabled_material_light = 2130968607;
        /* added by JADX */
        public static final int bright_foreground_inverse_material_dark = 2130968608;
        /* added by JADX */
        public static final int bright_foreground_inverse_material_light = 2130968609;
        /* added by JADX */
        public static final int bright_foreground_material_dark = 2130968610;
        /* added by JADX */
        public static final int bright_foreground_material_light = 2130968611;
        /* added by JADX */
        public static final int button_material_dark = 2130968612;
        /* added by JADX */
        public static final int button_material_light = 2130968613;
        /* added by JADX */
        public static final int colorAccent = 2130968614;
        /* added by JADX */
        public static final int colorPrimary = 2130968615;
        /* added by JADX */
        public static final int colorPrimaryDark = 2130968616;
        /* added by JADX */
        public static final int dim_foreground_disabled_material_dark = 2130968617;
        /* added by JADX */
        public static final int dim_foreground_disabled_material_light = 2130968618;
        /* added by JADX */
        public static final int dim_foreground_material_dark = 2130968619;
        /* added by JADX */
        public static final int dim_foreground_material_light = 2130968620;
        /* added by JADX */
        public static final int error_color_material_dark = 2130968621;
        /* added by JADX */
        public static final int error_color_material_light = 2130968622;
        /* added by JADX */
        public static final int foreground_material_dark = 2130968623;
        /* added by JADX */
        public static final int foreground_material_light = 2130968624;
        /* added by JADX */
        public static final int highlighted_text_material_dark = 2130968625;
        /* added by JADX */
        public static final int highlighted_text_material_light = 2130968626;
        /* added by JADX */
        public static final int material_blue_grey_800 = 2130968627;
        /* added by JADX */
        public static final int material_blue_grey_900 = 2130968628;
        /* added by JADX */
        public static final int material_blue_grey_950 = 2130968629;
        /* added by JADX */
        public static final int material_deep_teal_200 = 2130968630;
        /* added by JADX */
        public static final int material_deep_teal_500 = 2130968631;
        /* added by JADX */
        public static final int material_grey_100 = 2130968632;
        /* added by JADX */
        public static final int material_grey_300 = 2130968633;
        /* added by JADX */
        public static final int material_grey_50 = 2130968634;
        /* added by JADX */
        public static final int material_grey_600 = 2130968635;
        /* added by JADX */
        public static final int material_grey_800 = 2130968636;
        /* added by JADX */
        public static final int material_grey_850 = 2130968637;
        /* added by JADX */
        public static final int material_grey_900 = 2130968638;
        /* added by JADX */
        public static final int notification_action_color_filter = 2130968639;
        /* added by JADX */
        public static final int notification_icon_bg_color = 2130968640;
        /* added by JADX */
        public static final int notification_material_background_media_default_color = 2130968641;
        /* added by JADX */
        public static final int primary_dark_material_dark = 2130968642;
        /* added by JADX */
        public static final int primary_dark_material_light = 2130968643;
        /* added by JADX */
        public static final int primary_material_dark = 2130968644;
        /* added by JADX */
        public static final int primary_material_light = 2130968645;
        /* added by JADX */
        public static final int primary_text_default_material_dark = 2130968646;
        /* added by JADX */
        public static final int primary_text_default_material_light = 2130968647;
        /* added by JADX */
        public static final int primary_text_disabled_material_dark = 2130968648;
        /* added by JADX */
        public static final int primary_text_disabled_material_light = 2130968649;
        /* added by JADX */
        public static final int ripple_material_dark = 2130968650;
        /* added by JADX */
        public static final int ripple_material_light = 2130968651;
        /* added by JADX */
        public static final int secondary_text_default_material_dark = 2130968652;
        /* added by JADX */
        public static final int secondary_text_default_material_light = 2130968653;
        /* added by JADX */
        public static final int secondary_text_disabled_material_dark = 2130968654;
        /* added by JADX */
        public static final int secondary_text_disabled_material_light = 2130968655;
        /* added by JADX */
        public static final int switch_thumb_disabled_material_dark = 2130968656;
        /* added by JADX */
        public static final int switch_thumb_disabled_material_light = 2130968657;
        /* added by JADX */
        public static final int switch_thumb_material_dark = 2130968658;
        /* added by JADX */
        public static final int switch_thumb_material_light = 2130968659;
        /* added by JADX */
        public static final int switch_thumb_normal_material_dark = 2130968660;
        /* added by JADX */
        public static final int switch_thumb_normal_material_light = 2130968661;
        /* added by JADX */
        public static final int tooltip_background_dark = 2130968662;
        /* added by JADX */
        public static final int tooltip_background_light = 2130968663;
    }

    /* added by JADX */
    public static final class dimen {
        /* added by JADX */
        public static final int abc_action_bar_content_inset_material = 2131034112;
        /* added by JADX */
        public static final int abc_action_bar_content_inset_with_nav = 2131034113;
        /* added by JADX */
        public static final int abc_action_bar_default_height_material = 2131034114;
        /* added by JADX */
        public static final int abc_action_bar_default_padding_end_material = 2131034115;
        /* added by JADX */
        public static final int abc_action_bar_default_padding_start_material = 2131034116;
        /* added by JADX */
        public static final int abc_action_bar_elevation_material = 2131034117;
        /* added by JADX */
        public static final int abc_action_bar_icon_vertical_padding_material = 2131034118;
        /* added by JADX */
        public static final int abc_action_bar_overflow_padding_end_material = 2131034119;
        /* added by JADX */
        public static final int abc_action_bar_overflow_padding_start_material = 2131034120;
        /* added by JADX */
        public static final int abc_action_bar_stacked_max_height = 2131034121;
        /* added by JADX */
        public static final int abc_action_bar_stacked_tab_max_width = 2131034122;
        /* added by JADX */
        public static final int abc_action_bar_subtitle_bottom_margin_material = 2131034123;
        /* added by JADX */
        public static final int abc_action_bar_subtitle_top_margin_material = 2131034124;
        /* added by JADX */
        public static final int abc_action_button_min_height_material = 2131034125;
        /* added by JADX */
        public static final int abc_action_button_min_width_material = 2131034126;
        /* added by JADX */
        public static final int abc_action_button_min_width_overflow_material = 2131034127;
        /* added by JADX */
        public static final int abc_alert_dialog_button_bar_height = 2131034128;
        /* added by JADX */
        public static final int abc_alert_dialog_button_dimen = 2131034129;
        /* added by JADX */
        public static final int abc_button_inset_horizontal_material = 2131034130;
        /* added by JADX */
        public static final int abc_button_inset_vertical_material = 2131034131;
        /* added by JADX */
        public static final int abc_button_padding_horizontal_material = 2131034132;
        /* added by JADX */
        public static final int abc_button_padding_vertical_material = 2131034133;
        /* added by JADX */
        public static final int abc_cascading_menus_min_smallest_width = 2131034134;
        /* added by JADX */
        public static final int abc_config_prefDialogWidth = 2131034135;
        /* added by JADX */
        public static final int abc_control_corner_material = 2131034136;
        /* added by JADX */
        public static final int abc_control_inset_material = 2131034137;
        /* added by JADX */
        public static final int abc_control_padding_material = 2131034138;
        /* added by JADX */
        public static final int abc_dialog_corner_radius_material = 2131034139;
        /* added by JADX */
        public static final int abc_dialog_fixed_height_major = 2131034140;
        /* added by JADX */
        public static final int abc_dialog_fixed_height_minor = 2131034141;
        /* added by JADX */
        public static final int abc_dialog_fixed_width_major = 2131034142;
        /* added by JADX */
        public static final int abc_dialog_fixed_width_minor = 2131034143;
        /* added by JADX */
        public static final int abc_dialog_list_padding_bottom_no_buttons = 2131034144;
        /* added by JADX */
        public static final int abc_dialog_list_padding_top_no_title = 2131034145;
        /* added by JADX */
        public static final int abc_dialog_min_width_major = 2131034146;
        /* added by JADX */
        public static final int abc_dialog_min_width_minor = 2131034147;
        /* added by JADX */
        public static final int abc_dialog_padding_material = 2131034148;
        /* added by JADX */
        public static final int abc_dialog_padding_top_material = 2131034149;
        /* added by JADX */
        public static final int abc_dialog_title_divider_material = 2131034150;
        /* added by JADX */
        public static final int abc_disabled_alpha_material_dark = 2131034151;
        /* added by JADX */
        public static final int abc_disabled_alpha_material_light = 2131034152;
        /* added by JADX */
        public static final int abc_dropdownitem_icon_width = 2131034153;
        /* added by JADX */
        public static final int abc_dropdownitem_text_padding_left = 2131034154;
        /* added by JADX */
        public static final int abc_dropdownitem_text_padding_right = 2131034155;
        /* added by JADX */
        public static final int abc_edit_text_inset_bottom_material = 2131034156;
        /* added by JADX */
        public static final int abc_edit_text_inset_horizontal_material = 2131034157;
        /* added by JADX */
        public static final int abc_edit_text_inset_top_material = 2131034158;
        /* added by JADX */
        public static final int abc_floating_window_z = 2131034159;
        /* added by JADX */
        public static final int abc_list_item_height_large_material = 2131034160;
        /* added by JADX */
        public static final int abc_list_item_height_material = 2131034161;
        /* added by JADX */
        public static final int abc_list_item_height_small_material = 2131034162;
        /* added by JADX */
        public static final int abc_list_item_padding_horizontal_material = 2131034163;
        /* added by JADX */
        public static final int abc_panel_menu_list_width = 2131034164;
        /* added by JADX */
        public static final int abc_progress_bar_height_material = 2131034165;
        /* added by JADX */
        public static final int abc_search_view_preferred_height = 2131034166;
        /* added by JADX */
        public static final int abc_search_view_preferred_width = 2131034167;
        /* added by JADX */
        public static final int abc_seekbar_track_background_height_material = 2131034168;
        /* added by JADX */
        public static final int abc_seekbar_track_progress_height_material = 2131034169;
        /* added by JADX */
        public static final int abc_select_dialog_padding_start_material = 2131034170;
        /* added by JADX */
        public static final int abc_switch_padding = 2131034171;
        /* added by JADX */
        public static final int abc_text_size_body_1_material = 2131034172;
        /* added by JADX */
        public static final int abc_text_size_body_2_material = 2131034173;
        /* added by JADX */
        public static final int abc_text_size_button_material = 2131034174;
        /* added by JADX */
        public static final int abc_text_size_caption_material = 2131034175;
        /* added by JADX */
        public static final int abc_text_size_display_1_material = 2131034176;
        /* added by JADX */
        public static final int abc_text_size_display_2_material = 2131034177;
        /* added by JADX */
        public static final int abc_text_size_display_3_material = 2131034178;
        /* added by JADX */
        public static final int abc_text_size_display_4_material = 2131034179;
        /* added by JADX */
        public static final int abc_text_size_headline_material = 2131034180;
        /* added by JADX */
        public static final int abc_text_size_large_material = 2131034181;
        /* added by JADX */
        public static final int abc_text_size_medium_material = 2131034182;
        /* added by JADX */
        public static final int abc_text_size_menu_header_material = 2131034183;
        /* added by JADX */
        public static final int abc_text_size_menu_material = 2131034184;
        /* added by JADX */
        public static final int abc_text_size_small_material = 2131034185;
        /* added by JADX */
        public static final int abc_text_size_subhead_material = 2131034186;
        /* added by JADX */
        public static final int abc_text_size_subtitle_material_toolbar = 2131034187;
        /* added by JADX */
        public static final int abc_text_size_title_material = 2131034188;
        /* added by JADX */
        public static final int abc_text_size_title_material_toolbar = 2131034189;
        /* added by JADX */
        public static final int compat_button_inset_horizontal_material = 2131034190;
        /* added by JADX */
        public static final int compat_button_inset_vertical_material = 2131034191;
        /* added by JADX */
        public static final int compat_button_padding_horizontal_material = 2131034192;
        /* added by JADX */
        public static final int compat_button_padding_vertical_material = 2131034193;
        /* added by JADX */
        public static final int compat_control_corner_material = 2131034194;
        /* added by JADX */
        public static final int compat_notification_large_icon_max_height = 2131034195;
        /* added by JADX */
        public static final int compat_notification_large_icon_max_width = 2131034196;
        /* added by JADX */
        public static final int disabled_alpha_material_dark = 2131034197;
        /* added by JADX */
        public static final int disabled_alpha_material_light = 2131034198;
        /* added by JADX */
        public static final int highlight_alpha_material_colored = 2131034199;
        /* added by JADX */
        public static final int highlight_alpha_material_dark = 2131034200;
        /* added by JADX */
        public static final int highlight_alpha_material_light = 2131034201;
        /* added by JADX */
        public static final int hint_alpha_material_dark = 2131034202;
        /* added by JADX */
        public static final int hint_alpha_material_light = 2131034203;
        /* added by JADX */
        public static final int hint_pressed_alpha_material_dark = 2131034204;
        /* added by JADX */
        public static final int hint_pressed_alpha_material_light = 2131034205;
        /* added by JADX */
        public static final int notification_action_icon_size = 2131034206;
        /* added by JADX */
        public static final int notification_action_text_size = 2131034207;
        /* added by JADX */
        public static final int notification_big_circle_margin = 2131034208;
        /* added by JADX */
        public static final int notification_content_margin_start = 2131034209;
        /* added by JADX */
        public static final int notification_large_icon_height = 2131034210;
        /* added by JADX */
        public static final int notification_large_icon_width = 2131034211;
        /* added by JADX */
        public static final int notification_main_column_padding_top = 2131034212;
        /* added by JADX */
        public static final int notification_media_narrow_margin = 2131034213;
        /* added by JADX */
        public static final int notification_right_icon_size = 2131034214;
        /* added by JADX */
        public static final int notification_right_side_padding_top = 2131034215;
        /* added by JADX */
        public static final int notification_small_icon_background_padding = 2131034216;
        /* added by JADX */
        public static final int notification_small_icon_size_as_large = 2131034217;
        /* added by JADX */
        public static final int notification_subtext_size = 2131034218;
        /* added by JADX */
        public static final int notification_top_pad = 2131034219;
        /* added by JADX */
        public static final int notification_top_pad_large_text = 2131034220;
        /* added by JADX */
        public static final int subtitle_corner_radius = 2131034221;
        /* added by JADX */
        public static final int subtitle_outline_width = 2131034222;
        /* added by JADX */
        public static final int subtitle_shadow_offset = 2131034223;
        /* added by JADX */
        public static final int subtitle_shadow_radius = 2131034224;
        /* added by JADX */
        public static final int tooltip_corner_radius = 2131034225;
        /* added by JADX */
        public static final int tooltip_horizontal_padding = 2131034226;
        /* added by JADX */
        public static final int tooltip_margin = 2131034227;
        /* added by JADX */
        public static final int tooltip_precise_anchor_extra_offset = 2131034228;
        /* added by JADX */
        public static final int tooltip_precise_anchor_threshold = 2131034229;
        /* added by JADX */
        public static final int tooltip_vertical_padding = 2131034230;
        /* added by JADX */
        public static final int tooltip_y_offset_non_touch = 2131034231;
        /* added by JADX */
        public static final int tooltip_y_offset_touch = 2131034232;
    }

    /* added by JADX */
    public static final class drawable {
        /* added by JADX */
        public static final int $ic_launcher_foreground__0 = 2131099648;
        /* added by JADX */
        public static final int abc_ab_share_pack_mtrl_alpha = 2131099649;
        /* added by JADX */
        public static final int abc_action_bar_item_background_material = 2131099650;
        /* added by JADX */
        public static final int abc_btn_borderless_material = 2131099651;
        /* added by JADX */
        public static final int abc_btn_check_material = 2131099652;
        /* added by JADX */
        public static final int abc_btn_check_material_anim = 2131099653;
        /* added by JADX */
        public static final int abc_btn_check_to_on_mtrl_000 = 2131099654;
        /* added by JADX */
        public static final int abc_btn_check_to_on_mtrl_015 = 2131099655;
        /* added by JADX */
        public static final int abc_btn_colored_material = 2131099656;
        /* added by JADX */
        public static final int abc_btn_default_mtrl_shape = 2131099657;
        /* added by JADX */
        public static final int abc_btn_radio_material = 2131099658;
        /* added by JADX */
        public static final int abc_btn_radio_material_anim = 2131099659;
        /* added by JADX */
        public static final int abc_btn_radio_to_on_mtrl_000 = 2131099660;
        /* added by JADX */
        public static final int abc_btn_radio_to_on_mtrl_015 = 2131099661;
        /* added by JADX */
        public static final int abc_btn_switch_to_on_mtrl_00001 = 2131099662;
        /* added by JADX */
        public static final int abc_btn_switch_to_on_mtrl_00012 = 2131099663;
        /* added by JADX */
        public static final int abc_cab_background_internal_bg = 2131099664;
        /* added by JADX */
        public static final int abc_cab_background_top_material = 2131099665;
        /* added by JADX */
        public static final int abc_cab_background_top_mtrl_alpha = 2131099666;
        /* added by JADX */
        public static final int abc_control_background_material = 2131099667;
        /* added by JADX */
        public static final int abc_dialog_material_background = 2131099668;
        /* added by JADX */
        public static final int abc_edit_text_material = 2131099669;
        /* added by JADX */
        public static final int abc_ic_ab_back_material = 2131099670;
        /* added by JADX */
        public static final int abc_ic_arrow_drop_right_black_24dp = 2131099671;
        /* added by JADX */
        public static final int abc_ic_clear_material = 2131099672;
        /* added by JADX */
        public static final int abc_ic_commit_search_api_mtrl_alpha = 2131099673;
        /* added by JADX */
        public static final int abc_ic_go_search_api_material = 2131099674;
        /* added by JADX */
        public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131099675;
        /* added by JADX */
        public static final int abc_ic_menu_cut_mtrl_alpha = 2131099676;
        /* added by JADX */
        public static final int abc_ic_menu_overflow_material = 2131099677;
        /* added by JADX */
        public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131099678;
        /* added by JADX */
        public static final int abc_ic_menu_selectall_mtrl_alpha = 2131099679;
        /* added by JADX */
        public static final int abc_ic_menu_share_mtrl_alpha = 2131099680;
        /* added by JADX */
        public static final int abc_ic_search_api_material = 2131099681;
        /* added by JADX */
        public static final int abc_ic_star_black_16dp = 2131099682;
        /* added by JADX */
        public static final int abc_ic_star_black_36dp = 2131099683;
        /* added by JADX */
        public static final int abc_ic_star_black_48dp = 2131099684;
        /* added by JADX */
        public static final int abc_ic_star_half_black_16dp = 2131099685;
        /* added by JADX */
        public static final int abc_ic_star_half_black_36dp = 2131099686;
        /* added by JADX */
        public static final int abc_ic_star_half_black_48dp = 2131099687;
        /* added by JADX */
        public static final int abc_ic_voice_search_api_material = 2131099688;
        /* added by JADX */
        public static final int abc_item_background_holo_dark = 2131099689;
        /* added by JADX */
        public static final int abc_item_background_holo_light = 2131099690;
        /* added by JADX */
        public static final int abc_list_divider_material = 2131099691;
        /* added by JADX */
        public static final int abc_list_divider_mtrl_alpha = 2131099692;
        /* added by JADX */
        public static final int abc_list_focused_holo = 2131099693;
        /* added by JADX */
        public static final int abc_list_longpressed_holo = 2131099694;
        /* added by JADX */
        public static final int abc_list_pressed_holo_dark = 2131099695;
        /* added by JADX */
        public static final int abc_list_pressed_holo_light = 2131099696;
        /* added by JADX */
        public static final int abc_list_selector_background_transition_holo_dark = 2131099697;
        /* added by JADX */
        public static final int abc_list_selector_background_transition_holo_light = 2131099698;
        /* added by JADX */
        public static final int abc_list_selector_disabled_holo_dark = 2131099699;
        /* added by JADX */
        public static final int abc_list_selector_disabled_holo_light = 2131099700;
        /* added by JADX */
        public static final int abc_list_selector_holo_dark = 2131099701;
        /* added by JADX */
        public static final int abc_list_selector_holo_light = 2131099702;
        /* added by JADX */
        public static final int abc_menu_hardkey_panel_mtrl_mult = 2131099703;
        /* added by JADX */
        public static final int abc_popup_background_mtrl_mult = 2131099704;
        /* added by JADX */
        public static final int abc_ratingbar_indicator_material = 2131099705;
        /* added by JADX */
        public static final int abc_ratingbar_material = 2131099706;
        /* added by JADX */
        public static final int abc_ratingbar_small_material = 2131099707;
        /* added by JADX */
        public static final int abc_scrubber_control_off_mtrl_alpha = 2131099708;
        /* added by JADX */
        public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131099709;
        /* added by JADX */
        public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131099710;
        /* added by JADX */
        public static final int abc_scrubber_primary_mtrl_alpha = 2131099711;
        /* added by JADX */
        public static final int abc_scrubber_track_mtrl_alpha = 2131099712;
        /* added by JADX */
        public static final int abc_seekbar_thumb_material = 2131099713;
        /* added by JADX */
        public static final int abc_seekbar_tick_mark_material = 2131099714;
        /* added by JADX */
        public static final int abc_seekbar_track_material = 2131099715;
        /* added by JADX */
        public static final int abc_spinner_mtrl_am_alpha = 2131099716;
        /* added by JADX */
        public static final int abc_spinner_textfield_background_material = 2131099717;
        /* added by JADX */
        public static final int abc_switch_thumb_material = 2131099718;
        /* added by JADX */
        public static final int abc_switch_track_mtrl_alpha = 2131099719;
        /* added by JADX */
        public static final int abc_tab_indicator_material = 2131099720;
        /* added by JADX */
        public static final int abc_tab_indicator_mtrl_alpha = 2131099721;
        /* added by JADX */
        public static final int abc_text_cursor_material = 2131099722;
        /* added by JADX */
        public static final int abc_text_select_handle_left_mtrl_dark = 2131099723;
        /* added by JADX */
        public static final int abc_text_select_handle_left_mtrl_light = 2131099724;
        /* added by JADX */
        public static final int abc_text_select_handle_middle_mtrl_dark = 2131099725;
        /* added by JADX */
        public static final int abc_text_select_handle_middle_mtrl_light = 2131099726;
        /* added by JADX */
        public static final int abc_text_select_handle_right_mtrl_dark = 2131099727;
        /* added by JADX */
        public static final int abc_text_select_handle_right_mtrl_light = 2131099728;
        /* added by JADX */
        public static final int abc_textfield_activated_mtrl_alpha = 2131099729;
        /* added by JADX */
        public static final int abc_textfield_default_mtrl_alpha = 2131099730;
        /* added by JADX */
        public static final int abc_textfield_search_activated_mtrl_alpha = 2131099731;
        /* added by JADX */
        public static final int abc_textfield_search_default_mtrl_alpha = 2131099732;
        /* added by JADX */
        public static final int abc_textfield_search_material = 2131099733;
        /* added by JADX */
        public static final int abc_vector_test = 2131099734;
        /* added by JADX */
        public static final int btn_checkbox_checked_mtrl = 2131099735;
        /* added by JADX */
        public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131099736;
        /* added by JADX */
        public static final int btn_checkbox_unchecked_mtrl = 2131099737;
        /* added by JADX */
        public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131099738;
        /* added by JADX */
        public static final int btn_radio_off_mtrl = 2131099739;
        /* added by JADX */
        public static final int btn_radio_off_to_on_mtrl_animation = 2131099740;
        /* added by JADX */
        public static final int btn_radio_on_mtrl = 2131099741;
        /* added by JADX */
        public static final int btn_radio_on_to_off_mtrl_animation = 2131099742;
        /* added by JADX */
        public static final int ic_launcher_background = 2131099743;
        /* added by JADX */
        public static final int ic_launcher_foreground = 2131099744;
        /* added by JADX */
        public static final int notification_action_background = 2131099745;
        /* added by JADX */
        public static final int notification_bg = 2131099746;
        /* added by JADX */
        public static final int notification_bg_low = 2131099747;
        /* added by JADX */
        public static final int notification_bg_low_normal = 2131099748;
        /* added by JADX */
        public static final int notification_bg_low_pressed = 2131099749;
        /* added by JADX */
        public static final int notification_bg_normal = 2131099750;
        /* added by JADX */
        public static final int notification_bg_normal_pressed = 2131099751;
        /* added by JADX */
        public static final int notification_icon_background = 2131099752;
        /* added by JADX */
        public static final int notification_template_icon_bg = 2131099753;
        /* added by JADX */
        public static final int notification_template_icon_low_bg = 2131099754;
        /* added by JADX */
        public static final int notification_tile_bg = 2131099755;
        /* added by JADX */
        public static final int notify_panel_notification_icon_bg = 2131099756;
        /* added by JADX */
        public static final int right = 2131099757;
        /* added by JADX */
        public static final int the_main_hash = 2131099758;
        /* added by JADX */
        public static final int tooltip_frame_dark = 2131099759;
        /* added by JADX */
        public static final int tooltip_frame_light = 2131099760;
        /* added by JADX */
        public static final int wrong = 2131099761;
    }

    /* added by JADX */
    public static final class id {
        /* added by JADX */
        public static final int ALT = 2131165184;
        /* added by JADX */
        public static final int CTRL = 2131165185;
        /* added by JADX */
        public static final int FUNCTION = 2131165186;
        /* added by JADX */
        public static final int META = 2131165187;
        /* added by JADX */
        public static final int SHIFT = 2131165188;
        /* added by JADX */
        public static final int SYM = 2131165189;
        /* added by JADX */
        public static final int accessibility_action_clickable_span = 2131165190;
        /* added by JADX */
        public static final int accessibility_custom_action_0 = 2131165191;
        /* added by JADX */
        public static final int accessibility_custom_action_1 = 2131165192;
        /* added by JADX */
        public static final int accessibility_custom_action_10 = 2131165193;
        /* added by JADX */
        public static final int accessibility_custom_action_11 = 2131165194;
        /* added by JADX */
        public static final int accessibility_custom_action_12 = 2131165195;
        /* added by JADX */
        public static final int accessibility_custom_action_13 = 2131165196;
        /* added by JADX */
        public static final int accessibility_custom_action_14 = 2131165197;
        /* added by JADX */
        public static final int accessibility_custom_action_15 = 2131165198;
        /* added by JADX */
        public static final int accessibility_custom_action_16 = 2131165199;
        /* added by JADX */
        public static final int accessibility_custom_action_17 = 2131165200;
        /* added by JADX */
        public static final int accessibility_custom_action_18 = 2131165201;
        /* added by JADX */
        public static final int accessibility_custom_action_19 = 2131165202;
        /* added by JADX */
        public static final int accessibility_custom_action_2 = 2131165203;
        /* added by JADX */
        public static final int accessibility_custom_action_20 = 2131165204;
        /* added by JADX */
        public static final int accessibility_custom_action_21 = 2131165205;
        /* added by JADX */
        public static final int accessibility_custom_action_22 = 2131165206;
        /* added by JADX */
        public static final int accessibility_custom_action_23 = 2131165207;
        /* added by JADX */
        public static final int accessibility_custom_action_24 = 2131165208;
        /* added by JADX */
        public static final int accessibility_custom_action_25 = 2131165209;
        /* added by JADX */
        public static final int accessibility_custom_action_26 = 2131165210;
        /* added by JADX */
        public static final int accessibility_custom_action_27 = 2131165211;
        /* added by JADX */
        public static final int accessibility_custom_action_28 = 2131165212;
        /* added by JADX */
        public static final int accessibility_custom_action_29 = 2131165213;
        /* added by JADX */
        public static final int accessibility_custom_action_3 = 2131165214;
        /* added by JADX */
        public static final int accessibility_custom_action_30 = 2131165215;
        /* added by JADX */
        public static final int accessibility_custom_action_31 = 2131165216;
        /* added by JADX */
        public static final int accessibility_custom_action_4 = 2131165217;
        /* added by JADX */
        public static final int accessibility_custom_action_5 = 2131165218;
        /* added by JADX */
        public static final int accessibility_custom_action_6 = 2131165219;
        /* added by JADX */
        public static final int accessibility_custom_action_7 = 2131165220;
        /* added by JADX */
        public static final int accessibility_custom_action_8 = 2131165221;
        /* added by JADX */
        public static final int accessibility_custom_action_9 = 2131165222;
        /* added by JADX */
        public static final int action0 = 2131165223;
        /* added by JADX */
        public static final int action_bar = 2131165224;
        /* added by JADX */
        public static final int action_bar_activity_content = 2131165225;
        /* added by JADX */
        public static final int action_bar_container = 2131165226;
        /* added by JADX */
        public static final int action_bar_root = 2131165227;
        /* added by JADX */
        public static final int action_bar_spinner = 2131165228;
        /* added by JADX */
        public static final int action_bar_subtitle = 2131165229;
        /* added by JADX */
        public static final int action_bar_title = 2131165230;
        /* added by JADX */
        public static final int action_container = 2131165231;
        /* added by JADX */
        public static final int action_context_bar = 2131165232;
        /* added by JADX */
        public static final int action_divider = 2131165233;
        /* added by JADX */
        public static final int action_image = 2131165234;
        /* added by JADX */
        public static final int action_menu_divider = 2131165235;
        /* added by JADX */
        public static final int action_menu_presenter = 2131165236;
        /* added by JADX */
        public static final int action_mode_bar = 2131165237;
        /* added by JADX */
        public static final int action_mode_bar_stub = 2131165238;
        /* added by JADX */
        public static final int action_mode_close_button = 2131165239;
        /* added by JADX */
        public static final int action_text = 2131165240;
        /* added by JADX */
        public static final int actions = 2131165241;
        /* added by JADX */
        public static final int activity_chooser_view_content = 2131165242;
        /* added by JADX */
        public static final int add = 2131165243;
        /* added by JADX */
        public static final int alertTitle = 2131165244;
        /* added by JADX */
        public static final int all = 2131165245;
        /* added by JADX */
        public static final int always = 2131165246;
        /* added by JADX */
        public static final int async = 2131165247;
        /* added by JADX */
        public static final int banner_container = 2131165248;
        /* added by JADX */
        public static final int banner_container2 = 2131165249;
        /* added by JADX */
        public static final int beginning = 2131165250;
        /* added by JADX */
        public static final int blocking = 2131165251;
        /* added by JADX */
        public static final int bottom = 2131165252;
        /* added by JADX */
        public static final int button = 2131165253;
        /* added by JADX */
        public static final int buttonPanel = 2131165254;
        /* added by JADX */
        public static final int cancel_action = 2131165255;
        /* added by JADX */
        public static final int center = 2131165256;
        /* added by JADX */
        public static final int center_horizontal = 2131165257;
        /* added by JADX */
        public static final int center_vertical = 2131165258;
        /* added by JADX */
        public static final int checkbox = 2131165259;
        /* added by JADX */
        public static final int checked = 2131165260;
        /* added by JADX */
        public static final int chronometer = 2131165261;
        /* added by JADX */
        public static final int clip_horizontal = 2131165262;
        /* added by JADX */
        public static final int clip_vertical = 2131165263;
        /* added by JADX */
        public static final int collapseActionView = 2131165264;
        /* added by JADX */
        public static final int content = 2131165265;
        /* added by JADX */
        public static final int contentPanel = 2131165266;
        /* added by JADX */
        public static final int custom = 2131165267;
        /* added by JADX */
        public static final int customPanel = 2131165268;
        /* added by JADX */
        public static final int decor_content_parent = 2131165269;
        /* added by JADX */
        public static final int default_activity_button = 2131165270;
        /* added by JADX */
        public static final int dialog_button = 2131165271;
        /* added by JADX */
        public static final int disableHome = 2131165272;
        /* added by JADX */
        public static final int edit_query = 2131165273;
        /* added by JADX */
        public static final int end = 2131165274;
        /* added by JADX */
        public static final int end_padder = 2131165275;
        /* added by JADX */
        public static final int expand_activities_button = 2131165276;
        /* added by JADX */
        public static final int expanded_menu = 2131165277;
        /* added by JADX */
        public static final int fill = 2131165278;
        /* added by JADX */
        public static final int fill_horizontal = 2131165279;
        /* added by JADX */
        public static final int fill_vertical = 2131165280;
        /* added by JADX */
        public static final int forever = 2131165281;
        /* added by JADX */
        public static final int group_divider = 2131165282;
        /* added by JADX */
        public static final int home = 2131165283;
        /* added by JADX */
        public static final int homeAsUp = 2131165284;
        /* added by JADX */
        public static final int icon = 2131165285;
        /* added by JADX */
        public static final int icon_group = 2131165286;
        /* added by JADX */
        public static final int ifRoom = 2131165287;
        /* added by JADX */
        public static final int image = 2131165288;
        /* added by JADX */
        public static final int imageGreen = 2131165289;
        /* added by JADX */
        public static final int imageRed = 2131165290;
        /* added by JADX */
        public static final int info = 2131165291;
        /* added by JADX */
        public static final int italic = 2131165292;
        /* added by JADX */
        public static final int left = 2131165293;
        /* added by JADX */
        public static final int line1 = 2131165294;
        /* added by JADX */
        public static final int line3 = 2131165295;
        /* added by JADX */
        public static final int listMode = 2131165296;
        /* added by JADX */
        public static final int list_item = 2131165297;
        /* added by JADX */
        public static final int media_actions = 2131165298;
        /* added by JADX */
        public static final int message = 2131165299;
        /* added by JADX */
        public static final int middle = 2131165300;
        /* added by JADX */
        public static final int multiply = 2131165301;
        /* added by JADX */
        public static final int never = 2131165302;
        /* added by JADX */
        public static final int none = 2131165303;
        /* added by JADX */
        public static final int normal = 2131165304;
        /* added by JADX */
        public static final int notification_background = 2131165305;
        /* added by JADX */
        public static final int notification_main_column = 2131165306;
        /* added by JADX */
        public static final int notification_main_column_container = 2131165307;
        /* added by JADX */
        public static final int off = 2131165308;
        /* added by JADX */
        public static final int on = 2131165309;
        /* added by JADX */
        public static final int parentPanel = 2131165310;
        /* added by JADX */
        public static final int progress_circular = 2131165311;
        /* added by JADX */
        public static final int progress_horizontal = 2131165312;
        /* added by JADX */
        public static final int radio = 2131165313;
        /* added by JADX */
        public static final int right = 2131165314;
        /* added by JADX */
        public static final int right_icon = 2131165315;
        /* added by JADX */
        public static final int right_side = 2131165316;
        /* added by JADX */
        public static final int rootStatus = 2131165317;
        /* added by JADX */
        public static final int screen = 2131165318;
        /* added by JADX */
        public static final int scrollIndicatorDown = 2131165319;
        /* added by JADX */
        public static final int scrollIndicatorUp = 2131165320;
        /* added by JADX */
        public static final int scrollView = 2131165321;
        /* added by JADX */
        public static final int search_badge = 2131165322;
        /* added by JADX */
        public static final int search_bar = 2131165323;
        /* added by JADX */
        public static final int search_button = 2131165324;
        /* added by JADX */
        public static final int search_close_btn = 2131165325;
        /* added by JADX */
        public static final int search_edit_frame = 2131165326;
        /* added by JADX */
        public static final int search_go_btn = 2131165327;
        /* added by JADX */
        public static final int search_mag_icon = 2131165328;
        /* added by JADX */
        public static final int search_plate = 2131165329;
        /* added by JADX */
        public static final int search_src_text = 2131165330;
        /* added by JADX */
        public static final int search_voice_btn = 2131165331;
        /* added by JADX */
        public static final int select_dialog_listview = 2131165332;
        /* added by JADX */
        public static final int shortcut = 2131165333;
        /* added by JADX */
        public static final int showCustom = 2131165334;
        /* added by JADX */
        public static final int showHome = 2131165335;
        /* added by JADX */
        public static final int showTitle = 2131165336;
        /* added by JADX */
        public static final int spacer = 2131165337;
        /* added by JADX */
        public static final int split_action_bar = 2131165338;
        /* added by JADX */
        public static final int src_atop = 2131165339;
        /* added by JADX */
        public static final int src_in = 2131165340;
        /* added by JADX */
        public static final int src_over = 2131165341;
        /* added by JADX */
        public static final int start = 2131165342;
        /* added by JADX */
        public static final int status_bar_latest_event_content = 2131165343;
        /* added by JADX */
        public static final int submenuarrow = 2131165344;
        /* added by JADX */
        public static final int submit_area = 2131165345;
        /* added by JADX */
        public static final int tabMode = 2131165346;
        /* added by JADX */
        public static final int tag_accessibility_actions = 2131165347;
        /* added by JADX */
        public static final int tag_accessibility_clickable_spans = 2131165348;
        /* added by JADX */
        public static final int tag_accessibility_heading = 2131165349;
        /* added by JADX */
        public static final int tag_accessibility_pane_title = 2131165350;
        /* added by JADX */
        public static final int tag_screen_reader_focusable = 2131165351;
        /* added by JADX */
        public static final int tag_transition_group = 2131165352;
        /* added by JADX */
        public static final int tag_unhandled_key_event_manager = 2131165353;
        /* added by JADX */
        public static final int tag_unhandled_key_listeners = 2131165354;
        /* added by JADX */
        public static final int text = 2131165355;
        /* added by JADX */
        public static final int text2 = 2131165356;
        /* added by JADX */
        public static final int textSpacerNoButtons = 2131165357;
        /* added by JADX */
        public static final int textSpacerNoTitle = 2131165358;
        /* added by JADX */
        public static final int textView = 2131165359;
        /* added by JADX */
        public static final int textView2 = 2131165360;
        /* added by JADX */
        public static final int time = 2131165361;
        /* added by JADX */
        public static final int title = 2131165362;
        /* added by JADX */
        public static final int titleDividerNoCustom = 2131165363;
        /* added by JADX */
        public static final int title_template = 2131165364;
        /* added by JADX */
        public static final int top = 2131165365;
        /* added by JADX */
        public static final int topPanel = 2131165366;
        /* added by JADX */
        public static final int unchecked = 2131165367;
        /* added by JADX */
        public static final int uniform = 2131165368;
        /* added by JADX */
        public static final int up = 2131165369;
        /* added by JADX */
        public static final int useLogo = 2131165370;
        /* added by JADX */
        public static final int withText = 2131165371;
        /* added by JADX */
        public static final int wrap_content = 2131165372;
    }

    /* added by JADX */
    public static final class integer {
        /* added by JADX */
        public static final int abc_config_activityDefaultDur = 2131230720;
        /* added by JADX */
        public static final int abc_config_activityShortDur = 2131230721;
        /* added by JADX */
        public static final int cancel_button_image_alpha = 2131230722;
        /* added by JADX */
        public static final int config_tooltipAnimTime = 2131230723;
        /* added by JADX */
        public static final int google_play_services_version = 2131230724;
        /* added by JADX */
        public static final int status_bar_notification_info_maxnum = 2131230725;
    }

    /* added by JADX */
    public static final class interpolator {
        /* added by JADX */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131296256;
        /* added by JADX */
        public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131296257;
        /* added by JADX */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131296258;
        /* added by JADX */
        public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131296259;
        /* added by JADX */
        public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131296260;
        /* added by JADX */
        public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131296261;
        /* added by JADX */
        public static final int fast_out_slow_in = 2131296262;
    }

    /* added by JADX */
    public static final class layout {
        /* added by JADX */
        public static final int abc_action_bar_title_item = 2131361792;
        /* added by JADX */
        public static final int abc_action_bar_up_container = 2131361793;
        /* added by JADX */
        public static final int abc_action_menu_item_layout = 2131361794;
        /* added by JADX */
        public static final int abc_action_menu_layout = 2131361795;
        /* added by JADX */
        public static final int abc_action_mode_bar = 2131361796;
        /* added by JADX */
        public static final int abc_action_mode_close_item_material = 2131361797;
        /* added by JADX */
        public static final int abc_activity_chooser_view = 2131361798;
        /* added by JADX */
        public static final int abc_activity_chooser_view_list_item = 2131361799;
        /* added by JADX */
        public static final int abc_alert_dialog_button_bar_material = 2131361800;
        /* added by JADX */
        public static final int abc_alert_dialog_material = 2131361801;
        /* added by JADX */
        public static final int abc_alert_dialog_title_material = 2131361802;
        /* added by JADX */
        public static final int abc_cascading_menu_item_layout = 2131361803;
        /* added by JADX */
        public static final int abc_dialog_title_material = 2131361804;
        /* added by JADX */
        public static final int abc_expanded_menu_layout = 2131361805;
        /* added by JADX */
        public static final int abc_list_menu_item_checkbox = 2131361806;
        /* added by JADX */
        public static final int abc_list_menu_item_icon = 2131361807;
        /* added by JADX */
        public static final int abc_list_menu_item_layout = 2131361808;
        /* added by JADX */
        public static final int abc_list_menu_item_radio = 2131361809;
        /* added by JADX */
        public static final int abc_popup_menu_header_item_layout = 2131361810;
        /* added by JADX */
        public static final int abc_popup_menu_item_layout = 2131361811;
        /* added by JADX */
        public static final int abc_screen_content_include = 2131361812;
        /* added by JADX */
        public static final int abc_screen_simple = 2131361813;
        /* added by JADX */
        public static final int abc_screen_simple_overlay_action_mode = 2131361814;
        /* added by JADX */
        public static final int abc_screen_toolbar = 2131361815;
        /* added by JADX */
        public static final int abc_search_dropdown_item_icons_2line = 2131361816;
        /* added by JADX */
        public static final int abc_search_view = 2131361817;
        /* added by JADX */
        public static final int abc_select_dialog_material = 2131361818;
        /* added by JADX */
        public static final int abc_tooltip = 2131361819;
        /* added by JADX */
        public static final int activity_main = 2131361820;
        /* added by JADX */
        public static final int custom_dialog = 2131361821;
        /* added by JADX */
        public static final int notification_action = 2131361822;
        /* added by JADX */
        public static final int notification_action_tombstone = 2131361823;
        /* added by JADX */
        public static final int notification_media_action = 2131361824;
        /* added by JADX */
        public static final int notification_media_cancel_action = 2131361825;
        /* added by JADX */
        public static final int notification_template_big_media = 2131361826;
        /* added by JADX */
        public static final int notification_template_big_media_custom = 2131361827;
        /* added by JADX */
        public static final int notification_template_big_media_narrow = 2131361828;
        /* added by JADX */
        public static final int notification_template_big_media_narrow_custom = 2131361829;
        /* added by JADX */
        public static final int notification_template_custom_big = 2131361830;
        /* added by JADX */
        public static final int notification_template_icon_group = 2131361831;
        /* added by JADX */
        public static final int notification_template_lines_media = 2131361832;
        /* added by JADX */
        public static final int notification_template_media = 2131361833;
        /* added by JADX */
        public static final int notification_template_media_custom = 2131361834;
        /* added by JADX */
        public static final int notification_template_part_chronometer = 2131361835;
        /* added by JADX */
        public static final int notification_template_part_time = 2131361836;
        /* added by JADX */
        public static final int select_dialog_item_material = 2131361837;
        /* added by JADX */
        public static final int select_dialog_multichoice_material = 2131361838;
        /* added by JADX */
        public static final int select_dialog_singlechoice_material = 2131361839;
        /* added by JADX */
        public static final int support_simple_spinner_dropdown_item = 2131361840;
    }

    /* added by JADX */
    public static final class string {
        /* added by JADX */
        public static final int abc_action_bar_home_description = 2131427328;
        /* added by JADX */
        public static final int abc_action_bar_up_description = 2131427329;
        /* added by JADX */
        public static final int abc_action_menu_overflow_description = 2131427330;
        /* added by JADX */
        public static final int abc_action_mode_done = 2131427331;
        /* added by JADX */
        public static final int abc_activity_chooser_view_see_all = 2131427332;
        /* added by JADX */
        public static final int abc_activitychooserview_choose_application = 2131427333;
        /* added by JADX */
        public static final int abc_capital_off = 2131427334;
        /* added by JADX */
        public static final int abc_capital_on = 2131427335;
        /* added by JADX */
        public static final int abc_menu_alt_shortcut_label = 2131427336;
        /* added by JADX */
        public static final int abc_menu_ctrl_shortcut_label = 2131427337;
        /* added by JADX */
        public static final int abc_menu_delete_shortcut_label = 2131427338;
        /* added by JADX */
        public static final int abc_menu_enter_shortcut_label = 2131427339;
        /* added by JADX */
        public static final int abc_menu_function_shortcut_label = 2131427340;
        /* added by JADX */
        public static final int abc_menu_meta_shortcut_label = 2131427341;
        /* added by JADX */
        public static final int abc_menu_shift_shortcut_label = 2131427342;
        /* added by JADX */
        public static final int abc_menu_space_shortcut_label = 2131427343;
        /* added by JADX */
        public static final int abc_menu_sym_shortcut_label = 2131427344;
        /* added by JADX */
        public static final int abc_prepend_shortcut_label = 2131427345;
        /* added by JADX */
        public static final int abc_search_hint = 2131427346;
        /* added by JADX */
        public static final int abc_searchview_description_clear = 2131427347;
        /* added by JADX */
        public static final int abc_searchview_description_query = 2131427348;
        /* added by JADX */
        public static final int abc_searchview_description_search = 2131427349;
        /* added by JADX */
        public static final int abc_searchview_description_submit = 2131427350;
        /* added by JADX */
        public static final int abc_searchview_description_voice = 2131427351;
        /* added by JADX */
        public static final int abc_shareactionprovider_share_with = 2131427352;
        /* added by JADX */
        public static final int abc_shareactionprovider_share_with_application = 2131427353;
        /* added by JADX */
        public static final int abc_toolbar_collapse_description = 2131427354;
        /* added by JADX */
        public static final int app_name = 2131427355;
        /* added by JADX */
        public static final int common_google_play_services_unknown_issue = 2131427356;
        /* added by JADX */
        public static final int search_menu_title = 2131427357;
        /* added by JADX */
        public static final int status_bar_notification_info_overflow = 2131427358;
    }

    /* added by JADX */
    public static final class style {
        /* added by JADX */
        public static final int AlertDialog_AppCompat = 2131492864;
        /* added by JADX */
        public static final int AlertDialog_AppCompat_Light = 2131492865;
        /* added by JADX */
        public static final int Animation_AppCompat_Dialog = 2131492866;
        /* added by JADX */
        public static final int Animation_AppCompat_DropDownUp = 2131492867;
        /* added by JADX */
        public static final int Animation_AppCompat_Tooltip = 2131492868;
        /* added by JADX */
        public static final int AppTheme = 2131492869;
        /* added by JADX */
        public static final int Base_AlertDialog_AppCompat = 2131492870;
        /* added by JADX */
        public static final int Base_AlertDialog_AppCompat_Light = 2131492871;
        /* added by JADX */
        public static final int Base_Animation_AppCompat_Dialog = 2131492872;
        /* added by JADX */
        public static final int Base_Animation_AppCompat_DropDownUp = 2131492873;
        /* added by JADX */
        public static final int Base_Animation_AppCompat_Tooltip = 2131492874;
        /* added by JADX */
        public static final int Base_DialogWindowTitle_AppCompat = 2131492875;
        /* added by JADX */
        public static final int Base_DialogWindowTitleBackground_AppCompat = 2131492876;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat = 2131492877;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Body1 = 2131492878;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Body2 = 2131492879;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Button = 2131492880;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Caption = 2131492881;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display1 = 2131492882;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display2 = 2131492883;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display3 = 2131492884;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Display4 = 2131492885;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Headline = 2131492886;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Inverse = 2131492887;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Large = 2131492888;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131492889;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131492890;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131492891;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Medium = 2131492892;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131492893;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Menu = 2131492894;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult = 2131492895;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131492896;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131492897;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Small = 2131492898;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131492899;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Subhead = 2131492900;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131492901;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Title = 2131492902;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131492903;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Tooltip = 2131492904;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131492905;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131492906;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131492907;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131492908;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131492909;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131492910;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131492911;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131492912;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131492913;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131492914;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131492915;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131492916;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131492917;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131492918;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131492919;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131492920;
        /* added by JADX */
        public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131492921;
        /* added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131492922;
        /* added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131492923;
        /* added by JADX */
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131492924;
        /* added by JADX */
        public static final int Base_Theme_AppCompat = 2131492925;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_CompactMenu = 2131492926;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Dialog = 2131492927;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_Alert = 2131492928;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131492929;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131492930;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131492931;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Light = 2131492932;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131492933;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog = 2131492934;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131492935;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131492936;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131492937;
        /* added by JADX */
        public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131492938;
        /* added by JADX */
        public static final int Base_ThemeOverlay_AppCompat = 2131492939;
        /* added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131492940;
        /* added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dark = 2131492941;
        /* added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131492942;
        /* added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dialog = 2131492943;
        /* added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131492944;
        /* added by JADX */
        public static final int Base_ThemeOverlay_AppCompat_Light = 2131492945;
        /* added by JADX */
        public static final int Base_V21_Theme_AppCompat = 2131492946;
        /* added by JADX */
        public static final int Base_V21_Theme_AppCompat_Dialog = 2131492947;
        /* added by JADX */
        public static final int Base_V21_Theme_AppCompat_Light = 2131492948;
        /* added by JADX */
        public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131492949;
        /* added by JADX */
        public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131492950;
        /* added by JADX */
        public static final int Base_V22_Theme_AppCompat = 2131492951;
        /* added by JADX */
        public static final int Base_V22_Theme_AppCompat_Light = 2131492952;
        /* added by JADX */
        public static final int Base_V23_Theme_AppCompat = 2131492953;
        /* added by JADX */
        public static final int Base_V23_Theme_AppCompat_Light = 2131492954;
        /* added by JADX */
        public static final int Base_V26_Theme_AppCompat = 2131492955;
        /* added by JADX */
        public static final int Base_V26_Theme_AppCompat_Light = 2131492956;
        /* added by JADX */
        public static final int Base_V26_Widget_AppCompat_Toolbar = 2131492957;
        /* added by JADX */
        public static final int Base_V28_Theme_AppCompat = 2131492958;
        /* added by JADX */
        public static final int Base_V28_Theme_AppCompat_Light = 2131492959;
        /* added by JADX */
        public static final int Base_V7_Theme_AppCompat = 2131492960;
        /* added by JADX */
        public static final int Base_V7_Theme_AppCompat_Dialog = 2131492961;
        /* added by JADX */
        public static final int Base_V7_Theme_AppCompat_Light = 2131492962;
        /* added by JADX */
        public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131492963;
        /* added by JADX */
        public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131492964;
        /* added by JADX */
        public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131492965;
        /* added by JADX */
        public static final int Base_V7_Widget_AppCompat_EditText = 2131492966;
        /* added by JADX */
        public static final int Base_V7_Widget_AppCompat_Toolbar = 2131492967;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar = 2131492968;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131492969;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131492970;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131492971;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131492972;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton = 2131492973;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131492974;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131492975;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActionMode = 2131492976;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ActivityChooserView = 2131492977;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131492978;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Button = 2131492979;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Button_Borderless = 2131492980;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131492981;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131492982;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Button_Colored = 2131492983;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Button_Small = 2131492984;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ButtonBar = 2131492985;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131492986;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131492987;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131492988;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131492989;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131492990;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131492991;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131492992;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_EditText = 2131492993;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ImageButton = 2131492994;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar = 2131492995;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131492996;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131492997;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131492998;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131492999;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131493000;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131493001;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131493002;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ListMenuView = 2131493003;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ListPopupWindow = 2131493004;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ListView = 2131493005;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ListView_DropDown = 2131493006;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ListView_Menu = 2131493007;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_PopupMenu = 2131493008;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131493009;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_PopupWindow = 2131493010;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ProgressBar = 2131493011;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131493012;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar = 2131493013;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131493014;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_RatingBar_Small = 2131493015;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_SearchView = 2131493016;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131493017;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_SeekBar = 2131493018;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2131493019;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Spinner = 2131493020;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131493021;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_TextView = 2131493022;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131493023;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Toolbar = 2131493024;
        /* added by JADX */
        public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131493025;
        /* added by JADX */
        public static final int Platform_AppCompat = 2131493026;
        /* added by JADX */
        public static final int Platform_AppCompat_Light = 2131493027;
        /* added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat = 2131493028;
        /* added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131493029;
        /* added by JADX */
        public static final int Platform_ThemeOverlay_AppCompat_Light = 2131493030;
        /* added by JADX */
        public static final int Platform_V21_AppCompat = 2131493031;
        /* added by JADX */
        public static final int Platform_V21_AppCompat_Light = 2131493032;
        /* added by JADX */
        public static final int Platform_V25_AppCompat = 2131493033;
        /* added by JADX */
        public static final int Platform_V25_AppCompat_Light = 2131493034;
        /* added by JADX */
        public static final int Platform_Widget_AppCompat_Spinner = 2131493035;
        /* added by JADX */
        public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131493036;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131493037;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131493038;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131493039;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131493040;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131493041;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131493042;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131493043;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131493044;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131493045;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131493046;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131493047;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131493048;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131493049;
        /* added by JADX */
        public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131493050;
        /* added by JADX */
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131493051;
        /* added by JADX */
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131493052;
        /* added by JADX */
        public static final int TextAppearance_AppCompat = 2131493053;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Body1 = 2131493054;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Body2 = 2131493055;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Button = 2131493056;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Caption = 2131493057;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Display1 = 2131493058;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Display2 = 2131493059;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Display3 = 2131493060;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Display4 = 2131493061;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Headline = 2131493062;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Inverse = 2131493063;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Large = 2131493064;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Large_Inverse = 2131493065;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131493066;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131493067;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131493068;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131493069;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Medium = 2131493070;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Medium_Inverse = 2131493071;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Menu = 2131493072;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131493073;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_SearchResult_Title = 2131493074;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Small = 2131493075;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Small_Inverse = 2131493076;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Subhead = 2131493077;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131493078;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Title = 2131493079;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Title_Inverse = 2131493080;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Tooltip = 2131493081;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131493082;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131493083;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131493084;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131493085;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131493086;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131493087;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131493088;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131493089;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131493090;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button = 2131493091;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131493092;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2131493093;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131493094;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131493095;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131493096;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131493097;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131493098;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_Switch = 2131493099;
        /* added by JADX */
        public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131493100;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification = 2131493101;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Info = 2131493102;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Info_Media = 2131493103;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Line2 = 2131493104;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Line2_Media = 2131493105;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Media = 2131493106;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Time = 2131493107;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Time_Media = 2131493108;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Title = 2131493109;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Title_Media = 2131493110;
        /* added by JADX */
        public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131493111;
        /* added by JADX */
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131493112;
        /* added by JADX */
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131493113;
        /* added by JADX */
        public static final int Theme_AppCompat = 2131493114;
        /* added by JADX */
        public static final int Theme_AppCompat_CompactMenu = 2131493115;
        /* added by JADX */
        public static final int Theme_AppCompat_DayNight = 2131493116;
        /* added by JADX */
        public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131493117;
        /* added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog = 2131493118;
        /* added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131493119;
        /* added by JADX */
        public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131493120;
        /* added by JADX */
        public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131493121;
        /* added by JADX */
        public static final int Theme_AppCompat_DayNight_NoActionBar = 2131493122;
        /* added by JADX */
        public static final int Theme_AppCompat_Dialog = 2131493123;
        /* added by JADX */
        public static final int Theme_AppCompat_Dialog_Alert = 2131493124;
        /* added by JADX */
        public static final int Theme_AppCompat_Dialog_MinWidth = 2131493125;
        /* added by JADX */
        public static final int Theme_AppCompat_DialogWhenLarge = 2131493126;
        /* added by JADX */
        public static final int Theme_AppCompat_Light = 2131493127;
        /* added by JADX */
        public static final int Theme_AppCompat_Light_DarkActionBar = 2131493128;
        /* added by JADX */
        public static final int Theme_AppCompat_Light_Dialog = 2131493129;
        /* added by JADX */
        public static final int Theme_AppCompat_Light_Dialog_Alert = 2131493130;
        /* added by JADX */
        public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131493131;
        /* added by JADX */
        public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131493132;
        /* added by JADX */
        public static final int Theme_AppCompat_Light_NoActionBar = 2131493133;
        /* added by JADX */
        public static final int Theme_AppCompat_NoActionBar = 2131493134;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat = 2131493135;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_ActionBar = 2131493136;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_Dark = 2131493137;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131493138;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_DayNight = 2131493139;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 2131493140;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_Dialog = 2131493141;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2131493142;
        /* added by JADX */
        public static final int ThemeOverlay_AppCompat_Light = 2131493143;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionBar = 2131493144;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionBar_Solid = 2131493145;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabBar = 2131493146;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabText = 2131493147;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionBar_TabView = 2131493148;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionButton = 2131493149;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionButton_CloseMode = 2131493150;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionButton_Overflow = 2131493151;
        /* added by JADX */
        public static final int Widget_AppCompat_ActionMode = 2131493152;
        /* added by JADX */
        public static final int Widget_AppCompat_ActivityChooserView = 2131493153;
        /* added by JADX */
        public static final int Widget_AppCompat_AutoCompleteTextView = 2131493154;
        /* added by JADX */
        public static final int Widget_AppCompat_Button = 2131493155;
        /* added by JADX */
        public static final int Widget_AppCompat_Button_Borderless = 2131493156;
        /* added by JADX */
        public static final int Widget_AppCompat_Button_Borderless_Colored = 2131493157;
        /* added by JADX */
        public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131493158;
        /* added by JADX */
        public static final int Widget_AppCompat_Button_Colored = 2131493159;
        /* added by JADX */
        public static final int Widget_AppCompat_Button_Small = 2131493160;
        /* added by JADX */
        public static final int Widget_AppCompat_ButtonBar = 2131493161;
        /* added by JADX */
        public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131493162;
        /* added by JADX */
        public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131493163;
        /* added by JADX */
        public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131493164;
        /* added by JADX */
        public static final int Widget_AppCompat_CompoundButton_Switch = 2131493165;
        /* added by JADX */
        public static final int Widget_AppCompat_DrawerArrowToggle = 2131493166;
        /* added by JADX */
        public static final int Widget_AppCompat_DropDownItem_Spinner = 2131493167;
        /* added by JADX */
        public static final int Widget_AppCompat_EditText = 2131493168;
        /* added by JADX */
        public static final int Widget_AppCompat_ImageButton = 2131493169;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar = 2131493170;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131493171;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131493172;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131493173;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131493174;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131493175;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131493176;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131493177;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131493178;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton = 2131493179;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131493180;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131493181;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131493182;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ActivityChooserView = 2131493183;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131493184;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131493185;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ListPopupWindow = 2131493186;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_ListView_DropDown = 2131493187;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_PopupMenu = 2131493188;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131493189;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_SearchView = 2131493190;
        /* added by JADX */
        public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131493191;
        /* added by JADX */
        public static final int Widget_AppCompat_ListMenuView = 2131493192;
        /* added by JADX */
        public static final int Widget_AppCompat_ListPopupWindow = 2131493193;
        /* added by JADX */
        public static final int Widget_AppCompat_ListView = 2131493194;
        /* added by JADX */
        public static final int Widget_AppCompat_ListView_DropDown = 2131493195;
        /* added by JADX */
        public static final int Widget_AppCompat_ListView_Menu = 2131493196;
        /* added by JADX */
        public static final int Widget_AppCompat_PopupMenu = 2131493197;
        /* added by JADX */
        public static final int Widget_AppCompat_PopupMenu_Overflow = 2131493198;
        /* added by JADX */
        public static final int Widget_AppCompat_PopupWindow = 2131493199;
        /* added by JADX */
        public static final int Widget_AppCompat_ProgressBar = 2131493200;
        /* added by JADX */
        public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131493201;
        /* added by JADX */
        public static final int Widget_AppCompat_RatingBar = 2131493202;
        /* added by JADX */
        public static final int Widget_AppCompat_RatingBar_Indicator = 2131493203;
        /* added by JADX */
        public static final int Widget_AppCompat_RatingBar_Small = 2131493204;
        /* added by JADX */
        public static final int Widget_AppCompat_SearchView = 2131493205;
        /* added by JADX */
        public static final int Widget_AppCompat_SearchView_ActionBar = 2131493206;
        /* added by JADX */
        public static final int Widget_AppCompat_SeekBar = 2131493207;
        /* added by JADX */
        public static final int Widget_AppCompat_SeekBar_Discrete = 2131493208;
        /* added by JADX */
        public static final int Widget_AppCompat_Spinner = 2131493209;
        /* added by JADX */
        public static final int Widget_AppCompat_Spinner_DropDown = 2131493210;
        /* added by JADX */
        public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131493211;
        /* added by JADX */
        public static final int Widget_AppCompat_Spinner_Underlined = 2131493212;
        /* added by JADX */
        public static final int Widget_AppCompat_TextView = 2131493213;
        /* added by JADX */
        public static final int Widget_AppCompat_TextView_SpinnerItem = 2131493214;
        /* added by JADX */
        public static final int Widget_AppCompat_Toolbar = 2131493215;
        /* added by JADX */
        public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131493216;
        /* added by JADX */
        public static final int Widget_Compat_NotificationActionContainer = 2131493217;
        /* added by JADX */
        public static final int Widget_Compat_NotificationActionText = 2131493218;
        /* added by JADX */
        public static final int Widget_Support_CoordinatorLayout = 2131493219;
    }

    /* added by JADX */
    public static final class xml {
        /* added by JADX */
        public static final int splits0 = 2131623936;
    }
}
