package android.support.v4.media.session;

import a.a.a.a.a.b;
import a.a.a.a.a.c;
import a.a.a.a.a.d;
import android.os.Build;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.List;

public class MediaControllerCompat$MediaControllerImplApi21 implements d {

    /* renamed from: a  reason: collision with root package name */
    public final Object f26a;

    /* renamed from: b  reason: collision with root package name */
    public final List<c> f27b;

    /* renamed from: c  reason: collision with root package name */
    public HashMap<c, a> f28c;
    public final MediaSessionCompat.Token d;

    private static class ExtraBinderRequestResultReceiver extends ResultReceiver {

        /* renamed from: a  reason: collision with root package name */
        public WeakReference<MediaControllerCompat$MediaControllerImplApi21> f29a;

        public void onReceiveResult(int i, Bundle bundle) {
            MediaControllerCompat$MediaControllerImplApi21 mediaControllerCompat$MediaControllerImplApi21 = (MediaControllerCompat$MediaControllerImplApi21) this.f29a.get();
            if (mediaControllerCompat$MediaControllerImplApi21 != null && bundle != null) {
                synchronized (mediaControllerCompat$MediaControllerImplApi21.f26a) {
                    MediaSessionCompat.Token token = mediaControllerCompat$MediaControllerImplApi21.d;
                    int i2 = Build.VERSION.SDK_INT;
                    token.a(b.a.a(bundle.getBinder("android.support.v4.media.session.EXTRA_BINDER")));
                    mediaControllerCompat$MediaControllerImplApi21.d.a(bundle.getBundle("android.support.v4.media.session.SESSION_TOKEN2_BUNDLE"));
                    mediaControllerCompat$MediaControllerImplApi21.a();
                }
            }
        }
    }

    private static class a extends c.b {
        public a(c cVar) {
            super(cVar);
        }

        public void a() {
            throw new AssertionError();
        }

        public void a(Bundle bundle) {
            throw new AssertionError();
        }

        public void a(MediaMetadataCompat mediaMetadataCompat) {
            throw new AssertionError();
        }

        public void a(ParcelableVolumeInfo parcelableVolumeInfo) {
            throw new AssertionError();
        }

        public void a(CharSequence charSequence) {
            throw new AssertionError();
        }

        public void a(List<MediaSessionCompat.QueueItem> list) {
            throw new AssertionError();
        }
    }

    public void a() {
        if (this.d.a() != null) {
            for (c next : this.f27b) {
                a aVar = new a(next);
                this.f28c.put(next, aVar);
                next.f1a = aVar;
                try {
                    ((b.a.C0001a) this.d.a()).a(aVar);
                    next.a(13, (Object) null, (Bundle) null);
                } catch (RemoteException e) {
                    Log.e("MediaControllerCompat", "Dead object in registerCallback.", e);
                }
            }
            this.f27b.clear();
        }
    }
}
