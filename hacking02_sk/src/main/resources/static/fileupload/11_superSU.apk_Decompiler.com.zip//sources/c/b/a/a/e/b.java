package c.b.a.a.e;

import android.content.Context;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public static b f900a = new b();

    /* renamed from: b  reason: collision with root package name */
    public a f901b = null;

    public static a b(Context context) {
        return f900a.a(context);
    }

    public final synchronized a a(Context context) {
        if (this.f901b == null) {
            if (context.getApplicationContext() != null) {
                context = context.getApplicationContext();
            }
            this.f901b = new a(context);
        }
        return this.f901b;
    }
}
