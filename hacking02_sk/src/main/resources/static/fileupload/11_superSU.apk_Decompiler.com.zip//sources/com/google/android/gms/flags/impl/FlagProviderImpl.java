package com.google.android.gms.flags.impl;

import a.a.a.a.c;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.util.Log;
import c.b.a.a.d.a.a;
import c.b.a.a.d.a.b;
import c.b.a.a.d.a.e;
import c.b.a.a.e.d;
import com.google.android.gms.common.util.DynamiteApi;

@DynamiteApi
public class FlagProviderImpl extends d {

    /* renamed from: a  reason: collision with root package name */
    public boolean f926a = false;

    /* renamed from: b  reason: collision with root package name */
    public SharedPreferences f927b;

    public boolean getBooleanFlagValue(String str, boolean z, int i) {
        Boolean bool;
        if (!this.f926a) {
            return z;
        }
        SharedPreferences sharedPreferences = this.f927b;
        Boolean valueOf = Boolean.valueOf(z);
        try {
            bool = (Boolean) c.a(new a(sharedPreferences, str, valueOf));
        } catch (Exception e) {
            String valueOf2 = String.valueOf(e.getMessage());
            Log.w("FlagDataUtils", valueOf2.length() != 0 ? "Flag value not available, returning default: ".concat(valueOf2) : new String("Flag value not available, returning default: "));
            bool = valueOf;
        }
        return bool.booleanValue();
    }

    public int getIntFlagValue(String str, int i, int i2) {
        Integer num;
        if (!this.f926a) {
            return i;
        }
        SharedPreferences sharedPreferences = this.f927b;
        Integer valueOf = Integer.valueOf(i);
        try {
            num = (Integer) c.a(new b(sharedPreferences, str, valueOf));
        } catch (Exception e) {
            String valueOf2 = String.valueOf(e.getMessage());
            Log.w("FlagDataUtils", valueOf2.length() != 0 ? "Flag value not available, returning default: ".concat(valueOf2) : new String("Flag value not available, returning default: "));
            num = valueOf;
        }
        return num.intValue();
    }

    public long getLongFlagValue(String str, long j, int i) {
        Long l;
        if (!this.f926a) {
            return j;
        }
        SharedPreferences sharedPreferences = this.f927b;
        Long valueOf = Long.valueOf(j);
        try {
            l = (Long) c.a(new c.b.a.a.d.a.c(sharedPreferences, str, valueOf));
        } catch (Exception e) {
            String valueOf2 = String.valueOf(e.getMessage());
            Log.w("FlagDataUtils", valueOf2.length() != 0 ? "Flag value not available, returning default: ".concat(valueOf2) : new String("Flag value not available, returning default: "));
            l = valueOf;
        }
        return l.longValue();
    }

    public String getStringFlagValue(String str, String str2, int i) {
        if (!this.f926a) {
            return str2;
        }
        try {
            return (String) c.a(new c.b.a.a.d.a.d(this.f927b, str, str2));
        } catch (Exception e) {
            String valueOf = String.valueOf(e.getMessage());
            Log.w("FlagDataUtils", valueOf.length() != 0 ? "Flag value not available, returning default: ".concat(valueOf) : new String("Flag value not available, returning default: "));
            return str2;
        }
    }

    public void init(c.b.a.a.c.a aVar) {
        Context context = (Context) c.b.a.a.c.c.a(aVar);
        if (!this.f926a) {
            try {
                this.f927b = e.a(context.createPackageContext("com.google.android.gms", 0));
                this.f926a = true;
            } catch (PackageManager.NameNotFoundException unused) {
            } catch (Exception e) {
                String valueOf = String.valueOf(e.getMessage());
                Log.w("FlagProviderImpl", valueOf.length() != 0 ? "Could not retrieve sdk flags, continuing with defaults: ".concat(valueOf) : new String("Could not retrieve sdk flags, continuing with defaults: "));
            }
        }
    }
}
