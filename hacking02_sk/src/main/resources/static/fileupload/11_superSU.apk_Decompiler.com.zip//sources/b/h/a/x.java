package b.h.a;

import b.j.r;
import b.j.s;

class x implements s {
    public <T extends r> T a(Class<T> cls) {
        return new y(true);
    }
}
