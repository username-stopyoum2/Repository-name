package b.h.a;

import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import b.e.h.s;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@SuppressLint({"UnknownNullness"})
public abstract class P {
    public static boolean a(List list) {
        return list == null || list.isEmpty();
    }

    public static boolean a(List<View> list, View view, int i) {
        for (int i2 = 0; i2 < i; i2++) {
            if (list.get(i2) == view) {
                return true;
            }
        }
        return false;
    }

    public abstract Object a(Object obj, Object obj2, Object obj3);

    public void a(View view, Rect rect) {
        int[] iArr = new int[2];
        view.getLocationOnScreen(iArr);
        rect.set(iArr[0], iArr[1], view.getWidth() + iArr[0], view.getHeight() + iArr[1]);
    }

    public abstract void a(ViewGroup viewGroup, Object obj);

    public abstract void a(Object obj, Rect rect);

    public abstract void a(Object obj, View view);

    public abstract void a(Object obj, View view, ArrayList<View> arrayList);

    public abstract void a(Object obj, Object obj2, ArrayList<View> arrayList, Object obj3, ArrayList<View> arrayList2, Object obj4, ArrayList<View> arrayList3);

    public abstract void a(Object obj, ArrayList<View> arrayList);

    public abstract void a(Object obj, ArrayList<View> arrayList, ArrayList<View> arrayList2);

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v1, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v2, resolved type: android.view.ViewGroup} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v3, resolved type: android.view.ViewGroup} */
    /* JADX WARNING: Failed to insert additional move for type inference */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void a(java.util.ArrayList<android.view.View> r4, android.view.View r5) {
        /*
            r3 = this;
            int r0 = r5.getVisibility()
            if (r0 != 0) goto L_0x004e
            boolean r0 = r5 instanceof android.view.ViewGroup
            if (r0 == 0) goto L_0x004b
            android.view.ViewGroup r5 = (android.view.ViewGroup) r5
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 21
            r2 = 0
            if (r0 < r1) goto L_0x0018
            boolean r0 = r5.isTransitionGroup()
            goto L_0x0038
        L_0x0018:
            int r0 = b.e.b.tag_transition_group
            java.lang.Object r0 = r5.getTag(r0)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            if (r0 == 0) goto L_0x0028
            boolean r0 = r0.booleanValue()
            if (r0 != 0) goto L_0x0037
        L_0x0028:
            android.graphics.drawable.Drawable r0 = r5.getBackground()
            if (r0 != 0) goto L_0x0037
            java.lang.String r0 = b.e.h.s.g(r5)
            if (r0 == 0) goto L_0x0035
            goto L_0x0037
        L_0x0035:
            r0 = 0
            goto L_0x0038
        L_0x0037:
            r0 = 1
        L_0x0038:
            if (r0 == 0) goto L_0x003b
            goto L_0x004b
        L_0x003b:
            int r0 = r5.getChildCount()
        L_0x003f:
            if (r2 >= r0) goto L_0x004e
            android.view.View r1 = r5.getChildAt(r2)
            r3.a((java.util.ArrayList<android.view.View>) r4, (android.view.View) r1)
            int r2 = r2 + 1
            goto L_0x003f
        L_0x004b:
            r4.add(r5)
        L_0x004e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.h.a.P.a(java.util.ArrayList, android.view.View):void");
    }

    public void a(Map<String, View> map, View view) {
        if (view.getVisibility() == 0) {
            String g = s.g(view);
            if (g != null) {
                map.put(g, view);
            }
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                int childCount = viewGroup.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    a(map, viewGroup.getChildAt(i));
                }
            }
        }
    }

    public abstract boolean a(Object obj);

    public abstract Object b(Object obj);

    public abstract Object b(Object obj, Object obj2, Object obj3);

    public abstract void b(Object obj, View view);

    public abstract void b(Object obj, View view, ArrayList<View> arrayList);

    public abstract void b(Object obj, ArrayList<View> arrayList, ArrayList<View> arrayList2);
}
