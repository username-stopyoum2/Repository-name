package b.h.a;

import android.os.Bundle;

class t extends C0080k {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ u f769b;

    public t(u uVar) {
        this.f769b = uVar;
    }

    public C0076g a(ClassLoader classLoader, String str) {
        C0081l lVar = this.f769b.t;
        return lVar.a(lVar.f753b, str, (Bundle) null);
    }
}
