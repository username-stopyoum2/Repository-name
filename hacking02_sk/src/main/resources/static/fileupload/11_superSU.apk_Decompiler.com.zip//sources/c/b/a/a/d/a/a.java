package c.b.a.a.d.a;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

public final class a implements Callable<Boolean> {

    /* renamed from: a  reason: collision with root package name */
    public /* synthetic */ SharedPreferences f885a;

    /* renamed from: b  reason: collision with root package name */
    public /* synthetic */ String f886b;

    /* renamed from: c  reason: collision with root package name */
    public /* synthetic */ Boolean f887c;

    public a(SharedPreferences sharedPreferences, String str, Boolean bool) {
        this.f885a = sharedPreferences;
        this.f886b = str;
        this.f887c = bool;
    }

    public final /* synthetic */ Object call() {
        return Boolean.valueOf(this.f885a.getBoolean(this.f886b, this.f887c.booleanValue()));
    }
}
