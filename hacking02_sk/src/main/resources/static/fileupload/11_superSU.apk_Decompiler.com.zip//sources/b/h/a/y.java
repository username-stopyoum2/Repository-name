package b.h.a;

import android.util.Log;
import b.j.r;
import b.j.s;
import b.j.t;
import b.j.u;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class y extends r {

    /* renamed from: b  reason: collision with root package name */
    public static final s f785b = new x();

    /* renamed from: c  reason: collision with root package name */
    public final HashSet<C0076g> f786c = new HashSet<>();
    public final HashMap<String, y> d = new HashMap<>();
    public final HashMap<String, u> e = new HashMap<>();
    public final boolean f;
    public boolean g = false;
    public boolean h = false;

    public y(boolean z) {
        this.f = z;
    }

    public static y a(u uVar) {
        s sVar = f785b;
        Class cls = y.class;
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            String str = "androidx.lifecycle.ViewModelProvider.DefaultKey:" + canonicalName;
            r rVar = uVar.f811a.get(str);
            if (!cls.isInstance(rVar)) {
                rVar = sVar instanceof t ? ((t) sVar).a(str, cls) : sVar.a(cls);
                r put = uVar.f811a.put(str, rVar);
                if (put != null) {
                    put.b();
                }
            }
            return (y) rVar;
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    public boolean a(C0076g gVar) {
        return this.f786c.add(gVar);
    }

    public void b() {
        if (u.f770c) {
            Log.d("FragmentManager", "onCleared called for " + this);
        }
        this.g = true;
    }

    public void b(C0076g gVar) {
        if (u.f770c) {
            Log.d("FragmentManager", "Clearing non-config state for " + gVar);
        }
        y yVar = this.d.get(gVar.f);
        if (yVar != null) {
            yVar.b();
            this.d.remove(gVar.f);
        }
        u uVar = this.e.get(gVar.f);
        if (uVar != null) {
            uVar.a();
            this.e.remove(gVar.f);
        }
    }

    public y c(C0076g gVar) {
        y yVar = this.d.get(gVar.f);
        if (yVar != null) {
            return yVar;
        }
        y yVar2 = new y(this.f);
        this.d.put(gVar.f, yVar2);
        return yVar2;
    }

    public Collection<C0076g> c() {
        return this.f786c;
    }

    public u d(C0076g gVar) {
        u uVar = this.e.get(gVar.f);
        if (uVar != null) {
            return uVar;
        }
        u uVar2 = new u();
        this.e.put(gVar.f, uVar2);
        return uVar2;
    }

    public boolean d() {
        return this.g;
    }

    public boolean e(C0076g gVar) {
        return this.f786c.remove(gVar);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || y.class != obj.getClass()) {
            return false;
        }
        y yVar = (y) obj;
        return this.f786c.equals(yVar.f786c) && this.d.equals(yVar.d) && this.e.equals(yVar.e);
    }

    public boolean f(C0076g gVar) {
        if (!this.f786c.contains(gVar)) {
            return true;
        }
        return this.f ? this.g : !this.h;
    }

    public int hashCode() {
        int hashCode = this.d.hashCode();
        return this.e.hashCode() + ((hashCode + (this.f786c.hashCode() * 31)) * 31);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("FragmentManagerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} Fragments (");
        Iterator<C0076g> it = this.f786c.iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") Child Non Config (");
        Iterator<String> it2 = this.d.keySet().iterator();
        while (it2.hasNext()) {
            sb.append(it2.next());
            if (it2.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") ViewModelStores (");
        Iterator<String> it3 = this.e.keySet().iterator();
        while (it3.hasNext()) {
            sb.append(it3.next());
            if (it3.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }
}
