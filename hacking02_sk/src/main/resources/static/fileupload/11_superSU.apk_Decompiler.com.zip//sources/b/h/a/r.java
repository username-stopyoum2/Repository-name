package b.h.a;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;

public class r extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ViewGroup f763a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ View f764b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ C0076g f765c;
    public final /* synthetic */ u d;

    public r(u uVar, ViewGroup viewGroup, View view, C0076g gVar) {
        this.d = uVar;
        this.f763a = viewGroup;
        this.f764b = view;
        this.f765c = gVar;
    }

    public void onAnimationEnd(Animator animator) {
        this.f763a.endViewTransition(this.f764b);
        Animator h = this.f765c.h();
        this.f765c.a((Animator) null);
        if (h != null && this.f763a.indexOfChild(this.f764b) < 0) {
            u uVar = this.d;
            C0076g gVar = this.f765c;
            uVar.a(gVar, gVar.r(), 0, 0, false);
        }
    }
}
