package c.b.a.a.e;

import android.os.IBinder;

public final class k extends f implements i {
    public k(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
    }
}
