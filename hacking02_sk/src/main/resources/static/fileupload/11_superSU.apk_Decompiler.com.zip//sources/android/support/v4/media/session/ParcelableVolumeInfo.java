package android.support.v4.media.session;

import android.os.Parcel;
import android.os.Parcelable;

public class ParcelableVolumeInfo implements Parcelable {
    public static final Parcelable.Creator<ParcelableVolumeInfo> CREATOR = new k();

    /* renamed from: a  reason: collision with root package name */
    public int f35a;

    /* renamed from: b  reason: collision with root package name */
    public int f36b;

    /* renamed from: c  reason: collision with root package name */
    public int f37c;
    public int d;
    public int e;

    public ParcelableVolumeInfo(Parcel parcel) {
        this.f35a = parcel.readInt();
        this.f37c = parcel.readInt();
        this.d = parcel.readInt();
        this.e = parcel.readInt();
        this.f36b = parcel.readInt();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f35a);
        parcel.writeInt(this.f37c);
        parcel.writeInt(this.d);
        parcel.writeInt(this.e);
        parcel.writeInt(this.f36b);
    }
}
