package b.h.a;

import android.view.View;
import java.util.ArrayList;

public final class D implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Object f708a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ P f709b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ View f710c;
    public final /* synthetic */ C0076g d;
    public final /* synthetic */ ArrayList e;
    public final /* synthetic */ ArrayList f;
    public final /* synthetic */ ArrayList g;
    public final /* synthetic */ Object h;

    public D(Object obj, P p, View view, C0076g gVar, ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3, Object obj2) {
        this.f708a = obj;
        this.f709b = p;
        this.f710c = view;
        this.d = gVar;
        this.e = arrayList;
        this.f = arrayList2;
        this.g = arrayList3;
        this.h = obj2;
    }

    public void run() {
        Object obj = this.f708a;
        if (obj != null) {
            this.f709b.a(obj, this.f710c);
            this.f.addAll(G.a(this.f709b, this.f708a, this.d, (ArrayList<View>) this.e, this.f710c));
        }
        if (this.g != null) {
            if (this.h != null) {
                ArrayList arrayList = new ArrayList();
                arrayList.add(this.f710c);
                this.f709b.a(this.h, (ArrayList<View>) this.g, (ArrayList<View>) arrayList);
            }
            this.g.clear();
            this.g.add(this.f710c);
        }
    }
}
