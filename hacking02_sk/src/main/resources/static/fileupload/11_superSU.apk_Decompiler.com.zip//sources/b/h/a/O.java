package b.h.a;

import android.view.View;
import b.e.h.s;
import java.util.ArrayList;
import java.util.Map;

public class O implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ArrayList f735a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Map f736b;

    public O(P p, ArrayList arrayList, Map map) {
        this.f735a = arrayList;
        this.f736b = map;
    }

    public void run() {
        int size = this.f735a.size();
        for (int i = 0; i < size; i++) {
            View view = (View) this.f735a.get(i);
            s.a(view, (String) this.f736b.get(s.g(view)));
        }
    }
}
